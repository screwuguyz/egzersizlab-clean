(function(){const v=document.createElement("link").relList;if(v&&v.supports&&v.supports("modulepreload"))return;for(const w of document.querySelectorAll('link[rel="modulepreload"]'))d(w);new MutationObserver(w=>{for(const A of w)if(A.type==="childList")for(const S of A.addedNodes)S.tagName==="LINK"&&S.rel==="modulepreload"&&d(S)}).observe(document,{childList:!0,subtree:!0});function E(w){const A={};return w.integrity&&(A.integrity=w.integrity),w.referrerPolicy&&(A.referrerPolicy=w.referrerPolicy),w.crossOrigin==="use-credentials"?A.credentials="include":w.crossOrigin==="anonymous"?A.credentials="omit":A.credentials="same-origin",A}function d(w){if(w.ep)return;w.ep=!0;const A=E(w);fetch(w.href,A)}})();function mx(r){return r&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r}var Do={exports:{}},Pi={};/**
 * @license React
 * react-jsx-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Kf;function A0(){if(Kf)return Pi;Kf=1;var r=Symbol.for("react.transitional.element"),v=Symbol.for("react.fragment");function E(d,w,A){var S=null;if(A!==void 0&&(S=""+A),w.key!==void 0&&(S=""+w.key),"key"in w){A={};for(var B in w)B!=="key"&&(A[B]=w[B])}else A=w;return w=A.ref,{$$typeof:r,type:d,key:S,ref:w!==void 0?w:null,props:A}}return Pi.Fragment=v,Pi.jsx=E,Pi.jsxs=E,Pi}var qf;function O0(){return qf||(qf=1,Do.exports=A0()),Do.exports}var l=O0(),Mo={exports:{}},he={};/**
 * @license React
 * react.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Vf;function C0(){if(Vf)return he;Vf=1;var r=Symbol.for("react.transitional.element"),v=Symbol.for("react.portal"),E=Symbol.for("react.fragment"),d=Symbol.for("react.strict_mode"),w=Symbol.for("react.profiler"),A=Symbol.for("react.consumer"),S=Symbol.for("react.context"),B=Symbol.for("react.forward_ref"),b=Symbol.for("react.suspense"),p=Symbol.for("react.memo"),U=Symbol.for("react.lazy"),N=Symbol.for("react.activity"),G=Symbol.iterator;function L(f){return f===null||typeof f!="object"?null:(f=G&&f[G]||f["@@iterator"],typeof f=="function"?f:null)}var Z={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},ie=Object.assign,J={};function H(f,D,I){this.props=f,this.context=D,this.refs=J,this.updater=I||Z}H.prototype.isReactComponent={},H.prototype.setState=function(f,D){if(typeof f!="object"&&typeof f!="function"&&f!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,f,D,"setState")},H.prototype.forceUpdate=function(f){this.updater.enqueueForceUpdate(this,f,"forceUpdate")};function K(){}K.prototype=H.prototype;function ue(f,D,I){this.props=f,this.context=D,this.refs=J,this.updater=I||Z}var $=ue.prototype=new K;$.constructor=ue,ie($,H.prototype),$.isPureReactComponent=!0;var Ye=Array.isArray;function de(){}var Q={H:null,A:null,T:null,S:null},Y=Object.prototype.hasOwnProperty;function ne(f,D,I){var V=I.ref;return{$$typeof:r,type:f,key:D,ref:V!==void 0?V:null,props:I}}function re(f,D){return ne(f.type,D,f.props)}function Oe(f){return typeof f=="object"&&f!==null&&f.$$typeof===r}function ce(f){var D={"=":"=0",":":"=2"};return"$"+f.replace(/[=:]/g,function(I){return D[I]})}var at=/\/+/g;function ye(f,D){return typeof f=="object"&&f!==null&&f.key!=null?ce(""+f.key):D.toString(36)}function Me(f){switch(f.status){case"fulfilled":return f.value;case"rejected":throw f.reason;default:switch(typeof f.status=="string"?f.then(de,de):(f.status="pending",f.then(function(D){f.status==="pending"&&(f.status="fulfilled",f.value=D)},function(D){f.status==="pending"&&(f.status="rejected",f.reason=D)})),f.status){case"fulfilled":return f.value;case"rejected":throw f.reason}}throw f}function _(f,D,I,V,oe){var me=typeof f;(me==="undefined"||me==="boolean")&&(f=null);var O=!1;if(f===null)O=!0;else switch(me){case"bigint":case"string":case"number":O=!0;break;case"object":switch(f.$$typeof){case r:case v:O=!0;break;case U:return O=f._init,_(O(f._payload),D,I,V,oe)}}if(O)return oe=oe(f),O=V===""?"."+ye(f,0):V,Ye(oe)?(I="",O!=null&&(I=O.replace(at,"$&/")+"/"),_(oe,D,I,"",function(ke){return ke})):oe!=null&&(Oe(oe)&&(oe=re(oe,I+(oe.key==null||f&&f.key===oe.key?"":(""+oe.key).replace(at,"$&/")+"/")+O)),D.push(oe)),1;O=0;var ee=V===""?".":V+":";if(Ye(f))for(var P=0;P<f.length;P++)V=f[P],me=ee+ye(V,P),O+=_(V,D,I,me,oe);else if(P=L(f),typeof P=="function")for(f=P.call(f),P=0;!(V=f.next()).done;)V=V.value,me=ee+ye(V,P++),O+=_(V,D,I,me,oe);else if(me==="object"){if(typeof f.then=="function")return _(Me(f),D,I,V,oe);throw D=String(f),Error("Objects are not valid as a React child (found: "+(D==="[object Object]"?"object with keys {"+Object.keys(f).join(", ")+"}":D)+"). If you meant to render a collection of children, use an array instead.")}return O}function y(f,D,I){if(f==null)return f;var V=[],oe=0;return _(f,V,"","",function(me){return D.call(I,me,oe++)}),V}function te(f){if(f._status===-1){var D=f._result;D=D(),D.then(function(I){(f._status===0||f._status===-1)&&(f._status=1,f._result=I)},function(I){(f._status===0||f._status===-1)&&(f._status=2,f._result=I)}),f._status===-1&&(f._status=0,f._result=D)}if(f._status===1)return f._result.default;throw f._result}var ge=typeof reportError=="function"?reportError:function(f){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var D=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof f=="object"&&f!==null&&typeof f.message=="string"?String(f.message):String(f),error:f});if(!window.dispatchEvent(D))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",f);return}console.error(f)},fe={map:y,forEach:function(f,D,I){y(f,function(){D.apply(this,arguments)},I)},count:function(f){var D=0;return y(f,function(){D++}),D},toArray:function(f){return y(f,function(D){return D})||[]},only:function(f){if(!Oe(f))throw Error("React.Children.only expected to receive a single React element child.");return f}};return he.Activity=N,he.Children=fe,he.Component=H,he.Fragment=E,he.Profiler=w,he.PureComponent=ue,he.StrictMode=d,he.Suspense=b,he.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=Q,he.__COMPILER_RUNTIME={__proto__:null,c:function(f){return Q.H.useMemoCache(f)}},he.cache=function(f){return function(){return f.apply(null,arguments)}},he.cacheSignal=function(){return null},he.cloneElement=function(f,D,I){if(f==null)throw Error("The argument must be a React element, but you passed "+f+".");var V=ie({},f.props),oe=f.key;if(D!=null)for(me in D.key!==void 0&&(oe=""+D.key),D)!Y.call(D,me)||me==="key"||me==="__self"||me==="__source"||me==="ref"&&D.ref===void 0||(V[me]=D[me]);var me=arguments.length-2;if(me===1)V.children=I;else if(1<me){for(var O=Array(me),ee=0;ee<me;ee++)O[ee]=arguments[ee+2];V.children=O}return ne(f.type,oe,V)},he.createContext=function(f){return f={$$typeof:S,_currentValue:f,_currentValue2:f,_threadCount:0,Provider:null,Consumer:null},f.Provider=f,f.Consumer={$$typeof:A,_context:f},f},he.createElement=function(f,D,I){var V,oe={},me=null;if(D!=null)for(V in D.key!==void 0&&(me=""+D.key),D)Y.call(D,V)&&V!=="key"&&V!=="__self"&&V!=="__source"&&(oe[V]=D[V]);var O=arguments.length-2;if(O===1)oe.children=I;else if(1<O){for(var ee=Array(O),P=0;P<O;P++)ee[P]=arguments[P+2];oe.children=ee}if(f&&f.defaultProps)for(V in O=f.defaultProps,O)oe[V]===void 0&&(oe[V]=O[V]);return ne(f,me,oe)},he.createRef=function(){return{current:null}},he.forwardRef=function(f){return{$$typeof:B,render:f}},he.isValidElement=Oe,he.lazy=function(f){return{$$typeof:U,_payload:{_status:-1,_result:f},_init:te}},he.memo=function(f,D){return{$$typeof:p,type:f,compare:D===void 0?null:D}},he.startTransition=function(f){var D=Q.T,I={};Q.T=I;try{var V=f(),oe=Q.S;oe!==null&&oe(I,V),typeof V=="object"&&V!==null&&typeof V.then=="function"&&V.then(de,ge)}catch(me){ge(me)}finally{D!==null&&I.types!==null&&(D.types=I.types),Q.T=D}},he.unstable_useCacheRefresh=function(){return Q.H.useCacheRefresh()},he.use=function(f){return Q.H.use(f)},he.useActionState=function(f,D,I){return Q.H.useActionState(f,D,I)},he.useCallback=function(f,D){return Q.H.useCallback(f,D)},he.useContext=function(f){return Q.H.useContext(f)},he.useDebugValue=function(){},he.useDeferredValue=function(f,D){return Q.H.useDeferredValue(f,D)},he.useEffect=function(f,D){return Q.H.useEffect(f,D)},he.useEffectEvent=function(f){return Q.H.useEffectEvent(f)},he.useId=function(){return Q.H.useId()},he.useImperativeHandle=function(f,D,I){return Q.H.useImperativeHandle(f,D,I)},he.useInsertionEffect=function(f,D){return Q.H.useInsertionEffect(f,D)},he.useLayoutEffect=function(f,D){return Q.H.useLayoutEffect(f,D)},he.useMemo=function(f,D){return Q.H.useMemo(f,D)},he.useOptimistic=function(f,D){return Q.H.useOptimistic(f,D)},he.useReducer=function(f,D,I){return Q.H.useReducer(f,D,I)},he.useRef=function(f){return Q.H.useRef(f)},he.useState=function(f){return Q.H.useState(f)},he.useSyncExternalStore=function(f,D,I){return Q.H.useSyncExternalStore(f,D,I)},he.useTransition=function(){return Q.H.useTransition()},he.version="19.2.0",he}var Xf;function qo(){return Xf||(Xf=1,Mo.exports=C0()),Mo.exports}var g=qo();const Vo=mx(g);var Ro={exports:{}},Wi={},Uo={exports:{}},Bo={};/**
 * @license React
 * scheduler.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Qf;function D0(){return Qf||(Qf=1,(function(r){function v(_,y){var te=_.length;_.push(y);e:for(;0<te;){var ge=te-1>>>1,fe=_[ge];if(0<w(fe,y))_[ge]=y,_[te]=fe,te=ge;else break e}}function E(_){return _.length===0?null:_[0]}function d(_){if(_.length===0)return null;var y=_[0],te=_.pop();if(te!==y){_[0]=te;e:for(var ge=0,fe=_.length,f=fe>>>1;ge<f;){var D=2*(ge+1)-1,I=_[D],V=D+1,oe=_[V];if(0>w(I,te))V<fe&&0>w(oe,I)?(_[ge]=oe,_[V]=te,ge=V):(_[ge]=I,_[D]=te,ge=D);else if(V<fe&&0>w(oe,te))_[ge]=oe,_[V]=te,ge=V;else break e}}return y}function w(_,y){var te=_.sortIndex-y.sortIndex;return te!==0?te:_.id-y.id}if(r.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var A=performance;r.unstable_now=function(){return A.now()}}else{var S=Date,B=S.now();r.unstable_now=function(){return S.now()-B}}var b=[],p=[],U=1,N=null,G=3,L=!1,Z=!1,ie=!1,J=!1,H=typeof setTimeout=="function"?setTimeout:null,K=typeof clearTimeout=="function"?clearTimeout:null,ue=typeof setImmediate<"u"?setImmediate:null;function $(_){for(var y=E(p);y!==null;){if(y.callback===null)d(p);else if(y.startTime<=_)d(p),y.sortIndex=y.expirationTime,v(b,y);else break;y=E(p)}}function Ye(_){if(ie=!1,$(_),!Z)if(E(b)!==null)Z=!0,de||(de=!0,ce());else{var y=E(p);y!==null&&Me(Ye,y.startTime-_)}}var de=!1,Q=-1,Y=5,ne=-1;function re(){return J?!0:!(r.unstable_now()-ne<Y)}function Oe(){if(J=!1,de){var _=r.unstable_now();ne=_;var y=!0;try{e:{Z=!1,ie&&(ie=!1,K(Q),Q=-1),L=!0;var te=G;try{t:{for($(_),N=E(b);N!==null&&!(N.expirationTime>_&&re());){var ge=N.callback;if(typeof ge=="function"){N.callback=null,G=N.priorityLevel;var fe=ge(N.expirationTime<=_);if(_=r.unstable_now(),typeof fe=="function"){N.callback=fe,$(_),y=!0;break t}N===E(b)&&d(b),$(_)}else d(b);N=E(b)}if(N!==null)y=!0;else{var f=E(p);f!==null&&Me(Ye,f.startTime-_),y=!1}}break e}finally{N=null,G=te,L=!1}y=void 0}}finally{y?ce():de=!1}}}var ce;if(typeof ue=="function")ce=function(){ue(Oe)};else if(typeof MessageChannel<"u"){var at=new MessageChannel,ye=at.port2;at.port1.onmessage=Oe,ce=function(){ye.postMessage(null)}}else ce=function(){H(Oe,0)};function Me(_,y){Q=H(function(){_(r.unstable_now())},y)}r.unstable_IdlePriority=5,r.unstable_ImmediatePriority=1,r.unstable_LowPriority=4,r.unstable_NormalPriority=3,r.unstable_Profiling=null,r.unstable_UserBlockingPriority=2,r.unstable_cancelCallback=function(_){_.callback=null},r.unstable_forceFrameRate=function(_){0>_||125<_?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):Y=0<_?Math.floor(1e3/_):5},r.unstable_getCurrentPriorityLevel=function(){return G},r.unstable_next=function(_){switch(G){case 1:case 2:case 3:var y=3;break;default:y=G}var te=G;G=y;try{return _()}finally{G=te}},r.unstable_requestPaint=function(){J=!0},r.unstable_runWithPriority=function(_,y){switch(_){case 1:case 2:case 3:case 4:case 5:break;default:_=3}var te=G;G=_;try{return y()}finally{G=te}},r.unstable_scheduleCallback=function(_,y,te){var ge=r.unstable_now();switch(typeof te=="object"&&te!==null?(te=te.delay,te=typeof te=="number"&&0<te?ge+te:ge):te=ge,_){case 1:var fe=-1;break;case 2:fe=250;break;case 5:fe=1073741823;break;case 4:fe=1e4;break;default:fe=5e3}return fe=te+fe,_={id:U++,callback:y,priorityLevel:_,startTime:te,expirationTime:fe,sortIndex:-1},te>ge?(_.sortIndex=te,v(p,_),E(b)===null&&_===E(p)&&(ie?(K(Q),Q=-1):ie=!0,Me(Ye,te-ge))):(_.sortIndex=fe,v(b,_),Z||L||(Z=!0,de||(de=!0,ce()))),_},r.unstable_shouldYield=re,r.unstable_wrapCallback=function(_){var y=G;return function(){var te=G;G=y;try{return _.apply(this,arguments)}finally{G=te}}}})(Bo)),Bo}var Zf;function M0(){return Zf||(Zf=1,Uo.exports=D0()),Uo.exports}var Lo={exports:{}},xt={};/**
 * @license React
 * react-dom.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Jf;function R0(){if(Jf)return xt;Jf=1;var r=qo();function v(b){var p="https://react.dev/errors/"+b;if(1<arguments.length){p+="?args[]="+encodeURIComponent(arguments[1]);for(var U=2;U<arguments.length;U++)p+="&args[]="+encodeURIComponent(arguments[U])}return"Minified React error #"+b+"; visit "+p+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function E(){}var d={d:{f:E,r:function(){throw Error(v(522))},D:E,C:E,L:E,m:E,X:E,S:E,M:E},p:0,findDOMNode:null},w=Symbol.for("react.portal");function A(b,p,U){var N=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:w,key:N==null?null:""+N,children:b,containerInfo:p,implementation:U}}var S=r.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function B(b,p){if(b==="font")return"";if(typeof p=="string")return p==="use-credentials"?p:""}return xt.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=d,xt.createPortal=function(b,p){var U=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!p||p.nodeType!==1&&p.nodeType!==9&&p.nodeType!==11)throw Error(v(299));return A(b,p,null,U)},xt.flushSync=function(b){var p=S.T,U=d.p;try{if(S.T=null,d.p=2,b)return b()}finally{S.T=p,d.p=U,d.d.f()}},xt.preconnect=function(b,p){typeof b=="string"&&(p?(p=p.crossOrigin,p=typeof p=="string"?p==="use-credentials"?p:"":void 0):p=null,d.d.C(b,p))},xt.prefetchDNS=function(b){typeof b=="string"&&d.d.D(b)},xt.preinit=function(b,p){if(typeof b=="string"&&p&&typeof p.as=="string"){var U=p.as,N=B(U,p.crossOrigin),G=typeof p.integrity=="string"?p.integrity:void 0,L=typeof p.fetchPriority=="string"?p.fetchPriority:void 0;U==="style"?d.d.S(b,typeof p.precedence=="string"?p.precedence:void 0,{crossOrigin:N,integrity:G,fetchPriority:L}):U==="script"&&d.d.X(b,{crossOrigin:N,integrity:G,fetchPriority:L,nonce:typeof p.nonce=="string"?p.nonce:void 0})}},xt.preinitModule=function(b,p){if(typeof b=="string")if(typeof p=="object"&&p!==null){if(p.as==null||p.as==="script"){var U=B(p.as,p.crossOrigin);d.d.M(b,{crossOrigin:U,integrity:typeof p.integrity=="string"?p.integrity:void 0,nonce:typeof p.nonce=="string"?p.nonce:void 0})}}else p==null&&d.d.M(b)},xt.preload=function(b,p){if(typeof b=="string"&&typeof p=="object"&&p!==null&&typeof p.as=="string"){var U=p.as,N=B(U,p.crossOrigin);d.d.L(b,U,{crossOrigin:N,integrity:typeof p.integrity=="string"?p.integrity:void 0,nonce:typeof p.nonce=="string"?p.nonce:void 0,type:typeof p.type=="string"?p.type:void 0,fetchPriority:typeof p.fetchPriority=="string"?p.fetchPriority:void 0,referrerPolicy:typeof p.referrerPolicy=="string"?p.referrerPolicy:void 0,imageSrcSet:typeof p.imageSrcSet=="string"?p.imageSrcSet:void 0,imageSizes:typeof p.imageSizes=="string"?p.imageSizes:void 0,media:typeof p.media=="string"?p.media:void 0})}},xt.preloadModule=function(b,p){if(typeof b=="string")if(p){var U=B(p.as,p.crossOrigin);d.d.m(b,{as:typeof p.as=="string"&&p.as!=="script"?p.as:void 0,crossOrigin:U,integrity:typeof p.integrity=="string"?p.integrity:void 0})}else d.d.m(b)},xt.requestFormReset=function(b){d.d.r(b)},xt.unstable_batchedUpdates=function(b,p){return b(p)},xt.useFormState=function(b,p,U){return S.H.useFormState(b,p,U)},xt.useFormStatus=function(){return S.H.useHostTransitionStatus()},xt.version="19.2.0",xt}var Ff;function U0(){if(Ff)return Lo.exports;Ff=1;function r(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r)}catch(v){console.error(v)}}return r(),Lo.exports=R0(),Lo.exports}/**
 * @license React
 * react-dom-client.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Pf;function B0(){if(Pf)return Wi;Pf=1;var r=M0(),v=qo(),E=U0();function d(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var a=2;a<arguments.length;a++)t+="&args[]="+encodeURIComponent(arguments[a])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function w(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function A(e){var t=e,a=e;if(e.alternate)for(;t.return;)t=t.return;else{e=t;do t=e,(t.flags&4098)!==0&&(a=t.return),e=t.return;while(e)}return t.tag===3?a:null}function S(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function B(e){if(e.tag===31){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function b(e){if(A(e)!==e)throw Error(d(188))}function p(e){var t=e.alternate;if(!t){if(t=A(e),t===null)throw Error(d(188));return t!==e?null:e}for(var a=e,i=t;;){var n=a.return;if(n===null)break;var s=n.alternate;if(s===null){if(i=n.return,i!==null){a=i;continue}break}if(n.child===s.child){for(s=n.child;s;){if(s===a)return b(n),e;if(s===i)return b(n),t;s=s.sibling}throw Error(d(188))}if(a.return!==i.return)a=n,i=s;else{for(var o=!1,c=n.child;c;){if(c===a){o=!0,a=n,i=s;break}if(c===i){o=!0,i=n,a=s;break}c=c.sibling}if(!o){for(c=s.child;c;){if(c===a){o=!0,a=s,i=n;break}if(c===i){o=!0,i=s,a=n;break}c=c.sibling}if(!o)throw Error(d(189))}}if(a.alternate!==i)throw Error(d(190))}if(a.tag!==3)throw Error(d(188));return a.stateNode.current===a?e:t}function U(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e;for(e=e.child;e!==null;){if(t=U(e),t!==null)return t;e=e.sibling}return null}var N=Object.assign,G=Symbol.for("react.element"),L=Symbol.for("react.transitional.element"),Z=Symbol.for("react.portal"),ie=Symbol.for("react.fragment"),J=Symbol.for("react.strict_mode"),H=Symbol.for("react.profiler"),K=Symbol.for("react.consumer"),ue=Symbol.for("react.context"),$=Symbol.for("react.forward_ref"),Ye=Symbol.for("react.suspense"),de=Symbol.for("react.suspense_list"),Q=Symbol.for("react.memo"),Y=Symbol.for("react.lazy"),ne=Symbol.for("react.activity"),re=Symbol.for("react.memo_cache_sentinel"),Oe=Symbol.iterator;function ce(e){return e===null||typeof e!="object"?null:(e=Oe&&e[Oe]||e["@@iterator"],typeof e=="function"?e:null)}var at=Symbol.for("react.client.reference");function ye(e){if(e==null)return null;if(typeof e=="function")return e.$$typeof===at?null:e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case ie:return"Fragment";case H:return"Profiler";case J:return"StrictMode";case Ye:return"Suspense";case de:return"SuspenseList";case ne:return"Activity"}if(typeof e=="object")switch(e.$$typeof){case Z:return"Portal";case ue:return e.displayName||"Context";case K:return(e._context.displayName||"Context")+".Consumer";case $:var t=e.render;return e=e.displayName,e||(e=t.displayName||t.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case Q:return t=e.displayName||null,t!==null?t:ye(e.type)||"Memo";case Y:t=e._payload,e=e._init;try{return ye(e(t))}catch{}}return null}var Me=Array.isArray,_=v.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,y=E.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,te={pending:!1,data:null,method:null,action:null},ge=[],fe=-1;function f(e){return{current:e}}function D(e){0>fe||(e.current=ge[fe],ge[fe]=null,fe--)}function I(e,t){fe++,ge[fe]=e.current,e.current=t}var V=f(null),oe=f(null),me=f(null),O=f(null);function ee(e,t){switch(I(me,t),I(oe,e),I(V,null),t.nodeType){case 9:case 11:e=(e=t.documentElement)&&(e=e.namespaceURI)?ff(e):0;break;default:if(e=t.tagName,t=t.namespaceURI)t=ff(t),e=mf(t,e);else switch(e){case"svg":e=1;break;case"math":e=2;break;default:e=0}}D(V),I(V,e)}function P(){D(V),D(oe),D(me)}function ke(e){e.memoizedState!==null&&I(O,e);var t=V.current,a=mf(t,e.type);t!==a&&(I(oe,e),I(V,a))}function Qe(e){oe.current===e&&(D(V),D(oe)),O.current===e&&(D(O),Qi._currentValue=te)}var ft,Za;function bt(e){if(ft===void 0)try{throw Error()}catch(a){var t=a.stack.trim().match(/\n( *(at )?)/);ft=t&&t[1]||"",Za=-1<a.stack.indexOf(`
    at`)?" (<anonymous>)":-1<a.stack.indexOf("@")?"@unknown:0:0":""}return`
`+ft+e+Za}var va=!1;function ka(e,t){if(!e||va)return"";va=!0;var a=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var i={DetermineComponentFrameRoot:function(){try{if(t){var R=function(){throw Error()};if(Object.defineProperty(R.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(R,[])}catch(T){var z=T}Reflect.construct(e,[],R)}else{try{R.call()}catch(T){z=T}e.call(R.prototype)}}else{try{throw Error()}catch(T){z=T}(R=e())&&typeof R.catch=="function"&&R.catch(function(){})}}catch(T){if(T&&z&&typeof T.stack=="string")return[T.stack,z.stack]}return[null,null]}};i.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var n=Object.getOwnPropertyDescriptor(i.DetermineComponentFrameRoot,"name");n&&n.configurable&&Object.defineProperty(i.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var s=i.DetermineComponentFrameRoot(),o=s[0],c=s[1];if(o&&c){var u=o.split(`
`),j=c.split(`
`);for(n=i=0;i<u.length&&!u[i].includes("DetermineComponentFrameRoot");)i++;for(;n<j.length&&!j[n].includes("DetermineComponentFrameRoot");)n++;if(i===u.length||n===j.length)for(i=u.length-1,n=j.length-1;1<=i&&0<=n&&u[i]!==j[n];)n--;for(;1<=i&&0<=n;i--,n--)if(u[i]!==j[n]){if(i!==1||n!==1)do if(i--,n--,0>n||u[i]!==j[n]){var C=`
`+u[i].replace(" at new "," at ");return e.displayName&&C.includes("<anonymous>")&&(C=C.replace("<anonymous>",e.displayName)),C}while(1<=i&&0<=n);break}}}finally{va=!1,Error.prepareStackTrace=a}return(a=e?e.displayName||e.name:"")?bt(a):""}function ni(e,t){switch(e.tag){case 26:case 27:case 5:return bt(e.type);case 16:return bt("Lazy");case 13:return e.child!==t&&t!==null?bt("Suspense Fallback"):bt("Suspense");case 19:return bt("SuspenseList");case 0:case 15:return ka(e.type,!1);case 11:return ka(e.type.render,!1);case 1:return ka(e.type,!0);case 31:return bt("Activity");default:return""}}function yt(e){try{var t="",a=null;do t+=ni(e,a),a=e,e=e.return;while(e);return t}catch(i){return`
Error generating stack: `+i.message+`
`+i.stack}}var ja=Object.prototype.hasOwnProperty,Xt=r.unstable_scheduleCallback,st=r.unstable_cancelCallback,X=r.unstable_shouldYield,ae=r.unstable_requestPaint,xe=r.unstable_now,Ce=r.unstable_getCurrentPriorityLevel,Pe=r.unstable_ImmediatePriority,Ft=r.unstable_UserBlockingPriority,Et=r.unstable_NormalPriority,Na=r.unstable_LowPriority,si=r.unstable_IdlePriority,tn=r.log,gs=r.unstable_setDisableYieldValue,Ja=null,ht=null;function Rt(e){if(typeof tn=="function"&&gs(e),ht&&typeof ht.setStrictMode=="function")try{ht.setStrictMode(Ja,e)}catch{}}var mt=Math.clz32?Math.clz32:gl,bs=Math.log,ys=Math.LN2;function gl(e){return e>>>=0,e===0?32:31-(bs(e)/ys|0)|0}var Fa=256,Pa=262144,x=4194304;function q(e){var t=e&42;if(t!==0)return t;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&261888;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function pe(e,t,a){var i=e.pendingLanes;if(i===0)return 0;var n=0,s=e.suspendedLanes,o=e.pingedLanes;e=e.warmLanes;var c=i&134217727;return c!==0?(i=c&~s,i!==0?n=q(i):(o&=c,o!==0?n=q(o):a||(a=c&~e,a!==0&&(n=q(a))))):(c=i&~s,c!==0?n=q(c):o!==0?n=q(o):a||(a=i&~e,a!==0&&(n=q(a)))),n===0?0:t!==0&&t!==n&&(t&s)===0&&(s=n&-n,a=t&-t,s>=a||s===32&&(a&4194048)!==0)?t:n}function Te(e,t){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&t)===0}function Ee(e,t){switch(e){case 1:case 2:case 4:case 8:case 64:return t+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function vs(){var e=x;return x<<=1,(x&62914560)===0&&(x=4194304),e}function ri(e){for(var t=[],a=0;31>a;a++)t.push(e);return t}function Wa(e,t){e.pendingLanes|=t,t!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function bx(e,t,a,i,n,s){var o=e.pendingLanes;e.pendingLanes=a,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=a,e.entangledLanes&=a,e.errorRecoveryDisabledLanes&=a,e.shellSuspendCounter=0;var c=e.entanglements,u=e.expirationTimes,j=e.hiddenUpdates;for(a=o&~a;0<a;){var C=31-mt(a),R=1<<C;c[C]=0,u[C]=-1;var z=j[C];if(z!==null)for(j[C]=null,C=0;C<z.length;C++){var T=z[C];T!==null&&(T.lane&=-536870913)}a&=~R}i!==0&&Qo(e,i,0),s!==0&&n===0&&e.tag!==0&&(e.suspendedLanes|=s&~(o&~t))}function Qo(e,t,a){e.pendingLanes|=t,e.suspendedLanes&=~t;var i=31-mt(t);e.entangledLanes|=t,e.entanglements[i]=e.entanglements[i]|1073741824|a&261930}function Zo(e,t){var a=e.entangledLanes|=t;for(e=e.entanglements;a;){var i=31-mt(a),n=1<<i;n&t|e[i]&t&&(e[i]|=t),a&=~n}}function Jo(e,t){var a=t&-t;return a=(a&42)!==0?1:ks(a),(a&(e.suspendedLanes|t))!==0?0:a}function ks(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function js(e){return e&=-e,2<e?8<e?(e&134217727)!==0?32:268435456:8:2}function Fo(){var e=y.p;return e!==0?e:(e=window.event,e===void 0?32:Uf(e.type))}function Po(e,t){var a=y.p;try{return y.p=e,t()}finally{y.p=a}}var za=Math.random().toString(36).slice(2),rt="__reactFiber$"+za,vt="__reactProps$"+za,bl="__reactContainer$"+za,Ns="__reactEvents$"+za,yx="__reactListeners$"+za,vx="__reactHandles$"+za,Wo="__reactResources$"+za,oi="__reactMarker$"+za;function zs(e){delete e[rt],delete e[vt],delete e[Ns],delete e[yx],delete e[vx]}function yl(e){var t=e[rt];if(t)return t;for(var a=e.parentNode;a;){if(t=a[bl]||a[rt]){if(a=t.alternate,t.child!==null||a!==null&&a.child!==null)for(e=vf(e);e!==null;){if(a=e[rt])return a;e=vf(e)}return t}e=a,a=e.parentNode}return null}function vl(e){if(e=e[rt]||e[bl]){var t=e.tag;if(t===5||t===6||t===13||t===31||t===26||t===27||t===3)return e}return null}function ci(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e.stateNode;throw Error(d(33))}function kl(e){var t=e[Wo];return t||(t=e[Wo]={hoistableStyles:new Map,hoistableScripts:new Map}),t}function it(e){e[oi]=!0}var $o=new Set,ec={};function $a(e,t){jl(e,t),jl(e+"Capture",t)}function jl(e,t){for(ec[e]=t,e=0;e<t.length;e++)$o.add(t[e])}var kx=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),tc={},ac={};function jx(e){return ja.call(ac,e)?!0:ja.call(tc,e)?!1:kx.test(e)?ac[e]=!0:(tc[e]=!0,!1)}function an(e,t,a){if(jx(t))if(a===null)e.removeAttribute(t);else{switch(typeof a){case"undefined":case"function":case"symbol":e.removeAttribute(t);return;case"boolean":var i=t.toLowerCase().slice(0,5);if(i!=="data-"&&i!=="aria-"){e.removeAttribute(t);return}}e.setAttribute(t,""+a)}}function ln(e,t,a){if(a===null)e.removeAttribute(t);else{switch(typeof a){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(t);return}e.setAttribute(t,""+a)}}function aa(e,t,a,i){if(i===null)e.removeAttribute(a);else{switch(typeof i){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(a);return}e.setAttributeNS(t,a,""+i)}}function Ut(e){switch(typeof e){case"bigint":case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function lc(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(t==="checkbox"||t==="radio")}function Nx(e,t,a){var i=Object.getOwnPropertyDescriptor(e.constructor.prototype,t);if(!e.hasOwnProperty(t)&&typeof i<"u"&&typeof i.get=="function"&&typeof i.set=="function"){var n=i.get,s=i.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return n.call(this)},set:function(o){a=""+o,s.call(this,o)}}),Object.defineProperty(e,t,{enumerable:i.enumerable}),{getValue:function(){return a},setValue:function(o){a=""+o},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function ws(e){if(!e._valueTracker){var t=lc(e)?"checked":"value";e._valueTracker=Nx(e,t,""+e[t])}}function ic(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var a=t.getValue(),i="";return e&&(i=lc(e)?e.checked?"true":"false":e.value),e=i,e!==a?(t.setValue(e),!0):!1}function nn(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}var zx=/[\n"\\]/g;function Bt(e){return e.replace(zx,function(t){return"\\"+t.charCodeAt(0).toString(16)+" "})}function Ss(e,t,a,i,n,s,o,c){e.name="",o!=null&&typeof o!="function"&&typeof o!="symbol"&&typeof o!="boolean"?e.type=o:e.removeAttribute("type"),t!=null?o==="number"?(t===0&&e.value===""||e.value!=t)&&(e.value=""+Ut(t)):e.value!==""+Ut(t)&&(e.value=""+Ut(t)):o!=="submit"&&o!=="reset"||e.removeAttribute("value"),t!=null?Es(e,o,Ut(t)):a!=null?Es(e,o,Ut(a)):i!=null&&e.removeAttribute("value"),n==null&&s!=null&&(e.defaultChecked=!!s),n!=null&&(e.checked=n&&typeof n!="function"&&typeof n!="symbol"),c!=null&&typeof c!="function"&&typeof c!="symbol"&&typeof c!="boolean"?e.name=""+Ut(c):e.removeAttribute("name")}function nc(e,t,a,i,n,s,o,c){if(s!=null&&typeof s!="function"&&typeof s!="symbol"&&typeof s!="boolean"&&(e.type=s),t!=null||a!=null){if(!(s!=="submit"&&s!=="reset"||t!=null)){ws(e);return}a=a!=null?""+Ut(a):"",t=t!=null?""+Ut(t):a,c||t===e.value||(e.value=t),e.defaultValue=t}i=i??n,i=typeof i!="function"&&typeof i!="symbol"&&!!i,e.checked=c?e.checked:!!i,e.defaultChecked=!!i,o!=null&&typeof o!="function"&&typeof o!="symbol"&&typeof o!="boolean"&&(e.name=o),ws(e)}function Es(e,t,a){t==="number"&&nn(e.ownerDocument)===e||e.defaultValue===""+a||(e.defaultValue=""+a)}function Nl(e,t,a,i){if(e=e.options,t){t={};for(var n=0;n<a.length;n++)t["$"+a[n]]=!0;for(a=0;a<e.length;a++)n=t.hasOwnProperty("$"+e[a].value),e[a].selected!==n&&(e[a].selected=n),n&&i&&(e[a].defaultSelected=!0)}else{for(a=""+Ut(a),t=null,n=0;n<e.length;n++){if(e[n].value===a){e[n].selected=!0,i&&(e[n].defaultSelected=!0);return}t!==null||e[n].disabled||(t=e[n])}t!==null&&(t.selected=!0)}}function sc(e,t,a){if(t!=null&&(t=""+Ut(t),t!==e.value&&(e.value=t),a==null)){e.defaultValue!==t&&(e.defaultValue=t);return}e.defaultValue=a!=null?""+Ut(a):""}function rc(e,t,a,i){if(t==null){if(i!=null){if(a!=null)throw Error(d(92));if(Me(i)){if(1<i.length)throw Error(d(93));i=i[0]}a=i}a==null&&(a=""),t=a}a=Ut(t),e.defaultValue=a,i=e.textContent,i===a&&i!==""&&i!==null&&(e.value=i),ws(e)}function zl(e,t){if(t){var a=e.firstChild;if(a&&a===e.lastChild&&a.nodeType===3){a.nodeValue=t;return}}e.textContent=t}var wx=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function oc(e,t,a){var i=t.indexOf("--")===0;a==null||typeof a=="boolean"||a===""?i?e.setProperty(t,""):t==="float"?e.cssFloat="":e[t]="":i?e.setProperty(t,a):typeof a!="number"||a===0||wx.has(t)?t==="float"?e.cssFloat=a:e[t]=(""+a).trim():e[t]=a+"px"}function cc(e,t,a){if(t!=null&&typeof t!="object")throw Error(d(62));if(e=e.style,a!=null){for(var i in a)!a.hasOwnProperty(i)||t!=null&&t.hasOwnProperty(i)||(i.indexOf("--")===0?e.setProperty(i,""):i==="float"?e.cssFloat="":e[i]="");for(var n in t)i=t[n],t.hasOwnProperty(n)&&a[n]!==i&&oc(e,n,i)}else for(var s in t)t.hasOwnProperty(s)&&oc(e,s,t[s])}function Ts(e){if(e.indexOf("-")===-1)return!1;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var Sx=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),Ex=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function sn(e){return Ex.test(""+e)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":e}function la(){}var _s=null;function As(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var wl=null,Sl=null;function dc(e){var t=vl(e);if(t&&(e=t.stateNode)){var a=e[vt]||null;e:switch(e=t.stateNode,t.type){case"input":if(Ss(e,a.value,a.defaultValue,a.defaultValue,a.checked,a.defaultChecked,a.type,a.name),t=a.name,a.type==="radio"&&t!=null){for(a=e;a.parentNode;)a=a.parentNode;for(a=a.querySelectorAll('input[name="'+Bt(""+t)+'"][type="radio"]'),t=0;t<a.length;t++){var i=a[t];if(i!==e&&i.form===e.form){var n=i[vt]||null;if(!n)throw Error(d(90));Ss(i,n.value,n.defaultValue,n.defaultValue,n.checked,n.defaultChecked,n.type,n.name)}}for(t=0;t<a.length;t++)i=a[t],i.form===e.form&&ic(i)}break e;case"textarea":sc(e,a.value,a.defaultValue);break e;case"select":t=a.value,t!=null&&Nl(e,!!a.multiple,t,!1)}}}var Os=!1;function uc(e,t,a){if(Os)return e(t,a);Os=!0;try{var i=e(t);return i}finally{if(Os=!1,(wl!==null||Sl!==null)&&(Qn(),wl&&(t=wl,e=Sl,Sl=wl=null,dc(t),e)))for(t=0;t<e.length;t++)dc(e[t])}}function di(e,t){var a=e.stateNode;if(a===null)return null;var i=a[vt]||null;if(i===null)return null;a=i[t];e:switch(t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(i=!i.disabled)||(e=e.type,i=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!i;break e;default:e=!1}if(e)return null;if(a&&typeof a!="function")throw Error(d(231,t,typeof a));return a}var ia=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),Cs=!1;if(ia)try{var ui={};Object.defineProperty(ui,"passive",{get:function(){Cs=!0}}),window.addEventListener("test",ui,ui),window.removeEventListener("test",ui,ui)}catch{Cs=!1}var wa=null,Ds=null,rn=null;function fc(){if(rn)return rn;var e,t=Ds,a=t.length,i,n="value"in wa?wa.value:wa.textContent,s=n.length;for(e=0;e<a&&t[e]===n[e];e++);var o=a-e;for(i=1;i<=o&&t[a-i]===n[s-i];i++);return rn=n.slice(e,1<i?1-i:void 0)}function on(e){var t=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function cn(){return!0}function mc(){return!1}function kt(e){function t(a,i,n,s,o){this._reactName=a,this._targetInst=n,this.type=i,this.nativeEvent=s,this.target=o,this.currentTarget=null;for(var c in e)e.hasOwnProperty(c)&&(a=e[c],this[c]=a?a(s):s[c]);return this.isDefaultPrevented=(s.defaultPrevented!=null?s.defaultPrevented:s.returnValue===!1)?cn:mc,this.isPropagationStopped=mc,this}return N(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var a=this.nativeEvent;a&&(a.preventDefault?a.preventDefault():typeof a.returnValue!="unknown"&&(a.returnValue=!1),this.isDefaultPrevented=cn)},stopPropagation:function(){var a=this.nativeEvent;a&&(a.stopPropagation?a.stopPropagation():typeof a.cancelBubble!="unknown"&&(a.cancelBubble=!0),this.isPropagationStopped=cn)},persist:function(){},isPersistent:cn}),t}var el={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},dn=kt(el),fi=N({},el,{view:0,detail:0}),Tx=kt(fi),Ms,Rs,mi,un=N({},fi,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Bs,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==mi&&(mi&&e.type==="mousemove"?(Ms=e.screenX-mi.screenX,Rs=e.screenY-mi.screenY):Rs=Ms=0,mi=e),Ms)},movementY:function(e){return"movementY"in e?e.movementY:Rs}}),xc=kt(un),_x=N({},un,{dataTransfer:0}),Ax=kt(_x),Ox=N({},fi,{relatedTarget:0}),Us=kt(Ox),Cx=N({},el,{animationName:0,elapsedTime:0,pseudoElement:0}),Dx=kt(Cx),Mx=N({},el,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),Rx=kt(Mx),Ux=N({},el,{data:0}),pc=kt(Ux),Bx={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},Lx={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},Hx={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function Yx(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=Hx[e])?!!t[e]:!1}function Bs(){return Yx}var Gx=N({},fi,{key:function(e){if(e.key){var t=Bx[e.key]||e.key;if(t!=="Unidentified")return t}return e.type==="keypress"?(e=on(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?Lx[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Bs,charCode:function(e){return e.type==="keypress"?on(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?on(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),Ix=kt(Gx),Kx=N({},un,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),hc=kt(Kx),qx=N({},fi,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Bs}),Vx=kt(qx),Xx=N({},el,{propertyName:0,elapsedTime:0,pseudoElement:0}),Qx=kt(Xx),Zx=N({},un,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),Jx=kt(Zx),Fx=N({},el,{newState:0,oldState:0}),Px=kt(Fx),Wx=[9,13,27,32],Ls=ia&&"CompositionEvent"in window,xi=null;ia&&"documentMode"in document&&(xi=document.documentMode);var $x=ia&&"TextEvent"in window&&!xi,gc=ia&&(!Ls||xi&&8<xi&&11>=xi),bc=" ",yc=!1;function vc(e,t){switch(e){case"keyup":return Wx.indexOf(t.keyCode)!==-1;case"keydown":return t.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function kc(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var El=!1;function ep(e,t){switch(e){case"compositionend":return kc(t);case"keypress":return t.which!==32?null:(yc=!0,bc);case"textInput":return e=t.data,e===bc&&yc?null:e;default:return null}}function tp(e,t){if(El)return e==="compositionend"||!Ls&&vc(e,t)?(e=fc(),rn=Ds=wa=null,El=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return gc&&t.locale!=="ko"?null:t.data;default:return null}}var ap={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function jc(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t==="input"?!!ap[e.type]:t==="textarea"}function Nc(e,t,a,i){wl?Sl?Sl.push(i):Sl=[i]:wl=i,t=es(t,"onChange"),0<t.length&&(a=new dn("onChange","change",null,a,i),e.push({event:a,listeners:t}))}var pi=null,hi=null;function lp(e){sf(e,0)}function fn(e){var t=ci(e);if(ic(t))return e}function zc(e,t){if(e==="change")return t}var wc=!1;if(ia){var Hs;if(ia){var Ys="oninput"in document;if(!Ys){var Sc=document.createElement("div");Sc.setAttribute("oninput","return;"),Ys=typeof Sc.oninput=="function"}Hs=Ys}else Hs=!1;wc=Hs&&(!document.documentMode||9<document.documentMode)}function Ec(){pi&&(pi.detachEvent("onpropertychange",Tc),hi=pi=null)}function Tc(e){if(e.propertyName==="value"&&fn(hi)){var t=[];Nc(t,hi,e,As(e)),uc(lp,t)}}function ip(e,t,a){e==="focusin"?(Ec(),pi=t,hi=a,pi.attachEvent("onpropertychange",Tc)):e==="focusout"&&Ec()}function np(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return fn(hi)}function sp(e,t){if(e==="click")return fn(t)}function rp(e,t){if(e==="input"||e==="change")return fn(t)}function op(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var Tt=typeof Object.is=="function"?Object.is:op;function gi(e,t){if(Tt(e,t))return!0;if(typeof e!="object"||e===null||typeof t!="object"||t===null)return!1;var a=Object.keys(e),i=Object.keys(t);if(a.length!==i.length)return!1;for(i=0;i<a.length;i++){var n=a[i];if(!ja.call(t,n)||!Tt(e[n],t[n]))return!1}return!0}function _c(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function Ac(e,t){var a=_c(e);e=0;for(var i;a;){if(a.nodeType===3){if(i=e+a.textContent.length,e<=t&&i>=t)return{node:a,offset:t-e};e=i}e:{for(;a;){if(a.nextSibling){a=a.nextSibling;break e}a=a.parentNode}a=void 0}a=_c(a)}}function Oc(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?Oc(e,t.parentNode):"contains"in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function Cc(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var t=nn(e.document);t instanceof e.HTMLIFrameElement;){try{var a=typeof t.contentWindow.location.href=="string"}catch{a=!1}if(a)e=t.contentWindow;else break;t=nn(e.document)}return t}function Gs(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||t==="textarea"||e.contentEditable==="true")}var cp=ia&&"documentMode"in document&&11>=document.documentMode,Tl=null,Is=null,bi=null,Ks=!1;function Dc(e,t,a){var i=a.window===a?a.document:a.nodeType===9?a:a.ownerDocument;Ks||Tl==null||Tl!==nn(i)||(i=Tl,"selectionStart"in i&&Gs(i)?i={start:i.selectionStart,end:i.selectionEnd}:(i=(i.ownerDocument&&i.ownerDocument.defaultView||window).getSelection(),i={anchorNode:i.anchorNode,anchorOffset:i.anchorOffset,focusNode:i.focusNode,focusOffset:i.focusOffset}),bi&&gi(bi,i)||(bi=i,i=es(Is,"onSelect"),0<i.length&&(t=new dn("onSelect","select",null,t,a),e.push({event:t,listeners:i}),t.target=Tl)))}function tl(e,t){var a={};return a[e.toLowerCase()]=t.toLowerCase(),a["Webkit"+e]="webkit"+t,a["Moz"+e]="moz"+t,a}var _l={animationend:tl("Animation","AnimationEnd"),animationiteration:tl("Animation","AnimationIteration"),animationstart:tl("Animation","AnimationStart"),transitionrun:tl("Transition","TransitionRun"),transitionstart:tl("Transition","TransitionStart"),transitioncancel:tl("Transition","TransitionCancel"),transitionend:tl("Transition","TransitionEnd")},qs={},Mc={};ia&&(Mc=document.createElement("div").style,"AnimationEvent"in window||(delete _l.animationend.animation,delete _l.animationiteration.animation,delete _l.animationstart.animation),"TransitionEvent"in window||delete _l.transitionend.transition);function al(e){if(qs[e])return qs[e];if(!_l[e])return e;var t=_l[e],a;for(a in t)if(t.hasOwnProperty(a)&&a in Mc)return qs[e]=t[a];return e}var Rc=al("animationend"),Uc=al("animationiteration"),Bc=al("animationstart"),dp=al("transitionrun"),up=al("transitionstart"),fp=al("transitioncancel"),Lc=al("transitionend"),Hc=new Map,Vs="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");Vs.push("scrollEnd");function Qt(e,t){Hc.set(e,t),$a(t,[e])}var mn=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)},Lt=[],Al=0,Xs=0;function xn(){for(var e=Al,t=Xs=Al=0;t<e;){var a=Lt[t];Lt[t++]=null;var i=Lt[t];Lt[t++]=null;var n=Lt[t];Lt[t++]=null;var s=Lt[t];if(Lt[t++]=null,i!==null&&n!==null){var o=i.pending;o===null?n.next=n:(n.next=o.next,o.next=n),i.pending=n}s!==0&&Yc(a,n,s)}}function pn(e,t,a,i){Lt[Al++]=e,Lt[Al++]=t,Lt[Al++]=a,Lt[Al++]=i,Xs|=i,e.lanes|=i,e=e.alternate,e!==null&&(e.lanes|=i)}function Qs(e,t,a,i){return pn(e,t,a,i),hn(e)}function ll(e,t){return pn(e,null,null,t),hn(e)}function Yc(e,t,a){e.lanes|=a;var i=e.alternate;i!==null&&(i.lanes|=a);for(var n=!1,s=e.return;s!==null;)s.childLanes|=a,i=s.alternate,i!==null&&(i.childLanes|=a),s.tag===22&&(e=s.stateNode,e===null||e._visibility&1||(n=!0)),e=s,s=s.return;return e.tag===3?(s=e.stateNode,n&&t!==null&&(n=31-mt(a),e=s.hiddenUpdates,i=e[n],i===null?e[n]=[t]:i.push(t),t.lane=a|536870912),s):null}function hn(e){if(50<Yi)throw Yi=0,ao=null,Error(d(185));for(var t=e.return;t!==null;)e=t,t=e.return;return e.tag===3?e.stateNode:null}var Ol={};function mp(e,t,a,i){this.tag=e,this.key=a,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=i,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function _t(e,t,a,i){return new mp(e,t,a,i)}function Zs(e){return e=e.prototype,!(!e||!e.isReactComponent)}function na(e,t){var a=e.alternate;return a===null?(a=_t(e.tag,t,e.key,e.mode),a.elementType=e.elementType,a.type=e.type,a.stateNode=e.stateNode,a.alternate=e,e.alternate=a):(a.pendingProps=t,a.type=e.type,a.flags=0,a.subtreeFlags=0,a.deletions=null),a.flags=e.flags&65011712,a.childLanes=e.childLanes,a.lanes=e.lanes,a.child=e.child,a.memoizedProps=e.memoizedProps,a.memoizedState=e.memoizedState,a.updateQueue=e.updateQueue,t=e.dependencies,a.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},a.sibling=e.sibling,a.index=e.index,a.ref=e.ref,a.refCleanup=e.refCleanup,a}function Gc(e,t){e.flags&=65011714;var a=e.alternate;return a===null?(e.childLanes=0,e.lanes=t,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=a.childLanes,e.lanes=a.lanes,e.child=a.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=a.memoizedProps,e.memoizedState=a.memoizedState,e.updateQueue=a.updateQueue,e.type=a.type,t=a.dependencies,e.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext}),e}function gn(e,t,a,i,n,s){var o=0;if(i=e,typeof e=="function")Zs(e)&&(o=1);else if(typeof e=="string")o=b0(e,a,V.current)?26:e==="html"||e==="head"||e==="body"?27:5;else e:switch(e){case ne:return e=_t(31,a,t,n),e.elementType=ne,e.lanes=s,e;case ie:return il(a.children,n,s,t);case J:o=8,n|=24;break;case H:return e=_t(12,a,t,n|2),e.elementType=H,e.lanes=s,e;case Ye:return e=_t(13,a,t,n),e.elementType=Ye,e.lanes=s,e;case de:return e=_t(19,a,t,n),e.elementType=de,e.lanes=s,e;default:if(typeof e=="object"&&e!==null)switch(e.$$typeof){case ue:o=10;break e;case K:o=9;break e;case $:o=11;break e;case Q:o=14;break e;case Y:o=16,i=null;break e}o=29,a=Error(d(130,e===null?"null":typeof e,"")),i=null}return t=_t(o,a,t,n),t.elementType=e,t.type=i,t.lanes=s,t}function il(e,t,a,i){return e=_t(7,e,i,t),e.lanes=a,e}function Js(e,t,a){return e=_t(6,e,null,t),e.lanes=a,e}function Ic(e){var t=_t(18,null,null,0);return t.stateNode=e,t}function Fs(e,t,a){return t=_t(4,e.children!==null?e.children:[],e.key,t),t.lanes=a,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}var Kc=new WeakMap;function Ht(e,t){if(typeof e=="object"&&e!==null){var a=Kc.get(e);return a!==void 0?a:(t={value:e,source:t,stack:yt(t)},Kc.set(e,t),t)}return{value:e,source:t,stack:yt(t)}}var Cl=[],Dl=0,bn=null,yi=0,Yt=[],Gt=0,Sa=null,Pt=1,Wt="";function sa(e,t){Cl[Dl++]=yi,Cl[Dl++]=bn,bn=e,yi=t}function qc(e,t,a){Yt[Gt++]=Pt,Yt[Gt++]=Wt,Yt[Gt++]=Sa,Sa=e;var i=Pt;e=Wt;var n=32-mt(i)-1;i&=~(1<<n),a+=1;var s=32-mt(t)+n;if(30<s){var o=n-n%5;s=(i&(1<<o)-1).toString(32),i>>=o,n-=o,Pt=1<<32-mt(t)+n|a<<n|i,Wt=s+e}else Pt=1<<s|a<<n|i,Wt=e}function Ps(e){e.return!==null&&(sa(e,1),qc(e,1,0))}function Ws(e){for(;e===bn;)bn=Cl[--Dl],Cl[Dl]=null,yi=Cl[--Dl],Cl[Dl]=null;for(;e===Sa;)Sa=Yt[--Gt],Yt[Gt]=null,Wt=Yt[--Gt],Yt[Gt]=null,Pt=Yt[--Gt],Yt[Gt]=null}function Vc(e,t){Yt[Gt++]=Pt,Yt[Gt++]=Wt,Yt[Gt++]=Sa,Pt=t.id,Wt=t.overflow,Sa=e}var ot=null,Ie=null,Se=!1,Ea=null,It=!1,$s=Error(d(519));function Ta(e){var t=Error(d(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw vi(Ht(t,e)),$s}function Xc(e){var t=e.stateNode,a=e.type,i=e.memoizedProps;switch(t[rt]=e,t[vt]=i,a){case"dialog":Ne("cancel",t),Ne("close",t);break;case"iframe":case"object":case"embed":Ne("load",t);break;case"video":case"audio":for(a=0;a<Ii.length;a++)Ne(Ii[a],t);break;case"source":Ne("error",t);break;case"img":case"image":case"link":Ne("error",t),Ne("load",t);break;case"details":Ne("toggle",t);break;case"input":Ne("invalid",t),nc(t,i.value,i.defaultValue,i.checked,i.defaultChecked,i.type,i.name,!0);break;case"select":Ne("invalid",t);break;case"textarea":Ne("invalid",t),rc(t,i.value,i.defaultValue,i.children)}a=i.children,typeof a!="string"&&typeof a!="number"&&typeof a!="bigint"||t.textContent===""+a||i.suppressHydrationWarning===!0||df(t.textContent,a)?(i.popover!=null&&(Ne("beforetoggle",t),Ne("toggle",t)),i.onScroll!=null&&Ne("scroll",t),i.onScrollEnd!=null&&Ne("scrollend",t),i.onClick!=null&&(t.onclick=la),t=!0):t=!1,t||Ta(e,!0)}function Qc(e){for(ot=e.return;ot;)switch(ot.tag){case 5:case 31:case 13:It=!1;return;case 27:case 3:It=!0;return;default:ot=ot.return}}function Ml(e){if(e!==ot)return!1;if(!Se)return Qc(e),Se=!0,!1;var t=e.tag,a;if((a=t!==3&&t!==27)&&((a=t===5)&&(a=e.type,a=!(a!=="form"&&a!=="button")||bo(e.type,e.memoizedProps)),a=!a),a&&Ie&&Ta(e),Qc(e),t===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(d(317));Ie=yf(e)}else if(t===31){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(d(317));Ie=yf(e)}else t===27?(t=Ie,Ia(e.type)?(e=No,No=null,Ie=e):Ie=t):Ie=ot?qt(e.stateNode.nextSibling):null;return!0}function nl(){Ie=ot=null,Se=!1}function er(){var e=Ea;return e!==null&&(wt===null?wt=e:wt.push.apply(wt,e),Ea=null),e}function vi(e){Ea===null?Ea=[e]:Ea.push(e)}var tr=f(null),sl=null,ra=null;function _a(e,t,a){I(tr,t._currentValue),t._currentValue=a}function oa(e){e._currentValue=tr.current,D(tr)}function ar(e,t,a){for(;e!==null;){var i=e.alternate;if((e.childLanes&t)!==t?(e.childLanes|=t,i!==null&&(i.childLanes|=t)):i!==null&&(i.childLanes&t)!==t&&(i.childLanes|=t),e===a)break;e=e.return}}function lr(e,t,a,i){var n=e.child;for(n!==null&&(n.return=e);n!==null;){var s=n.dependencies;if(s!==null){var o=n.child;s=s.firstContext;e:for(;s!==null;){var c=s;s=n;for(var u=0;u<t.length;u++)if(c.context===t[u]){s.lanes|=a,c=s.alternate,c!==null&&(c.lanes|=a),ar(s.return,a,e),i||(o=null);break e}s=c.next}}else if(n.tag===18){if(o=n.return,o===null)throw Error(d(341));o.lanes|=a,s=o.alternate,s!==null&&(s.lanes|=a),ar(o,a,e),o=null}else o=n.child;if(o!==null)o.return=n;else for(o=n;o!==null;){if(o===e){o=null;break}if(n=o.sibling,n!==null){n.return=o.return,o=n;break}o=o.return}n=o}}function Rl(e,t,a,i){e=null;for(var n=t,s=!1;n!==null;){if(!s){if((n.flags&524288)!==0)s=!0;else if((n.flags&262144)!==0)break}if(n.tag===10){var o=n.alternate;if(o===null)throw Error(d(387));if(o=o.memoizedProps,o!==null){var c=n.type;Tt(n.pendingProps.value,o.value)||(e!==null?e.push(c):e=[c])}}else if(n===O.current){if(o=n.alternate,o===null)throw Error(d(387));o.memoizedState.memoizedState!==n.memoizedState.memoizedState&&(e!==null?e.push(Qi):e=[Qi])}n=n.return}e!==null&&lr(t,e,a,i),t.flags|=262144}function yn(e){for(e=e.firstContext;e!==null;){if(!Tt(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function rl(e){sl=e,ra=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function ct(e){return Zc(sl,e)}function vn(e,t){return sl===null&&rl(e),Zc(e,t)}function Zc(e,t){var a=t._currentValue;if(t={context:t,memoizedValue:a,next:null},ra===null){if(e===null)throw Error(d(308));ra=t,e.dependencies={lanes:0,firstContext:t},e.flags|=524288}else ra=ra.next=t;return a}var xp=typeof AbortController<"u"?AbortController:function(){var e=[],t=this.signal={aborted:!1,addEventListener:function(a,i){e.push(i)}};this.abort=function(){t.aborted=!0,e.forEach(function(a){return a()})}},pp=r.unstable_scheduleCallback,hp=r.unstable_NormalPriority,We={$$typeof:ue,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function ir(){return{controller:new xp,data:new Map,refCount:0}}function ki(e){e.refCount--,e.refCount===0&&pp(hp,function(){e.controller.abort()})}var ji=null,nr=0,Ul=0,Bl=null;function gp(e,t){if(ji===null){var a=ji=[];nr=0,Ul=oo(),Bl={status:"pending",value:void 0,then:function(i){a.push(i)}}}return nr++,t.then(Jc,Jc),t}function Jc(){if(--nr===0&&ji!==null){Bl!==null&&(Bl.status="fulfilled");var e=ji;ji=null,Ul=0,Bl=null;for(var t=0;t<e.length;t++)(0,e[t])()}}function bp(e,t){var a=[],i={status:"pending",value:null,reason:null,then:function(n){a.push(n)}};return e.then(function(){i.status="fulfilled",i.value=t;for(var n=0;n<a.length;n++)(0,a[n])(t)},function(n){for(i.status="rejected",i.reason=n,n=0;n<a.length;n++)(0,a[n])(void 0)}),i}var Fc=_.S;_.S=function(e,t){Du=xe(),typeof t=="object"&&t!==null&&typeof t.then=="function"&&gp(e,t),Fc!==null&&Fc(e,t)};var ol=f(null);function sr(){var e=ol.current;return e!==null?e:Ge.pooledCache}function kn(e,t){t===null?I(ol,ol.current):I(ol,t.pool)}function Pc(){var e=sr();return e===null?null:{parent:We._currentValue,pool:e}}var Ll=Error(d(460)),rr=Error(d(474)),jn=Error(d(542)),Nn={then:function(){}};function Wc(e){return e=e.status,e==="fulfilled"||e==="rejected"}function $c(e,t,a){switch(a=e[a],a===void 0?e.push(t):a!==t&&(t.then(la,la),t=a),t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,td(e),e;default:if(typeof t.status=="string")t.then(la,la);else{if(e=Ge,e!==null&&100<e.shellSuspendCounter)throw Error(d(482));e=t,e.status="pending",e.then(function(i){if(t.status==="pending"){var n=t;n.status="fulfilled",n.value=i}},function(i){if(t.status==="pending"){var n=t;n.status="rejected",n.reason=i}})}switch(t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,td(e),e}throw dl=t,Ll}}function cl(e){try{var t=e._init;return t(e._payload)}catch(a){throw a!==null&&typeof a=="object"&&typeof a.then=="function"?(dl=a,Ll):a}}var dl=null;function ed(){if(dl===null)throw Error(d(459));var e=dl;return dl=null,e}function td(e){if(e===Ll||e===jn)throw Error(d(483))}var Hl=null,Ni=0;function zn(e){var t=Ni;return Ni+=1,Hl===null&&(Hl=[]),$c(Hl,e,t)}function zi(e,t){t=t.props.ref,e.ref=t!==void 0?t:null}function wn(e,t){throw t.$$typeof===G?Error(d(525)):(e=Object.prototype.toString.call(t),Error(d(31,e==="[object Object]"?"object with keys {"+Object.keys(t).join(", ")+"}":e)))}function ad(e){function t(h,m){if(e){var k=h.deletions;k===null?(h.deletions=[m],h.flags|=16):k.push(m)}}function a(h,m){if(!e)return null;for(;m!==null;)t(h,m),m=m.sibling;return null}function i(h){for(var m=new Map;h!==null;)h.key!==null?m.set(h.key,h):m.set(h.index,h),h=h.sibling;return m}function n(h,m){return h=na(h,m),h.index=0,h.sibling=null,h}function s(h,m,k){return h.index=k,e?(k=h.alternate,k!==null?(k=k.index,k<m?(h.flags|=67108866,m):k):(h.flags|=67108866,m)):(h.flags|=1048576,m)}function o(h){return e&&h.alternate===null&&(h.flags|=67108866),h}function c(h,m,k,M){return m===null||m.tag!==6?(m=Js(k,h.mode,M),m.return=h,m):(m=n(m,k),m.return=h,m)}function u(h,m,k,M){var le=k.type;return le===ie?C(h,m,k.props.children,M,k.key):m!==null&&(m.elementType===le||typeof le=="object"&&le!==null&&le.$$typeof===Y&&cl(le)===m.type)?(m=n(m,k.props),zi(m,k),m.return=h,m):(m=gn(k.type,k.key,k.props,null,h.mode,M),zi(m,k),m.return=h,m)}function j(h,m,k,M){return m===null||m.tag!==4||m.stateNode.containerInfo!==k.containerInfo||m.stateNode.implementation!==k.implementation?(m=Fs(k,h.mode,M),m.return=h,m):(m=n(m,k.children||[]),m.return=h,m)}function C(h,m,k,M,le){return m===null||m.tag!==7?(m=il(k,h.mode,M,le),m.return=h,m):(m=n(m,k),m.return=h,m)}function R(h,m,k){if(typeof m=="string"&&m!==""||typeof m=="number"||typeof m=="bigint")return m=Js(""+m,h.mode,k),m.return=h,m;if(typeof m=="object"&&m!==null){switch(m.$$typeof){case L:return k=gn(m.type,m.key,m.props,null,h.mode,k),zi(k,m),k.return=h,k;case Z:return m=Fs(m,h.mode,k),m.return=h,m;case Y:return m=cl(m),R(h,m,k)}if(Me(m)||ce(m))return m=il(m,h.mode,k,null),m.return=h,m;if(typeof m.then=="function")return R(h,zn(m),k);if(m.$$typeof===ue)return R(h,vn(h,m),k);wn(h,m)}return null}function z(h,m,k,M){var le=m!==null?m.key:null;if(typeof k=="string"&&k!==""||typeof k=="number"||typeof k=="bigint")return le!==null?null:c(h,m,""+k,M);if(typeof k=="object"&&k!==null){switch(k.$$typeof){case L:return k.key===le?u(h,m,k,M):null;case Z:return k.key===le?j(h,m,k,M):null;case Y:return k=cl(k),z(h,m,k,M)}if(Me(k)||ce(k))return le!==null?null:C(h,m,k,M,null);if(typeof k.then=="function")return z(h,m,zn(k),M);if(k.$$typeof===ue)return z(h,m,vn(h,k),M);wn(h,k)}return null}function T(h,m,k,M,le){if(typeof M=="string"&&M!==""||typeof M=="number"||typeof M=="bigint")return h=h.get(k)||null,c(m,h,""+M,le);if(typeof M=="object"&&M!==null){switch(M.$$typeof){case L:return h=h.get(M.key===null?k:M.key)||null,u(m,h,M,le);case Z:return h=h.get(M.key===null?k:M.key)||null,j(m,h,M,le);case Y:return M=cl(M),T(h,m,k,M,le)}if(Me(M)||ce(M))return h=h.get(k)||null,C(m,h,M,le,null);if(typeof M.then=="function")return T(h,m,k,zn(M),le);if(M.$$typeof===ue)return T(h,m,k,vn(m,M),le);wn(m,M)}return null}function F(h,m,k,M){for(var le=null,_e=null,W=m,ve=m=0,we=null;W!==null&&ve<k.length;ve++){W.index>ve?(we=W,W=null):we=W.sibling;var Ae=z(h,W,k[ve],M);if(Ae===null){W===null&&(W=we);break}e&&W&&Ae.alternate===null&&t(h,W),m=s(Ae,m,ve),_e===null?le=Ae:_e.sibling=Ae,_e=Ae,W=we}if(ve===k.length)return a(h,W),Se&&sa(h,ve),le;if(W===null){for(;ve<k.length;ve++)W=R(h,k[ve],M),W!==null&&(m=s(W,m,ve),_e===null?le=W:_e.sibling=W,_e=W);return Se&&sa(h,ve),le}for(W=i(W);ve<k.length;ve++)we=T(W,h,ve,k[ve],M),we!==null&&(e&&we.alternate!==null&&W.delete(we.key===null?ve:we.key),m=s(we,m,ve),_e===null?le=we:_e.sibling=we,_e=we);return e&&W.forEach(function(Qa){return t(h,Qa)}),Se&&sa(h,ve),le}function se(h,m,k,M){if(k==null)throw Error(d(151));for(var le=null,_e=null,W=m,ve=m=0,we=null,Ae=k.next();W!==null&&!Ae.done;ve++,Ae=k.next()){W.index>ve?(we=W,W=null):we=W.sibling;var Qa=z(h,W,Ae.value,M);if(Qa===null){W===null&&(W=we);break}e&&W&&Qa.alternate===null&&t(h,W),m=s(Qa,m,ve),_e===null?le=Qa:_e.sibling=Qa,_e=Qa,W=we}if(Ae.done)return a(h,W),Se&&sa(h,ve),le;if(W===null){for(;!Ae.done;ve++,Ae=k.next())Ae=R(h,Ae.value,M),Ae!==null&&(m=s(Ae,m,ve),_e===null?le=Ae:_e.sibling=Ae,_e=Ae);return Se&&sa(h,ve),le}for(W=i(W);!Ae.done;ve++,Ae=k.next())Ae=T(W,h,ve,Ae.value,M),Ae!==null&&(e&&Ae.alternate!==null&&W.delete(Ae.key===null?ve:Ae.key),m=s(Ae,m,ve),_e===null?le=Ae:_e.sibling=Ae,_e=Ae);return e&&W.forEach(function(_0){return t(h,_0)}),Se&&sa(h,ve),le}function He(h,m,k,M){if(typeof k=="object"&&k!==null&&k.type===ie&&k.key===null&&(k=k.props.children),typeof k=="object"&&k!==null){switch(k.$$typeof){case L:e:{for(var le=k.key;m!==null;){if(m.key===le){if(le=k.type,le===ie){if(m.tag===7){a(h,m.sibling),M=n(m,k.props.children),M.return=h,h=M;break e}}else if(m.elementType===le||typeof le=="object"&&le!==null&&le.$$typeof===Y&&cl(le)===m.type){a(h,m.sibling),M=n(m,k.props),zi(M,k),M.return=h,h=M;break e}a(h,m);break}else t(h,m);m=m.sibling}k.type===ie?(M=il(k.props.children,h.mode,M,k.key),M.return=h,h=M):(M=gn(k.type,k.key,k.props,null,h.mode,M),zi(M,k),M.return=h,h=M)}return o(h);case Z:e:{for(le=k.key;m!==null;){if(m.key===le)if(m.tag===4&&m.stateNode.containerInfo===k.containerInfo&&m.stateNode.implementation===k.implementation){a(h,m.sibling),M=n(m,k.children||[]),M.return=h,h=M;break e}else{a(h,m);break}else t(h,m);m=m.sibling}M=Fs(k,h.mode,M),M.return=h,h=M}return o(h);case Y:return k=cl(k),He(h,m,k,M)}if(Me(k))return F(h,m,k,M);if(ce(k)){if(le=ce(k),typeof le!="function")throw Error(d(150));return k=le.call(k),se(h,m,k,M)}if(typeof k.then=="function")return He(h,m,zn(k),M);if(k.$$typeof===ue)return He(h,m,vn(h,k),M);wn(h,k)}return typeof k=="string"&&k!==""||typeof k=="number"||typeof k=="bigint"?(k=""+k,m!==null&&m.tag===6?(a(h,m.sibling),M=n(m,k),M.return=h,h=M):(a(h,m),M=Js(k,h.mode,M),M.return=h,h=M),o(h)):a(h,m)}return function(h,m,k,M){try{Ni=0;var le=He(h,m,k,M);return Hl=null,le}catch(W){if(W===Ll||W===jn)throw W;var _e=_t(29,W,null,h.mode);return _e.lanes=M,_e.return=h,_e}finally{}}}var ul=ad(!0),ld=ad(!1),Aa=!1;function or(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function cr(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function Oa(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function Ca(e,t,a){var i=e.updateQueue;if(i===null)return null;if(i=i.shared,(De&2)!==0){var n=i.pending;return n===null?t.next=t:(t.next=n.next,n.next=t),i.pending=t,t=hn(e),Yc(e,null,a),t}return pn(e,i,t,a),hn(e)}function wi(e,t,a){if(t=t.updateQueue,t!==null&&(t=t.shared,(a&4194048)!==0)){var i=t.lanes;i&=e.pendingLanes,a|=i,t.lanes=a,Zo(e,a)}}function dr(e,t){var a=e.updateQueue,i=e.alternate;if(i!==null&&(i=i.updateQueue,a===i)){var n=null,s=null;if(a=a.firstBaseUpdate,a!==null){do{var o={lane:a.lane,tag:a.tag,payload:a.payload,callback:null,next:null};s===null?n=s=o:s=s.next=o,a=a.next}while(a!==null);s===null?n=s=t:s=s.next=t}else n=s=t;a={baseState:i.baseState,firstBaseUpdate:n,lastBaseUpdate:s,shared:i.shared,callbacks:i.callbacks},e.updateQueue=a;return}e=a.lastBaseUpdate,e===null?a.firstBaseUpdate=t:e.next=t,a.lastBaseUpdate=t}var ur=!1;function Si(){if(ur){var e=Bl;if(e!==null)throw e}}function Ei(e,t,a,i){ur=!1;var n=e.updateQueue;Aa=!1;var s=n.firstBaseUpdate,o=n.lastBaseUpdate,c=n.shared.pending;if(c!==null){n.shared.pending=null;var u=c,j=u.next;u.next=null,o===null?s=j:o.next=j,o=u;var C=e.alternate;C!==null&&(C=C.updateQueue,c=C.lastBaseUpdate,c!==o&&(c===null?C.firstBaseUpdate=j:c.next=j,C.lastBaseUpdate=u))}if(s!==null){var R=n.baseState;o=0,C=j=u=null,c=s;do{var z=c.lane&-536870913,T=z!==c.lane;if(T?(ze&z)===z:(i&z)===z){z!==0&&z===Ul&&(ur=!0),C!==null&&(C=C.next={lane:0,tag:c.tag,payload:c.payload,callback:null,next:null});e:{var F=e,se=c;z=t;var He=a;switch(se.tag){case 1:if(F=se.payload,typeof F=="function"){R=F.call(He,R,z);break e}R=F;break e;case 3:F.flags=F.flags&-65537|128;case 0:if(F=se.payload,z=typeof F=="function"?F.call(He,R,z):F,z==null)break e;R=N({},R,z);break e;case 2:Aa=!0}}z=c.callback,z!==null&&(e.flags|=64,T&&(e.flags|=8192),T=n.callbacks,T===null?n.callbacks=[z]:T.push(z))}else T={lane:z,tag:c.tag,payload:c.payload,callback:c.callback,next:null},C===null?(j=C=T,u=R):C=C.next=T,o|=z;if(c=c.next,c===null){if(c=n.shared.pending,c===null)break;T=c,c=T.next,T.next=null,n.lastBaseUpdate=T,n.shared.pending=null}}while(!0);C===null&&(u=R),n.baseState=u,n.firstBaseUpdate=j,n.lastBaseUpdate=C,s===null&&(n.shared.lanes=0),Ba|=o,e.lanes=o,e.memoizedState=R}}function id(e,t){if(typeof e!="function")throw Error(d(191,e));e.call(t)}function nd(e,t){var a=e.callbacks;if(a!==null)for(e.callbacks=null,e=0;e<a.length;e++)id(a[e],t)}var Yl=f(null),Sn=f(0);function sd(e,t){e=ga,I(Sn,e),I(Yl,t),ga=e|t.baseLanes}function fr(){I(Sn,ga),I(Yl,Yl.current)}function mr(){ga=Sn.current,D(Yl),D(Sn)}var At=f(null),Kt=null;function Da(e){var t=e.alternate;I(Ze,Ze.current&1),I(At,e),Kt===null&&(t===null||Yl.current!==null||t.memoizedState!==null)&&(Kt=e)}function xr(e){I(Ze,Ze.current),I(At,e),Kt===null&&(Kt=e)}function rd(e){e.tag===22?(I(Ze,Ze.current),I(At,e),Kt===null&&(Kt=e)):Ma()}function Ma(){I(Ze,Ze.current),I(At,At.current)}function Ot(e){D(At),Kt===e&&(Kt=null),D(Ze)}var Ze=f(0);function En(e){for(var t=e;t!==null;){if(t.tag===13){var a=t.memoizedState;if(a!==null&&(a=a.dehydrated,a===null||ko(a)||jo(a)))return t}else if(t.tag===19&&(t.memoizedProps.revealOrder==="forwards"||t.memoizedProps.revealOrder==="backwards"||t.memoizedProps.revealOrder==="unstable_legacy-backwards"||t.memoizedProps.revealOrder==="together")){if((t.flags&128)!==0)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var ca=0,be=null,Be=null,$e=null,Tn=!1,Gl=!1,fl=!1,_n=0,Ti=0,Il=null,yp=0;function Ve(){throw Error(d(321))}function pr(e,t){if(t===null)return!1;for(var a=0;a<t.length&&a<e.length;a++)if(!Tt(e[a],t[a]))return!1;return!0}function hr(e,t,a,i,n,s){return ca=s,be=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,_.H=e===null||e.memoizedState===null?qd:Or,fl=!1,s=a(i,n),fl=!1,Gl&&(s=cd(t,a,i,n)),od(e),s}function od(e){_.H=Oi;var t=Be!==null&&Be.next!==null;if(ca=0,$e=Be=be=null,Tn=!1,Ti=0,Il=null,t)throw Error(d(300));e===null||et||(e=e.dependencies,e!==null&&yn(e)&&(et=!0))}function cd(e,t,a,i){be=e;var n=0;do{if(Gl&&(Il=null),Ti=0,Gl=!1,25<=n)throw Error(d(301));if(n+=1,$e=Be=null,e.updateQueue!=null){var s=e.updateQueue;s.lastEffect=null,s.events=null,s.stores=null,s.memoCache!=null&&(s.memoCache.index=0)}_.H=Vd,s=t(a,i)}while(Gl);return s}function vp(){var e=_.H,t=e.useState()[0];return t=typeof t.then=="function"?_i(t):t,e=e.useState()[0],(Be!==null?Be.memoizedState:null)!==e&&(be.flags|=1024),t}function gr(){var e=_n!==0;return _n=0,e}function br(e,t,a){t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~a}function yr(e){if(Tn){for(e=e.memoizedState;e!==null;){var t=e.queue;t!==null&&(t.pending=null),e=e.next}Tn=!1}ca=0,$e=Be=be=null,Gl=!1,Ti=_n=0,Il=null}function gt(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return $e===null?be.memoizedState=$e=e:$e=$e.next=e,$e}function Je(){if(Be===null){var e=be.alternate;e=e!==null?e.memoizedState:null}else e=Be.next;var t=$e===null?be.memoizedState:$e.next;if(t!==null)$e=t,Be=e;else{if(e===null)throw be.alternate===null?Error(d(467)):Error(d(310));Be=e,e={memoizedState:Be.memoizedState,baseState:Be.baseState,baseQueue:Be.baseQueue,queue:Be.queue,next:null},$e===null?be.memoizedState=$e=e:$e=$e.next=e}return $e}function An(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function _i(e){var t=Ti;return Ti+=1,Il===null&&(Il=[]),e=$c(Il,e,t),t=be,($e===null?t.memoizedState:$e.next)===null&&(t=t.alternate,_.H=t===null||t.memoizedState===null?qd:Or),e}function On(e){if(e!==null&&typeof e=="object"){if(typeof e.then=="function")return _i(e);if(e.$$typeof===ue)return ct(e)}throw Error(d(438,String(e)))}function vr(e){var t=null,a=be.updateQueue;if(a!==null&&(t=a.memoCache),t==null){var i=be.alternate;i!==null&&(i=i.updateQueue,i!==null&&(i=i.memoCache,i!=null&&(t={data:i.data.map(function(n){return n.slice()}),index:0})))}if(t==null&&(t={data:[],index:0}),a===null&&(a=An(),be.updateQueue=a),a.memoCache=t,a=t.data[t.index],a===void 0)for(a=t.data[t.index]=Array(e),i=0;i<e;i++)a[i]=re;return t.index++,a}function da(e,t){return typeof t=="function"?t(e):t}function Cn(e){var t=Je();return kr(t,Be,e)}function kr(e,t,a){var i=e.queue;if(i===null)throw Error(d(311));i.lastRenderedReducer=a;var n=e.baseQueue,s=i.pending;if(s!==null){if(n!==null){var o=n.next;n.next=s.next,s.next=o}t.baseQueue=n=s,i.pending=null}if(s=e.baseState,n===null)e.memoizedState=s;else{t=n.next;var c=o=null,u=null,j=t,C=!1;do{var R=j.lane&-536870913;if(R!==j.lane?(ze&R)===R:(ca&R)===R){var z=j.revertLane;if(z===0)u!==null&&(u=u.next={lane:0,revertLane:0,gesture:null,action:j.action,hasEagerState:j.hasEagerState,eagerState:j.eagerState,next:null}),R===Ul&&(C=!0);else if((ca&z)===z){j=j.next,z===Ul&&(C=!0);continue}else R={lane:0,revertLane:j.revertLane,gesture:null,action:j.action,hasEagerState:j.hasEagerState,eagerState:j.eagerState,next:null},u===null?(c=u=R,o=s):u=u.next=R,be.lanes|=z,Ba|=z;R=j.action,fl&&a(s,R),s=j.hasEagerState?j.eagerState:a(s,R)}else z={lane:R,revertLane:j.revertLane,gesture:j.gesture,action:j.action,hasEagerState:j.hasEagerState,eagerState:j.eagerState,next:null},u===null?(c=u=z,o=s):u=u.next=z,be.lanes|=R,Ba|=R;j=j.next}while(j!==null&&j!==t);if(u===null?o=s:u.next=c,!Tt(s,e.memoizedState)&&(et=!0,C&&(a=Bl,a!==null)))throw a;e.memoizedState=s,e.baseState=o,e.baseQueue=u,i.lastRenderedState=s}return n===null&&(i.lanes=0),[e.memoizedState,i.dispatch]}function jr(e){var t=Je(),a=t.queue;if(a===null)throw Error(d(311));a.lastRenderedReducer=e;var i=a.dispatch,n=a.pending,s=t.memoizedState;if(n!==null){a.pending=null;var o=n=n.next;do s=e(s,o.action),o=o.next;while(o!==n);Tt(s,t.memoizedState)||(et=!0),t.memoizedState=s,t.baseQueue===null&&(t.baseState=s),a.lastRenderedState=s}return[s,i]}function dd(e,t,a){var i=be,n=Je(),s=Se;if(s){if(a===void 0)throw Error(d(407));a=a()}else a=t();var o=!Tt((Be||n).memoizedState,a);if(o&&(n.memoizedState=a,et=!0),n=n.queue,wr(md.bind(null,i,n,e),[e]),n.getSnapshot!==t||o||$e!==null&&$e.memoizedState.tag&1){if(i.flags|=2048,Kl(9,{destroy:void 0},fd.bind(null,i,n,a,t),null),Ge===null)throw Error(d(349));s||(ca&127)!==0||ud(i,t,a)}return a}function ud(e,t,a){e.flags|=16384,e={getSnapshot:t,value:a},t=be.updateQueue,t===null?(t=An(),be.updateQueue=t,t.stores=[e]):(a=t.stores,a===null?t.stores=[e]:a.push(e))}function fd(e,t,a,i){t.value=a,t.getSnapshot=i,xd(t)&&pd(e)}function md(e,t,a){return a(function(){xd(t)&&pd(e)})}function xd(e){var t=e.getSnapshot;e=e.value;try{var a=t();return!Tt(e,a)}catch{return!0}}function pd(e){var t=ll(e,2);t!==null&&St(t,e,2)}function Nr(e){var t=gt();if(typeof e=="function"){var a=e;if(e=a(),fl){Rt(!0);try{a()}finally{Rt(!1)}}}return t.memoizedState=t.baseState=e,t.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:da,lastRenderedState:e},t}function hd(e,t,a,i){return e.baseState=a,kr(e,Be,typeof i=="function"?i:da)}function kp(e,t,a,i,n){if(Rn(e))throw Error(d(485));if(e=t.action,e!==null){var s={payload:n,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(o){s.listeners.push(o)}};_.T!==null?a(!0):s.isTransition=!1,i(s),a=t.pending,a===null?(s.next=t.pending=s,gd(t,s)):(s.next=a.next,t.pending=a.next=s)}}function gd(e,t){var a=t.action,i=t.payload,n=e.state;if(t.isTransition){var s=_.T,o={};_.T=o;try{var c=a(n,i),u=_.S;u!==null&&u(o,c),bd(e,t,c)}catch(j){zr(e,t,j)}finally{s!==null&&o.types!==null&&(s.types=o.types),_.T=s}}else try{s=a(n,i),bd(e,t,s)}catch(j){zr(e,t,j)}}function bd(e,t,a){a!==null&&typeof a=="object"&&typeof a.then=="function"?a.then(function(i){yd(e,t,i)},function(i){return zr(e,t,i)}):yd(e,t,a)}function yd(e,t,a){t.status="fulfilled",t.value=a,vd(t),e.state=a,t=e.pending,t!==null&&(a=t.next,a===t?e.pending=null:(a=a.next,t.next=a,gd(e,a)))}function zr(e,t,a){var i=e.pending;if(e.pending=null,i!==null){i=i.next;do t.status="rejected",t.reason=a,vd(t),t=t.next;while(t!==i)}e.action=null}function vd(e){e=e.listeners;for(var t=0;t<e.length;t++)(0,e[t])()}function kd(e,t){return t}function jd(e,t){if(Se){var a=Ge.formState;if(a!==null){e:{var i=be;if(Se){if(Ie){t:{for(var n=Ie,s=It;n.nodeType!==8;){if(!s){n=null;break t}if(n=qt(n.nextSibling),n===null){n=null;break t}}s=n.data,n=s==="F!"||s==="F"?n:null}if(n){Ie=qt(n.nextSibling),i=n.data==="F!";break e}}Ta(i)}i=!1}i&&(t=a[0])}}return a=gt(),a.memoizedState=a.baseState=t,i={pending:null,lanes:0,dispatch:null,lastRenderedReducer:kd,lastRenderedState:t},a.queue=i,a=Gd.bind(null,be,i),i.dispatch=a,i=Nr(!1),s=Ar.bind(null,be,!1,i.queue),i=gt(),n={state:t,dispatch:null,action:e,pending:null},i.queue=n,a=kp.bind(null,be,n,s,a),n.dispatch=a,i.memoizedState=e,[t,a,!1]}function Nd(e){var t=Je();return zd(t,Be,e)}function zd(e,t,a){if(t=kr(e,t,kd)[0],e=Cn(da)[0],typeof t=="object"&&t!==null&&typeof t.then=="function")try{var i=_i(t)}catch(o){throw o===Ll?jn:o}else i=t;t=Je();var n=t.queue,s=n.dispatch;return a!==t.memoizedState&&(be.flags|=2048,Kl(9,{destroy:void 0},jp.bind(null,n,a),null)),[i,s,e]}function jp(e,t){e.action=t}function wd(e){var t=Je(),a=Be;if(a!==null)return zd(t,a,e);Je(),t=t.memoizedState,a=Je();var i=a.queue.dispatch;return a.memoizedState=e,[t,i,!1]}function Kl(e,t,a,i){return e={tag:e,create:a,deps:i,inst:t,next:null},t=be.updateQueue,t===null&&(t=An(),be.updateQueue=t),a=t.lastEffect,a===null?t.lastEffect=e.next=e:(i=a.next,a.next=e,e.next=i,t.lastEffect=e),e}function Sd(){return Je().memoizedState}function Dn(e,t,a,i){var n=gt();be.flags|=e,n.memoizedState=Kl(1|t,{destroy:void 0},a,i===void 0?null:i)}function Mn(e,t,a,i){var n=Je();i=i===void 0?null:i;var s=n.memoizedState.inst;Be!==null&&i!==null&&pr(i,Be.memoizedState.deps)?n.memoizedState=Kl(t,s,a,i):(be.flags|=e,n.memoizedState=Kl(1|t,s,a,i))}function Ed(e,t){Dn(8390656,8,e,t)}function wr(e,t){Mn(2048,8,e,t)}function Np(e){be.flags|=4;var t=be.updateQueue;if(t===null)t=An(),be.updateQueue=t,t.events=[e];else{var a=t.events;a===null?t.events=[e]:a.push(e)}}function Td(e){var t=Je().memoizedState;return Np({ref:t,nextImpl:e}),function(){if((De&2)!==0)throw Error(d(440));return t.impl.apply(void 0,arguments)}}function _d(e,t){return Mn(4,2,e,t)}function Ad(e,t){return Mn(4,4,e,t)}function Od(e,t){if(typeof t=="function"){e=e();var a=t(e);return function(){typeof a=="function"?a():t(null)}}if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function Cd(e,t,a){a=a!=null?a.concat([e]):null,Mn(4,4,Od.bind(null,t,e),a)}function Sr(){}function Dd(e,t){var a=Je();t=t===void 0?null:t;var i=a.memoizedState;return t!==null&&pr(t,i[1])?i[0]:(a.memoizedState=[e,t],e)}function Md(e,t){var a=Je();t=t===void 0?null:t;var i=a.memoizedState;if(t!==null&&pr(t,i[1]))return i[0];if(i=e(),fl){Rt(!0);try{e()}finally{Rt(!1)}}return a.memoizedState=[i,t],i}function Er(e,t,a){return a===void 0||(ca&1073741824)!==0&&(ze&261930)===0?e.memoizedState=t:(e.memoizedState=a,e=Ru(),be.lanes|=e,Ba|=e,a)}function Rd(e,t,a,i){return Tt(a,t)?a:Yl.current!==null?(e=Er(e,a,i),Tt(e,t)||(et=!0),e):(ca&42)===0||(ca&1073741824)!==0&&(ze&261930)===0?(et=!0,e.memoizedState=a):(e=Ru(),be.lanes|=e,Ba|=e,t)}function Ud(e,t,a,i,n){var s=y.p;y.p=s!==0&&8>s?s:8;var o=_.T,c={};_.T=c,Ar(e,!1,t,a);try{var u=n(),j=_.S;if(j!==null&&j(c,u),u!==null&&typeof u=="object"&&typeof u.then=="function"){var C=bp(u,i);Ai(e,t,C,Mt(e))}else Ai(e,t,i,Mt(e))}catch(R){Ai(e,t,{then:function(){},status:"rejected",reason:R},Mt())}finally{y.p=s,o!==null&&c.types!==null&&(o.types=c.types),_.T=o}}function zp(){}function Tr(e,t,a,i){if(e.tag!==5)throw Error(d(476));var n=Bd(e).queue;Ud(e,n,t,te,a===null?zp:function(){return Ld(e),a(i)})}function Bd(e){var t=e.memoizedState;if(t!==null)return t;t={memoizedState:te,baseState:te,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:da,lastRenderedState:te},next:null};var a={};return t.next={memoizedState:a,baseState:a,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:da,lastRenderedState:a},next:null},e.memoizedState=t,e=e.alternate,e!==null&&(e.memoizedState=t),t}function Ld(e){var t=Bd(e);t.next===null&&(t=e.alternate.memoizedState),Ai(e,t.next.queue,{},Mt())}function _r(){return ct(Qi)}function Hd(){return Je().memoizedState}function Yd(){return Je().memoizedState}function wp(e){for(var t=e.return;t!==null;){switch(t.tag){case 24:case 3:var a=Mt();e=Oa(a);var i=Ca(t,e,a);i!==null&&(St(i,t,a),wi(i,t,a)),t={cache:ir()},e.payload=t;return}t=t.return}}function Sp(e,t,a){var i=Mt();a={lane:i,revertLane:0,gesture:null,action:a,hasEagerState:!1,eagerState:null,next:null},Rn(e)?Id(t,a):(a=Qs(e,t,a,i),a!==null&&(St(a,e,i),Kd(a,t,i)))}function Gd(e,t,a){var i=Mt();Ai(e,t,a,i)}function Ai(e,t,a,i){var n={lane:i,revertLane:0,gesture:null,action:a,hasEagerState:!1,eagerState:null,next:null};if(Rn(e))Id(t,n);else{var s=e.alternate;if(e.lanes===0&&(s===null||s.lanes===0)&&(s=t.lastRenderedReducer,s!==null))try{var o=t.lastRenderedState,c=s(o,a);if(n.hasEagerState=!0,n.eagerState=c,Tt(c,o))return pn(e,t,n,0),Ge===null&&xn(),!1}catch{}finally{}if(a=Qs(e,t,n,i),a!==null)return St(a,e,i),Kd(a,t,i),!0}return!1}function Ar(e,t,a,i){if(i={lane:2,revertLane:oo(),gesture:null,action:i,hasEagerState:!1,eagerState:null,next:null},Rn(e)){if(t)throw Error(d(479))}else t=Qs(e,a,i,2),t!==null&&St(t,e,2)}function Rn(e){var t=e.alternate;return e===be||t!==null&&t===be}function Id(e,t){Gl=Tn=!0;var a=e.pending;a===null?t.next=t:(t.next=a.next,a.next=t),e.pending=t}function Kd(e,t,a){if((a&4194048)!==0){var i=t.lanes;i&=e.pendingLanes,a|=i,t.lanes=a,Zo(e,a)}}var Oi={readContext:ct,use:On,useCallback:Ve,useContext:Ve,useEffect:Ve,useImperativeHandle:Ve,useLayoutEffect:Ve,useInsertionEffect:Ve,useMemo:Ve,useReducer:Ve,useRef:Ve,useState:Ve,useDebugValue:Ve,useDeferredValue:Ve,useTransition:Ve,useSyncExternalStore:Ve,useId:Ve,useHostTransitionStatus:Ve,useFormState:Ve,useActionState:Ve,useOptimistic:Ve,useMemoCache:Ve,useCacheRefresh:Ve};Oi.useEffectEvent=Ve;var qd={readContext:ct,use:On,useCallback:function(e,t){return gt().memoizedState=[e,t===void 0?null:t],e},useContext:ct,useEffect:Ed,useImperativeHandle:function(e,t,a){a=a!=null?a.concat([e]):null,Dn(4194308,4,Od.bind(null,t,e),a)},useLayoutEffect:function(e,t){return Dn(4194308,4,e,t)},useInsertionEffect:function(e,t){Dn(4,2,e,t)},useMemo:function(e,t){var a=gt();t=t===void 0?null:t;var i=e();if(fl){Rt(!0);try{e()}finally{Rt(!1)}}return a.memoizedState=[i,t],i},useReducer:function(e,t,a){var i=gt();if(a!==void 0){var n=a(t);if(fl){Rt(!0);try{a(t)}finally{Rt(!1)}}}else n=t;return i.memoizedState=i.baseState=n,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:n},i.queue=e,e=e.dispatch=Sp.bind(null,be,e),[i.memoizedState,e]},useRef:function(e){var t=gt();return e={current:e},t.memoizedState=e},useState:function(e){e=Nr(e);var t=e.queue,a=Gd.bind(null,be,t);return t.dispatch=a,[e.memoizedState,a]},useDebugValue:Sr,useDeferredValue:function(e,t){var a=gt();return Er(a,e,t)},useTransition:function(){var e=Nr(!1);return e=Ud.bind(null,be,e.queue,!0,!1),gt().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,t,a){var i=be,n=gt();if(Se){if(a===void 0)throw Error(d(407));a=a()}else{if(a=t(),Ge===null)throw Error(d(349));(ze&127)!==0||ud(i,t,a)}n.memoizedState=a;var s={value:a,getSnapshot:t};return n.queue=s,Ed(md.bind(null,i,s,e),[e]),i.flags|=2048,Kl(9,{destroy:void 0},fd.bind(null,i,s,a,t),null),a},useId:function(){var e=gt(),t=Ge.identifierPrefix;if(Se){var a=Wt,i=Pt;a=(i&~(1<<32-mt(i)-1)).toString(32)+a,t="_"+t+"R_"+a,a=_n++,0<a&&(t+="H"+a.toString(32)),t+="_"}else a=yp++,t="_"+t+"r_"+a.toString(32)+"_";return e.memoizedState=t},useHostTransitionStatus:_r,useFormState:jd,useActionState:jd,useOptimistic:function(e){var t=gt();t.memoizedState=t.baseState=e;var a={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return t.queue=a,t=Ar.bind(null,be,!0,a),a.dispatch=t,[e,t]},useMemoCache:vr,useCacheRefresh:function(){return gt().memoizedState=wp.bind(null,be)},useEffectEvent:function(e){var t=gt(),a={impl:e};return t.memoizedState=a,function(){if((De&2)!==0)throw Error(d(440));return a.impl.apply(void 0,arguments)}}},Or={readContext:ct,use:On,useCallback:Dd,useContext:ct,useEffect:wr,useImperativeHandle:Cd,useInsertionEffect:_d,useLayoutEffect:Ad,useMemo:Md,useReducer:Cn,useRef:Sd,useState:function(){return Cn(da)},useDebugValue:Sr,useDeferredValue:function(e,t){var a=Je();return Rd(a,Be.memoizedState,e,t)},useTransition:function(){var e=Cn(da)[0],t=Je().memoizedState;return[typeof e=="boolean"?e:_i(e),t]},useSyncExternalStore:dd,useId:Hd,useHostTransitionStatus:_r,useFormState:Nd,useActionState:Nd,useOptimistic:function(e,t){var a=Je();return hd(a,Be,e,t)},useMemoCache:vr,useCacheRefresh:Yd};Or.useEffectEvent=Td;var Vd={readContext:ct,use:On,useCallback:Dd,useContext:ct,useEffect:wr,useImperativeHandle:Cd,useInsertionEffect:_d,useLayoutEffect:Ad,useMemo:Md,useReducer:jr,useRef:Sd,useState:function(){return jr(da)},useDebugValue:Sr,useDeferredValue:function(e,t){var a=Je();return Be===null?Er(a,e,t):Rd(a,Be.memoizedState,e,t)},useTransition:function(){var e=jr(da)[0],t=Je().memoizedState;return[typeof e=="boolean"?e:_i(e),t]},useSyncExternalStore:dd,useId:Hd,useHostTransitionStatus:_r,useFormState:wd,useActionState:wd,useOptimistic:function(e,t){var a=Je();return Be!==null?hd(a,Be,e,t):(a.baseState=e,[e,a.queue.dispatch])},useMemoCache:vr,useCacheRefresh:Yd};Vd.useEffectEvent=Td;function Cr(e,t,a,i){t=e.memoizedState,a=a(i,t),a=a==null?t:N({},t,a),e.memoizedState=a,e.lanes===0&&(e.updateQueue.baseState=a)}var Dr={enqueueSetState:function(e,t,a){e=e._reactInternals;var i=Mt(),n=Oa(i);n.payload=t,a!=null&&(n.callback=a),t=Ca(e,n,i),t!==null&&(St(t,e,i),wi(t,e,i))},enqueueReplaceState:function(e,t,a){e=e._reactInternals;var i=Mt(),n=Oa(i);n.tag=1,n.payload=t,a!=null&&(n.callback=a),t=Ca(e,n,i),t!==null&&(St(t,e,i),wi(t,e,i))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var a=Mt(),i=Oa(a);i.tag=2,t!=null&&(i.callback=t),t=Ca(e,i,a),t!==null&&(St(t,e,a),wi(t,e,a))}};function Xd(e,t,a,i,n,s,o){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(i,s,o):t.prototype&&t.prototype.isPureReactComponent?!gi(a,i)||!gi(n,s):!0}function Qd(e,t,a,i){e=t.state,typeof t.componentWillReceiveProps=="function"&&t.componentWillReceiveProps(a,i),typeof t.UNSAFE_componentWillReceiveProps=="function"&&t.UNSAFE_componentWillReceiveProps(a,i),t.state!==e&&Dr.enqueueReplaceState(t,t.state,null)}function ml(e,t){var a=t;if("ref"in t){a={};for(var i in t)i!=="ref"&&(a[i]=t[i])}if(e=e.defaultProps){a===t&&(a=N({},a));for(var n in e)a[n]===void 0&&(a[n]=e[n])}return a}function Zd(e){mn(e)}function Jd(e){console.error(e)}function Fd(e){mn(e)}function Un(e,t){try{var a=e.onUncaughtError;a(t.value,{componentStack:t.stack})}catch(i){setTimeout(function(){throw i})}}function Pd(e,t,a){try{var i=e.onCaughtError;i(a.value,{componentStack:a.stack,errorBoundary:t.tag===1?t.stateNode:null})}catch(n){setTimeout(function(){throw n})}}function Mr(e,t,a){return a=Oa(a),a.tag=3,a.payload={element:null},a.callback=function(){Un(e,t)},a}function Wd(e){return e=Oa(e),e.tag=3,e}function $d(e,t,a,i){var n=a.type.getDerivedStateFromError;if(typeof n=="function"){var s=i.value;e.payload=function(){return n(s)},e.callback=function(){Pd(t,a,i)}}var o=a.stateNode;o!==null&&typeof o.componentDidCatch=="function"&&(e.callback=function(){Pd(t,a,i),typeof n!="function"&&(La===null?La=new Set([this]):La.add(this));var c=i.stack;this.componentDidCatch(i.value,{componentStack:c!==null?c:""})})}function Ep(e,t,a,i,n){if(a.flags|=32768,i!==null&&typeof i=="object"&&typeof i.then=="function"){if(t=a.alternate,t!==null&&Rl(t,a,n,!0),a=At.current,a!==null){switch(a.tag){case 31:case 13:return Kt===null?Zn():a.alternate===null&&Xe===0&&(Xe=3),a.flags&=-257,a.flags|=65536,a.lanes=n,i===Nn?a.flags|=16384:(t=a.updateQueue,t===null?a.updateQueue=new Set([i]):t.add(i),no(e,i,n)),!1;case 22:return a.flags|=65536,i===Nn?a.flags|=16384:(t=a.updateQueue,t===null?(t={transitions:null,markerInstances:null,retryQueue:new Set([i])},a.updateQueue=t):(a=t.retryQueue,a===null?t.retryQueue=new Set([i]):a.add(i)),no(e,i,n)),!1}throw Error(d(435,a.tag))}return no(e,i,n),Zn(),!1}if(Se)return t=At.current,t!==null?((t.flags&65536)===0&&(t.flags|=256),t.flags|=65536,t.lanes=n,i!==$s&&(e=Error(d(422),{cause:i}),vi(Ht(e,a)))):(i!==$s&&(t=Error(d(423),{cause:i}),vi(Ht(t,a))),e=e.current.alternate,e.flags|=65536,n&=-n,e.lanes|=n,i=Ht(i,a),n=Mr(e.stateNode,i,n),dr(e,n),Xe!==4&&(Xe=2)),!1;var s=Error(d(520),{cause:i});if(s=Ht(s,a),Hi===null?Hi=[s]:Hi.push(s),Xe!==4&&(Xe=2),t===null)return!0;i=Ht(i,a),a=t;do{switch(a.tag){case 3:return a.flags|=65536,e=n&-n,a.lanes|=e,e=Mr(a.stateNode,i,e),dr(a,e),!1;case 1:if(t=a.type,s=a.stateNode,(a.flags&128)===0&&(typeof t.getDerivedStateFromError=="function"||s!==null&&typeof s.componentDidCatch=="function"&&(La===null||!La.has(s))))return a.flags|=65536,n&=-n,a.lanes|=n,n=Wd(n),$d(n,e,a,i),dr(a,n),!1}a=a.return}while(a!==null);return!1}var Rr=Error(d(461)),et=!1;function dt(e,t,a,i){t.child=e===null?ld(t,null,a,i):ul(t,e.child,a,i)}function eu(e,t,a,i,n){a=a.render;var s=t.ref;if("ref"in i){var o={};for(var c in i)c!=="ref"&&(o[c]=i[c])}else o=i;return rl(t),i=hr(e,t,a,o,s,n),c=gr(),e!==null&&!et?(br(e,t,n),ua(e,t,n)):(Se&&c&&Ps(t),t.flags|=1,dt(e,t,i,n),t.child)}function tu(e,t,a,i,n){if(e===null){var s=a.type;return typeof s=="function"&&!Zs(s)&&s.defaultProps===void 0&&a.compare===null?(t.tag=15,t.type=s,au(e,t,s,i,n)):(e=gn(a.type,null,i,t,t.mode,n),e.ref=t.ref,e.return=t,t.child=e)}if(s=e.child,!Kr(e,n)){var o=s.memoizedProps;if(a=a.compare,a=a!==null?a:gi,a(o,i)&&e.ref===t.ref)return ua(e,t,n)}return t.flags|=1,e=na(s,i),e.ref=t.ref,e.return=t,t.child=e}function au(e,t,a,i,n){if(e!==null){var s=e.memoizedProps;if(gi(s,i)&&e.ref===t.ref)if(et=!1,t.pendingProps=i=s,Kr(e,n))(e.flags&131072)!==0&&(et=!0);else return t.lanes=e.lanes,ua(e,t,n)}return Ur(e,t,a,i,n)}function lu(e,t,a,i){var n=i.children,s=e!==null?e.memoizedState:null;if(e===null&&t.stateNode===null&&(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),i.mode==="hidden"){if((t.flags&128)!==0){if(s=s!==null?s.baseLanes|a:a,e!==null){for(i=t.child=e.child,n=0;i!==null;)n=n|i.lanes|i.childLanes,i=i.sibling;i=n&~s}else i=0,t.child=null;return iu(e,t,s,a,i)}if((a&536870912)!==0)t.memoizedState={baseLanes:0,cachePool:null},e!==null&&kn(t,s!==null?s.cachePool:null),s!==null?sd(t,s):fr(),rd(t);else return i=t.lanes=536870912,iu(e,t,s!==null?s.baseLanes|a:a,a,i)}else s!==null?(kn(t,s.cachePool),sd(t,s),Ma(),t.memoizedState=null):(e!==null&&kn(t,null),fr(),Ma());return dt(e,t,n,a),t.child}function Ci(e,t){return e!==null&&e.tag===22||t.stateNode!==null||(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),t.sibling}function iu(e,t,a,i,n){var s=sr();return s=s===null?null:{parent:We._currentValue,pool:s},t.memoizedState={baseLanes:a,cachePool:s},e!==null&&kn(t,null),fr(),rd(t),e!==null&&Rl(e,t,i,!0),t.childLanes=n,null}function Bn(e,t){return t=Hn({mode:t.mode,children:t.children},e.mode),t.ref=e.ref,e.child=t,t.return=e,t}function nu(e,t,a){return ul(t,e.child,null,a),e=Bn(t,t.pendingProps),e.flags|=2,Ot(t),t.memoizedState=null,e}function Tp(e,t,a){var i=t.pendingProps,n=(t.flags&128)!==0;if(t.flags&=-129,e===null){if(Se){if(i.mode==="hidden")return e=Bn(t,i),t.lanes=536870912,Ci(null,e);if(xr(t),(e=Ie)?(e=bf(e,It),e=e!==null&&e.data==="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:Sa!==null?{id:Pt,overflow:Wt}:null,retryLane:536870912,hydrationErrors:null},a=Ic(e),a.return=t,t.child=a,ot=t,Ie=null)):e=null,e===null)throw Ta(t);return t.lanes=536870912,null}return Bn(t,i)}var s=e.memoizedState;if(s!==null){var o=s.dehydrated;if(xr(t),n)if(t.flags&256)t.flags&=-257,t=nu(e,t,a);else if(t.memoizedState!==null)t.child=e.child,t.flags|=128,t=null;else throw Error(d(558));else if(et||Rl(e,t,a,!1),n=(a&e.childLanes)!==0,et||n){if(i=Ge,i!==null&&(o=Jo(i,a),o!==0&&o!==s.retryLane))throw s.retryLane=o,ll(e,o),St(i,e,o),Rr;Zn(),t=nu(e,t,a)}else e=s.treeContext,Ie=qt(o.nextSibling),ot=t,Se=!0,Ea=null,It=!1,e!==null&&Vc(t,e),t=Bn(t,i),t.flags|=4096;return t}return e=na(e.child,{mode:i.mode,children:i.children}),e.ref=t.ref,t.child=e,e.return=t,e}function Ln(e,t){var a=t.ref;if(a===null)e!==null&&e.ref!==null&&(t.flags|=4194816);else{if(typeof a!="function"&&typeof a!="object")throw Error(d(284));(e===null||e.ref!==a)&&(t.flags|=4194816)}}function Ur(e,t,a,i,n){return rl(t),a=hr(e,t,a,i,void 0,n),i=gr(),e!==null&&!et?(br(e,t,n),ua(e,t,n)):(Se&&i&&Ps(t),t.flags|=1,dt(e,t,a,n),t.child)}function su(e,t,a,i,n,s){return rl(t),t.updateQueue=null,a=cd(t,i,a,n),od(e),i=gr(),e!==null&&!et?(br(e,t,s),ua(e,t,s)):(Se&&i&&Ps(t),t.flags|=1,dt(e,t,a,s),t.child)}function ru(e,t,a,i,n){if(rl(t),t.stateNode===null){var s=Ol,o=a.contextType;typeof o=="object"&&o!==null&&(s=ct(o)),s=new a(i,s),t.memoizedState=s.state!==null&&s.state!==void 0?s.state:null,s.updater=Dr,t.stateNode=s,s._reactInternals=t,s=t.stateNode,s.props=i,s.state=t.memoizedState,s.refs={},or(t),o=a.contextType,s.context=typeof o=="object"&&o!==null?ct(o):Ol,s.state=t.memoizedState,o=a.getDerivedStateFromProps,typeof o=="function"&&(Cr(t,a,o,i),s.state=t.memoizedState),typeof a.getDerivedStateFromProps=="function"||typeof s.getSnapshotBeforeUpdate=="function"||typeof s.UNSAFE_componentWillMount!="function"&&typeof s.componentWillMount!="function"||(o=s.state,typeof s.componentWillMount=="function"&&s.componentWillMount(),typeof s.UNSAFE_componentWillMount=="function"&&s.UNSAFE_componentWillMount(),o!==s.state&&Dr.enqueueReplaceState(s,s.state,null),Ei(t,i,s,n),Si(),s.state=t.memoizedState),typeof s.componentDidMount=="function"&&(t.flags|=4194308),i=!0}else if(e===null){s=t.stateNode;var c=t.memoizedProps,u=ml(a,c);s.props=u;var j=s.context,C=a.contextType;o=Ol,typeof C=="object"&&C!==null&&(o=ct(C));var R=a.getDerivedStateFromProps;C=typeof R=="function"||typeof s.getSnapshotBeforeUpdate=="function",c=t.pendingProps!==c,C||typeof s.UNSAFE_componentWillReceiveProps!="function"&&typeof s.componentWillReceiveProps!="function"||(c||j!==o)&&Qd(t,s,i,o),Aa=!1;var z=t.memoizedState;s.state=z,Ei(t,i,s,n),Si(),j=t.memoizedState,c||z!==j||Aa?(typeof R=="function"&&(Cr(t,a,R,i),j=t.memoizedState),(u=Aa||Xd(t,a,u,i,z,j,o))?(C||typeof s.UNSAFE_componentWillMount!="function"&&typeof s.componentWillMount!="function"||(typeof s.componentWillMount=="function"&&s.componentWillMount(),typeof s.UNSAFE_componentWillMount=="function"&&s.UNSAFE_componentWillMount()),typeof s.componentDidMount=="function"&&(t.flags|=4194308)):(typeof s.componentDidMount=="function"&&(t.flags|=4194308),t.memoizedProps=i,t.memoizedState=j),s.props=i,s.state=j,s.context=o,i=u):(typeof s.componentDidMount=="function"&&(t.flags|=4194308),i=!1)}else{s=t.stateNode,cr(e,t),o=t.memoizedProps,C=ml(a,o),s.props=C,R=t.pendingProps,z=s.context,j=a.contextType,u=Ol,typeof j=="object"&&j!==null&&(u=ct(j)),c=a.getDerivedStateFromProps,(j=typeof c=="function"||typeof s.getSnapshotBeforeUpdate=="function")||typeof s.UNSAFE_componentWillReceiveProps!="function"&&typeof s.componentWillReceiveProps!="function"||(o!==R||z!==u)&&Qd(t,s,i,u),Aa=!1,z=t.memoizedState,s.state=z,Ei(t,i,s,n),Si();var T=t.memoizedState;o!==R||z!==T||Aa||e!==null&&e.dependencies!==null&&yn(e.dependencies)?(typeof c=="function"&&(Cr(t,a,c,i),T=t.memoizedState),(C=Aa||Xd(t,a,C,i,z,T,u)||e!==null&&e.dependencies!==null&&yn(e.dependencies))?(j||typeof s.UNSAFE_componentWillUpdate!="function"&&typeof s.componentWillUpdate!="function"||(typeof s.componentWillUpdate=="function"&&s.componentWillUpdate(i,T,u),typeof s.UNSAFE_componentWillUpdate=="function"&&s.UNSAFE_componentWillUpdate(i,T,u)),typeof s.componentDidUpdate=="function"&&(t.flags|=4),typeof s.getSnapshotBeforeUpdate=="function"&&(t.flags|=1024)):(typeof s.componentDidUpdate!="function"||o===e.memoizedProps&&z===e.memoizedState||(t.flags|=4),typeof s.getSnapshotBeforeUpdate!="function"||o===e.memoizedProps&&z===e.memoizedState||(t.flags|=1024),t.memoizedProps=i,t.memoizedState=T),s.props=i,s.state=T,s.context=u,i=C):(typeof s.componentDidUpdate!="function"||o===e.memoizedProps&&z===e.memoizedState||(t.flags|=4),typeof s.getSnapshotBeforeUpdate!="function"||o===e.memoizedProps&&z===e.memoizedState||(t.flags|=1024),i=!1)}return s=i,Ln(e,t),i=(t.flags&128)!==0,s||i?(s=t.stateNode,a=i&&typeof a.getDerivedStateFromError!="function"?null:s.render(),t.flags|=1,e!==null&&i?(t.child=ul(t,e.child,null,n),t.child=ul(t,null,a,n)):dt(e,t,a,n),t.memoizedState=s.state,e=t.child):e=ua(e,t,n),e}function ou(e,t,a,i){return nl(),t.flags|=256,dt(e,t,a,i),t.child}var Br={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function Lr(e){return{baseLanes:e,cachePool:Pc()}}function Hr(e,t,a){return e=e!==null?e.childLanes&~a:0,t&&(e|=Dt),e}function cu(e,t,a){var i=t.pendingProps,n=!1,s=(t.flags&128)!==0,o;if((o=s)||(o=e!==null&&e.memoizedState===null?!1:(Ze.current&2)!==0),o&&(n=!0,t.flags&=-129),o=(t.flags&32)!==0,t.flags&=-33,e===null){if(Se){if(n?Da(t):Ma(),(e=Ie)?(e=bf(e,It),e=e!==null&&e.data!=="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:Sa!==null?{id:Pt,overflow:Wt}:null,retryLane:536870912,hydrationErrors:null},a=Ic(e),a.return=t,t.child=a,ot=t,Ie=null)):e=null,e===null)throw Ta(t);return jo(e)?t.lanes=32:t.lanes=536870912,null}var c=i.children;return i=i.fallback,n?(Ma(),n=t.mode,c=Hn({mode:"hidden",children:c},n),i=il(i,n,a,null),c.return=t,i.return=t,c.sibling=i,t.child=c,i=t.child,i.memoizedState=Lr(a),i.childLanes=Hr(e,o,a),t.memoizedState=Br,Ci(null,i)):(Da(t),Yr(t,c))}var u=e.memoizedState;if(u!==null&&(c=u.dehydrated,c!==null)){if(s)t.flags&256?(Da(t),t.flags&=-257,t=Gr(e,t,a)):t.memoizedState!==null?(Ma(),t.child=e.child,t.flags|=128,t=null):(Ma(),c=i.fallback,n=t.mode,i=Hn({mode:"visible",children:i.children},n),c=il(c,n,a,null),c.flags|=2,i.return=t,c.return=t,i.sibling=c,t.child=i,ul(t,e.child,null,a),i=t.child,i.memoizedState=Lr(a),i.childLanes=Hr(e,o,a),t.memoizedState=Br,t=Ci(null,i));else if(Da(t),jo(c)){if(o=c.nextSibling&&c.nextSibling.dataset,o)var j=o.dgst;o=j,i=Error(d(419)),i.stack="",i.digest=o,vi({value:i,source:null,stack:null}),t=Gr(e,t,a)}else if(et||Rl(e,t,a,!1),o=(a&e.childLanes)!==0,et||o){if(o=Ge,o!==null&&(i=Jo(o,a),i!==0&&i!==u.retryLane))throw u.retryLane=i,ll(e,i),St(o,e,i),Rr;ko(c)||Zn(),t=Gr(e,t,a)}else ko(c)?(t.flags|=192,t.child=e.child,t=null):(e=u.treeContext,Ie=qt(c.nextSibling),ot=t,Se=!0,Ea=null,It=!1,e!==null&&Vc(t,e),t=Yr(t,i.children),t.flags|=4096);return t}return n?(Ma(),c=i.fallback,n=t.mode,u=e.child,j=u.sibling,i=na(u,{mode:"hidden",children:i.children}),i.subtreeFlags=u.subtreeFlags&65011712,j!==null?c=na(j,c):(c=il(c,n,a,null),c.flags|=2),c.return=t,i.return=t,i.sibling=c,t.child=i,Ci(null,i),i=t.child,c=e.child.memoizedState,c===null?c=Lr(a):(n=c.cachePool,n!==null?(u=We._currentValue,n=n.parent!==u?{parent:u,pool:u}:n):n=Pc(),c={baseLanes:c.baseLanes|a,cachePool:n}),i.memoizedState=c,i.childLanes=Hr(e,o,a),t.memoizedState=Br,Ci(e.child,i)):(Da(t),a=e.child,e=a.sibling,a=na(a,{mode:"visible",children:i.children}),a.return=t,a.sibling=null,e!==null&&(o=t.deletions,o===null?(t.deletions=[e],t.flags|=16):o.push(e)),t.child=a,t.memoizedState=null,a)}function Yr(e,t){return t=Hn({mode:"visible",children:t},e.mode),t.return=e,e.child=t}function Hn(e,t){return e=_t(22,e,null,t),e.lanes=0,e}function Gr(e,t,a){return ul(t,e.child,null,a),e=Yr(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function du(e,t,a){e.lanes|=t;var i=e.alternate;i!==null&&(i.lanes|=t),ar(e.return,t,a)}function Ir(e,t,a,i,n,s){var o=e.memoizedState;o===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:i,tail:a,tailMode:n,treeForkCount:s}:(o.isBackwards=t,o.rendering=null,o.renderingStartTime=0,o.last=i,o.tail=a,o.tailMode=n,o.treeForkCount=s)}function uu(e,t,a){var i=t.pendingProps,n=i.revealOrder,s=i.tail;i=i.children;var o=Ze.current,c=(o&2)!==0;if(c?(o=o&1|2,t.flags|=128):o&=1,I(Ze,o),dt(e,t,i,a),i=Se?yi:0,!c&&e!==null&&(e.flags&128)!==0)e:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&du(e,a,t);else if(e.tag===19)du(e,a,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;e.sibling===null;){if(e.return===null||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(n){case"forwards":for(a=t.child,n=null;a!==null;)e=a.alternate,e!==null&&En(e)===null&&(n=a),a=a.sibling;a=n,a===null?(n=t.child,t.child=null):(n=a.sibling,a.sibling=null),Ir(t,!1,n,a,s,i);break;case"backwards":case"unstable_legacy-backwards":for(a=null,n=t.child,t.child=null;n!==null;){if(e=n.alternate,e!==null&&En(e)===null){t.child=n;break}e=n.sibling,n.sibling=a,a=n,n=e}Ir(t,!0,a,null,s,i);break;case"together":Ir(t,!1,null,null,void 0,i);break;default:t.memoizedState=null}return t.child}function ua(e,t,a){if(e!==null&&(t.dependencies=e.dependencies),Ba|=t.lanes,(a&t.childLanes)===0)if(e!==null){if(Rl(e,t,a,!1),(a&t.childLanes)===0)return null}else return null;if(e!==null&&t.child!==e.child)throw Error(d(153));if(t.child!==null){for(e=t.child,a=na(e,e.pendingProps),t.child=a,a.return=t;e.sibling!==null;)e=e.sibling,a=a.sibling=na(e,e.pendingProps),a.return=t;a.sibling=null}return t.child}function Kr(e,t){return(e.lanes&t)!==0?!0:(e=e.dependencies,!!(e!==null&&yn(e)))}function _p(e,t,a){switch(t.tag){case 3:ee(t,t.stateNode.containerInfo),_a(t,We,e.memoizedState.cache),nl();break;case 27:case 5:ke(t);break;case 4:ee(t,t.stateNode.containerInfo);break;case 10:_a(t,t.type,t.memoizedProps.value);break;case 31:if(t.memoizedState!==null)return t.flags|=128,xr(t),null;break;case 13:var i=t.memoizedState;if(i!==null)return i.dehydrated!==null?(Da(t),t.flags|=128,null):(a&t.child.childLanes)!==0?cu(e,t,a):(Da(t),e=ua(e,t,a),e!==null?e.sibling:null);Da(t);break;case 19:var n=(e.flags&128)!==0;if(i=(a&t.childLanes)!==0,i||(Rl(e,t,a,!1),i=(a&t.childLanes)!==0),n){if(i)return uu(e,t,a);t.flags|=128}if(n=t.memoizedState,n!==null&&(n.rendering=null,n.tail=null,n.lastEffect=null),I(Ze,Ze.current),i)break;return null;case 22:return t.lanes=0,lu(e,t,a,t.pendingProps);case 24:_a(t,We,e.memoizedState.cache)}return ua(e,t,a)}function fu(e,t,a){if(e!==null)if(e.memoizedProps!==t.pendingProps)et=!0;else{if(!Kr(e,a)&&(t.flags&128)===0)return et=!1,_p(e,t,a);et=(e.flags&131072)!==0}else et=!1,Se&&(t.flags&1048576)!==0&&qc(t,yi,t.index);switch(t.lanes=0,t.tag){case 16:e:{var i=t.pendingProps;if(e=cl(t.elementType),t.type=e,typeof e=="function")Zs(e)?(i=ml(e,i),t.tag=1,t=ru(null,t,e,i,a)):(t.tag=0,t=Ur(null,t,e,i,a));else{if(e!=null){var n=e.$$typeof;if(n===$){t.tag=11,t=eu(null,t,e,i,a);break e}else if(n===Q){t.tag=14,t=tu(null,t,e,i,a);break e}}throw t=ye(e)||e,Error(d(306,t,""))}}return t;case 0:return Ur(e,t,t.type,t.pendingProps,a);case 1:return i=t.type,n=ml(i,t.pendingProps),ru(e,t,i,n,a);case 3:e:{if(ee(t,t.stateNode.containerInfo),e===null)throw Error(d(387));i=t.pendingProps;var s=t.memoizedState;n=s.element,cr(e,t),Ei(t,i,null,a);var o=t.memoizedState;if(i=o.cache,_a(t,We,i),i!==s.cache&&lr(t,[We],a,!0),Si(),i=o.element,s.isDehydrated)if(s={element:i,isDehydrated:!1,cache:o.cache},t.updateQueue.baseState=s,t.memoizedState=s,t.flags&256){t=ou(e,t,i,a);break e}else if(i!==n){n=Ht(Error(d(424)),t),vi(n),t=ou(e,t,i,a);break e}else{switch(e=t.stateNode.containerInfo,e.nodeType){case 9:e=e.body;break;default:e=e.nodeName==="HTML"?e.ownerDocument.body:e}for(Ie=qt(e.firstChild),ot=t,Se=!0,Ea=null,It=!0,a=ld(t,null,i,a),t.child=a;a;)a.flags=a.flags&-3|4096,a=a.sibling}else{if(nl(),i===n){t=ua(e,t,a);break e}dt(e,t,i,a)}t=t.child}return t;case 26:return Ln(e,t),e===null?(a=zf(t.type,null,t.pendingProps,null))?t.memoizedState=a:Se||(a=t.type,e=t.pendingProps,i=ts(me.current).createElement(a),i[rt]=t,i[vt]=e,ut(i,a,e),it(i),t.stateNode=i):t.memoizedState=zf(t.type,e.memoizedProps,t.pendingProps,e.memoizedState),null;case 27:return ke(t),e===null&&Se&&(i=t.stateNode=kf(t.type,t.pendingProps,me.current),ot=t,It=!0,n=Ie,Ia(t.type)?(No=n,Ie=qt(i.firstChild)):Ie=n),dt(e,t,t.pendingProps.children,a),Ln(e,t),e===null&&(t.flags|=4194304),t.child;case 5:return e===null&&Se&&((n=i=Ie)&&(i=n0(i,t.type,t.pendingProps,It),i!==null?(t.stateNode=i,ot=t,Ie=qt(i.firstChild),It=!1,n=!0):n=!1),n||Ta(t)),ke(t),n=t.type,s=t.pendingProps,o=e!==null?e.memoizedProps:null,i=s.children,bo(n,s)?i=null:o!==null&&bo(n,o)&&(t.flags|=32),t.memoizedState!==null&&(n=hr(e,t,vp,null,null,a),Qi._currentValue=n),Ln(e,t),dt(e,t,i,a),t.child;case 6:return e===null&&Se&&((e=a=Ie)&&(a=s0(a,t.pendingProps,It),a!==null?(t.stateNode=a,ot=t,Ie=null,e=!0):e=!1),e||Ta(t)),null;case 13:return cu(e,t,a);case 4:return ee(t,t.stateNode.containerInfo),i=t.pendingProps,e===null?t.child=ul(t,null,i,a):dt(e,t,i,a),t.child;case 11:return eu(e,t,t.type,t.pendingProps,a);case 7:return dt(e,t,t.pendingProps,a),t.child;case 8:return dt(e,t,t.pendingProps.children,a),t.child;case 12:return dt(e,t,t.pendingProps.children,a),t.child;case 10:return i=t.pendingProps,_a(t,t.type,i.value),dt(e,t,i.children,a),t.child;case 9:return n=t.type._context,i=t.pendingProps.children,rl(t),n=ct(n),i=i(n),t.flags|=1,dt(e,t,i,a),t.child;case 14:return tu(e,t,t.type,t.pendingProps,a);case 15:return au(e,t,t.type,t.pendingProps,a);case 19:return uu(e,t,a);case 31:return Tp(e,t,a);case 22:return lu(e,t,a,t.pendingProps);case 24:return rl(t),i=ct(We),e===null?(n=sr(),n===null&&(n=Ge,s=ir(),n.pooledCache=s,s.refCount++,s!==null&&(n.pooledCacheLanes|=a),n=s),t.memoizedState={parent:i,cache:n},or(t),_a(t,We,n)):((e.lanes&a)!==0&&(cr(e,t),Ei(t,null,null,a),Si()),n=e.memoizedState,s=t.memoizedState,n.parent!==i?(n={parent:i,cache:i},t.memoizedState=n,t.lanes===0&&(t.memoizedState=t.updateQueue.baseState=n),_a(t,We,i)):(i=s.cache,_a(t,We,i),i!==n.cache&&lr(t,[We],a,!0))),dt(e,t,t.pendingProps.children,a),t.child;case 29:throw t.pendingProps}throw Error(d(156,t.tag))}function fa(e){e.flags|=4}function qr(e,t,a,i,n){if((t=(e.mode&32)!==0)&&(t=!1),t){if(e.flags|=16777216,(n&335544128)===n)if(e.stateNode.complete)e.flags|=8192;else if(Hu())e.flags|=8192;else throw dl=Nn,rr}else e.flags&=-16777217}function mu(e,t){if(t.type!=="stylesheet"||(t.state.loading&4)!==0)e.flags&=-16777217;else if(e.flags|=16777216,!_f(t))if(Hu())e.flags|=8192;else throw dl=Nn,rr}function Yn(e,t){t!==null&&(e.flags|=4),e.flags&16384&&(t=e.tag!==22?vs():536870912,e.lanes|=t,Ql|=t)}function Di(e,t){if(!Se)switch(e.tailMode){case"hidden":t=e.tail;for(var a=null;t!==null;)t.alternate!==null&&(a=t),t=t.sibling;a===null?e.tail=null:a.sibling=null;break;case"collapsed":a=e.tail;for(var i=null;a!==null;)a.alternate!==null&&(i=a),a=a.sibling;i===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:i.sibling=null}}function Ke(e){var t=e.alternate!==null&&e.alternate.child===e.child,a=0,i=0;if(t)for(var n=e.child;n!==null;)a|=n.lanes|n.childLanes,i|=n.subtreeFlags&65011712,i|=n.flags&65011712,n.return=e,n=n.sibling;else for(n=e.child;n!==null;)a|=n.lanes|n.childLanes,i|=n.subtreeFlags,i|=n.flags,n.return=e,n=n.sibling;return e.subtreeFlags|=i,e.childLanes=a,t}function Ap(e,t,a){var i=t.pendingProps;switch(Ws(t),t.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return Ke(t),null;case 1:return Ke(t),null;case 3:return a=t.stateNode,i=null,e!==null&&(i=e.memoizedState.cache),t.memoizedState.cache!==i&&(t.flags|=2048),oa(We),P(),a.pendingContext&&(a.context=a.pendingContext,a.pendingContext=null),(e===null||e.child===null)&&(Ml(t)?fa(t):e===null||e.memoizedState.isDehydrated&&(t.flags&256)===0||(t.flags|=1024,er())),Ke(t),null;case 26:var n=t.type,s=t.memoizedState;return e===null?(fa(t),s!==null?(Ke(t),mu(t,s)):(Ke(t),qr(t,n,null,i,a))):s?s!==e.memoizedState?(fa(t),Ke(t),mu(t,s)):(Ke(t),t.flags&=-16777217):(e=e.memoizedProps,e!==i&&fa(t),Ke(t),qr(t,n,e,i,a)),null;case 27:if(Qe(t),a=me.current,n=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==i&&fa(t);else{if(!i){if(t.stateNode===null)throw Error(d(166));return Ke(t),null}e=V.current,Ml(t)?Xc(t):(e=kf(n,i,a),t.stateNode=e,fa(t))}return Ke(t),null;case 5:if(Qe(t),n=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==i&&fa(t);else{if(!i){if(t.stateNode===null)throw Error(d(166));return Ke(t),null}if(s=V.current,Ml(t))Xc(t);else{var o=ts(me.current);switch(s){case 1:s=o.createElementNS("http://www.w3.org/2000/svg",n);break;case 2:s=o.createElementNS("http://www.w3.org/1998/Math/MathML",n);break;default:switch(n){case"svg":s=o.createElementNS("http://www.w3.org/2000/svg",n);break;case"math":s=o.createElementNS("http://www.w3.org/1998/Math/MathML",n);break;case"script":s=o.createElement("div"),s.innerHTML="<script><\/script>",s=s.removeChild(s.firstChild);break;case"select":s=typeof i.is=="string"?o.createElement("select",{is:i.is}):o.createElement("select"),i.multiple?s.multiple=!0:i.size&&(s.size=i.size);break;default:s=typeof i.is=="string"?o.createElement(n,{is:i.is}):o.createElement(n)}}s[rt]=t,s[vt]=i;e:for(o=t.child;o!==null;){if(o.tag===5||o.tag===6)s.appendChild(o.stateNode);else if(o.tag!==4&&o.tag!==27&&o.child!==null){o.child.return=o,o=o.child;continue}if(o===t)break e;for(;o.sibling===null;){if(o.return===null||o.return===t)break e;o=o.return}o.sibling.return=o.return,o=o.sibling}t.stateNode=s;e:switch(ut(s,n,i),n){case"button":case"input":case"select":case"textarea":i=!!i.autoFocus;break e;case"img":i=!0;break e;default:i=!1}i&&fa(t)}}return Ke(t),qr(t,t.type,e===null?null:e.memoizedProps,t.pendingProps,a),null;case 6:if(e&&t.stateNode!=null)e.memoizedProps!==i&&fa(t);else{if(typeof i!="string"&&t.stateNode===null)throw Error(d(166));if(e=me.current,Ml(t)){if(e=t.stateNode,a=t.memoizedProps,i=null,n=ot,n!==null)switch(n.tag){case 27:case 5:i=n.memoizedProps}e[rt]=t,e=!!(e.nodeValue===a||i!==null&&i.suppressHydrationWarning===!0||df(e.nodeValue,a)),e||Ta(t,!0)}else e=ts(e).createTextNode(i),e[rt]=t,t.stateNode=e}return Ke(t),null;case 31:if(a=t.memoizedState,e===null||e.memoizedState!==null){if(i=Ml(t),a!==null){if(e===null){if(!i)throw Error(d(318));if(e=t.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(d(557));e[rt]=t}else nl(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;Ke(t),e=!1}else a=er(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=a),e=!0;if(!e)return t.flags&256?(Ot(t),t):(Ot(t),null);if((t.flags&128)!==0)throw Error(d(558))}return Ke(t),null;case 13:if(i=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(n=Ml(t),i!==null&&i.dehydrated!==null){if(e===null){if(!n)throw Error(d(318));if(n=t.memoizedState,n=n!==null?n.dehydrated:null,!n)throw Error(d(317));n[rt]=t}else nl(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;Ke(t),n=!1}else n=er(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=n),n=!0;if(!n)return t.flags&256?(Ot(t),t):(Ot(t),null)}return Ot(t),(t.flags&128)!==0?(t.lanes=a,t):(a=i!==null,e=e!==null&&e.memoizedState!==null,a&&(i=t.child,n=null,i.alternate!==null&&i.alternate.memoizedState!==null&&i.alternate.memoizedState.cachePool!==null&&(n=i.alternate.memoizedState.cachePool.pool),s=null,i.memoizedState!==null&&i.memoizedState.cachePool!==null&&(s=i.memoizedState.cachePool.pool),s!==n&&(i.flags|=2048)),a!==e&&a&&(t.child.flags|=8192),Yn(t,t.updateQueue),Ke(t),null);case 4:return P(),e===null&&mo(t.stateNode.containerInfo),Ke(t),null;case 10:return oa(t.type),Ke(t),null;case 19:if(D(Ze),i=t.memoizedState,i===null)return Ke(t),null;if(n=(t.flags&128)!==0,s=i.rendering,s===null)if(n)Di(i,!1);else{if(Xe!==0||e!==null&&(e.flags&128)!==0)for(e=t.child;e!==null;){if(s=En(e),s!==null){for(t.flags|=128,Di(i,!1),e=s.updateQueue,t.updateQueue=e,Yn(t,e),t.subtreeFlags=0,e=a,a=t.child;a!==null;)Gc(a,e),a=a.sibling;return I(Ze,Ze.current&1|2),Se&&sa(t,i.treeForkCount),t.child}e=e.sibling}i.tail!==null&&xe()>Vn&&(t.flags|=128,n=!0,Di(i,!1),t.lanes=4194304)}else{if(!n)if(e=En(s),e!==null){if(t.flags|=128,n=!0,e=e.updateQueue,t.updateQueue=e,Yn(t,e),Di(i,!0),i.tail===null&&i.tailMode==="hidden"&&!s.alternate&&!Se)return Ke(t),null}else 2*xe()-i.renderingStartTime>Vn&&a!==536870912&&(t.flags|=128,n=!0,Di(i,!1),t.lanes=4194304);i.isBackwards?(s.sibling=t.child,t.child=s):(e=i.last,e!==null?e.sibling=s:t.child=s,i.last=s)}return i.tail!==null?(e=i.tail,i.rendering=e,i.tail=e.sibling,i.renderingStartTime=xe(),e.sibling=null,a=Ze.current,I(Ze,n?a&1|2:a&1),Se&&sa(t,i.treeForkCount),e):(Ke(t),null);case 22:case 23:return Ot(t),mr(),i=t.memoizedState!==null,e!==null?e.memoizedState!==null!==i&&(t.flags|=8192):i&&(t.flags|=8192),i?(a&536870912)!==0&&(t.flags&128)===0&&(Ke(t),t.subtreeFlags&6&&(t.flags|=8192)):Ke(t),a=t.updateQueue,a!==null&&Yn(t,a.retryQueue),a=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(a=e.memoizedState.cachePool.pool),i=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(i=t.memoizedState.cachePool.pool),i!==a&&(t.flags|=2048),e!==null&&D(ol),null;case 24:return a=null,e!==null&&(a=e.memoizedState.cache),t.memoizedState.cache!==a&&(t.flags|=2048),oa(We),Ke(t),null;case 25:return null;case 30:return null}throw Error(d(156,t.tag))}function Op(e,t){switch(Ws(t),t.tag){case 1:return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return oa(We),P(),e=t.flags,(e&65536)!==0&&(e&128)===0?(t.flags=e&-65537|128,t):null;case 26:case 27:case 5:return Qe(t),null;case 31:if(t.memoizedState!==null){if(Ot(t),t.alternate===null)throw Error(d(340));nl()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 13:if(Ot(t),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(d(340));nl()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return D(Ze),null;case 4:return P(),null;case 10:return oa(t.type),null;case 22:case 23:return Ot(t),mr(),e!==null&&D(ol),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 24:return oa(We),null;case 25:return null;default:return null}}function xu(e,t){switch(Ws(t),t.tag){case 3:oa(We),P();break;case 26:case 27:case 5:Qe(t);break;case 4:P();break;case 31:t.memoizedState!==null&&Ot(t);break;case 13:Ot(t);break;case 19:D(Ze);break;case 10:oa(t.type);break;case 22:case 23:Ot(t),mr(),e!==null&&D(ol);break;case 24:oa(We)}}function Mi(e,t){try{var a=t.updateQueue,i=a!==null?a.lastEffect:null;if(i!==null){var n=i.next;a=n;do{if((a.tag&e)===e){i=void 0;var s=a.create,o=a.inst;i=s(),o.destroy=i}a=a.next}while(a!==n)}}catch(c){Ue(t,t.return,c)}}function Ra(e,t,a){try{var i=t.updateQueue,n=i!==null?i.lastEffect:null;if(n!==null){var s=n.next;i=s;do{if((i.tag&e)===e){var o=i.inst,c=o.destroy;if(c!==void 0){o.destroy=void 0,n=t;var u=a,j=c;try{j()}catch(C){Ue(n,u,C)}}}i=i.next}while(i!==s)}}catch(C){Ue(t,t.return,C)}}function pu(e){var t=e.updateQueue;if(t!==null){var a=e.stateNode;try{nd(t,a)}catch(i){Ue(e,e.return,i)}}}function hu(e,t,a){a.props=ml(e.type,e.memoizedProps),a.state=e.memoizedState;try{a.componentWillUnmount()}catch(i){Ue(e,t,i)}}function Ri(e,t){try{var a=e.ref;if(a!==null){switch(e.tag){case 26:case 27:case 5:var i=e.stateNode;break;case 30:i=e.stateNode;break;default:i=e.stateNode}typeof a=="function"?e.refCleanup=a(i):a.current=i}}catch(n){Ue(e,t,n)}}function $t(e,t){var a=e.ref,i=e.refCleanup;if(a!==null)if(typeof i=="function")try{i()}catch(n){Ue(e,t,n)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof a=="function")try{a(null)}catch(n){Ue(e,t,n)}else a.current=null}function gu(e){var t=e.type,a=e.memoizedProps,i=e.stateNode;try{e:switch(t){case"button":case"input":case"select":case"textarea":a.autoFocus&&i.focus();break e;case"img":a.src?i.src=a.src:a.srcSet&&(i.srcset=a.srcSet)}}catch(n){Ue(e,e.return,n)}}function Vr(e,t,a){try{var i=e.stateNode;$p(i,e.type,a,t),i[vt]=t}catch(n){Ue(e,e.return,n)}}function bu(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&Ia(e.type)||e.tag===4}function Xr(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||bu(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&Ia(e.type)||e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function Qr(e,t,a){var i=e.tag;if(i===5||i===6)e=e.stateNode,t?(a.nodeType===9?a.body:a.nodeName==="HTML"?a.ownerDocument.body:a).insertBefore(e,t):(t=a.nodeType===9?a.body:a.nodeName==="HTML"?a.ownerDocument.body:a,t.appendChild(e),a=a._reactRootContainer,a!=null||t.onclick!==null||(t.onclick=la));else if(i!==4&&(i===27&&Ia(e.type)&&(a=e.stateNode,t=null),e=e.child,e!==null))for(Qr(e,t,a),e=e.sibling;e!==null;)Qr(e,t,a),e=e.sibling}function Gn(e,t,a){var i=e.tag;if(i===5||i===6)e=e.stateNode,t?a.insertBefore(e,t):a.appendChild(e);else if(i!==4&&(i===27&&Ia(e.type)&&(a=e.stateNode),e=e.child,e!==null))for(Gn(e,t,a),e=e.sibling;e!==null;)Gn(e,t,a),e=e.sibling}function yu(e){var t=e.stateNode,a=e.memoizedProps;try{for(var i=e.type,n=t.attributes;n.length;)t.removeAttributeNode(n[0]);ut(t,i,a),t[rt]=e,t[vt]=a}catch(s){Ue(e,e.return,s)}}var ma=!1,tt=!1,Zr=!1,vu=typeof WeakSet=="function"?WeakSet:Set,nt=null;function Cp(e,t){if(e=e.containerInfo,ho=os,e=Cc(e),Gs(e)){if("selectionStart"in e)var a={start:e.selectionStart,end:e.selectionEnd};else e:{a=(a=e.ownerDocument)&&a.defaultView||window;var i=a.getSelection&&a.getSelection();if(i&&i.rangeCount!==0){a=i.anchorNode;var n=i.anchorOffset,s=i.focusNode;i=i.focusOffset;try{a.nodeType,s.nodeType}catch{a=null;break e}var o=0,c=-1,u=-1,j=0,C=0,R=e,z=null;t:for(;;){for(var T;R!==a||n!==0&&R.nodeType!==3||(c=o+n),R!==s||i!==0&&R.nodeType!==3||(u=o+i),R.nodeType===3&&(o+=R.nodeValue.length),(T=R.firstChild)!==null;)z=R,R=T;for(;;){if(R===e)break t;if(z===a&&++j===n&&(c=o),z===s&&++C===i&&(u=o),(T=R.nextSibling)!==null)break;R=z,z=R.parentNode}R=T}a=c===-1||u===-1?null:{start:c,end:u}}else a=null}a=a||{start:0,end:0}}else a=null;for(go={focusedElem:e,selectionRange:a},os=!1,nt=t;nt!==null;)if(t=nt,e=t.child,(t.subtreeFlags&1028)!==0&&e!==null)e.return=t,nt=e;else for(;nt!==null;){switch(t=nt,s=t.alternate,e=t.flags,t.tag){case 0:if((e&4)!==0&&(e=t.updateQueue,e=e!==null?e.events:null,e!==null))for(a=0;a<e.length;a++)n=e[a],n.ref.impl=n.nextImpl;break;case 11:case 15:break;case 1:if((e&1024)!==0&&s!==null){e=void 0,a=t,n=s.memoizedProps,s=s.memoizedState,i=a.stateNode;try{var F=ml(a.type,n);e=i.getSnapshotBeforeUpdate(F,s),i.__reactInternalSnapshotBeforeUpdate=e}catch(se){Ue(a,a.return,se)}}break;case 3:if((e&1024)!==0){if(e=t.stateNode.containerInfo,a=e.nodeType,a===9)vo(e);else if(a===1)switch(e.nodeName){case"HEAD":case"HTML":case"BODY":vo(e);break;default:e.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((e&1024)!==0)throw Error(d(163))}if(e=t.sibling,e!==null){e.return=t.return,nt=e;break}nt=t.return}}function ku(e,t,a){var i=a.flags;switch(a.tag){case 0:case 11:case 15:pa(e,a),i&4&&Mi(5,a);break;case 1:if(pa(e,a),i&4)if(e=a.stateNode,t===null)try{e.componentDidMount()}catch(o){Ue(a,a.return,o)}else{var n=ml(a.type,t.memoizedProps);t=t.memoizedState;try{e.componentDidUpdate(n,t,e.__reactInternalSnapshotBeforeUpdate)}catch(o){Ue(a,a.return,o)}}i&64&&pu(a),i&512&&Ri(a,a.return);break;case 3:if(pa(e,a),i&64&&(e=a.updateQueue,e!==null)){if(t=null,a.child!==null)switch(a.child.tag){case 27:case 5:t=a.child.stateNode;break;case 1:t=a.child.stateNode}try{nd(e,t)}catch(o){Ue(a,a.return,o)}}break;case 27:t===null&&i&4&&yu(a);case 26:case 5:pa(e,a),t===null&&i&4&&gu(a),i&512&&Ri(a,a.return);break;case 12:pa(e,a);break;case 31:pa(e,a),i&4&&zu(e,a);break;case 13:pa(e,a),i&4&&wu(e,a),i&64&&(e=a.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(a=Gp.bind(null,a),r0(e,a))));break;case 22:if(i=a.memoizedState!==null||ma,!i){t=t!==null&&t.memoizedState!==null||tt,n=ma;var s=tt;ma=i,(tt=t)&&!s?ha(e,a,(a.subtreeFlags&8772)!==0):pa(e,a),ma=n,tt=s}break;case 30:break;default:pa(e,a)}}function ju(e){var t=e.alternate;t!==null&&(e.alternate=null,ju(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&zs(t)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var qe=null,jt=!1;function xa(e,t,a){for(a=a.child;a!==null;)Nu(e,t,a),a=a.sibling}function Nu(e,t,a){if(ht&&typeof ht.onCommitFiberUnmount=="function")try{ht.onCommitFiberUnmount(Ja,a)}catch{}switch(a.tag){case 26:tt||$t(a,t),xa(e,t,a),a.memoizedState?a.memoizedState.count--:a.stateNode&&(a=a.stateNode,a.parentNode.removeChild(a));break;case 27:tt||$t(a,t);var i=qe,n=jt;Ia(a.type)&&(qe=a.stateNode,jt=!1),xa(e,t,a),qi(a.stateNode),qe=i,jt=n;break;case 5:tt||$t(a,t);case 6:if(i=qe,n=jt,qe=null,xa(e,t,a),qe=i,jt=n,qe!==null)if(jt)try{(qe.nodeType===9?qe.body:qe.nodeName==="HTML"?qe.ownerDocument.body:qe).removeChild(a.stateNode)}catch(s){Ue(a,t,s)}else try{qe.removeChild(a.stateNode)}catch(s){Ue(a,t,s)}break;case 18:qe!==null&&(jt?(e=qe,hf(e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,a.stateNode),ti(e)):hf(qe,a.stateNode));break;case 4:i=qe,n=jt,qe=a.stateNode.containerInfo,jt=!0,xa(e,t,a),qe=i,jt=n;break;case 0:case 11:case 14:case 15:Ra(2,a,t),tt||Ra(4,a,t),xa(e,t,a);break;case 1:tt||($t(a,t),i=a.stateNode,typeof i.componentWillUnmount=="function"&&hu(a,t,i)),xa(e,t,a);break;case 21:xa(e,t,a);break;case 22:tt=(i=tt)||a.memoizedState!==null,xa(e,t,a),tt=i;break;default:xa(e,t,a)}}function zu(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{ti(e)}catch(a){Ue(t,t.return,a)}}}function wu(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{ti(e)}catch(a){Ue(t,t.return,a)}}function Dp(e){switch(e.tag){case 31:case 13:case 19:var t=e.stateNode;return t===null&&(t=e.stateNode=new vu),t;case 22:return e=e.stateNode,t=e._retryCache,t===null&&(t=e._retryCache=new vu),t;default:throw Error(d(435,e.tag))}}function In(e,t){var a=Dp(e);t.forEach(function(i){if(!a.has(i)){a.add(i);var n=Ip.bind(null,e,i);i.then(n,n)}})}function Nt(e,t){var a=t.deletions;if(a!==null)for(var i=0;i<a.length;i++){var n=a[i],s=e,o=t,c=o;e:for(;c!==null;){switch(c.tag){case 27:if(Ia(c.type)){qe=c.stateNode,jt=!1;break e}break;case 5:qe=c.stateNode,jt=!1;break e;case 3:case 4:qe=c.stateNode.containerInfo,jt=!0;break e}c=c.return}if(qe===null)throw Error(d(160));Nu(s,o,n),qe=null,jt=!1,s=n.alternate,s!==null&&(s.return=null),n.return=null}if(t.subtreeFlags&13886)for(t=t.child;t!==null;)Su(t,e),t=t.sibling}var Zt=null;function Su(e,t){var a=e.alternate,i=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:Nt(t,e),zt(e),i&4&&(Ra(3,e,e.return),Mi(3,e),Ra(5,e,e.return));break;case 1:Nt(t,e),zt(e),i&512&&(tt||a===null||$t(a,a.return)),i&64&&ma&&(e=e.updateQueue,e!==null&&(i=e.callbacks,i!==null&&(a=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=a===null?i:a.concat(i))));break;case 26:var n=Zt;if(Nt(t,e),zt(e),i&512&&(tt||a===null||$t(a,a.return)),i&4){var s=a!==null?a.memoizedState:null;if(i=e.memoizedState,a===null)if(i===null)if(e.stateNode===null){e:{i=e.type,a=e.memoizedProps,n=n.ownerDocument||n;t:switch(i){case"title":s=n.getElementsByTagName("title")[0],(!s||s[oi]||s[rt]||s.namespaceURI==="http://www.w3.org/2000/svg"||s.hasAttribute("itemprop"))&&(s=n.createElement(i),n.head.insertBefore(s,n.querySelector("head > title"))),ut(s,i,a),s[rt]=e,it(s),i=s;break e;case"link":var o=Ef("link","href",n).get(i+(a.href||""));if(o){for(var c=0;c<o.length;c++)if(s=o[c],s.getAttribute("href")===(a.href==null||a.href===""?null:a.href)&&s.getAttribute("rel")===(a.rel==null?null:a.rel)&&s.getAttribute("title")===(a.title==null?null:a.title)&&s.getAttribute("crossorigin")===(a.crossOrigin==null?null:a.crossOrigin)){o.splice(c,1);break t}}s=n.createElement(i),ut(s,i,a),n.head.appendChild(s);break;case"meta":if(o=Ef("meta","content",n).get(i+(a.content||""))){for(c=0;c<o.length;c++)if(s=o[c],s.getAttribute("content")===(a.content==null?null:""+a.content)&&s.getAttribute("name")===(a.name==null?null:a.name)&&s.getAttribute("property")===(a.property==null?null:a.property)&&s.getAttribute("http-equiv")===(a.httpEquiv==null?null:a.httpEquiv)&&s.getAttribute("charset")===(a.charSet==null?null:a.charSet)){o.splice(c,1);break t}}s=n.createElement(i),ut(s,i,a),n.head.appendChild(s);break;default:throw Error(d(468,i))}s[rt]=e,it(s),i=s}e.stateNode=i}else Tf(n,e.type,e.stateNode);else e.stateNode=Sf(n,i,e.memoizedProps);else s!==i?(s===null?a.stateNode!==null&&(a=a.stateNode,a.parentNode.removeChild(a)):s.count--,i===null?Tf(n,e.type,e.stateNode):Sf(n,i,e.memoizedProps)):i===null&&e.stateNode!==null&&Vr(e,e.memoizedProps,a.memoizedProps)}break;case 27:Nt(t,e),zt(e),i&512&&(tt||a===null||$t(a,a.return)),a!==null&&i&4&&Vr(e,e.memoizedProps,a.memoizedProps);break;case 5:if(Nt(t,e),zt(e),i&512&&(tt||a===null||$t(a,a.return)),e.flags&32){n=e.stateNode;try{zl(n,"")}catch(F){Ue(e,e.return,F)}}i&4&&e.stateNode!=null&&(n=e.memoizedProps,Vr(e,n,a!==null?a.memoizedProps:n)),i&1024&&(Zr=!0);break;case 6:if(Nt(t,e),zt(e),i&4){if(e.stateNode===null)throw Error(d(162));i=e.memoizedProps,a=e.stateNode;try{a.nodeValue=i}catch(F){Ue(e,e.return,F)}}break;case 3:if(is=null,n=Zt,Zt=as(t.containerInfo),Nt(t,e),Zt=n,zt(e),i&4&&a!==null&&a.memoizedState.isDehydrated)try{ti(t.containerInfo)}catch(F){Ue(e,e.return,F)}Zr&&(Zr=!1,Eu(e));break;case 4:i=Zt,Zt=as(e.stateNode.containerInfo),Nt(t,e),zt(e),Zt=i;break;case 12:Nt(t,e),zt(e);break;case 31:Nt(t,e),zt(e),i&4&&(i=e.updateQueue,i!==null&&(e.updateQueue=null,In(e,i)));break;case 13:Nt(t,e),zt(e),e.child.flags&8192&&e.memoizedState!==null!=(a!==null&&a.memoizedState!==null)&&(qn=xe()),i&4&&(i=e.updateQueue,i!==null&&(e.updateQueue=null,In(e,i)));break;case 22:n=e.memoizedState!==null;var u=a!==null&&a.memoizedState!==null,j=ma,C=tt;if(ma=j||n,tt=C||u,Nt(t,e),tt=C,ma=j,zt(e),i&8192)e:for(t=e.stateNode,t._visibility=n?t._visibility&-2:t._visibility|1,n&&(a===null||u||ma||tt||xl(e)),a=null,t=e;;){if(t.tag===5||t.tag===26){if(a===null){u=a=t;try{if(s=u.stateNode,n)o=s.style,typeof o.setProperty=="function"?o.setProperty("display","none","important"):o.display="none";else{c=u.stateNode;var R=u.memoizedProps.style,z=R!=null&&R.hasOwnProperty("display")?R.display:null;c.style.display=z==null||typeof z=="boolean"?"":(""+z).trim()}}catch(F){Ue(u,u.return,F)}}}else if(t.tag===6){if(a===null){u=t;try{u.stateNode.nodeValue=n?"":u.memoizedProps}catch(F){Ue(u,u.return,F)}}}else if(t.tag===18){if(a===null){u=t;try{var T=u.stateNode;n?gf(T,!0):gf(u.stateNode,!1)}catch(F){Ue(u,u.return,F)}}}else if((t.tag!==22&&t.tag!==23||t.memoizedState===null||t===e)&&t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break e;for(;t.sibling===null;){if(t.return===null||t.return===e)break e;a===t&&(a=null),t=t.return}a===t&&(a=null),t.sibling.return=t.return,t=t.sibling}i&4&&(i=e.updateQueue,i!==null&&(a=i.retryQueue,a!==null&&(i.retryQueue=null,In(e,a))));break;case 19:Nt(t,e),zt(e),i&4&&(i=e.updateQueue,i!==null&&(e.updateQueue=null,In(e,i)));break;case 30:break;case 21:break;default:Nt(t,e),zt(e)}}function zt(e){var t=e.flags;if(t&2){try{for(var a,i=e.return;i!==null;){if(bu(i)){a=i;break}i=i.return}if(a==null)throw Error(d(160));switch(a.tag){case 27:var n=a.stateNode,s=Xr(e);Gn(e,s,n);break;case 5:var o=a.stateNode;a.flags&32&&(zl(o,""),a.flags&=-33);var c=Xr(e);Gn(e,c,o);break;case 3:case 4:var u=a.stateNode.containerInfo,j=Xr(e);Qr(e,j,u);break;default:throw Error(d(161))}}catch(C){Ue(e,e.return,C)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function Eu(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var t=e;Eu(t),t.tag===5&&t.flags&1024&&t.stateNode.reset(),e=e.sibling}}function pa(e,t){if(t.subtreeFlags&8772)for(t=t.child;t!==null;)ku(e,t.alternate,t),t=t.sibling}function xl(e){for(e=e.child;e!==null;){var t=e;switch(t.tag){case 0:case 11:case 14:case 15:Ra(4,t,t.return),xl(t);break;case 1:$t(t,t.return);var a=t.stateNode;typeof a.componentWillUnmount=="function"&&hu(t,t.return,a),xl(t);break;case 27:qi(t.stateNode);case 26:case 5:$t(t,t.return),xl(t);break;case 22:t.memoizedState===null&&xl(t);break;case 30:xl(t);break;default:xl(t)}e=e.sibling}}function ha(e,t,a){for(a=a&&(t.subtreeFlags&8772)!==0,t=t.child;t!==null;){var i=t.alternate,n=e,s=t,o=s.flags;switch(s.tag){case 0:case 11:case 15:ha(n,s,a),Mi(4,s);break;case 1:if(ha(n,s,a),i=s,n=i.stateNode,typeof n.componentDidMount=="function")try{n.componentDidMount()}catch(j){Ue(i,i.return,j)}if(i=s,n=i.updateQueue,n!==null){var c=i.stateNode;try{var u=n.shared.hiddenCallbacks;if(u!==null)for(n.shared.hiddenCallbacks=null,n=0;n<u.length;n++)id(u[n],c)}catch(j){Ue(i,i.return,j)}}a&&o&64&&pu(s),Ri(s,s.return);break;case 27:yu(s);case 26:case 5:ha(n,s,a),a&&i===null&&o&4&&gu(s),Ri(s,s.return);break;case 12:ha(n,s,a);break;case 31:ha(n,s,a),a&&o&4&&zu(n,s);break;case 13:ha(n,s,a),a&&o&4&&wu(n,s);break;case 22:s.memoizedState===null&&ha(n,s,a),Ri(s,s.return);break;case 30:break;default:ha(n,s,a)}t=t.sibling}}function Jr(e,t){var a=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(a=e.memoizedState.cachePool.pool),e=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(e=t.memoizedState.cachePool.pool),e!==a&&(e!=null&&e.refCount++,a!=null&&ki(a))}function Fr(e,t){e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&ki(e))}function Jt(e,t,a,i){if(t.subtreeFlags&10256)for(t=t.child;t!==null;)Tu(e,t,a,i),t=t.sibling}function Tu(e,t,a,i){var n=t.flags;switch(t.tag){case 0:case 11:case 15:Jt(e,t,a,i),n&2048&&Mi(9,t);break;case 1:Jt(e,t,a,i);break;case 3:Jt(e,t,a,i),n&2048&&(e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&ki(e)));break;case 12:if(n&2048){Jt(e,t,a,i),e=t.stateNode;try{var s=t.memoizedProps,o=s.id,c=s.onPostCommit;typeof c=="function"&&c(o,t.alternate===null?"mount":"update",e.passiveEffectDuration,-0)}catch(u){Ue(t,t.return,u)}}else Jt(e,t,a,i);break;case 31:Jt(e,t,a,i);break;case 13:Jt(e,t,a,i);break;case 23:break;case 22:s=t.stateNode,o=t.alternate,t.memoizedState!==null?s._visibility&2?Jt(e,t,a,i):Ui(e,t):s._visibility&2?Jt(e,t,a,i):(s._visibility|=2,ql(e,t,a,i,(t.subtreeFlags&10256)!==0||!1)),n&2048&&Jr(o,t);break;case 24:Jt(e,t,a,i),n&2048&&Fr(t.alternate,t);break;default:Jt(e,t,a,i)}}function ql(e,t,a,i,n){for(n=n&&((t.subtreeFlags&10256)!==0||!1),t=t.child;t!==null;){var s=e,o=t,c=a,u=i,j=o.flags;switch(o.tag){case 0:case 11:case 15:ql(s,o,c,u,n),Mi(8,o);break;case 23:break;case 22:var C=o.stateNode;o.memoizedState!==null?C._visibility&2?ql(s,o,c,u,n):Ui(s,o):(C._visibility|=2,ql(s,o,c,u,n)),n&&j&2048&&Jr(o.alternate,o);break;case 24:ql(s,o,c,u,n),n&&j&2048&&Fr(o.alternate,o);break;default:ql(s,o,c,u,n)}t=t.sibling}}function Ui(e,t){if(t.subtreeFlags&10256)for(t=t.child;t!==null;){var a=e,i=t,n=i.flags;switch(i.tag){case 22:Ui(a,i),n&2048&&Jr(i.alternate,i);break;case 24:Ui(a,i),n&2048&&Fr(i.alternate,i);break;default:Ui(a,i)}t=t.sibling}}var Bi=8192;function Vl(e,t,a){if(e.subtreeFlags&Bi)for(e=e.child;e!==null;)_u(e,t,a),e=e.sibling}function _u(e,t,a){switch(e.tag){case 26:Vl(e,t,a),e.flags&Bi&&e.memoizedState!==null&&y0(a,Zt,e.memoizedState,e.memoizedProps);break;case 5:Vl(e,t,a);break;case 3:case 4:var i=Zt;Zt=as(e.stateNode.containerInfo),Vl(e,t,a),Zt=i;break;case 22:e.memoizedState===null&&(i=e.alternate,i!==null&&i.memoizedState!==null?(i=Bi,Bi=16777216,Vl(e,t,a),Bi=i):Vl(e,t,a));break;default:Vl(e,t,a)}}function Au(e){var t=e.alternate;if(t!==null&&(e=t.child,e!==null)){t.child=null;do t=e.sibling,e.sibling=null,e=t;while(e!==null)}}function Li(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var a=0;a<t.length;a++){var i=t[a];nt=i,Cu(i,e)}Au(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)Ou(e),e=e.sibling}function Ou(e){switch(e.tag){case 0:case 11:case 15:Li(e),e.flags&2048&&Ra(9,e,e.return);break;case 3:Li(e);break;case 12:Li(e);break;case 22:var t=e.stateNode;e.memoizedState!==null&&t._visibility&2&&(e.return===null||e.return.tag!==13)?(t._visibility&=-3,Kn(e)):Li(e);break;default:Li(e)}}function Kn(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var a=0;a<t.length;a++){var i=t[a];nt=i,Cu(i,e)}Au(e)}for(e=e.child;e!==null;){switch(t=e,t.tag){case 0:case 11:case 15:Ra(8,t,t.return),Kn(t);break;case 22:a=t.stateNode,a._visibility&2&&(a._visibility&=-3,Kn(t));break;default:Kn(t)}e=e.sibling}}function Cu(e,t){for(;nt!==null;){var a=nt;switch(a.tag){case 0:case 11:case 15:Ra(8,a,t);break;case 23:case 22:if(a.memoizedState!==null&&a.memoizedState.cachePool!==null){var i=a.memoizedState.cachePool.pool;i!=null&&i.refCount++}break;case 24:ki(a.memoizedState.cache)}if(i=a.child,i!==null)i.return=a,nt=i;else e:for(a=e;nt!==null;){i=nt;var n=i.sibling,s=i.return;if(ju(i),i===a){nt=null;break e}if(n!==null){n.return=s,nt=n;break e}nt=s}}}var Mp={getCacheForType:function(e){var t=ct(We),a=t.data.get(e);return a===void 0&&(a=e(),t.data.set(e,a)),a},cacheSignal:function(){return ct(We).controller.signal}},Rp=typeof WeakMap=="function"?WeakMap:Map,De=0,Ge=null,je=null,ze=0,Re=0,Ct=null,Ua=!1,Xl=!1,Pr=!1,ga=0,Xe=0,Ba=0,pl=0,Wr=0,Dt=0,Ql=0,Hi=null,wt=null,$r=!1,qn=0,Du=0,Vn=1/0,Xn=null,La=null,lt=0,Ha=null,Zl=null,ba=0,eo=0,to=null,Mu=null,Yi=0,ao=null;function Mt(){return(De&2)!==0&&ze!==0?ze&-ze:_.T!==null?oo():Fo()}function Ru(){if(Dt===0)if((ze&536870912)===0||Se){var e=Pa;Pa<<=1,(Pa&3932160)===0&&(Pa=262144),Dt=e}else Dt=536870912;return e=At.current,e!==null&&(e.flags|=32),Dt}function St(e,t,a){(e===Ge&&(Re===2||Re===9)||e.cancelPendingCommit!==null)&&(Jl(e,0),Ya(e,ze,Dt,!1)),Wa(e,a),((De&2)===0||e!==Ge)&&(e===Ge&&((De&2)===0&&(pl|=a),Xe===4&&Ya(e,ze,Dt,!1)),ea(e))}function Uu(e,t,a){if((De&6)!==0)throw Error(d(327));var i=!a&&(t&127)===0&&(t&e.expiredLanes)===0||Te(e,t),n=i?Lp(e,t):io(e,t,!0),s=i;do{if(n===0){Xl&&!i&&Ya(e,t,0,!1);break}else{if(a=e.current.alternate,s&&!Up(a)){n=io(e,t,!1),s=!1;continue}if(n===2){if(s=t,e.errorRecoveryDisabledLanes&s)var o=0;else o=e.pendingLanes&-536870913,o=o!==0?o:o&536870912?536870912:0;if(o!==0){t=o;e:{var c=e;n=Hi;var u=c.current.memoizedState.isDehydrated;if(u&&(Jl(c,o).flags|=256),o=io(c,o,!1),o!==2){if(Pr&&!u){c.errorRecoveryDisabledLanes|=s,pl|=s,n=4;break e}s=wt,wt=n,s!==null&&(wt===null?wt=s:wt.push.apply(wt,s))}n=o}if(s=!1,n!==2)continue}}if(n===1){Jl(e,0),Ya(e,t,0,!0);break}e:{switch(i=e,s=n,s){case 0:case 1:throw Error(d(345));case 4:if((t&4194048)!==t)break;case 6:Ya(i,t,Dt,!Ua);break e;case 2:wt=null;break;case 3:case 5:break;default:throw Error(d(329))}if((t&62914560)===t&&(n=qn+300-xe(),10<n)){if(Ya(i,t,Dt,!Ua),pe(i,0,!0)!==0)break e;ba=t,i.timeoutHandle=xf(Bu.bind(null,i,a,wt,Xn,$r,t,Dt,pl,Ql,Ua,s,"Throttled",-0,0),n);break e}Bu(i,a,wt,Xn,$r,t,Dt,pl,Ql,Ua,s,null,-0,0)}}break}while(!0);ea(e)}function Bu(e,t,a,i,n,s,o,c,u,j,C,R,z,T){if(e.timeoutHandle=-1,R=t.subtreeFlags,R&8192||(R&16785408)===16785408){R={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:la},_u(t,s,R);var F=(s&62914560)===s?qn-xe():(s&4194048)===s?Du-xe():0;if(F=v0(R,F),F!==null){ba=s,e.cancelPendingCommit=F(Vu.bind(null,e,t,s,a,i,n,o,c,u,C,R,null,z,T)),Ya(e,s,o,!j);return}}Vu(e,t,s,a,i,n,o,c,u)}function Up(e){for(var t=e;;){var a=t.tag;if((a===0||a===11||a===15)&&t.flags&16384&&(a=t.updateQueue,a!==null&&(a=a.stores,a!==null)))for(var i=0;i<a.length;i++){var n=a[i],s=n.getSnapshot;n=n.value;try{if(!Tt(s(),n))return!1}catch{return!1}}if(a=t.child,t.subtreeFlags&16384&&a!==null)a.return=t,t=a;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function Ya(e,t,a,i){t&=~Wr,t&=~pl,e.suspendedLanes|=t,e.pingedLanes&=~t,i&&(e.warmLanes|=t),i=e.expirationTimes;for(var n=t;0<n;){var s=31-mt(n),o=1<<s;i[s]=-1,n&=~o}a!==0&&Qo(e,a,t)}function Qn(){return(De&6)===0?(Gi(0),!1):!0}function lo(){if(je!==null){if(Re===0)var e=je.return;else e=je,ra=sl=null,yr(e),Hl=null,Ni=0,e=je;for(;e!==null;)xu(e.alternate,e),e=e.return;je=null}}function Jl(e,t){var a=e.timeoutHandle;a!==-1&&(e.timeoutHandle=-1,a0(a)),a=e.cancelPendingCommit,a!==null&&(e.cancelPendingCommit=null,a()),ba=0,lo(),Ge=e,je=a=na(e.current,null),ze=t,Re=0,Ct=null,Ua=!1,Xl=Te(e,t),Pr=!1,Ql=Dt=Wr=pl=Ba=Xe=0,wt=Hi=null,$r=!1,(t&8)!==0&&(t|=t&32);var i=e.entangledLanes;if(i!==0)for(e=e.entanglements,i&=t;0<i;){var n=31-mt(i),s=1<<n;t|=e[n],i&=~s}return ga=t,xn(),a}function Lu(e,t){be=null,_.H=Oi,t===Ll||t===jn?(t=ed(),Re=3):t===rr?(t=ed(),Re=4):Re=t===Rr?8:t!==null&&typeof t=="object"&&typeof t.then=="function"?6:1,Ct=t,je===null&&(Xe=1,Un(e,Ht(t,e.current)))}function Hu(){var e=At.current;return e===null?!0:(ze&4194048)===ze?Kt===null:(ze&62914560)===ze||(ze&536870912)!==0?e===Kt:!1}function Yu(){var e=_.H;return _.H=Oi,e===null?Oi:e}function Gu(){var e=_.A;return _.A=Mp,e}function Zn(){Xe=4,Ua||(ze&4194048)!==ze&&At.current!==null||(Xl=!0),(Ba&134217727)===0&&(pl&134217727)===0||Ge===null||Ya(Ge,ze,Dt,!1)}function io(e,t,a){var i=De;De|=2;var n=Yu(),s=Gu();(Ge!==e||ze!==t)&&(Xn=null,Jl(e,t)),t=!1;var o=Xe;e:do try{if(Re!==0&&je!==null){var c=je,u=Ct;switch(Re){case 8:lo(),o=6;break e;case 3:case 2:case 9:case 6:At.current===null&&(t=!0);var j=Re;if(Re=0,Ct=null,Fl(e,c,u,j),a&&Xl){o=0;break e}break;default:j=Re,Re=0,Ct=null,Fl(e,c,u,j)}}Bp(),o=Xe;break}catch(C){Lu(e,C)}while(!0);return t&&e.shellSuspendCounter++,ra=sl=null,De=i,_.H=n,_.A=s,je===null&&(Ge=null,ze=0,xn()),o}function Bp(){for(;je!==null;)Iu(je)}function Lp(e,t){var a=De;De|=2;var i=Yu(),n=Gu();Ge!==e||ze!==t?(Xn=null,Vn=xe()+500,Jl(e,t)):Xl=Te(e,t);e:do try{if(Re!==0&&je!==null){t=je;var s=Ct;t:switch(Re){case 1:Re=0,Ct=null,Fl(e,t,s,1);break;case 2:case 9:if(Wc(s)){Re=0,Ct=null,Ku(t);break}t=function(){Re!==2&&Re!==9||Ge!==e||(Re=7),ea(e)},s.then(t,t);break e;case 3:Re=7;break e;case 4:Re=5;break e;case 7:Wc(s)?(Re=0,Ct=null,Ku(t)):(Re=0,Ct=null,Fl(e,t,s,7));break;case 5:var o=null;switch(je.tag){case 26:o=je.memoizedState;case 5:case 27:var c=je;if(o?_f(o):c.stateNode.complete){Re=0,Ct=null;var u=c.sibling;if(u!==null)je=u;else{var j=c.return;j!==null?(je=j,Jn(j)):je=null}break t}}Re=0,Ct=null,Fl(e,t,s,5);break;case 6:Re=0,Ct=null,Fl(e,t,s,6);break;case 8:lo(),Xe=6;break e;default:throw Error(d(462))}}Hp();break}catch(C){Lu(e,C)}while(!0);return ra=sl=null,_.H=i,_.A=n,De=a,je!==null?0:(Ge=null,ze=0,xn(),Xe)}function Hp(){for(;je!==null&&!X();)Iu(je)}function Iu(e){var t=fu(e.alternate,e,ga);e.memoizedProps=e.pendingProps,t===null?Jn(e):je=t}function Ku(e){var t=e,a=t.alternate;switch(t.tag){case 15:case 0:t=su(a,t,t.pendingProps,t.type,void 0,ze);break;case 11:t=su(a,t,t.pendingProps,t.type.render,t.ref,ze);break;case 5:yr(t);default:xu(a,t),t=je=Gc(t,ga),t=fu(a,t,ga)}e.memoizedProps=e.pendingProps,t===null?Jn(e):je=t}function Fl(e,t,a,i){ra=sl=null,yr(t),Hl=null,Ni=0;var n=t.return;try{if(Ep(e,n,t,a,ze)){Xe=1,Un(e,Ht(a,e.current)),je=null;return}}catch(s){if(n!==null)throw je=n,s;Xe=1,Un(e,Ht(a,e.current)),je=null;return}t.flags&32768?(Se||i===1?e=!0:Xl||(ze&536870912)!==0?e=!1:(Ua=e=!0,(i===2||i===9||i===3||i===6)&&(i=At.current,i!==null&&i.tag===13&&(i.flags|=16384))),qu(t,e)):Jn(t)}function Jn(e){var t=e;do{if((t.flags&32768)!==0){qu(t,Ua);return}e=t.return;var a=Ap(t.alternate,t,ga);if(a!==null){je=a;return}if(t=t.sibling,t!==null){je=t;return}je=t=e}while(t!==null);Xe===0&&(Xe=5)}function qu(e,t){do{var a=Op(e.alternate,e);if(a!==null){a.flags&=32767,je=a;return}if(a=e.return,a!==null&&(a.flags|=32768,a.subtreeFlags=0,a.deletions=null),!t&&(e=e.sibling,e!==null)){je=e;return}je=e=a}while(e!==null);Xe=6,je=null}function Vu(e,t,a,i,n,s,o,c,u){e.cancelPendingCommit=null;do Fn();while(lt!==0);if((De&6)!==0)throw Error(d(327));if(t!==null){if(t===e.current)throw Error(d(177));if(s=t.lanes|t.childLanes,s|=Xs,bx(e,a,s,o,c,u),e===Ge&&(je=Ge=null,ze=0),Zl=t,Ha=e,ba=a,eo=s,to=n,Mu=i,(t.subtreeFlags&10256)!==0||(t.flags&10256)!==0?(e.callbackNode=null,e.callbackPriority=0,Kp(Et,function(){return Fu(),null})):(e.callbackNode=null,e.callbackPriority=0),i=(t.flags&13878)!==0,(t.subtreeFlags&13878)!==0||i){i=_.T,_.T=null,n=y.p,y.p=2,o=De,De|=4;try{Cp(e,t,a)}finally{De=o,y.p=n,_.T=i}}lt=1,Xu(),Qu(),Zu()}}function Xu(){if(lt===1){lt=0;var e=Ha,t=Zl,a=(t.flags&13878)!==0;if((t.subtreeFlags&13878)!==0||a){a=_.T,_.T=null;var i=y.p;y.p=2;var n=De;De|=4;try{Su(t,e);var s=go,o=Cc(e.containerInfo),c=s.focusedElem,u=s.selectionRange;if(o!==c&&c&&c.ownerDocument&&Oc(c.ownerDocument.documentElement,c)){if(u!==null&&Gs(c)){var j=u.start,C=u.end;if(C===void 0&&(C=j),"selectionStart"in c)c.selectionStart=j,c.selectionEnd=Math.min(C,c.value.length);else{var R=c.ownerDocument||document,z=R&&R.defaultView||window;if(z.getSelection){var T=z.getSelection(),F=c.textContent.length,se=Math.min(u.start,F),He=u.end===void 0?se:Math.min(u.end,F);!T.extend&&se>He&&(o=He,He=se,se=o);var h=Ac(c,se),m=Ac(c,He);if(h&&m&&(T.rangeCount!==1||T.anchorNode!==h.node||T.anchorOffset!==h.offset||T.focusNode!==m.node||T.focusOffset!==m.offset)){var k=R.createRange();k.setStart(h.node,h.offset),T.removeAllRanges(),se>He?(T.addRange(k),T.extend(m.node,m.offset)):(k.setEnd(m.node,m.offset),T.addRange(k))}}}}for(R=[],T=c;T=T.parentNode;)T.nodeType===1&&R.push({element:T,left:T.scrollLeft,top:T.scrollTop});for(typeof c.focus=="function"&&c.focus(),c=0;c<R.length;c++){var M=R[c];M.element.scrollLeft=M.left,M.element.scrollTop=M.top}}os=!!ho,go=ho=null}finally{De=n,y.p=i,_.T=a}}e.current=t,lt=2}}function Qu(){if(lt===2){lt=0;var e=Ha,t=Zl,a=(t.flags&8772)!==0;if((t.subtreeFlags&8772)!==0||a){a=_.T,_.T=null;var i=y.p;y.p=2;var n=De;De|=4;try{ku(e,t.alternate,t)}finally{De=n,y.p=i,_.T=a}}lt=3}}function Zu(){if(lt===4||lt===3){lt=0,ae();var e=Ha,t=Zl,a=ba,i=Mu;(t.subtreeFlags&10256)!==0||(t.flags&10256)!==0?lt=5:(lt=0,Zl=Ha=null,Ju(e,e.pendingLanes));var n=e.pendingLanes;if(n===0&&(La=null),js(a),t=t.stateNode,ht&&typeof ht.onCommitFiberRoot=="function")try{ht.onCommitFiberRoot(Ja,t,void 0,(t.current.flags&128)===128)}catch{}if(i!==null){t=_.T,n=y.p,y.p=2,_.T=null;try{for(var s=e.onRecoverableError,o=0;o<i.length;o++){var c=i[o];s(c.value,{componentStack:c.stack})}}finally{_.T=t,y.p=n}}(ba&3)!==0&&Fn(),ea(e),n=e.pendingLanes,(a&261930)!==0&&(n&42)!==0?e===ao?Yi++:(Yi=0,ao=e):Yi=0,Gi(0)}}function Ju(e,t){(e.pooledCacheLanes&=t)===0&&(t=e.pooledCache,t!=null&&(e.pooledCache=null,ki(t)))}function Fn(){return Xu(),Qu(),Zu(),Fu()}function Fu(){if(lt!==5)return!1;var e=Ha,t=eo;eo=0;var a=js(ba),i=_.T,n=y.p;try{y.p=32>a?32:a,_.T=null,a=to,to=null;var s=Ha,o=ba;if(lt=0,Zl=Ha=null,ba=0,(De&6)!==0)throw Error(d(331));var c=De;if(De|=4,Ou(s.current),Tu(s,s.current,o,a),De=c,Gi(0,!1),ht&&typeof ht.onPostCommitFiberRoot=="function")try{ht.onPostCommitFiberRoot(Ja,s)}catch{}return!0}finally{y.p=n,_.T=i,Ju(e,t)}}function Pu(e,t,a){t=Ht(a,t),t=Mr(e.stateNode,t,2),e=Ca(e,t,2),e!==null&&(Wa(e,2),ea(e))}function Ue(e,t,a){if(e.tag===3)Pu(e,e,a);else for(;t!==null;){if(t.tag===3){Pu(t,e,a);break}else if(t.tag===1){var i=t.stateNode;if(typeof t.type.getDerivedStateFromError=="function"||typeof i.componentDidCatch=="function"&&(La===null||!La.has(i))){e=Ht(a,e),a=Wd(2),i=Ca(t,a,2),i!==null&&($d(a,i,t,e),Wa(i,2),ea(i));break}}t=t.return}}function no(e,t,a){var i=e.pingCache;if(i===null){i=e.pingCache=new Rp;var n=new Set;i.set(t,n)}else n=i.get(t),n===void 0&&(n=new Set,i.set(t,n));n.has(a)||(Pr=!0,n.add(a),e=Yp.bind(null,e,t,a),t.then(e,e))}function Yp(e,t,a){var i=e.pingCache;i!==null&&i.delete(t),e.pingedLanes|=e.suspendedLanes&a,e.warmLanes&=~a,Ge===e&&(ze&a)===a&&(Xe===4||Xe===3&&(ze&62914560)===ze&&300>xe()-qn?(De&2)===0&&Jl(e,0):Wr|=a,Ql===ze&&(Ql=0)),ea(e)}function Wu(e,t){t===0&&(t=vs()),e=ll(e,t),e!==null&&(Wa(e,t),ea(e))}function Gp(e){var t=e.memoizedState,a=0;t!==null&&(a=t.retryLane),Wu(e,a)}function Ip(e,t){var a=0;switch(e.tag){case 31:case 13:var i=e.stateNode,n=e.memoizedState;n!==null&&(a=n.retryLane);break;case 19:i=e.stateNode;break;case 22:i=e.stateNode._retryCache;break;default:throw Error(d(314))}i!==null&&i.delete(t),Wu(e,a)}function Kp(e,t){return Xt(e,t)}var Pn=null,Pl=null,so=!1,Wn=!1,ro=!1,Ga=0;function ea(e){e!==Pl&&e.next===null&&(Pl===null?Pn=Pl=e:Pl=Pl.next=e),Wn=!0,so||(so=!0,Vp())}function Gi(e,t){if(!ro&&Wn){ro=!0;do for(var a=!1,i=Pn;i!==null;){if(e!==0){var n=i.pendingLanes;if(n===0)var s=0;else{var o=i.suspendedLanes,c=i.pingedLanes;s=(1<<31-mt(42|e)+1)-1,s&=n&~(o&~c),s=s&201326741?s&201326741|1:s?s|2:0}s!==0&&(a=!0,af(i,s))}else s=ze,s=pe(i,i===Ge?s:0,i.cancelPendingCommit!==null||i.timeoutHandle!==-1),(s&3)===0||Te(i,s)||(a=!0,af(i,s));i=i.next}while(a);ro=!1}}function qp(){$u()}function $u(){Wn=so=!1;var e=0;Ga!==0&&t0()&&(e=Ga);for(var t=xe(),a=null,i=Pn;i!==null;){var n=i.next,s=ef(i,t);s===0?(i.next=null,a===null?Pn=n:a.next=n,n===null&&(Pl=a)):(a=i,(e!==0||(s&3)!==0)&&(Wn=!0)),i=n}lt!==0&&lt!==5||Gi(e),Ga!==0&&(Ga=0)}function ef(e,t){for(var a=e.suspendedLanes,i=e.pingedLanes,n=e.expirationTimes,s=e.pendingLanes&-62914561;0<s;){var o=31-mt(s),c=1<<o,u=n[o];u===-1?((c&a)===0||(c&i)!==0)&&(n[o]=Ee(c,t)):u<=t&&(e.expiredLanes|=c),s&=~c}if(t=Ge,a=ze,a=pe(e,e===t?a:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),i=e.callbackNode,a===0||e===t&&(Re===2||Re===9)||e.cancelPendingCommit!==null)return i!==null&&i!==null&&st(i),e.callbackNode=null,e.callbackPriority=0;if((a&3)===0||Te(e,a)){if(t=a&-a,t===e.callbackPriority)return t;switch(i!==null&&st(i),js(a)){case 2:case 8:a=Ft;break;case 32:a=Et;break;case 268435456:a=si;break;default:a=Et}return i=tf.bind(null,e),a=Xt(a,i),e.callbackPriority=t,e.callbackNode=a,t}return i!==null&&i!==null&&st(i),e.callbackPriority=2,e.callbackNode=null,2}function tf(e,t){if(lt!==0&&lt!==5)return e.callbackNode=null,e.callbackPriority=0,null;var a=e.callbackNode;if(Fn()&&e.callbackNode!==a)return null;var i=ze;return i=pe(e,e===Ge?i:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),i===0?null:(Uu(e,i,t),ef(e,xe()),e.callbackNode!=null&&e.callbackNode===a?tf.bind(null,e):null)}function af(e,t){if(Fn())return null;Uu(e,t,!0)}function Vp(){l0(function(){(De&6)!==0?Xt(Pe,qp):$u()})}function oo(){if(Ga===0){var e=Ul;e===0&&(e=Fa,Fa<<=1,(Fa&261888)===0&&(Fa=256)),Ga=e}return Ga}function lf(e){return e==null||typeof e=="symbol"||typeof e=="boolean"?null:typeof e=="function"?e:sn(""+e)}function nf(e,t){var a=t.ownerDocument.createElement("input");return a.name=t.name,a.value=t.value,e.id&&a.setAttribute("form",e.id),t.parentNode.insertBefore(a,t),e=new FormData(e),a.parentNode.removeChild(a),e}function Xp(e,t,a,i,n){if(t==="submit"&&a&&a.stateNode===n){var s=lf((n[vt]||null).action),o=i.submitter;o&&(t=(t=o[vt]||null)?lf(t.formAction):o.getAttribute("formAction"),t!==null&&(s=t,o=null));var c=new dn("action","action",null,i,n);e.push({event:c,listeners:[{instance:null,listener:function(){if(i.defaultPrevented){if(Ga!==0){var u=o?nf(n,o):new FormData(n);Tr(a,{pending:!0,data:u,method:n.method,action:s},null,u)}}else typeof s=="function"&&(c.preventDefault(),u=o?nf(n,o):new FormData(n),Tr(a,{pending:!0,data:u,method:n.method,action:s},s,u))},currentTarget:n}]})}}for(var co=0;co<Vs.length;co++){var uo=Vs[co],Qp=uo.toLowerCase(),Zp=uo[0].toUpperCase()+uo.slice(1);Qt(Qp,"on"+Zp)}Qt(Rc,"onAnimationEnd"),Qt(Uc,"onAnimationIteration"),Qt(Bc,"onAnimationStart"),Qt("dblclick","onDoubleClick"),Qt("focusin","onFocus"),Qt("focusout","onBlur"),Qt(dp,"onTransitionRun"),Qt(up,"onTransitionStart"),Qt(fp,"onTransitionCancel"),Qt(Lc,"onTransitionEnd"),jl("onMouseEnter",["mouseout","mouseover"]),jl("onMouseLeave",["mouseout","mouseover"]),jl("onPointerEnter",["pointerout","pointerover"]),jl("onPointerLeave",["pointerout","pointerover"]),$a("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),$a("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),$a("onBeforeInput",["compositionend","keypress","textInput","paste"]),$a("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),$a("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),$a("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Ii="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),Jp=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Ii));function sf(e,t){t=(t&4)!==0;for(var a=0;a<e.length;a++){var i=e[a],n=i.event;i=i.listeners;e:{var s=void 0;if(t)for(var o=i.length-1;0<=o;o--){var c=i[o],u=c.instance,j=c.currentTarget;if(c=c.listener,u!==s&&n.isPropagationStopped())break e;s=c,n.currentTarget=j;try{s(n)}catch(C){mn(C)}n.currentTarget=null,s=u}else for(o=0;o<i.length;o++){if(c=i[o],u=c.instance,j=c.currentTarget,c=c.listener,u!==s&&n.isPropagationStopped())break e;s=c,n.currentTarget=j;try{s(n)}catch(C){mn(C)}n.currentTarget=null,s=u}}}}function Ne(e,t){var a=t[Ns];a===void 0&&(a=t[Ns]=new Set);var i=e+"__bubble";a.has(i)||(rf(t,e,2,!1),a.add(i))}function fo(e,t,a){var i=0;t&&(i|=4),rf(a,e,i,t)}var $n="_reactListening"+Math.random().toString(36).slice(2);function mo(e){if(!e[$n]){e[$n]=!0,$o.forEach(function(a){a!=="selectionchange"&&(Jp.has(a)||fo(a,!1,e),fo(a,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[$n]||(t[$n]=!0,fo("selectionchange",!1,t))}}function rf(e,t,a,i){switch(Uf(t)){case 2:var n=N0;break;case 8:n=z0;break;default:n=To}a=n.bind(null,t,a,e),n=void 0,!Cs||t!=="touchstart"&&t!=="touchmove"&&t!=="wheel"||(n=!0),i?n!==void 0?e.addEventListener(t,a,{capture:!0,passive:n}):e.addEventListener(t,a,!0):n!==void 0?e.addEventListener(t,a,{passive:n}):e.addEventListener(t,a,!1)}function xo(e,t,a,i,n){var s=i;if((t&1)===0&&(t&2)===0&&i!==null)e:for(;;){if(i===null)return;var o=i.tag;if(o===3||o===4){var c=i.stateNode.containerInfo;if(c===n)break;if(o===4)for(o=i.return;o!==null;){var u=o.tag;if((u===3||u===4)&&o.stateNode.containerInfo===n)return;o=o.return}for(;c!==null;){if(o=yl(c),o===null)return;if(u=o.tag,u===5||u===6||u===26||u===27){i=s=o;continue e}c=c.parentNode}}i=i.return}uc(function(){var j=s,C=As(a),R=[];e:{var z=Hc.get(e);if(z!==void 0){var T=dn,F=e;switch(e){case"keypress":if(on(a)===0)break e;case"keydown":case"keyup":T=Ix;break;case"focusin":F="focus",T=Us;break;case"focusout":F="blur",T=Us;break;case"beforeblur":case"afterblur":T=Us;break;case"click":if(a.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":T=xc;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":T=Ax;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":T=Vx;break;case Rc:case Uc:case Bc:T=Dx;break;case Lc:T=Qx;break;case"scroll":case"scrollend":T=Tx;break;case"wheel":T=Jx;break;case"copy":case"cut":case"paste":T=Rx;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":T=hc;break;case"toggle":case"beforetoggle":T=Px}var se=(t&4)!==0,He=!se&&(e==="scroll"||e==="scrollend"),h=se?z!==null?z+"Capture":null:z;se=[];for(var m=j,k;m!==null;){var M=m;if(k=M.stateNode,M=M.tag,M!==5&&M!==26&&M!==27||k===null||h===null||(M=di(m,h),M!=null&&se.push(Ki(m,M,k))),He)break;m=m.return}0<se.length&&(z=new T(z,F,null,a,C),R.push({event:z,listeners:se}))}}if((t&7)===0){e:{if(z=e==="mouseover"||e==="pointerover",T=e==="mouseout"||e==="pointerout",z&&a!==_s&&(F=a.relatedTarget||a.fromElement)&&(yl(F)||F[bl]))break e;if((T||z)&&(z=C.window===C?C:(z=C.ownerDocument)?z.defaultView||z.parentWindow:window,T?(F=a.relatedTarget||a.toElement,T=j,F=F?yl(F):null,F!==null&&(He=A(F),se=F.tag,F!==He||se!==5&&se!==27&&se!==6)&&(F=null)):(T=null,F=j),T!==F)){if(se=xc,M="onMouseLeave",h="onMouseEnter",m="mouse",(e==="pointerout"||e==="pointerover")&&(se=hc,M="onPointerLeave",h="onPointerEnter",m="pointer"),He=T==null?z:ci(T),k=F==null?z:ci(F),z=new se(M,m+"leave",T,a,C),z.target=He,z.relatedTarget=k,M=null,yl(C)===j&&(se=new se(h,m+"enter",F,a,C),se.target=k,se.relatedTarget=He,M=se),He=M,T&&F)t:{for(se=Fp,h=T,m=F,k=0,M=h;M;M=se(M))k++;M=0;for(var le=m;le;le=se(le))M++;for(;0<k-M;)h=se(h),k--;for(;0<M-k;)m=se(m),M--;for(;k--;){if(h===m||m!==null&&h===m.alternate){se=h;break t}h=se(h),m=se(m)}se=null}else se=null;T!==null&&of(R,z,T,se,!1),F!==null&&He!==null&&of(R,He,F,se,!0)}}e:{if(z=j?ci(j):window,T=z.nodeName&&z.nodeName.toLowerCase(),T==="select"||T==="input"&&z.type==="file")var _e=zc;else if(jc(z))if(wc)_e=rp;else{_e=np;var W=ip}else T=z.nodeName,!T||T.toLowerCase()!=="input"||z.type!=="checkbox"&&z.type!=="radio"?j&&Ts(j.elementType)&&(_e=zc):_e=sp;if(_e&&(_e=_e(e,j))){Nc(R,_e,a,C);break e}W&&W(e,z,j),e==="focusout"&&j&&z.type==="number"&&j.memoizedProps.value!=null&&Es(z,"number",z.value)}switch(W=j?ci(j):window,e){case"focusin":(jc(W)||W.contentEditable==="true")&&(Tl=W,Is=j,bi=null);break;case"focusout":bi=Is=Tl=null;break;case"mousedown":Ks=!0;break;case"contextmenu":case"mouseup":case"dragend":Ks=!1,Dc(R,a,C);break;case"selectionchange":if(cp)break;case"keydown":case"keyup":Dc(R,a,C)}var ve;if(Ls)e:{switch(e){case"compositionstart":var we="onCompositionStart";break e;case"compositionend":we="onCompositionEnd";break e;case"compositionupdate":we="onCompositionUpdate";break e}we=void 0}else El?vc(e,a)&&(we="onCompositionEnd"):e==="keydown"&&a.keyCode===229&&(we="onCompositionStart");we&&(gc&&a.locale!=="ko"&&(El||we!=="onCompositionStart"?we==="onCompositionEnd"&&El&&(ve=fc()):(wa=C,Ds="value"in wa?wa.value:wa.textContent,El=!0)),W=es(j,we),0<W.length&&(we=new pc(we,e,null,a,C),R.push({event:we,listeners:W}),ve?we.data=ve:(ve=kc(a),ve!==null&&(we.data=ve)))),(ve=$x?ep(e,a):tp(e,a))&&(we=es(j,"onBeforeInput"),0<we.length&&(W=new pc("onBeforeInput","beforeinput",null,a,C),R.push({event:W,listeners:we}),W.data=ve)),Xp(R,e,j,a,C)}sf(R,t)})}function Ki(e,t,a){return{instance:e,listener:t,currentTarget:a}}function es(e,t){for(var a=t+"Capture",i=[];e!==null;){var n=e,s=n.stateNode;if(n=n.tag,n!==5&&n!==26&&n!==27||s===null||(n=di(e,a),n!=null&&i.unshift(Ki(e,n,s)),n=di(e,t),n!=null&&i.push(Ki(e,n,s))),e.tag===3)return i;e=e.return}return[]}function Fp(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function of(e,t,a,i,n){for(var s=t._reactName,o=[];a!==null&&a!==i;){var c=a,u=c.alternate,j=c.stateNode;if(c=c.tag,u!==null&&u===i)break;c!==5&&c!==26&&c!==27||j===null||(u=j,n?(j=di(a,s),j!=null&&o.unshift(Ki(a,j,u))):n||(j=di(a,s),j!=null&&o.push(Ki(a,j,u)))),a=a.return}o.length!==0&&e.push({event:t,listeners:o})}var Pp=/\r\n?/g,Wp=/\u0000|\uFFFD/g;function cf(e){return(typeof e=="string"?e:""+e).replace(Pp,`
`).replace(Wp,"")}function df(e,t){return t=cf(t),cf(e)===t}function Le(e,t,a,i,n,s){switch(a){case"children":typeof i=="string"?t==="body"||t==="textarea"&&i===""||zl(e,i):(typeof i=="number"||typeof i=="bigint")&&t!=="body"&&zl(e,""+i);break;case"className":ln(e,"class",i);break;case"tabIndex":ln(e,"tabindex",i);break;case"dir":case"role":case"viewBox":case"width":case"height":ln(e,a,i);break;case"style":cc(e,i,s);break;case"data":if(t!=="object"){ln(e,"data",i);break}case"src":case"href":if(i===""&&(t!=="a"||a!=="href")){e.removeAttribute(a);break}if(i==null||typeof i=="function"||typeof i=="symbol"||typeof i=="boolean"){e.removeAttribute(a);break}i=sn(""+i),e.setAttribute(a,i);break;case"action":case"formAction":if(typeof i=="function"){e.setAttribute(a,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof s=="function"&&(a==="formAction"?(t!=="input"&&Le(e,t,"name",n.name,n,null),Le(e,t,"formEncType",n.formEncType,n,null),Le(e,t,"formMethod",n.formMethod,n,null),Le(e,t,"formTarget",n.formTarget,n,null)):(Le(e,t,"encType",n.encType,n,null),Le(e,t,"method",n.method,n,null),Le(e,t,"target",n.target,n,null)));if(i==null||typeof i=="symbol"||typeof i=="boolean"){e.removeAttribute(a);break}i=sn(""+i),e.setAttribute(a,i);break;case"onClick":i!=null&&(e.onclick=la);break;case"onScroll":i!=null&&Ne("scroll",e);break;case"onScrollEnd":i!=null&&Ne("scrollend",e);break;case"dangerouslySetInnerHTML":if(i!=null){if(typeof i!="object"||!("__html"in i))throw Error(d(61));if(a=i.__html,a!=null){if(n.children!=null)throw Error(d(60));e.innerHTML=a}}break;case"multiple":e.multiple=i&&typeof i!="function"&&typeof i!="symbol";break;case"muted":e.muted=i&&typeof i!="function"&&typeof i!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(i==null||typeof i=="function"||typeof i=="boolean"||typeof i=="symbol"){e.removeAttribute("xlink:href");break}a=sn(""+i),e.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",a);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":i!=null&&typeof i!="function"&&typeof i!="symbol"?e.setAttribute(a,""+i):e.removeAttribute(a);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":i&&typeof i!="function"&&typeof i!="symbol"?e.setAttribute(a,""):e.removeAttribute(a);break;case"capture":case"download":i===!0?e.setAttribute(a,""):i!==!1&&i!=null&&typeof i!="function"&&typeof i!="symbol"?e.setAttribute(a,i):e.removeAttribute(a);break;case"cols":case"rows":case"size":case"span":i!=null&&typeof i!="function"&&typeof i!="symbol"&&!isNaN(i)&&1<=i?e.setAttribute(a,i):e.removeAttribute(a);break;case"rowSpan":case"start":i==null||typeof i=="function"||typeof i=="symbol"||isNaN(i)?e.removeAttribute(a):e.setAttribute(a,i);break;case"popover":Ne("beforetoggle",e),Ne("toggle",e),an(e,"popover",i);break;case"xlinkActuate":aa(e,"http://www.w3.org/1999/xlink","xlink:actuate",i);break;case"xlinkArcrole":aa(e,"http://www.w3.org/1999/xlink","xlink:arcrole",i);break;case"xlinkRole":aa(e,"http://www.w3.org/1999/xlink","xlink:role",i);break;case"xlinkShow":aa(e,"http://www.w3.org/1999/xlink","xlink:show",i);break;case"xlinkTitle":aa(e,"http://www.w3.org/1999/xlink","xlink:title",i);break;case"xlinkType":aa(e,"http://www.w3.org/1999/xlink","xlink:type",i);break;case"xmlBase":aa(e,"http://www.w3.org/XML/1998/namespace","xml:base",i);break;case"xmlLang":aa(e,"http://www.w3.org/XML/1998/namespace","xml:lang",i);break;case"xmlSpace":aa(e,"http://www.w3.org/XML/1998/namespace","xml:space",i);break;case"is":an(e,"is",i);break;case"innerText":case"textContent":break;default:(!(2<a.length)||a[0]!=="o"&&a[0]!=="O"||a[1]!=="n"&&a[1]!=="N")&&(a=Sx.get(a)||a,an(e,a,i))}}function po(e,t,a,i,n,s){switch(a){case"style":cc(e,i,s);break;case"dangerouslySetInnerHTML":if(i!=null){if(typeof i!="object"||!("__html"in i))throw Error(d(61));if(a=i.__html,a!=null){if(n.children!=null)throw Error(d(60));e.innerHTML=a}}break;case"children":typeof i=="string"?zl(e,i):(typeof i=="number"||typeof i=="bigint")&&zl(e,""+i);break;case"onScroll":i!=null&&Ne("scroll",e);break;case"onScrollEnd":i!=null&&Ne("scrollend",e);break;case"onClick":i!=null&&(e.onclick=la);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!ec.hasOwnProperty(a))e:{if(a[0]==="o"&&a[1]==="n"&&(n=a.endsWith("Capture"),t=a.slice(2,n?a.length-7:void 0),s=e[vt]||null,s=s!=null?s[a]:null,typeof s=="function"&&e.removeEventListener(t,s,n),typeof i=="function")){typeof s!="function"&&s!==null&&(a in e?e[a]=null:e.hasAttribute(a)&&e.removeAttribute(a)),e.addEventListener(t,i,n);break e}a in e?e[a]=i:i===!0?e.setAttribute(a,""):an(e,a,i)}}}function ut(e,t,a){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":Ne("error",e),Ne("load",e);var i=!1,n=!1,s;for(s in a)if(a.hasOwnProperty(s)){var o=a[s];if(o!=null)switch(s){case"src":i=!0;break;case"srcSet":n=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(d(137,t));default:Le(e,t,s,o,a,null)}}n&&Le(e,t,"srcSet",a.srcSet,a,null),i&&Le(e,t,"src",a.src,a,null);return;case"input":Ne("invalid",e);var c=s=o=n=null,u=null,j=null;for(i in a)if(a.hasOwnProperty(i)){var C=a[i];if(C!=null)switch(i){case"name":n=C;break;case"type":o=C;break;case"checked":u=C;break;case"defaultChecked":j=C;break;case"value":s=C;break;case"defaultValue":c=C;break;case"children":case"dangerouslySetInnerHTML":if(C!=null)throw Error(d(137,t));break;default:Le(e,t,i,C,a,null)}}nc(e,s,c,u,j,o,n,!1);return;case"select":Ne("invalid",e),i=o=s=null;for(n in a)if(a.hasOwnProperty(n)&&(c=a[n],c!=null))switch(n){case"value":s=c;break;case"defaultValue":o=c;break;case"multiple":i=c;default:Le(e,t,n,c,a,null)}t=s,a=o,e.multiple=!!i,t!=null?Nl(e,!!i,t,!1):a!=null&&Nl(e,!!i,a,!0);return;case"textarea":Ne("invalid",e),s=n=i=null;for(o in a)if(a.hasOwnProperty(o)&&(c=a[o],c!=null))switch(o){case"value":i=c;break;case"defaultValue":n=c;break;case"children":s=c;break;case"dangerouslySetInnerHTML":if(c!=null)throw Error(d(91));break;default:Le(e,t,o,c,a,null)}rc(e,i,n,s);return;case"option":for(u in a)if(a.hasOwnProperty(u)&&(i=a[u],i!=null))switch(u){case"selected":e.selected=i&&typeof i!="function"&&typeof i!="symbol";break;default:Le(e,t,u,i,a,null)}return;case"dialog":Ne("beforetoggle",e),Ne("toggle",e),Ne("cancel",e),Ne("close",e);break;case"iframe":case"object":Ne("load",e);break;case"video":case"audio":for(i=0;i<Ii.length;i++)Ne(Ii[i],e);break;case"image":Ne("error",e),Ne("load",e);break;case"details":Ne("toggle",e);break;case"embed":case"source":case"link":Ne("error",e),Ne("load",e);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(j in a)if(a.hasOwnProperty(j)&&(i=a[j],i!=null))switch(j){case"children":case"dangerouslySetInnerHTML":throw Error(d(137,t));default:Le(e,t,j,i,a,null)}return;default:if(Ts(t)){for(C in a)a.hasOwnProperty(C)&&(i=a[C],i!==void 0&&po(e,t,C,i,a,void 0));return}}for(c in a)a.hasOwnProperty(c)&&(i=a[c],i!=null&&Le(e,t,c,i,a,null))}function $p(e,t,a,i){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var n=null,s=null,o=null,c=null,u=null,j=null,C=null;for(T in a){var R=a[T];if(a.hasOwnProperty(T)&&R!=null)switch(T){case"checked":break;case"value":break;case"defaultValue":u=R;default:i.hasOwnProperty(T)||Le(e,t,T,null,i,R)}}for(var z in i){var T=i[z];if(R=a[z],i.hasOwnProperty(z)&&(T!=null||R!=null))switch(z){case"type":s=T;break;case"name":n=T;break;case"checked":j=T;break;case"defaultChecked":C=T;break;case"value":o=T;break;case"defaultValue":c=T;break;case"children":case"dangerouslySetInnerHTML":if(T!=null)throw Error(d(137,t));break;default:T!==R&&Le(e,t,z,T,i,R)}}Ss(e,o,c,u,j,C,s,n);return;case"select":T=o=c=z=null;for(s in a)if(u=a[s],a.hasOwnProperty(s)&&u!=null)switch(s){case"value":break;case"multiple":T=u;default:i.hasOwnProperty(s)||Le(e,t,s,null,i,u)}for(n in i)if(s=i[n],u=a[n],i.hasOwnProperty(n)&&(s!=null||u!=null))switch(n){case"value":z=s;break;case"defaultValue":c=s;break;case"multiple":o=s;default:s!==u&&Le(e,t,n,s,i,u)}t=c,a=o,i=T,z!=null?Nl(e,!!a,z,!1):!!i!=!!a&&(t!=null?Nl(e,!!a,t,!0):Nl(e,!!a,a?[]:"",!1));return;case"textarea":T=z=null;for(c in a)if(n=a[c],a.hasOwnProperty(c)&&n!=null&&!i.hasOwnProperty(c))switch(c){case"value":break;case"children":break;default:Le(e,t,c,null,i,n)}for(o in i)if(n=i[o],s=a[o],i.hasOwnProperty(o)&&(n!=null||s!=null))switch(o){case"value":z=n;break;case"defaultValue":T=n;break;case"children":break;case"dangerouslySetInnerHTML":if(n!=null)throw Error(d(91));break;default:n!==s&&Le(e,t,o,n,i,s)}sc(e,z,T);return;case"option":for(var F in a)if(z=a[F],a.hasOwnProperty(F)&&z!=null&&!i.hasOwnProperty(F))switch(F){case"selected":e.selected=!1;break;default:Le(e,t,F,null,i,z)}for(u in i)if(z=i[u],T=a[u],i.hasOwnProperty(u)&&z!==T&&(z!=null||T!=null))switch(u){case"selected":e.selected=z&&typeof z!="function"&&typeof z!="symbol";break;default:Le(e,t,u,z,i,T)}return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var se in a)z=a[se],a.hasOwnProperty(se)&&z!=null&&!i.hasOwnProperty(se)&&Le(e,t,se,null,i,z);for(j in i)if(z=i[j],T=a[j],i.hasOwnProperty(j)&&z!==T&&(z!=null||T!=null))switch(j){case"children":case"dangerouslySetInnerHTML":if(z!=null)throw Error(d(137,t));break;default:Le(e,t,j,z,i,T)}return;default:if(Ts(t)){for(var He in a)z=a[He],a.hasOwnProperty(He)&&z!==void 0&&!i.hasOwnProperty(He)&&po(e,t,He,void 0,i,z);for(C in i)z=i[C],T=a[C],!i.hasOwnProperty(C)||z===T||z===void 0&&T===void 0||po(e,t,C,z,i,T);return}}for(var h in a)z=a[h],a.hasOwnProperty(h)&&z!=null&&!i.hasOwnProperty(h)&&Le(e,t,h,null,i,z);for(R in i)z=i[R],T=a[R],!i.hasOwnProperty(R)||z===T||z==null&&T==null||Le(e,t,R,z,i,T)}function uf(e){switch(e){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function e0(){if(typeof performance.getEntriesByType=="function"){for(var e=0,t=0,a=performance.getEntriesByType("resource"),i=0;i<a.length;i++){var n=a[i],s=n.transferSize,o=n.initiatorType,c=n.duration;if(s&&c&&uf(o)){for(o=0,c=n.responseEnd,i+=1;i<a.length;i++){var u=a[i],j=u.startTime;if(j>c)break;var C=u.transferSize,R=u.initiatorType;C&&uf(R)&&(u=u.responseEnd,o+=C*(u<c?1:(c-j)/(u-j)))}if(--i,t+=8*(s+o)/(n.duration/1e3),e++,10<e)break}}if(0<e)return t/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e=="number")?e:5}var ho=null,go=null;function ts(e){return e.nodeType===9?e:e.ownerDocument}function ff(e){switch(e){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function mf(e,t){if(e===0)switch(t){case"svg":return 1;case"math":return 2;default:return 0}return e===1&&t==="foreignObject"?0:e}function bo(e,t){return e==="textarea"||e==="noscript"||typeof t.children=="string"||typeof t.children=="number"||typeof t.children=="bigint"||typeof t.dangerouslySetInnerHTML=="object"&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var yo=null;function t0(){var e=window.event;return e&&e.type==="popstate"?e===yo?!1:(yo=e,!0):(yo=null,!1)}var xf=typeof setTimeout=="function"?setTimeout:void 0,a0=typeof clearTimeout=="function"?clearTimeout:void 0,pf=typeof Promise=="function"?Promise:void 0,l0=typeof queueMicrotask=="function"?queueMicrotask:typeof pf<"u"?function(e){return pf.resolve(null).then(e).catch(i0)}:xf;function i0(e){setTimeout(function(){throw e})}function Ia(e){return e==="head"}function hf(e,t){var a=t,i=0;do{var n=a.nextSibling;if(e.removeChild(a),n&&n.nodeType===8)if(a=n.data,a==="/$"||a==="/&"){if(i===0){e.removeChild(n),ti(t);return}i--}else if(a==="$"||a==="$?"||a==="$~"||a==="$!"||a==="&")i++;else if(a==="html")qi(e.ownerDocument.documentElement);else if(a==="head"){a=e.ownerDocument.head,qi(a);for(var s=a.firstChild;s;){var o=s.nextSibling,c=s.nodeName;s[oi]||c==="SCRIPT"||c==="STYLE"||c==="LINK"&&s.rel.toLowerCase()==="stylesheet"||a.removeChild(s),s=o}}else a==="body"&&qi(e.ownerDocument.body);a=n}while(a);ti(t)}function gf(e,t){var a=e;e=0;do{var i=a.nextSibling;if(a.nodeType===1?t?(a._stashedDisplay=a.style.display,a.style.display="none"):(a.style.display=a._stashedDisplay||"",a.getAttribute("style")===""&&a.removeAttribute("style")):a.nodeType===3&&(t?(a._stashedText=a.nodeValue,a.nodeValue=""):a.nodeValue=a._stashedText||""),i&&i.nodeType===8)if(a=i.data,a==="/$"){if(e===0)break;e--}else a!=="$"&&a!=="$?"&&a!=="$~"&&a!=="$!"||e++;a=i}while(a)}function vo(e){var t=e.firstChild;for(t&&t.nodeType===10&&(t=t.nextSibling);t;){var a=t;switch(t=t.nextSibling,a.nodeName){case"HTML":case"HEAD":case"BODY":vo(a),zs(a);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(a.rel.toLowerCase()==="stylesheet")continue}e.removeChild(a)}}function n0(e,t,a,i){for(;e.nodeType===1;){var n=a;if(e.nodeName.toLowerCase()!==t.toLowerCase()){if(!i&&(e.nodeName!=="INPUT"||e.type!=="hidden"))break}else if(i){if(!e[oi])switch(t){case"meta":if(!e.hasAttribute("itemprop"))break;return e;case"link":if(s=e.getAttribute("rel"),s==="stylesheet"&&e.hasAttribute("data-precedence"))break;if(s!==n.rel||e.getAttribute("href")!==(n.href==null||n.href===""?null:n.href)||e.getAttribute("crossorigin")!==(n.crossOrigin==null?null:n.crossOrigin)||e.getAttribute("title")!==(n.title==null?null:n.title))break;return e;case"style":if(e.hasAttribute("data-precedence"))break;return e;case"script":if(s=e.getAttribute("src"),(s!==(n.src==null?null:n.src)||e.getAttribute("type")!==(n.type==null?null:n.type)||e.getAttribute("crossorigin")!==(n.crossOrigin==null?null:n.crossOrigin))&&s&&e.hasAttribute("async")&&!e.hasAttribute("itemprop"))break;return e;default:return e}}else if(t==="input"&&e.type==="hidden"){var s=n.name==null?null:""+n.name;if(n.type==="hidden"&&e.getAttribute("name")===s)return e}else return e;if(e=qt(e.nextSibling),e===null)break}return null}function s0(e,t,a){if(t==="")return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!a||(e=qt(e.nextSibling),e===null))return null;return e}function bf(e,t){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!t||(e=qt(e.nextSibling),e===null))return null;return e}function ko(e){return e.data==="$?"||e.data==="$~"}function jo(e){return e.data==="$!"||e.data==="$?"&&e.ownerDocument.readyState!=="loading"}function r0(e,t){var a=e.ownerDocument;if(e.data==="$~")e._reactRetry=t;else if(e.data!=="$?"||a.readyState!=="loading")t();else{var i=function(){t(),a.removeEventListener("DOMContentLoaded",i)};a.addEventListener("DOMContentLoaded",i),e._reactRetry=i}}function qt(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t==="$"||t==="$!"||t==="$?"||t==="$~"||t==="&"||t==="F!"||t==="F")break;if(t==="/$"||t==="/&")return null}}return e}var No=null;function yf(e){e=e.nextSibling;for(var t=0;e;){if(e.nodeType===8){var a=e.data;if(a==="/$"||a==="/&"){if(t===0)return qt(e.nextSibling);t--}else a!=="$"&&a!=="$!"&&a!=="$?"&&a!=="$~"&&a!=="&"||t++}e=e.nextSibling}return null}function vf(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var a=e.data;if(a==="$"||a==="$!"||a==="$?"||a==="$~"||a==="&"){if(t===0)return e;t--}else a!=="/$"&&a!=="/&"||t++}e=e.previousSibling}return null}function kf(e,t,a){switch(t=ts(a),e){case"html":if(e=t.documentElement,!e)throw Error(d(452));return e;case"head":if(e=t.head,!e)throw Error(d(453));return e;case"body":if(e=t.body,!e)throw Error(d(454));return e;default:throw Error(d(451))}}function qi(e){for(var t=e.attributes;t.length;)e.removeAttributeNode(t[0]);zs(e)}var Vt=new Map,jf=new Set;function as(e){return typeof e.getRootNode=="function"?e.getRootNode():e.nodeType===9?e:e.ownerDocument}var ya=y.d;y.d={f:o0,r:c0,D:d0,C:u0,L:f0,m:m0,X:p0,S:x0,M:h0};function o0(){var e=ya.f(),t=Qn();return e||t}function c0(e){var t=vl(e);t!==null&&t.tag===5&&t.type==="form"?Ld(t):ya.r(e)}var Wl=typeof document>"u"?null:document;function Nf(e,t,a){var i=Wl;if(i&&typeof t=="string"&&t){var n=Bt(t);n='link[rel="'+e+'"][href="'+n+'"]',typeof a=="string"&&(n+='[crossorigin="'+a+'"]'),jf.has(n)||(jf.add(n),e={rel:e,crossOrigin:a,href:t},i.querySelector(n)===null&&(t=i.createElement("link"),ut(t,"link",e),it(t),i.head.appendChild(t)))}}function d0(e){ya.D(e),Nf("dns-prefetch",e,null)}function u0(e,t){ya.C(e,t),Nf("preconnect",e,t)}function f0(e,t,a){ya.L(e,t,a);var i=Wl;if(i&&e&&t){var n='link[rel="preload"][as="'+Bt(t)+'"]';t==="image"&&a&&a.imageSrcSet?(n+='[imagesrcset="'+Bt(a.imageSrcSet)+'"]',typeof a.imageSizes=="string"&&(n+='[imagesizes="'+Bt(a.imageSizes)+'"]')):n+='[href="'+Bt(e)+'"]';var s=n;switch(t){case"style":s=$l(e);break;case"script":s=ei(e)}Vt.has(s)||(e=N({rel:"preload",href:t==="image"&&a&&a.imageSrcSet?void 0:e,as:t},a),Vt.set(s,e),i.querySelector(n)!==null||t==="style"&&i.querySelector(Vi(s))||t==="script"&&i.querySelector(Xi(s))||(t=i.createElement("link"),ut(t,"link",e),it(t),i.head.appendChild(t)))}}function m0(e,t){ya.m(e,t);var a=Wl;if(a&&e){var i=t&&typeof t.as=="string"?t.as:"script",n='link[rel="modulepreload"][as="'+Bt(i)+'"][href="'+Bt(e)+'"]',s=n;switch(i){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":s=ei(e)}if(!Vt.has(s)&&(e=N({rel:"modulepreload",href:e},t),Vt.set(s,e),a.querySelector(n)===null)){switch(i){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(a.querySelector(Xi(s)))return}i=a.createElement("link"),ut(i,"link",e),it(i),a.head.appendChild(i)}}}function x0(e,t,a){ya.S(e,t,a);var i=Wl;if(i&&e){var n=kl(i).hoistableStyles,s=$l(e);t=t||"default";var o=n.get(s);if(!o){var c={loading:0,preload:null};if(o=i.querySelector(Vi(s)))c.loading=5;else{e=N({rel:"stylesheet",href:e,"data-precedence":t},a),(a=Vt.get(s))&&zo(e,a);var u=o=i.createElement("link");it(u),ut(u,"link",e),u._p=new Promise(function(j,C){u.onload=j,u.onerror=C}),u.addEventListener("load",function(){c.loading|=1}),u.addEventListener("error",function(){c.loading|=2}),c.loading|=4,ls(o,t,i)}o={type:"stylesheet",instance:o,count:1,state:c},n.set(s,o)}}}function p0(e,t){ya.X(e,t);var a=Wl;if(a&&e){var i=kl(a).hoistableScripts,n=ei(e),s=i.get(n);s||(s=a.querySelector(Xi(n)),s||(e=N({src:e,async:!0},t),(t=Vt.get(n))&&wo(e,t),s=a.createElement("script"),it(s),ut(s,"link",e),a.head.appendChild(s)),s={type:"script",instance:s,count:1,state:null},i.set(n,s))}}function h0(e,t){ya.M(e,t);var a=Wl;if(a&&e){var i=kl(a).hoistableScripts,n=ei(e),s=i.get(n);s||(s=a.querySelector(Xi(n)),s||(e=N({src:e,async:!0,type:"module"},t),(t=Vt.get(n))&&wo(e,t),s=a.createElement("script"),it(s),ut(s,"link",e),a.head.appendChild(s)),s={type:"script",instance:s,count:1,state:null},i.set(n,s))}}function zf(e,t,a,i){var n=(n=me.current)?as(n):null;if(!n)throw Error(d(446));switch(e){case"meta":case"title":return null;case"style":return typeof a.precedence=="string"&&typeof a.href=="string"?(t=$l(a.href),a=kl(n).hoistableStyles,i=a.get(t),i||(i={type:"style",instance:null,count:0,state:null},a.set(t,i)),i):{type:"void",instance:null,count:0,state:null};case"link":if(a.rel==="stylesheet"&&typeof a.href=="string"&&typeof a.precedence=="string"){e=$l(a.href);var s=kl(n).hoistableStyles,o=s.get(e);if(o||(n=n.ownerDocument||n,o={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},s.set(e,o),(s=n.querySelector(Vi(e)))&&!s._p&&(o.instance=s,o.state.loading=5),Vt.has(e)||(a={rel:"preload",as:"style",href:a.href,crossOrigin:a.crossOrigin,integrity:a.integrity,media:a.media,hrefLang:a.hrefLang,referrerPolicy:a.referrerPolicy},Vt.set(e,a),s||g0(n,e,a,o.state))),t&&i===null)throw Error(d(528,""));return o}if(t&&i!==null)throw Error(d(529,""));return null;case"script":return t=a.async,a=a.src,typeof a=="string"&&t&&typeof t!="function"&&typeof t!="symbol"?(t=ei(a),a=kl(n).hoistableScripts,i=a.get(t),i||(i={type:"script",instance:null,count:0,state:null},a.set(t,i)),i):{type:"void",instance:null,count:0,state:null};default:throw Error(d(444,e))}}function $l(e){return'href="'+Bt(e)+'"'}function Vi(e){return'link[rel="stylesheet"]['+e+"]"}function wf(e){return N({},e,{"data-precedence":e.precedence,precedence:null})}function g0(e,t,a,i){e.querySelector('link[rel="preload"][as="style"]['+t+"]")?i.loading=1:(t=e.createElement("link"),i.preload=t,t.addEventListener("load",function(){return i.loading|=1}),t.addEventListener("error",function(){return i.loading|=2}),ut(t,"link",a),it(t),e.head.appendChild(t))}function ei(e){return'[src="'+Bt(e)+'"]'}function Xi(e){return"script[async]"+e}function Sf(e,t,a){if(t.count++,t.instance===null)switch(t.type){case"style":var i=e.querySelector('style[data-href~="'+Bt(a.href)+'"]');if(i)return t.instance=i,it(i),i;var n=N({},a,{"data-href":a.href,"data-precedence":a.precedence,href:null,precedence:null});return i=(e.ownerDocument||e).createElement("style"),it(i),ut(i,"style",n),ls(i,a.precedence,e),t.instance=i;case"stylesheet":n=$l(a.href);var s=e.querySelector(Vi(n));if(s)return t.state.loading|=4,t.instance=s,it(s),s;i=wf(a),(n=Vt.get(n))&&zo(i,n),s=(e.ownerDocument||e).createElement("link"),it(s);var o=s;return o._p=new Promise(function(c,u){o.onload=c,o.onerror=u}),ut(s,"link",i),t.state.loading|=4,ls(s,a.precedence,e),t.instance=s;case"script":return s=ei(a.src),(n=e.querySelector(Xi(s)))?(t.instance=n,it(n),n):(i=a,(n=Vt.get(s))&&(i=N({},a),wo(i,n)),e=e.ownerDocument||e,n=e.createElement("script"),it(n),ut(n,"link",i),e.head.appendChild(n),t.instance=n);case"void":return null;default:throw Error(d(443,t.type))}else t.type==="stylesheet"&&(t.state.loading&4)===0&&(i=t.instance,t.state.loading|=4,ls(i,a.precedence,e));return t.instance}function ls(e,t,a){for(var i=a.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),n=i.length?i[i.length-1]:null,s=n,o=0;o<i.length;o++){var c=i[o];if(c.dataset.precedence===t)s=c;else if(s!==n)break}s?s.parentNode.insertBefore(e,s.nextSibling):(t=a.nodeType===9?a.head:a,t.insertBefore(e,t.firstChild))}function zo(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.title==null&&(e.title=t.title)}function wo(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.integrity==null&&(e.integrity=t.integrity)}var is=null;function Ef(e,t,a){if(is===null){var i=new Map,n=is=new Map;n.set(a,i)}else n=is,i=n.get(a),i||(i=new Map,n.set(a,i));if(i.has(e))return i;for(i.set(e,null),a=a.getElementsByTagName(e),n=0;n<a.length;n++){var s=a[n];if(!(s[oi]||s[rt]||e==="link"&&s.getAttribute("rel")==="stylesheet")&&s.namespaceURI!=="http://www.w3.org/2000/svg"){var o=s.getAttribute(t)||"";o=e+o;var c=i.get(o);c?c.push(s):i.set(o,[s])}}return i}function Tf(e,t,a){e=e.ownerDocument||e,e.head.insertBefore(a,t==="title"?e.querySelector("head > title"):null)}function b0(e,t,a){if(a===1||t.itemProp!=null)return!1;switch(e){case"meta":case"title":return!0;case"style":if(typeof t.precedence!="string"||typeof t.href!="string"||t.href==="")break;return!0;case"link":if(typeof t.rel!="string"||typeof t.href!="string"||t.href===""||t.onLoad||t.onError)break;switch(t.rel){case"stylesheet":return e=t.disabled,typeof t.precedence=="string"&&e==null;default:return!0}case"script":if(t.async&&typeof t.async!="function"&&typeof t.async!="symbol"&&!t.onLoad&&!t.onError&&t.src&&typeof t.src=="string")return!0}return!1}function _f(e){return!(e.type==="stylesheet"&&(e.state.loading&3)===0)}function y0(e,t,a,i){if(a.type==="stylesheet"&&(typeof i.media!="string"||matchMedia(i.media).matches!==!1)&&(a.state.loading&4)===0){if(a.instance===null){var n=$l(i.href),s=t.querySelector(Vi(n));if(s){t=s._p,t!==null&&typeof t=="object"&&typeof t.then=="function"&&(e.count++,e=ns.bind(e),t.then(e,e)),a.state.loading|=4,a.instance=s,it(s);return}s=t.ownerDocument||t,i=wf(i),(n=Vt.get(n))&&zo(i,n),s=s.createElement("link"),it(s);var o=s;o._p=new Promise(function(c,u){o.onload=c,o.onerror=u}),ut(s,"link",i),a.instance=s}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(a,t),(t=a.state.preload)&&(a.state.loading&3)===0&&(e.count++,a=ns.bind(e),t.addEventListener("load",a),t.addEventListener("error",a))}}var So=0;function v0(e,t){return e.stylesheets&&e.count===0&&rs(e,e.stylesheets),0<e.count||0<e.imgCount?function(a){var i=setTimeout(function(){if(e.stylesheets&&rs(e,e.stylesheets),e.unsuspend){var s=e.unsuspend;e.unsuspend=null,s()}},6e4+t);0<e.imgBytes&&So===0&&(So=62500*e0());var n=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&rs(e,e.stylesheets),e.unsuspend)){var s=e.unsuspend;e.unsuspend=null,s()}},(e.imgBytes>So?50:800)+t);return e.unsuspend=a,function(){e.unsuspend=null,clearTimeout(i),clearTimeout(n)}}:null}function ns(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)rs(this,this.stylesheets);else if(this.unsuspend){var e=this.unsuspend;this.unsuspend=null,e()}}}var ss=null;function rs(e,t){e.stylesheets=null,e.unsuspend!==null&&(e.count++,ss=new Map,t.forEach(k0,e),ss=null,ns.call(e))}function k0(e,t){if(!(t.state.loading&4)){var a=ss.get(e);if(a)var i=a.get(null);else{a=new Map,ss.set(e,a);for(var n=e.querySelectorAll("link[data-precedence],style[data-precedence]"),s=0;s<n.length;s++){var o=n[s];(o.nodeName==="LINK"||o.getAttribute("media")!=="not all")&&(a.set(o.dataset.precedence,o),i=o)}i&&a.set(null,i)}n=t.instance,o=n.getAttribute("data-precedence"),s=a.get(o)||i,s===i&&a.set(null,n),a.set(o,n),this.count++,i=ns.bind(this),n.addEventListener("load",i),n.addEventListener("error",i),s?s.parentNode.insertBefore(n,s.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(n,e.firstChild)),t.state.loading|=4}}var Qi={$$typeof:ue,Provider:null,Consumer:null,_currentValue:te,_currentValue2:te,_threadCount:0};function j0(e,t,a,i,n,s,o,c,u){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=ri(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=ri(0),this.hiddenUpdates=ri(null),this.identifierPrefix=i,this.onUncaughtError=n,this.onCaughtError=s,this.onRecoverableError=o,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=u,this.incompleteTransitions=new Map}function Af(e,t,a,i,n,s,o,c,u,j,C,R){return e=new j0(e,t,a,o,u,j,C,R,c),t=1,s===!0&&(t|=24),s=_t(3,null,null,t),e.current=s,s.stateNode=e,t=ir(),t.refCount++,e.pooledCache=t,t.refCount++,s.memoizedState={element:i,isDehydrated:a,cache:t},or(s),e}function Of(e){return e?(e=Ol,e):Ol}function Cf(e,t,a,i,n,s){n=Of(n),i.context===null?i.context=n:i.pendingContext=n,i=Oa(t),i.payload={element:a},s=s===void 0?null:s,s!==null&&(i.callback=s),a=Ca(e,i,t),a!==null&&(St(a,e,t),wi(a,e,t))}function Df(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var a=e.retryLane;e.retryLane=a!==0&&a<t?a:t}}function Eo(e,t){Df(e,t),(e=e.alternate)&&Df(e,t)}function Mf(e){if(e.tag===13||e.tag===31){var t=ll(e,67108864);t!==null&&St(t,e,67108864),Eo(e,67108864)}}function Rf(e){if(e.tag===13||e.tag===31){var t=Mt();t=ks(t);var a=ll(e,t);a!==null&&St(a,e,t),Eo(e,t)}}var os=!0;function N0(e,t,a,i){var n=_.T;_.T=null;var s=y.p;try{y.p=2,To(e,t,a,i)}finally{y.p=s,_.T=n}}function z0(e,t,a,i){var n=_.T;_.T=null;var s=y.p;try{y.p=8,To(e,t,a,i)}finally{y.p=s,_.T=n}}function To(e,t,a,i){if(os){var n=_o(i);if(n===null)xo(e,t,i,cs,a),Bf(e,i);else if(S0(n,e,t,a,i))i.stopPropagation();else if(Bf(e,i),t&4&&-1<w0.indexOf(e)){for(;n!==null;){var s=vl(n);if(s!==null)switch(s.tag){case 3:if(s=s.stateNode,s.current.memoizedState.isDehydrated){var o=q(s.pendingLanes);if(o!==0){var c=s;for(c.pendingLanes|=2,c.entangledLanes|=2;o;){var u=1<<31-mt(o);c.entanglements[1]|=u,o&=~u}ea(s),(De&6)===0&&(Vn=xe()+500,Gi(0))}}break;case 31:case 13:c=ll(s,2),c!==null&&St(c,s,2),Qn(),Eo(s,2)}if(s=_o(i),s===null&&xo(e,t,i,cs,a),s===n)break;n=s}n!==null&&i.stopPropagation()}else xo(e,t,i,null,a)}}function _o(e){return e=As(e),Ao(e)}var cs=null;function Ao(e){if(cs=null,e=yl(e),e!==null){var t=A(e);if(t===null)e=null;else{var a=t.tag;if(a===13){if(e=S(t),e!==null)return e;e=null}else if(a===31){if(e=B(t),e!==null)return e;e=null}else if(a===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}}return cs=e,null}function Uf(e){switch(e){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(Ce()){case Pe:return 2;case Ft:return 8;case Et:case Na:return 32;case si:return 268435456;default:return 32}default:return 32}}var Oo=!1,Ka=null,qa=null,Va=null,Zi=new Map,Ji=new Map,Xa=[],w0="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function Bf(e,t){switch(e){case"focusin":case"focusout":Ka=null;break;case"dragenter":case"dragleave":qa=null;break;case"mouseover":case"mouseout":Va=null;break;case"pointerover":case"pointerout":Zi.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":Ji.delete(t.pointerId)}}function Fi(e,t,a,i,n,s){return e===null||e.nativeEvent!==s?(e={blockedOn:t,domEventName:a,eventSystemFlags:i,nativeEvent:s,targetContainers:[n]},t!==null&&(t=vl(t),t!==null&&Mf(t)),e):(e.eventSystemFlags|=i,t=e.targetContainers,n!==null&&t.indexOf(n)===-1&&t.push(n),e)}function S0(e,t,a,i,n){switch(t){case"focusin":return Ka=Fi(Ka,e,t,a,i,n),!0;case"dragenter":return qa=Fi(qa,e,t,a,i,n),!0;case"mouseover":return Va=Fi(Va,e,t,a,i,n),!0;case"pointerover":var s=n.pointerId;return Zi.set(s,Fi(Zi.get(s)||null,e,t,a,i,n)),!0;case"gotpointercapture":return s=n.pointerId,Ji.set(s,Fi(Ji.get(s)||null,e,t,a,i,n)),!0}return!1}function Lf(e){var t=yl(e.target);if(t!==null){var a=A(t);if(a!==null){if(t=a.tag,t===13){if(t=S(a),t!==null){e.blockedOn=t,Po(e.priority,function(){Rf(a)});return}}else if(t===31){if(t=B(a),t!==null){e.blockedOn=t,Po(e.priority,function(){Rf(a)});return}}else if(t===3&&a.stateNode.current.memoizedState.isDehydrated){e.blockedOn=a.tag===3?a.stateNode.containerInfo:null;return}}}e.blockedOn=null}function ds(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var a=_o(e.nativeEvent);if(a===null){a=e.nativeEvent;var i=new a.constructor(a.type,a);_s=i,a.target.dispatchEvent(i),_s=null}else return t=vl(a),t!==null&&Mf(t),e.blockedOn=a,!1;t.shift()}return!0}function Hf(e,t,a){ds(e)&&a.delete(t)}function E0(){Oo=!1,Ka!==null&&ds(Ka)&&(Ka=null),qa!==null&&ds(qa)&&(qa=null),Va!==null&&ds(Va)&&(Va=null),Zi.forEach(Hf),Ji.forEach(Hf)}function us(e,t){e.blockedOn===t&&(e.blockedOn=null,Oo||(Oo=!0,r.unstable_scheduleCallback(r.unstable_NormalPriority,E0)))}var fs=null;function Yf(e){fs!==e&&(fs=e,r.unstable_scheduleCallback(r.unstable_NormalPriority,function(){fs===e&&(fs=null);for(var t=0;t<e.length;t+=3){var a=e[t],i=e[t+1],n=e[t+2];if(typeof i!="function"){if(Ao(i||a)===null)continue;break}var s=vl(a);s!==null&&(e.splice(t,3),t-=3,Tr(s,{pending:!0,data:n,method:a.method,action:i},i,n))}}))}function ti(e){function t(u){return us(u,e)}Ka!==null&&us(Ka,e),qa!==null&&us(qa,e),Va!==null&&us(Va,e),Zi.forEach(t),Ji.forEach(t);for(var a=0;a<Xa.length;a++){var i=Xa[a];i.blockedOn===e&&(i.blockedOn=null)}for(;0<Xa.length&&(a=Xa[0],a.blockedOn===null);)Lf(a),a.blockedOn===null&&Xa.shift();if(a=(e.ownerDocument||e).$$reactFormReplay,a!=null)for(i=0;i<a.length;i+=3){var n=a[i],s=a[i+1],o=n[vt]||null;if(typeof s=="function")o||Yf(a);else if(o){var c=null;if(s&&s.hasAttribute("formAction")){if(n=s,o=s[vt]||null)c=o.formAction;else if(Ao(n)!==null)continue}else c=o.action;typeof c=="function"?a[i+1]=c:(a.splice(i,3),i-=3),Yf(a)}}}function Gf(){function e(s){s.canIntercept&&s.info==="react-transition"&&s.intercept({handler:function(){return new Promise(function(o){return n=o})},focusReset:"manual",scroll:"manual"})}function t(){n!==null&&(n(),n=null),i||setTimeout(a,20)}function a(){if(!i&&!navigation.transition){var s=navigation.currentEntry;s&&s.url!=null&&navigation.navigate(s.url,{state:s.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var i=!1,n=null;return navigation.addEventListener("navigate",e),navigation.addEventListener("navigatesuccess",t),navigation.addEventListener("navigateerror",t),setTimeout(a,100),function(){i=!0,navigation.removeEventListener("navigate",e),navigation.removeEventListener("navigatesuccess",t),navigation.removeEventListener("navigateerror",t),n!==null&&(n(),n=null)}}}function Co(e){this._internalRoot=e}ms.prototype.render=Co.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(d(409));var a=t.current,i=Mt();Cf(a,i,e,t,null,null)},ms.prototype.unmount=Co.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;Cf(e.current,2,null,e,null,null),Qn(),t[bl]=null}};function ms(e){this._internalRoot=e}ms.prototype.unstable_scheduleHydration=function(e){if(e){var t=Fo();e={blockedOn:null,target:e,priority:t};for(var a=0;a<Xa.length&&t!==0&&t<Xa[a].priority;a++);Xa.splice(a,0,e),a===0&&Lf(e)}};var If=v.version;if(If!=="19.2.0")throw Error(d(527,If,"19.2.0"));y.findDOMNode=function(e){var t=e._reactInternals;if(t===void 0)throw typeof e.render=="function"?Error(d(188)):(e=Object.keys(e).join(","),Error(d(268,e)));return e=p(t),e=e!==null?U(e):null,e=e===null?null:e.stateNode,e};var T0={bundleType:0,version:"19.2.0",rendererPackageName:"react-dom",currentDispatcherRef:_,reconcilerVersion:"19.2.0"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var xs=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!xs.isDisabled&&xs.supportsFiber)try{Ja=xs.inject(T0),ht=xs}catch{}}return Wi.createRoot=function(e,t){if(!w(e))throw Error(d(299));var a=!1,i="",n=Zd,s=Jd,o=Fd;return t!=null&&(t.unstable_strictMode===!0&&(a=!0),t.identifierPrefix!==void 0&&(i=t.identifierPrefix),t.onUncaughtError!==void 0&&(n=t.onUncaughtError),t.onCaughtError!==void 0&&(s=t.onCaughtError),t.onRecoverableError!==void 0&&(o=t.onRecoverableError)),t=Af(e,1,!1,null,null,a,i,null,n,s,o,Gf),e[bl]=t.current,mo(e),new Co(t)},Wi.hydrateRoot=function(e,t,a){if(!w(e))throw Error(d(299));var i=!1,n="",s=Zd,o=Jd,c=Fd,u=null;return a!=null&&(a.unstable_strictMode===!0&&(i=!0),a.identifierPrefix!==void 0&&(n=a.identifierPrefix),a.onUncaughtError!==void 0&&(s=a.onUncaughtError),a.onCaughtError!==void 0&&(o=a.onCaughtError),a.onRecoverableError!==void 0&&(c=a.onRecoverableError),a.formState!==void 0&&(u=a.formState)),t=Af(e,1,!0,t,a??null,i,n,u,s,o,c,Gf),t.context=Of(null),a=t.current,i=Mt(),i=ks(i),n=Oa(i),n.callback=null,Ca(a,n,i),a=i,t.current.lanes=a,Wa(t,a),ea(t),e[bl]=t.current,mo(e),new ms(t)},Wi.version="19.2.0",Wi}var Wf;function L0(){if(Wf)return Ro.exports;Wf=1;function r(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r)}catch(v){console.error(v)}}return r(),Ro.exports=B0(),Ro.exports}var H0=L0();const Y0=mx(H0);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const G0=r=>r.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),I0=r=>r.replace(/^([A-Z])|[\s-_]+(\w)/g,(v,E,d)=>d?d.toUpperCase():E.toLowerCase()),$f=r=>{const v=I0(r);return v.charAt(0).toUpperCase()+v.slice(1)},xx=(...r)=>r.filter((v,E,d)=>!!v&&v.trim()!==""&&d.indexOf(v)===E).join(" ").trim(),K0=r=>{for(const v in r)if(v.startsWith("aria-")||v==="role"||v==="title")return!0};/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var q0={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const V0=g.forwardRef(({color:r="currentColor",size:v=24,strokeWidth:E=2,absoluteStrokeWidth:d,className:w="",children:A,iconNode:S,...B},b)=>g.createElement("svg",{ref:b,...q0,width:v,height:v,stroke:r,strokeWidth:d?Number(E)*24/Number(v):E,className:xx("lucide",w),...!A&&!K0(B)&&{"aria-hidden":"true"},...B},[...S.map(([p,U])=>g.createElement(p,U)),...Array.isArray(A)?A:[A]]));/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Fe=(r,v)=>{const E=g.forwardRef(({className:d,...w},A)=>g.createElement(V0,{ref:A,iconNode:v,className:xx(`lucide-${G0($f(r))}`,`lucide-${r}`,d),...w}));return E.displayName=$f(r),E};/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const X0=[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]],Q0=Fe("arrow-left",X0);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Z0=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]],ii=Fe("arrow-right",Z0);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const J0=[["path",{d:"M12 8V4H8",key:"hb8ula"}],["rect",{width:"16",height:"12",x:"4",y:"8",rx:"2",key:"enze0r"}],["path",{d:"M2 14h2",key:"vft8re"}],["path",{d:"M20 14h2",key:"4cs60a"}],["path",{d:"M15 13v2",key:"1xurst"}],["path",{d:"M9 13v2",key:"rq6x2g"}]],F0=Fe("bot",J0);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const P0=[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]],W0=Fe("check",P0);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $0=[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]],Yo=Fe("chevron-right",$0);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const eh=[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]],Go=Fe("chevron-left",eh);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const th=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]],ah=Fe("circle-alert",th);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const lh=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],ai=Fe("circle-check",lh);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ih=[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]],nh=Fe("loader-circle",ih);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const sh=[["path",{d:"M4 5h16",key:"1tepv9"}],["path",{d:"M4 12h16",key:"1lakjw"}],["path",{d:"M4 19h16",key:"1djgab"}]],rh=Fe("menu",sh);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const oh=[["path",{d:"M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",key:"18887p"}]],ch=Fe("message-square",oh);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const dh=[["rect",{x:"14",y:"3",width:"5",height:"18",rx:"1",key:"kaeet6"}],["rect",{x:"5",y:"3",width:"5",height:"18",rx:"1",key:"1wsw3u"}]],uh=Fe("pause",dh);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const fh=[["path",{d:"M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z",key:"10ikf1"}]],mh=Fe("play",fh);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const xh=[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}]],Io=Fe("rotate-ccw",xh);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ph=[["path",{d:"m21 21-4.34-4.34",key:"14j7rj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}]],hh=Fe("search",ph);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const gh=[["path",{d:"M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",key:"1ffxy3"}],["path",{d:"m21.854 2.147-10.94 10.939",key:"12cjpa"}]],bh=Fe("send",gh);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const yh=[["path",{d:"M10 11v6",key:"nco0om"}],["path",{d:"M14 11v6",key:"outv1u"}],["path",{d:"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6",key:"miytrc"}],["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",key:"e791ji"}]],Ko=Fe("trash-2",yh);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const vh=[["path",{d:"M12 3v12",key:"1x0j5s"}],["path",{d:"m17 8-5-5-5 5",key:"7q97r8"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}]],em=Fe("upload",vh);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const kh=[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]],jh=Fe("user",kh);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Nh=[["path",{d:"m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5",key:"ftymec"}],["rect",{x:"2",y:"6",width:"14",height:"12",rx:"2",key:"158x01"}]],tm=Fe("video",Nh);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const zh=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],Xo=Fe("x",zh),am="http://localhost:5000/api";class wh{getToken(){return localStorage.getItem("token")}async request(v,E={}){const d=this.getToken(),w={"Content-Type":"application/json",...E.headers};d&&(w.Authorization=`Bearer ${d}`);try{const A=await fetch(`${am}${v}`,{...E,headers:w}),S=await A.json();if(A.status===401)throw localStorage.removeItem("token"),window.location.href="/#login",new Error("Oturum süresi doldu. Lütfen tekrar giriş yapın.");if(!A.ok)throw new Error(S.error||"Bir hata oluştu");return S}catch(A){throw A instanceof Error?A:new Error("Network hatası. Lütfen internet bağlantınızı kontrol edin.")}}async sendVerificationCode(v,E,d,w){return this.request("/auth/send-verification-code",{method:"POST",body:JSON.stringify({email:v,password:E,name:d,phone:w})})}async verifyAndRegister(v,E,d,w,A){const S=await this.request("/auth/verify-and-register",{method:"POST",body:JSON.stringify({email:v,code:E,password:d,name:w,phone:A})});return S.success&&S.token&&localStorage.setItem("token",S.token),S}async register(v,E,d,w){const A=await this.request("/auth/register",{method:"POST",body:JSON.stringify({email:v,password:E,name:d,phone:w})});return A.success&&A.token&&localStorage.setItem("token",A.token),A}async login(v,E){const d=this.getToken(),w={"Content-Type":"application/json"};d&&(w.Authorization=`Bearer ${d}`);try{const A=await fetch(`${am}/auth/login`,{method:"POST",headers:w,body:JSON.stringify({email:v,password:E})}),S=await A.json();if(A.status===401)return{success:!1,error:S.error||"E-posta veya şifre hatalı"};if(!A.ok)throw new Error(S.error||"Bir hata oluştu");return S.success&&S.token&&localStorage.setItem("token",S.token),S}catch(A){throw A instanceof Error?A:new Error("Network hatası. Lütfen internet bağlantınızı kontrol edin.")}}async getCurrentUser(){return this.request("/auth/me")}logout(){localStorage.removeItem("token"),window.location.href="/"}isAuthenticated(){return!!this.getToken()}async sendPasswordResetCode(v){return this.request("/auth/forgot-password",{method:"POST",body:JSON.stringify({email:v})})}async resetPassword(v,E,d){return this.request("/auth/reset-password",{method:"POST",body:JSON.stringify({email:v,code:E,newPassword:d})})}async saveDashboardData(v){return this.request("/auth/dashboard/data",{method:"PUT",body:JSON.stringify(v)})}async getDashboardData(){return this.request("/auth/dashboard/data")}}const ta=new wh,Sh=Object.freeze(Object.defineProperty({__proto__:null,apiService:ta},Symbol.toStringTag,{value:"Module"})),Eh=({email:r,onClose:v})=>{const[E,d]=g.useState(["","","",""]),[w,A]=g.useState(""),[S,B]=g.useState(""),[b,p]=g.useState(!1),[U,N]=g.useState(!1),[G,L]=g.useState(null),[Z,ie]=g.useState(!1),[J,H]=g.useState(0),K=g.useRef([]);g.useEffect(()=>{if(J>0){const Y=setTimeout(()=>H(J-1),1e3);return()=>clearTimeout(Y)}},[J]);const ue=(Y,ne)=>{var Oe;if(!/^\d*$/.test(ne))return;const re=[...E];re[Y]=ne.slice(-1),d(re),L(null),ne&&Y<3&&((Oe=K.current[Y+1])==null||Oe.focus())},$=(Y,ne)=>{var re;ne.key==="Backspace"&&!E[Y]&&Y>0&&((re=K.current[Y-1])==null||re.focus())},Ye=Y=>{var re;Y.preventDefault();const ne=Y.clipboardData.getData("text").slice(0,4);if(/^\d{4}$/.test(ne)){const Oe=ne.split("");d([...Oe,...Array(4-Oe.length).fill("")].slice(0,4)),(re=K.current[3])==null||re.focus()}},de=async Y=>{var re,Oe;Y.preventDefault(),L(null);const ne=E.join("");if(ne.length!==4){L("Lütfen 4 haneli kodu giriniz");return}if(w.length<8){L("Şifre en az 8 karakter olmalıdır");return}if(!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(w)){L("Şifre en az bir küçük harf, bir büyük harf ve bir rakam içermelidir");return}if(w!==S){L("Şifreler eşleşmiyor");return}N(!0);try{const ce=await ta.resetPassword(r,ne,w);ce.success?(alert("Şifreniz başarıyla güncellendi! Lütfen yeni şifrenizle giriş yapın."),v(),window.dispatchEvent(new CustomEvent("openLoginModal"))):(L(ce.error||"Kod doğrulanamadı veya şifre güncellenemedi. Lütfen tekrar deneyin."),d(["","","",""]),(re=K.current[0])==null||re.focus())}catch(ce){L(ce.message||"Bir hata oluştu. Lütfen tekrar deneyin."),d(["","","",""]),(Oe=K.current[0])==null||Oe.focus()}finally{N(!1)}},Q=async()=>{var Y;ie(!0),L(null);try{const ne=await ta.sendPasswordResetCode(r);ne.success?(H(60),d(["","","",""]),(Y=K.current[0])==null||Y.focus()):L(ne.error||"Kod gönderilemedi. Lütfen tekrar deneyin.")}catch(ne){L(ne.message||"Kod gönderilemedi. Lütfen tekrar deneyin.")}finally{ie(!1)}};return l.jsx("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm px-4",children:l.jsx("div",{className:"bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto",children:l.jsxs("div",{className:"p-8",children:[l.jsx("button",{onClick:v,className:"absolute right-4 top-4 text-gray-500 hover:text-gray-700 transition text-xl","aria-label":"Kapat",children:"×"}),l.jsxs("div",{className:"text-center mb-6",children:[l.jsx("div",{className:"w-16 h-16 bg-gradient-to-br from-orange-500 to-red-600 rounded-full flex items-center justify-center mx-auto mb-4",children:l.jsx("svg",{className:"w-8 h-8 text-white",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:l.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"})})}),l.jsx("h2",{className:"text-2xl font-bold text-gray-800 mb-2",children:"Yeni Şifre Belirle"}),l.jsxs("p",{className:"text-gray-600 text-sm",children:[l.jsx("strong",{children:r})," adresine gönderilen 4 haneli kodu giriniz"]})]}),G&&l.jsx("div",{className:"mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm",children:G}),l.jsxs("form",{onSubmit:de,className:"space-y-6",children:[l.jsxs("div",{children:[l.jsx("label",{className:"block text-sm font-semibold text-gray-700 mb-3 text-center",children:"Şifre Sıfırlama Kodu"}),l.jsx("div",{className:"flex gap-3 justify-center",onPaste:Ye,children:E.map((Y,ne)=>l.jsx("input",{ref:re=>K.current[ne]=re,type:"text",inputMode:"numeric",maxLength:1,value:Y,onChange:re=>ue(ne,re.target.value),onKeyDown:re=>$(ne,re),className:"w-14 h-14 text-center text-2xl font-bold border-2 border-gray-300 rounded-xl focus:outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-200 transition"},ne))}),l.jsx("p",{className:"text-xs text-gray-500 text-center mt-2",children:"Kod 10 dakika geçerlidir"})]}),l.jsxs("div",{children:[l.jsxs("label",{className:"block text-sm font-semibold text-gray-700 mb-2",children:["Yeni Şifre ",l.jsx("span",{className:"text-red-500",children:"*"})]}),l.jsxs("div",{className:"relative",children:[l.jsx("input",{type:b?"text":"password",required:!0,value:w,onChange:Y=>A(Y.target.value),className:"w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-200 transition",placeholder:"En az 8 karakter"}),l.jsx("button",{type:"button",onClick:()=>p(Y=>!Y),className:"absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 text-sm",children:b?"Gizle":"Göster"})]}),l.jsx("p",{className:"text-xs text-gray-500 mt-1",children:"En az 8 karakter, bir büyük harf, bir küçük harf ve bir rakam içermelidir"})]}),l.jsxs("div",{children:[l.jsxs("label",{className:"block text-sm font-semibold text-gray-700 mb-2",children:["Yeni Şifre (Tekrar) ",l.jsx("span",{className:"text-red-500",children:"*"})]}),l.jsx("input",{type:b?"text":"password",required:!0,value:S,onChange:Y=>B(Y.target.value),className:"w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-200 transition",placeholder:"Şifrenizi tekrar giriniz"})]}),l.jsx("button",{type:"submit",disabled:U||E.join("").length!==4||!w||!S,className:"w-full py-3 text-white font-bold rounded-lg shadow-lg bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed",children:U?"Şifre Güncelleniyor...":"Şifreyi Güncelle"}),l.jsx("div",{className:"text-center",children:l.jsx("button",{type:"button",onClick:Q,disabled:Z||J>0,className:"text-sm text-orange-600 hover:text-orange-700 font-semibold disabled:text-gray-400 disabled:cursor-not-allowed",children:J>0?`Yeni kod gönder (${J}s)`:Z?"Gönderiliyor...":"Kodu tekrar gönder"})})]})]})})})},Th=({onClose:r})=>{const[v,E]=g.useState(""),[d,w]=g.useState(!1),[A,S]=g.useState(null),[B,b]=g.useState(!1),[p,U]=g.useState(!1),[N,G]=g.useState(""),L=async ie=>{ie.preventDefault(),S(null),w(!0);try{const J=await ta.sendPasswordResetCode(v);J.success?(b(!0),G(v.split("@")[0]),J.code&&(console.log(`
========================================`),console.log("SIFRE SIFIRLAMA KODU"),console.log("========================================"),console.log(`E-posta: ${v}`),console.log(`KOD: ${J.code}`),console.log(`========================================
`))):S(J.error||"Bir hata oluştu. Lütfen tekrar deneyin.")}catch(J){S(J.message||"Bir hata oluştu. Lütfen tekrar deneyin.")}finally{w(!1)}},Z=()=>{U(!0)};return p?l.jsx(Eh,{email:v,onClose:r}):l.jsx("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm px-4",children:l.jsx("div",{className:"bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden",children:l.jsxs("div",{className:"p-8",children:[l.jsx("button",{onClick:r,className:"absolute right-4 top-4 text-gray-500 hover:text-gray-700 transition text-xl","aria-label":"Kapat",children:"×"}),l.jsxs("div",{className:"text-center mb-6",children:[l.jsx("div",{className:"w-16 h-16 bg-gradient-to-br from-orange-500 to-red-600 rounded-full flex items-center justify-center mx-auto mb-4",children:l.jsx("svg",{className:"w-8 h-8 text-white",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:l.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"})})}),l.jsx("h2",{className:"text-2xl font-bold text-gray-800 mb-2",children:"Şifremi Unuttum"}),l.jsx("p",{className:"text-gray-600 text-sm",children:B?"E-posta adresinize şifre sıfırlama kodu gönderildi":"E-posta adresinizi girin, size şifre sıfırlama kodu gönderelim"})]}),A&&l.jsx("div",{className:"mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm",children:A}),B?l.jsxs("div",{className:"space-y-4",children:[l.jsx("div",{className:"p-4 bg-green-50 border border-green-200 rounded-lg",children:l.jsxs("p",{className:"text-green-800 text-sm text-center",children:[l.jsx("strong",{children:v})," adresine şifre sıfırlama kodu gönderildi.",l.jsx("br",{}),"Lütfen e-posta kutunuzu kontrol edin."]})}),l.jsx("button",{onClick:Z,className:"w-full py-3 text-white font-bold rounded-lg shadow-lg bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300",children:"Kodu Girdim, Devam Et"}),l.jsx("button",{onClick:r,className:"w-full py-2 text-gray-600 hover:text-gray-800 font-semibold",children:"İptal"})]}):l.jsxs("form",{onSubmit:L,className:"space-y-4",children:[l.jsxs("div",{children:[l.jsxs("label",{className:"block text-sm font-semibold text-gray-700 mb-2",children:["E-posta Adresi ",l.jsx("span",{className:"text-red-500",children:"*"})]}),l.jsx("input",{type:"email",required:!0,value:v,onChange:ie=>E(ie.target.value),className:"w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-200 transition",placeholder:"ornek@email.com"})]}),l.jsx("button",{type:"submit",disabled:d,className:"w-full py-3 text-white font-bold rounded-lg shadow-lg bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed",children:d?"Gönderiliyor...":"Şifre Sıfırlama Kodu Gönder"}),l.jsx("button",{type:"button",onClick:r,className:"w-full py-2 text-gray-600 hover:text-gray-800 font-semibold",children:"İptal"})]})]})})})},px=({onClose:r,onSuccess:v,onOpenRegister:E})=>{const[d,w]=g.useState(!1),[A,S]=g.useState(!1),[B,b]=g.useState(null),[p,U]=g.useState(!1),[N,G]=g.useState({email:"",password:""}),L={backgroundImage:'linear-gradient(135deg, rgba(102,126,234,0.95), rgba(118,75,162,0.95)), url("https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=900&q=80")',backgroundSize:"cover",backgroundPosition:"center"};return l.jsxs("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm px-4",children:[l.jsx("style",{children:`
        .floating-icon { animation: float 3s ease-in-out infinite; }
        @keyframes float { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }
        .input-field:focus {
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
        }
        .checkbox-custom {
          appearance: none;
          width: 18px;
          height: 18px;
          border: 2px solid #d1d5db;
          border-radius: 4px;
          cursor: pointer;
          transition: all 0.2s;
          flex-shrink: 0;
        }
        .checkbox-custom:checked {
          background-color: #667eea;
          border-color: #667eea;
          background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='white'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='3' d='M5 13l4 4L19 7'%3E%3C/path%3E%3C/svg%3E");
          background-size: 14px;
          background-position: center;
          background-repeat: no-repeat;
        }
        .login-submit {
          position: relative;
          overflow: hidden;
        }
        .login-submit::before {
          content: '';
          position: absolute;
          top: 0;
          left: -100%;
          width: 100%;
          height: 100%;
          background: linear-gradient(90deg, transparent, rgba(255,255,255,0.25), transparent);
          transition: left 0.6s ease;
        }
        .login-submit:hover::before { left: 100%; }
      `}),l.jsxs("div",{className:"bg-white w-full max-w-5xl rounded-3xl overflow-hidden shadow-2xl grid grid-cols-1 md:grid-cols-2",children:[l.jsx("div",{className:"text-white p-8 md:p-10 flex items-center",style:L,children:l.jsxs("div",{className:"space-y-6 max-w-md text-center md:text-left",children:[l.jsx("div",{className:"floating-icon",children:l.jsx("svg",{className:"w-16 h-16 mx-auto md:mx-0",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:l.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:1.5,d:"M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"})})}),l.jsx("h1",{className:"text-3xl md:text-4xl font-bold leading-tight",children:"Tekrar Hoş Geldiniz"}),l.jsx("p",{className:"text-lg md:text-xl opacity-90 leading-relaxed",children:"İyileşme yolculuğunuza kaldığınız yerden devam edin. Bugün kendiniz için harika bir gün olsun."}),l.jsxs("div",{className:"flex items-center justify-center md:justify-start gap-3 pt-2",children:[l.jsx("div",{className:"h-1 w-12 bg-white opacity-50 rounded"}),l.jsx("div",{className:"h-1 w-12 bg-white opacity-70 rounded"}),l.jsx("div",{className:"h-1 w-12 bg-white opacity-50 rounded"})]})]})}),l.jsxs("div",{className:"p-8 md:p-10 bg-gray-50 relative",children:[l.jsx("button",{onClick:r,className:"absolute right-4 top-4 text-gray-500 hover:text-gray-700 transition text-xl","aria-label":"Kapat",children:"×"}),l.jsxs("div",{className:"bg-white rounded-2xl shadow-lg p-6 md:p-8",children:[l.jsxs("div",{className:"text-center mb-6",children:[l.jsx("h2",{className:"text-3xl font-bold text-gray-800 mb-2",children:"Hesabınıza Giriş Yapın"}),l.jsx("p",{className:"text-gray-600 text-sm",children:"Sağlık yolculuğunuza devam edin"})]}),B&&l.jsx("div",{className:"mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm",children:B}),l.jsxs("form",{className:"space-y-5",onSubmit:async Z=>{Z.preventDefault(),b(null),S(!0);try{const ie=await ta.login(N.email,N.password);ie.success?(localStorage.setItem("showLoginSuccess","true"),r(),v?v():(window.location.hash="#dashboard",setTimeout(()=>{window.location.reload()},100))):b(ie.error||"Giriş başarısız. Lütfen tekrar deneyin.")}catch(ie){const J=ie.message||"Bir hata oluştu. Lütfen tekrar deneyin.";b(J)}finally{S(!1)}},children:[l.jsxs("div",{children:[l.jsxs("label",{className:"block text-sm font-semibold text-gray-700 mb-2",children:["E-posta Adresi ",l.jsx("span",{className:"text-red-500",children:"*"})]}),l.jsx("input",{type:"email",required:!0,value:N.email,onChange:Z=>G({...N,email:Z.target.value}),className:"input-field w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-purple-500",placeholder:"ornek@email.com"})]}),l.jsxs("div",{children:[l.jsxs("label",{className:"block text-sm font-semibold text-gray-700 mb-2",children:["Şifre ",l.jsx("span",{className:"text-red-500",children:"*"})]}),l.jsxs("div",{className:"relative",children:[l.jsx("input",{type:d?"text":"password",required:!0,value:N.password,onChange:Z=>G({...N,password:Z.target.value}),className:"input-field w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-purple-500",placeholder:"••••••••"}),l.jsx("button",{type:"button",onClick:()=>w(Z=>!Z),className:"absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 text-sm","aria-label":"Şifreyi göster/gizle",children:d?"Gizle":"Göster"})]})]}),l.jsxs("div",{className:"flex items-center justify-between pt-2",children:[l.jsxs("label",{className:"flex items-center gap-2 cursor-pointer",children:[l.jsx("input",{type:"checkbox",className:"checkbox-custom"}),l.jsx("span",{className:"text-sm text-gray-700",children:"Beni Hatırla"})]}),l.jsx("button",{type:"button",onClick:()=>U(!0),className:"text-sm text-blue-600 font-semibold hover:underline",children:"Şifremi Unuttum"})]}),l.jsx("button",{type:"submit",disabled:A,className:"login-submit w-full py-4 text-white font-bold rounded-lg shadow-lg bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300 mt-6 disabled:opacity-50 disabled:cursor-not-allowed",children:A?"Giriş yapılıyor...":"Giriş Yap"}),l.jsxs("div",{className:"mt-5 text-center text-sm text-gray-600",children:["Henüz hesabınız yok mu?"," ",l.jsx("button",{type:"button",onClick:()=>{r(),E?E():window.location.hash="#register"},className:"text-purple-600 hover:text-purple-700 font-semibold",children:"Kayıt Olun"})]})]})]})]})]}),p&&l.jsx(Th,{onClose:()=>{U(!1),r()}})]})},hx=({size:r=80})=>l.jsxs("div",{className:"animated-logo-container",style:{width:r,height:r},children:[l.jsx("style",{children:`
        .animated-logo-container {
          position: relative;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        
        .logo-svg {
          width: 100%;
          height: 100%;
        }
        
        /* Pulse ring animation */
        .pulse-ring {
          animation: pulseRing 2s ease-out infinite;
          transform-origin: center;
        }
        
        @keyframes pulseRing {
          0% { transform: scale(0.8); opacity: 0.8; }
          50% { transform: scale(1); opacity: 0.4; }
          100% { transform: scale(0.8); opacity: 0.8; }
        }
        
        /* Figure bounce animation */
        .figure-body {
          animation: figureMove 3s ease-in-out infinite;
          transform-origin: center bottom;
        }
        
        @keyframes figureMove {
          0%, 100% { transform: translateY(0) scaleY(1); }
          25% { transform: translateY(-3px) scaleY(1.02); }
          50% { transform: translateY(0) scaleY(0.98); }
          75% { transform: translateY(-2px) scaleY(1.01); }
        }
        
        /* Arms animation */
        .arm-left {
          animation: armSwingLeft 2s ease-in-out infinite;
          transform-origin: 28px 32px;
        }
        
        .arm-right {
          animation: armSwingRight 2s ease-in-out infinite;
          transform-origin: 52px 32px;
        }
        
        @keyframes armSwingLeft {
          0%, 100% { transform: rotate(-20deg); }
          50% { transform: rotate(30deg); }
        }
        
        @keyframes armSwingRight {
          0%, 100% { transform: rotate(20deg); }
          50% { transform: rotate(-30deg); }
        }
        
        /* Gradient rotation */
        .gradient-bg {
          animation: gradientShift 4s linear infinite;
        }
        
        @keyframes gradientShift {
          0% { stop-color: #667eea; }
          50% { stop-color: #764ba2; }
          100% { stop-color: #667eea; }
        }
        
        /* Sparkle effect */
        .sparkle {
          animation: sparkle 2s ease-in-out infinite;
        }
        
        .sparkle:nth-child(1) { animation-delay: 0s; }
        .sparkle:nth-child(2) { animation-delay: 0.5s; }
        .sparkle:nth-child(3) { animation-delay: 1s; }
        
        @keyframes sparkle {
          0%, 100% { opacity: 0; transform: scale(0); }
          50% { opacity: 1; transform: scale(1); }
        }
      `}),l.jsxs("svg",{viewBox:"0 0 80 80",className:"logo-svg",children:[l.jsxs("defs",{children:[l.jsxs("linearGradient",{id:"logoGradient",x1:"0%",y1:"0%",x2:"100%",y2:"100%",children:[l.jsx("stop",{offset:"0%",stopColor:"#667eea",className:"gradient-bg"}),l.jsx("stop",{offset:"100%",stopColor:"#10b981"})]}),l.jsxs("linearGradient",{id:"accentGradient",x1:"0%",y1:"0%",x2:"100%",y2:"100%",children:[l.jsx("stop",{offset:"0%",stopColor:"#f59e0b"}),l.jsx("stop",{offset:"100%",stopColor:"#ef4444"})]}),l.jsxs("filter",{id:"glow",children:[l.jsx("feGaussianBlur",{stdDeviation:"2",result:"coloredBlur"}),l.jsxs("feMerge",{children:[l.jsx("feMergeNode",{in:"coloredBlur"}),l.jsx("feMergeNode",{in:"SourceGraphic"})]})]})]}),l.jsx("circle",{cx:"40",cy:"40",r:"36",fill:"url(#logoGradient)",opacity:"0.15",className:"pulse-ring"}),l.jsx("circle",{cx:"40",cy:"40",r:"32",fill:"url(#logoGradient)",opacity:"0.1"}),l.jsx("circle",{cx:"40",cy:"40",r:"35",fill:"none",stroke:"url(#logoGradient)",strokeWidth:"3",strokeLinecap:"round",strokeDasharray:"180 220",className:"pulse-ring"}),l.jsxs("g",{className:"figure-body",children:[l.jsx("circle",{cx:"40",cy:"24",r:"8",fill:"url(#logoGradient)",filter:"url(#glow)"}),l.jsx("path",{d:"M40 32 L40 52",stroke:"url(#logoGradient)",strokeWidth:"4",strokeLinecap:"round"}),l.jsx("path",{d:"M40 52 L32 66",stroke:"url(#logoGradient)",strokeWidth:"4",strokeLinecap:"round"}),l.jsx("path",{d:"M40 52 L48 66",stroke:"url(#logoGradient)",strokeWidth:"4",strokeLinecap:"round"})]}),l.jsx("path",{d:"M40 36 L26 28",stroke:"url(#logoGradient)",strokeWidth:"4",strokeLinecap:"round",className:"arm-left"}),l.jsx("path",{d:"M40 36 L54 28",stroke:"url(#logoGradient)",strokeWidth:"4",strokeLinecap:"round",className:"arm-right"}),l.jsxs("g",{className:"arm-left",children:[l.jsx("rect",{x:"20",y:"22",width:"12",height:"4",rx:"2",fill:"url(#accentGradient)"}),l.jsx("circle",{cx:"20",cy:"24",r:"4",fill:"url(#accentGradient)"}),l.jsx("circle",{cx:"32",cy:"24",r:"4",fill:"url(#accentGradient)"})]}),l.jsx("circle",{cx:"18",cy:"18",r:"2",fill:"#f59e0b",className:"sparkle"}),l.jsx("circle",{cx:"62",cy:"45",r:"1.5",fill:"#10b981",className:"sparkle"}),l.jsx("circle",{cx:"25",cy:"58",r:"1.5",fill:"#667eea",className:"sparkle"}),l.jsx("path",{d:"M12 40 Q8 42, 12 44",stroke:"#667eea",strokeWidth:"1.5",fill:"none",opacity:"0.5",strokeLinecap:"round",className:"pulse-ring"}),l.jsx("path",{d:"M68 40 Q72 42, 68 44",stroke:"#667eea",strokeWidth:"1.5",fill:"none",opacity:"0.5",strokeLinecap:"round",className:"pulse-ring"})]})]}),Ho=[{href:"#hero",label:"Ana Sayfa"},{href:"#process",label:"Sistem Nasıl İşliyor?"},{href:"#packages",label:"Hizmet Paketleri"},{href:"#blog",label:"Blog"},{href:"#testimonials",label:"Müşteri Yorumları"},{href:"#about",label:"Hakkımızda"},{href:"#contact",label:"İletişim"}],_h=({onOpenRegister:r,isAuthenticated:v=!1})=>{const[E,d]=g.useState(!1),[w,A]=g.useState("#hero"),[S,B]=g.useState(!1),b=()=>{r&&r()};g.useEffect(()=>{const N=()=>{const G=window.location.hash||"#hero";A(G)};return N(),window.addEventListener("hashchange",N),()=>window.removeEventListener("hashchange",N)},[]),g.useEffect(()=>{const N=Ho.map(L=>L.href.replace("#","")),G=new IntersectionObserver(L=>{L.forEach(Z=>{Z.isIntersecting&&A(`#${Z.target.id}`)})},{root:null,rootMargin:"0px 0px -60% 0px",threshold:.2});return N.forEach(L=>{const Z=document.getElementById(L);Z&&G.observe(Z)}),()=>G.disconnect()},[]);const p=N=>{A(N),d(!1)},U=N=>`px-3 py-2 rounded-full transition-colors ${w===N?"bg-blue-600 text-white shadow-md":"text-gray-700 hover:bg-blue-50 hover:text-blue-700"}`;return l.jsxs(l.Fragment,{children:[l.jsxs("header",{className:"w-full bg-white shadow-sm sticky top-0 z-40",children:[l.jsx("div",{className:"hidden md:block w-full bg-gradient-to-r from-[#263562] to-[#1e2a4a] text-white py-3 shadow-sm",children:l.jsxs("div",{className:"container mx-auto px-6 flex justify-between items-center",children:[l.jsxs("div",{className:"flex items-center gap-2 text-sm font-medium",children:[l.jsx("svg",{className:"w-4 h-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:l.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"})}),l.jsx("span",{children:"iletisim@egzersizlab.com"})]}),l.jsxs("div",{className:"flex items-center gap-3",children:[l.jsx("a",{href:"#",onClick:N=>{N.preventDefault(),B(!0)},className:"relative px-6 py-2 text-sm font-semibold rounded-lg border-2 border-white bg-transparent text-white transition hover:bg-white hover:text-[#263562]",children:"Giriş Yap"}),l.jsx("div",{className:"w-px h-6 bg-white/30"}),l.jsx("a",{href:"#",onClick:N=>{N.preventDefault(),b()},className:"relative px-6 py-2 text-sm font-semibold rounded-lg bg-blue-500 hover:bg-blue-600 text-white shadow-md hover:shadow-lg transition",children:"Kayıt Ol"})]})]})}),l.jsx("div",{className:"container mx-auto px-4 py-4",children:l.jsxs("div",{className:"flex justify-between items-center",children:[l.jsxs("div",{className:"flex items-center gap-3",children:[l.jsx(hx,{size:70}),l.jsxs("div",{className:"flex flex-col",children:[l.jsx("span",{className:"text-3xl font-bold bg-gradient-to-r from-[#667eea] to-[#10b981] bg-clip-text text-transparent",children:"EgzersizLab"}),l.jsx("span",{className:"text-xs text-gray-500 font-medium tracking-wider",children:"DİJİTAL REHABİLİTASYON"})]})]}),l.jsx("nav",{className:"hidden lg:flex items-center gap-3 font-medium text-gray-600 bg-white/70 backdrop-blur-lg rounded-full px-3 py-2 shadow-sm border border-gray-100",children:Ho.map(N=>l.jsx("a",{href:N.href,onClick:()=>p(N.href),className:U(N.href),children:N.label},N.href))}),l.jsx("div",{className:"hidden lg:flex items-center gap-4",children:l.jsxs("div",{className:"relative",children:[l.jsx("input",{type:"text",placeholder:"Ara...",className:"pl-4 pr-10 py-2 border border-gray-200 rounded-full text-sm focus:outline-none focus:border-blue-500 w-48 transition-all focus:w-64"}),l.jsx(hh,{className:"absolute right-3 top-2.5 text-gray-400",size:18})]})}),l.jsx("button",{className:"lg:hidden p-2 text-gray-700",onClick:()=>d(!E),children:E?l.jsx(Xo,{size:24}):l.jsx(rh,{size:24})})]})}),E&&l.jsx("div",{className:"lg:hidden bg-white border-t border-gray-100 py-4 px-4 shadow-lg absolute w-full left-0 z-50",children:l.jsxs("div",{className:"flex flex-col space-y-4",children:[Ho.map(N=>l.jsx("a",{href:N.href,onClick:()=>p(N.href),className:U(N.href),children:N.label},N.href)),l.jsxs("div",{className:"border-t pt-4 flex flex-col gap-3",children:[l.jsxs("button",{className:"flex items-center gap-2 text-gray-700 font-medium",onClick:()=>B(!0),children:[l.jsx(jh,{size:18})," Giriş Yap"]}),l.jsx("button",{className:"bg-[#263562] text-white py-2 rounded-lg font-medium w-full",onClick:b,children:"Kayıt Ol"})]})]})})]}),S&&l.jsx(px,{onClose:()=>B(!1),onOpenRegister:()=>{B(!1),b()}})]})};/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *//**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */var lm;(function(r){r.OUTCOME_UNSPECIFIED="OUTCOME_UNSPECIFIED",r.OUTCOME_OK="OUTCOME_OK",r.OUTCOME_FAILED="OUTCOME_FAILED",r.OUTCOME_DEADLINE_EXCEEDED="OUTCOME_DEADLINE_EXCEEDED"})(lm||(lm={}));var im;(function(r){r.LANGUAGE_UNSPECIFIED="LANGUAGE_UNSPECIFIED",r.PYTHON="PYTHON"})(im||(im={}));var nm;(function(r){r.SCHEDULING_UNSPECIFIED="SCHEDULING_UNSPECIFIED",r.SILENT="SILENT",r.WHEN_IDLE="WHEN_IDLE",r.INTERRUPT="INTERRUPT"})(nm||(nm={}));var sm;(function(r){r.TYPE_UNSPECIFIED="TYPE_UNSPECIFIED",r.STRING="STRING",r.NUMBER="NUMBER",r.INTEGER="INTEGER",r.BOOLEAN="BOOLEAN",r.ARRAY="ARRAY",r.OBJECT="OBJECT",r.NULL="NULL"})(sm||(sm={}));var rm;(function(r){r.MODE_UNSPECIFIED="MODE_UNSPECIFIED",r.MODE_DYNAMIC="MODE_DYNAMIC"})(rm||(rm={}));var om;(function(r){r.API_SPEC_UNSPECIFIED="API_SPEC_UNSPECIFIED",r.SIMPLE_SEARCH="SIMPLE_SEARCH",r.ELASTIC_SEARCH="ELASTIC_SEARCH"})(om||(om={}));var cm;(function(r){r.AUTH_TYPE_UNSPECIFIED="AUTH_TYPE_UNSPECIFIED",r.NO_AUTH="NO_AUTH",r.API_KEY_AUTH="API_KEY_AUTH",r.HTTP_BASIC_AUTH="HTTP_BASIC_AUTH",r.GOOGLE_SERVICE_ACCOUNT_AUTH="GOOGLE_SERVICE_ACCOUNT_AUTH",r.OAUTH="OAUTH",r.OIDC_AUTH="OIDC_AUTH"})(cm||(cm={}));var dm;(function(r){r.HTTP_IN_UNSPECIFIED="HTTP_IN_UNSPECIFIED",r.HTTP_IN_QUERY="HTTP_IN_QUERY",r.HTTP_IN_HEADER="HTTP_IN_HEADER",r.HTTP_IN_PATH="HTTP_IN_PATH",r.HTTP_IN_BODY="HTTP_IN_BODY",r.HTTP_IN_COOKIE="HTTP_IN_COOKIE"})(dm||(dm={}));var um;(function(r){r.PHISH_BLOCK_THRESHOLD_UNSPECIFIED="PHISH_BLOCK_THRESHOLD_UNSPECIFIED",r.BLOCK_LOW_AND_ABOVE="BLOCK_LOW_AND_ABOVE",r.BLOCK_MEDIUM_AND_ABOVE="BLOCK_MEDIUM_AND_ABOVE",r.BLOCK_HIGH_AND_ABOVE="BLOCK_HIGH_AND_ABOVE",r.BLOCK_HIGHER_AND_ABOVE="BLOCK_HIGHER_AND_ABOVE",r.BLOCK_VERY_HIGH_AND_ABOVE="BLOCK_VERY_HIGH_AND_ABOVE",r.BLOCK_ONLY_EXTREMELY_HIGH="BLOCK_ONLY_EXTREMELY_HIGH"})(um||(um={}));var fm;(function(r){r.THINKING_LEVEL_UNSPECIFIED="THINKING_LEVEL_UNSPECIFIED",r.LOW="LOW",r.HIGH="HIGH"})(fm||(fm={}));var mm;(function(r){r.HARM_CATEGORY_UNSPECIFIED="HARM_CATEGORY_UNSPECIFIED",r.HARM_CATEGORY_HARASSMENT="HARM_CATEGORY_HARASSMENT",r.HARM_CATEGORY_HATE_SPEECH="HARM_CATEGORY_HATE_SPEECH",r.HARM_CATEGORY_SEXUALLY_EXPLICIT="HARM_CATEGORY_SEXUALLY_EXPLICIT",r.HARM_CATEGORY_DANGEROUS_CONTENT="HARM_CATEGORY_DANGEROUS_CONTENT",r.HARM_CATEGORY_CIVIC_INTEGRITY="HARM_CATEGORY_CIVIC_INTEGRITY",r.HARM_CATEGORY_IMAGE_HATE="HARM_CATEGORY_IMAGE_HATE",r.HARM_CATEGORY_IMAGE_DANGEROUS_CONTENT="HARM_CATEGORY_IMAGE_DANGEROUS_CONTENT",r.HARM_CATEGORY_IMAGE_HARASSMENT="HARM_CATEGORY_IMAGE_HARASSMENT",r.HARM_CATEGORY_IMAGE_SEXUALLY_EXPLICIT="HARM_CATEGORY_IMAGE_SEXUALLY_EXPLICIT",r.HARM_CATEGORY_JAILBREAK="HARM_CATEGORY_JAILBREAK"})(mm||(mm={}));var xm;(function(r){r.HARM_BLOCK_METHOD_UNSPECIFIED="HARM_BLOCK_METHOD_UNSPECIFIED",r.SEVERITY="SEVERITY",r.PROBABILITY="PROBABILITY"})(xm||(xm={}));var pm;(function(r){r.HARM_BLOCK_THRESHOLD_UNSPECIFIED="HARM_BLOCK_THRESHOLD_UNSPECIFIED",r.BLOCK_LOW_AND_ABOVE="BLOCK_LOW_AND_ABOVE",r.BLOCK_MEDIUM_AND_ABOVE="BLOCK_MEDIUM_AND_ABOVE",r.BLOCK_ONLY_HIGH="BLOCK_ONLY_HIGH",r.BLOCK_NONE="BLOCK_NONE",r.OFF="OFF"})(pm||(pm={}));var hm;(function(r){r.FINISH_REASON_UNSPECIFIED="FINISH_REASON_UNSPECIFIED",r.STOP="STOP",r.MAX_TOKENS="MAX_TOKENS",r.SAFETY="SAFETY",r.RECITATION="RECITATION",r.LANGUAGE="LANGUAGE",r.OTHER="OTHER",r.BLOCKLIST="BLOCKLIST",r.PROHIBITED_CONTENT="PROHIBITED_CONTENT",r.SPII="SPII",r.MALFORMED_FUNCTION_CALL="MALFORMED_FUNCTION_CALL",r.IMAGE_SAFETY="IMAGE_SAFETY",r.UNEXPECTED_TOOL_CALL="UNEXPECTED_TOOL_CALL",r.IMAGE_PROHIBITED_CONTENT="IMAGE_PROHIBITED_CONTENT",r.NO_IMAGE="NO_IMAGE"})(hm||(hm={}));var gm;(function(r){r.HARM_PROBABILITY_UNSPECIFIED="HARM_PROBABILITY_UNSPECIFIED",r.NEGLIGIBLE="NEGLIGIBLE",r.LOW="LOW",r.MEDIUM="MEDIUM",r.HIGH="HIGH"})(gm||(gm={}));var bm;(function(r){r.HARM_SEVERITY_UNSPECIFIED="HARM_SEVERITY_UNSPECIFIED",r.HARM_SEVERITY_NEGLIGIBLE="HARM_SEVERITY_NEGLIGIBLE",r.HARM_SEVERITY_LOW="HARM_SEVERITY_LOW",r.HARM_SEVERITY_MEDIUM="HARM_SEVERITY_MEDIUM",r.HARM_SEVERITY_HIGH="HARM_SEVERITY_HIGH"})(bm||(bm={}));var ym;(function(r){r.URL_RETRIEVAL_STATUS_UNSPECIFIED="URL_RETRIEVAL_STATUS_UNSPECIFIED",r.URL_RETRIEVAL_STATUS_SUCCESS="URL_RETRIEVAL_STATUS_SUCCESS",r.URL_RETRIEVAL_STATUS_ERROR="URL_RETRIEVAL_STATUS_ERROR",r.URL_RETRIEVAL_STATUS_PAYWALL="URL_RETRIEVAL_STATUS_PAYWALL",r.URL_RETRIEVAL_STATUS_UNSAFE="URL_RETRIEVAL_STATUS_UNSAFE"})(ym||(ym={}));var vm;(function(r){r.BLOCKED_REASON_UNSPECIFIED="BLOCKED_REASON_UNSPECIFIED",r.SAFETY="SAFETY",r.OTHER="OTHER",r.BLOCKLIST="BLOCKLIST",r.PROHIBITED_CONTENT="PROHIBITED_CONTENT",r.IMAGE_SAFETY="IMAGE_SAFETY",r.MODEL_ARMOR="MODEL_ARMOR",r.JAILBREAK="JAILBREAK"})(vm||(vm={}));var km;(function(r){r.TRAFFIC_TYPE_UNSPECIFIED="TRAFFIC_TYPE_UNSPECIFIED",r.ON_DEMAND="ON_DEMAND",r.PROVISIONED_THROUGHPUT="PROVISIONED_THROUGHPUT"})(km||(km={}));var jm;(function(r){r.MODALITY_UNSPECIFIED="MODALITY_UNSPECIFIED",r.TEXT="TEXT",r.IMAGE="IMAGE",r.AUDIO="AUDIO"})(jm||(jm={}));var Nm;(function(r){r.MEDIA_RESOLUTION_UNSPECIFIED="MEDIA_RESOLUTION_UNSPECIFIED",r.MEDIA_RESOLUTION_LOW="MEDIA_RESOLUTION_LOW",r.MEDIA_RESOLUTION_MEDIUM="MEDIA_RESOLUTION_MEDIUM",r.MEDIA_RESOLUTION_HIGH="MEDIA_RESOLUTION_HIGH"})(Nm||(Nm={}));var zm;(function(r){r.TUNING_MODE_UNSPECIFIED="TUNING_MODE_UNSPECIFIED",r.TUNING_MODE_FULL="TUNING_MODE_FULL",r.TUNING_MODE_PEFT_ADAPTER="TUNING_MODE_PEFT_ADAPTER"})(zm||(zm={}));var wm;(function(r){r.ADAPTER_SIZE_UNSPECIFIED="ADAPTER_SIZE_UNSPECIFIED",r.ADAPTER_SIZE_ONE="ADAPTER_SIZE_ONE",r.ADAPTER_SIZE_TWO="ADAPTER_SIZE_TWO",r.ADAPTER_SIZE_FOUR="ADAPTER_SIZE_FOUR",r.ADAPTER_SIZE_EIGHT="ADAPTER_SIZE_EIGHT",r.ADAPTER_SIZE_SIXTEEN="ADAPTER_SIZE_SIXTEEN",r.ADAPTER_SIZE_THIRTY_TWO="ADAPTER_SIZE_THIRTY_TWO"})(wm||(wm={}));var Sm;(function(r){r.JOB_STATE_UNSPECIFIED="JOB_STATE_UNSPECIFIED",r.JOB_STATE_QUEUED="JOB_STATE_QUEUED",r.JOB_STATE_PENDING="JOB_STATE_PENDING",r.JOB_STATE_RUNNING="JOB_STATE_RUNNING",r.JOB_STATE_SUCCEEDED="JOB_STATE_SUCCEEDED",r.JOB_STATE_FAILED="JOB_STATE_FAILED",r.JOB_STATE_CANCELLING="JOB_STATE_CANCELLING",r.JOB_STATE_CANCELLED="JOB_STATE_CANCELLED",r.JOB_STATE_PAUSED="JOB_STATE_PAUSED",r.JOB_STATE_EXPIRED="JOB_STATE_EXPIRED",r.JOB_STATE_UPDATING="JOB_STATE_UPDATING",r.JOB_STATE_PARTIALLY_SUCCEEDED="JOB_STATE_PARTIALLY_SUCCEEDED"})(Sm||(Sm={}));var Em;(function(r){r.TUNING_TASK_UNSPECIFIED="TUNING_TASK_UNSPECIFIED",r.TUNING_TASK_I2V="TUNING_TASK_I2V",r.TUNING_TASK_T2V="TUNING_TASK_T2V",r.TUNING_TASK_R2V="TUNING_TASK_R2V"})(Em||(Em={}));var Tm;(function(r){r.MEDIA_RESOLUTION_UNSPECIFIED="MEDIA_RESOLUTION_UNSPECIFIED",r.MEDIA_RESOLUTION_LOW="MEDIA_RESOLUTION_LOW",r.MEDIA_RESOLUTION_MEDIUM="MEDIA_RESOLUTION_MEDIUM",r.MEDIA_RESOLUTION_HIGH="MEDIA_RESOLUTION_HIGH"})(Tm||(Tm={}));var _m;(function(r){r.FEATURE_SELECTION_PREFERENCE_UNSPECIFIED="FEATURE_SELECTION_PREFERENCE_UNSPECIFIED",r.PRIORITIZE_QUALITY="PRIORITIZE_QUALITY",r.BALANCED="BALANCED",r.PRIORITIZE_COST="PRIORITIZE_COST"})(_m||(_m={}));var Am;(function(r){r.UNSPECIFIED="UNSPECIFIED",r.BLOCKING="BLOCKING",r.NON_BLOCKING="NON_BLOCKING"})(Am||(Am={}));var Om;(function(r){r.MODE_UNSPECIFIED="MODE_UNSPECIFIED",r.MODE_DYNAMIC="MODE_DYNAMIC"})(Om||(Om={}));var Cm;(function(r){r.ENVIRONMENT_UNSPECIFIED="ENVIRONMENT_UNSPECIFIED",r.ENVIRONMENT_BROWSER="ENVIRONMENT_BROWSER"})(Cm||(Cm={}));var Dm;(function(r){r.MODE_UNSPECIFIED="MODE_UNSPECIFIED",r.AUTO="AUTO",r.ANY="ANY",r.NONE="NONE",r.VALIDATED="VALIDATED"})(Dm||(Dm={}));var Mm;(function(r){r.BLOCK_LOW_AND_ABOVE="BLOCK_LOW_AND_ABOVE",r.BLOCK_MEDIUM_AND_ABOVE="BLOCK_MEDIUM_AND_ABOVE",r.BLOCK_ONLY_HIGH="BLOCK_ONLY_HIGH",r.BLOCK_NONE="BLOCK_NONE"})(Mm||(Mm={}));var Rm;(function(r){r.DONT_ALLOW="DONT_ALLOW",r.ALLOW_ADULT="ALLOW_ADULT",r.ALLOW_ALL="ALLOW_ALL"})(Rm||(Rm={}));var Um;(function(r){r.auto="auto",r.en="en",r.ja="ja",r.ko="ko",r.hi="hi",r.zh="zh",r.pt="pt",r.es="es"})(Um||(Um={}));var Bm;(function(r){r.MASK_MODE_DEFAULT="MASK_MODE_DEFAULT",r.MASK_MODE_USER_PROVIDED="MASK_MODE_USER_PROVIDED",r.MASK_MODE_BACKGROUND="MASK_MODE_BACKGROUND",r.MASK_MODE_FOREGROUND="MASK_MODE_FOREGROUND",r.MASK_MODE_SEMANTIC="MASK_MODE_SEMANTIC"})(Bm||(Bm={}));var Lm;(function(r){r.CONTROL_TYPE_DEFAULT="CONTROL_TYPE_DEFAULT",r.CONTROL_TYPE_CANNY="CONTROL_TYPE_CANNY",r.CONTROL_TYPE_SCRIBBLE="CONTROL_TYPE_SCRIBBLE",r.CONTROL_TYPE_FACE_MESH="CONTROL_TYPE_FACE_MESH"})(Lm||(Lm={}));var Hm;(function(r){r.SUBJECT_TYPE_DEFAULT="SUBJECT_TYPE_DEFAULT",r.SUBJECT_TYPE_PERSON="SUBJECT_TYPE_PERSON",r.SUBJECT_TYPE_ANIMAL="SUBJECT_TYPE_ANIMAL",r.SUBJECT_TYPE_PRODUCT="SUBJECT_TYPE_PRODUCT"})(Hm||(Hm={}));var Ym;(function(r){r.EDIT_MODE_DEFAULT="EDIT_MODE_DEFAULT",r.EDIT_MODE_INPAINT_REMOVAL="EDIT_MODE_INPAINT_REMOVAL",r.EDIT_MODE_INPAINT_INSERTION="EDIT_MODE_INPAINT_INSERTION",r.EDIT_MODE_OUTPAINT="EDIT_MODE_OUTPAINT",r.EDIT_MODE_CONTROLLED_EDITING="EDIT_MODE_CONTROLLED_EDITING",r.EDIT_MODE_STYLE="EDIT_MODE_STYLE",r.EDIT_MODE_BGSWAP="EDIT_MODE_BGSWAP",r.EDIT_MODE_PRODUCT_IMAGE="EDIT_MODE_PRODUCT_IMAGE"})(Ym||(Ym={}));var Gm;(function(r){r.FOREGROUND="FOREGROUND",r.BACKGROUND="BACKGROUND",r.PROMPT="PROMPT",r.SEMANTIC="SEMANTIC",r.INTERACTIVE="INTERACTIVE"})(Gm||(Gm={}));var Im;(function(r){r.ASSET="ASSET",r.STYLE="STYLE"})(Im||(Im={}));var Km;(function(r){r.INSERT="INSERT",r.REMOVE="REMOVE",r.REMOVE_STATIC="REMOVE_STATIC",r.OUTPAINT="OUTPAINT"})(Km||(Km={}));var qm;(function(r){r.OPTIMIZED="OPTIMIZED",r.LOSSLESS="LOSSLESS"})(qm||(qm={}));var Vm;(function(r){r.SUPERVISED_FINE_TUNING="SUPERVISED_FINE_TUNING",r.PREFERENCE_TUNING="PREFERENCE_TUNING"})(Vm||(Vm={}));var Xm;(function(r){r.STATE_UNSPECIFIED="STATE_UNSPECIFIED",r.STATE_PENDING="STATE_PENDING",r.STATE_ACTIVE="STATE_ACTIVE",r.STATE_FAILED="STATE_FAILED"})(Xm||(Xm={}));var Qm;(function(r){r.STATE_UNSPECIFIED="STATE_UNSPECIFIED",r.PROCESSING="PROCESSING",r.ACTIVE="ACTIVE",r.FAILED="FAILED"})(Qm||(Qm={}));var Zm;(function(r){r.SOURCE_UNSPECIFIED="SOURCE_UNSPECIFIED",r.UPLOADED="UPLOADED",r.GENERATED="GENERATED"})(Zm||(Zm={}));var Jm;(function(r){r.TURN_COMPLETE_REASON_UNSPECIFIED="TURN_COMPLETE_REASON_UNSPECIFIED",r.MALFORMED_FUNCTION_CALL="MALFORMED_FUNCTION_CALL",r.RESPONSE_REJECTED="RESPONSE_REJECTED",r.NEED_MORE_INPUT="NEED_MORE_INPUT"})(Jm||(Jm={}));var Fm;(function(r){r.MODALITY_UNSPECIFIED="MODALITY_UNSPECIFIED",r.TEXT="TEXT",r.IMAGE="IMAGE",r.VIDEO="VIDEO",r.AUDIO="AUDIO",r.DOCUMENT="DOCUMENT"})(Fm||(Fm={}));var Pm;(function(r){r.START_SENSITIVITY_UNSPECIFIED="START_SENSITIVITY_UNSPECIFIED",r.START_SENSITIVITY_HIGH="START_SENSITIVITY_HIGH",r.START_SENSITIVITY_LOW="START_SENSITIVITY_LOW"})(Pm||(Pm={}));var Wm;(function(r){r.END_SENSITIVITY_UNSPECIFIED="END_SENSITIVITY_UNSPECIFIED",r.END_SENSITIVITY_HIGH="END_SENSITIVITY_HIGH",r.END_SENSITIVITY_LOW="END_SENSITIVITY_LOW"})(Wm||(Wm={}));var $m;(function(r){r.ACTIVITY_HANDLING_UNSPECIFIED="ACTIVITY_HANDLING_UNSPECIFIED",r.START_OF_ACTIVITY_INTERRUPTS="START_OF_ACTIVITY_INTERRUPTS",r.NO_INTERRUPTION="NO_INTERRUPTION"})($m||($m={}));var ex;(function(r){r.TURN_COVERAGE_UNSPECIFIED="TURN_COVERAGE_UNSPECIFIED",r.TURN_INCLUDES_ONLY_ACTIVITY="TURN_INCLUDES_ONLY_ACTIVITY",r.TURN_INCLUDES_ALL_INPUT="TURN_INCLUDES_ALL_INPUT"})(ex||(ex={}));var tx;(function(r){r.SCALE_UNSPECIFIED="SCALE_UNSPECIFIED",r.C_MAJOR_A_MINOR="C_MAJOR_A_MINOR",r.D_FLAT_MAJOR_B_FLAT_MINOR="D_FLAT_MAJOR_B_FLAT_MINOR",r.D_MAJOR_B_MINOR="D_MAJOR_B_MINOR",r.E_FLAT_MAJOR_C_MINOR="E_FLAT_MAJOR_C_MINOR",r.E_MAJOR_D_FLAT_MINOR="E_MAJOR_D_FLAT_MINOR",r.F_MAJOR_D_MINOR="F_MAJOR_D_MINOR",r.G_FLAT_MAJOR_E_FLAT_MINOR="G_FLAT_MAJOR_E_FLAT_MINOR",r.G_MAJOR_E_MINOR="G_MAJOR_E_MINOR",r.A_FLAT_MAJOR_F_MINOR="A_FLAT_MAJOR_F_MINOR",r.A_MAJOR_G_FLAT_MINOR="A_MAJOR_G_FLAT_MINOR",r.B_FLAT_MAJOR_G_MINOR="B_FLAT_MAJOR_G_MINOR",r.B_MAJOR_A_FLAT_MINOR="B_MAJOR_A_FLAT_MINOR"})(tx||(tx={}));var ax;(function(r){r.MUSIC_GENERATION_MODE_UNSPECIFIED="MUSIC_GENERATION_MODE_UNSPECIFIED",r.QUALITY="QUALITY",r.DIVERSITY="DIVERSITY",r.VOCALIZATION="VOCALIZATION"})(ax||(ax={}));var lx;(function(r){r.PLAYBACK_CONTROL_UNSPECIFIED="PLAYBACK_CONTROL_UNSPECIFIED",r.PLAY="PLAY",r.PAUSE="PAUSE",r.STOP="STOP",r.RESET_CONTEXT="RESET_CONTEXT"})(lx||(lx={}));/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */var ix;(function(r){r.PAGED_ITEM_BATCH_JOBS="batchJobs",r.PAGED_ITEM_MODELS="models",r.PAGED_ITEM_TUNING_JOBS="tuningJobs",r.PAGED_ITEM_FILES="files",r.PAGED_ITEM_CACHED_CONTENTS="cachedContents",r.PAGED_ITEM_FILE_SEARCH_STORES="fileSearchStores",r.PAGED_ITEM_DOCUMENTS="documents"})(ix||(ix={}));console.warn("API_KEY not found in environment variables. Gemini features will be disabled.");const Ah=async r=>"API Anahtarı eksik. Lütfen yapılandırmayı kontrol edin.",nx="egersizlab_chat_messages",sx="egersizlab_deleted_messages",Oh=()=>{const r=[{role:"model",text:"Merhaba! Ben EgzersizLab asistanıyım. Size hangi konuda yardımcı olabilirim? Kurs önerisi ister misiniz?"}],v=()=>{try{const K=localStorage.getItem(nx);if(K){const ue=JSON.parse(K);return ue.length>0?ue:r}}catch(K){console.error("Mesajlar yüklenirken hata:",K)}return r},[E,d]=g.useState(!1),[w,A]=g.useState(v),[S,B]=g.useState(()=>{try{const K=localStorage.getItem(sx);return K?JSON.parse(K):[]}catch{return[]}}),[b,p]=g.useState(""),[U,N]=g.useState(!1),G=g.useRef(null),L=()=>{var K;(K=G.current)==null||K.scrollIntoView({behavior:"smooth"})};g.useEffect(()=>{try{localStorage.setItem(nx,JSON.stringify(w))}catch(K){console.error("Mesajlar kaydedilirken hata:",K)}},[w]),g.useEffect(()=>{try{localStorage.setItem(sx,JSON.stringify(S))}catch(K){console.error("Silinen mesajlar kaydedilirken hata:",K)}},[S]),g.useEffect(()=>{L()},[w,E]);const Z=async()=>{if(!b.trim())return;const K={role:"user",text:b};A($=>[...$,K]),p(""),N(!0);const ue=await Ah();A($=>[...$,{role:"model",text:ue}]),N(!1)},ie=K=>{K.key==="Enter"&&!K.shiftKey&&(K.preventDefault(),Z())},J=()=>{window.confirm("Tüm konuşmayı silmek istediğinize emin misiniz?")&&(B(K=>[...K,...w]),A(r))},H=()=>{if(S.length===0){alert("Geri getirilecek konuşma bulunamadı.");return}window.confirm("Son silinen konuşmayı geri getirmek istediğinize emin misiniz?")&&(A(K=>[...S,...K]),B([]))};return l.jsxs(l.Fragment,{children:[l.jsx("button",{onClick:()=>d(!0),className:`fixed bottom-6 right-6 bg-gradient-to-r from-blue-600 to-teal-500 text-white p-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 z-50 hover:scale-110 ${E?"hidden":"flex"}`,children:l.jsx(ch,{size:28})}),E&&l.jsxs("div",{className:"fixed bottom-6 right-6 w-[350px] md:w-[400px] h-[500px] bg-white rounded-2xl shadow-2xl z-50 flex flex-col border border-gray-200 overflow-hidden animate-in slide-in-from-bottom-10 fade-in duration-300",children:[l.jsxs("div",{className:"bg-[#263562] text-white p-4 flex justify-between items-center",children:[l.jsxs("div",{className:"flex items-center gap-3",children:[l.jsx("div",{className:"bg-white/20 p-2 rounded-full",children:l.jsx(F0,{size:20})}),l.jsxs("div",{children:[l.jsx("h3",{className:"font-bold text-sm",children:"EgzersizLab Asistanı"}),l.jsx("p",{className:"text-xs text-blue-200",children:"Gemini AI tarafından desteklenmektedir"})]})]}),l.jsxs("div",{className:"flex items-center gap-2",children:[S.length>0&&l.jsx("button",{onClick:H,className:"text-white/80 hover:text-white hover:bg-white/10 p-1.5 rounded transition",title:"Silinen konuşmayı geri getir",children:l.jsx(Io,{size:18})}),w.length>1&&l.jsx("button",{onClick:J,className:"text-white/80 hover:text-white hover:bg-white/10 p-1.5 rounded transition",title:"Konuşmayı temizle",children:l.jsx(Ko,{size:18})}),l.jsx("button",{onClick:()=>d(!1),className:"text-white/80 hover:text-white hover:bg-white/10 p-1 rounded transition",children:l.jsx(Xo,{size:20})})]})]}),l.jsxs("div",{className:"flex-1 overflow-y-auto p-4 bg-gray-50 space-y-4",children:[w.map((K,ue)=>l.jsx("div",{className:`flex ${K.role==="user"?"justify-end":"justify-start"}`,children:l.jsx("div",{className:`max-w-[80%] rounded-2xl p-3 text-sm ${K.role==="user"?"bg-blue-600 text-white rounded-br-none":"bg-white text-gray-800 border border-gray-200 rounded-bl-none shadow-sm"}`,children:K.text})},ue)),U&&l.jsx("div",{className:"flex justify-start",children:l.jsxs("div",{className:"bg-white text-gray-500 border border-gray-200 rounded-2xl rounded-bl-none p-3 shadow-sm flex items-center gap-2",children:[l.jsx(nh,{size:16,className:"animate-spin"}),l.jsx("span",{className:"text-xs",children:"Yazıyor..."})]})}),l.jsx("div",{ref:G})]}),l.jsx("div",{className:"p-4 bg-white border-t border-gray-100",children:l.jsxs("div",{className:"flex items-center gap-2 bg-gray-100 rounded-full px-4 py-2 border border-transparent focus-within:border-blue-300 focus-within:bg-white transition-all",children:[l.jsx("input",{type:"text",value:b,onChange:K=>p(K.target.value),onKeyDown:ie,placeholder:"Bir soru sorun...",className:"flex-1 bg-transparent text-sm focus:outline-none"}),l.jsx("button",{onClick:Z,disabled:U||!b.trim(),className:"text-blue-600 hover:text-blue-800 disabled:opacity-50 transition",children:l.jsx(bh,{size:18})})]})})]})]})},Ch=[{tag:"Ortopedi",title:"Bel, Boyun ve Eklem Ağrıları",desc:"Kas-iskelet sistemi sorunları ve tedavi yöntemleri hakkında bilgiler",gradient:"from-blue-100 to-blue-200",pill:"bg-blue-100 text-blue-700",iconColor:"text-blue-600",icon:l.jsxs("svg",{viewBox:"0 0 24 24",className:"w-full h-full p-12",fill:"none",stroke:"currentColor",strokeWidth:"1.5",children:[l.jsx("path",{d:"M8 2v4M16 2v4M8 18v4M16 18v4M2 8h4M18 8h4M2 16h4M18 16h4"}),l.jsx("rect",{x:"6",y:"6",width:"12",height:"12",rx:"2"}),l.jsx("circle",{cx:"12",cy:"12",r:"2"})]})},{tag:"Nöroloji",title:"İnme, Sinir Sıkışması ve Rehabilitasyon",desc:"Sinir sistemi hastalıkları ve iyileşme süreçleri",gradient:"from-purple-100 to-purple-200",pill:"bg-purple-100 text-purple-700",iconColor:"text-purple-600",icon:l.jsxs("svg",{viewBox:"0 0 24 24",className:"w-full h-full p-12",fill:"none",stroke:"currentColor",strokeWidth:"1.5",children:[l.jsx("circle",{cx:"12",cy:"12",r:"10"}),l.jsx("path",{d:"M12 2C12 2 8 6 8 12s4 10 4 10"}),l.jsx("path",{d:"M12 2C12 2 16 6 16 12s-4 10-4 10"}),l.jsx("path",{d:"M2 12h20"}),l.jsx("circle",{cx:"12",cy:"8",r:"1.5",fill:"currentColor"}),l.jsx("circle",{cx:"12",cy:"16",r:"1.5",fill:"currentColor"})]})},{tag:"Pediatri",title:"Çocuk Sağlığı ve Gelişim Takibi",desc:"Çocuklarda büyüme, gelişim ve sağlık rehberi",gradient:"from-pink-100 to-pink-200",pill:"bg-pink-100 text-pink-700",iconColor:"text-pink-600",icon:l.jsxs("svg",{viewBox:"0 0 24 24",className:"w-full h-full p-12",fill:"none",stroke:"currentColor",strokeWidth:"1.5",children:[l.jsx("path",{d:"M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"}),l.jsx("circle",{cx:"12",cy:"7",r:"4"}),l.jsx("path",{d:"M8 3h8"}),l.jsx("path",{d:"M12 3v4"})]})},{tag:"Yaşam",title:"Koruyucu Sağlık ve Doğru Duruş",desc:"Egzersiz, beslenme ve sağlıklı yaşam önerileri",gradient:"from-green-100 to-green-200",pill:"bg-green-100 text-green-700",iconColor:"text-green-600",icon:l.jsxs("svg",{viewBox:"0 0 24 24",className:"w-full h-full p-12",fill:"none",stroke:"currentColor",strokeWidth:"1.5",children:[l.jsx("path",{d:"M22 12h-4l-3 9L9 3l-3 9H2"}),l.jsx("circle",{cx:"12",cy:"12",r:"1",fill:"currentColor"})]})},{tag:"Kadın Sağlığı",title:"Hamilelik ve Doğum Sonrası",desc:"Pelvik taban sağlığı, menopoz dönemi, güvenli egzersiz",gradient:"from-rose-100 to-rose-200",pill:"bg-rose-100 text-rose-700",iconColor:"text-rose-600",icon:l.jsxs("svg",{viewBox:"0 0 24 24",className:"w-full h-full p-12",fill:"none",stroke:"currentColor",strokeWidth:"1.5",children:[l.jsx("path",{d:"M12 16c3.314 0 6-2.686 6-6s-2.686-6-6-6-6 2.686-6 6 2.686 6 6 6z"}),l.jsx("path",{d:"M12 16v4"}),l.jsx("path",{d:"M8 20h8"}),l.jsx("path",{d:"M12 20v2"}),l.jsx("circle",{cx:"12",cy:"10",r:"2",fill:"currentColor"})]})},{tag:"Sporcu Sağlığı",title:"Sakatlıklar ve Performans",desc:"Spora dönüş, ön çapraz bağ, sakatlık yönetimi",gradient:"from-orange-100 to-orange-200",pill:"bg-orange-100 text-orange-700",iconColor:"text-orange-600",icon:l.jsxs("svg",{viewBox:"0 0 24 24",className:"w-full h-full p-12",fill:"none",stroke:"currentColor",strokeWidth:"1.5",children:[l.jsx("path",{d:"M6.5 6.5l11 11"}),l.jsx("path",{d:"M17.5 6.5l-11 11"}),l.jsx("circle",{cx:"12",cy:"12",r:"2",fill:"currentColor"}),l.jsx("path",{d:"M2 12h4M18 12h4M12 2v4M12 18v4"})]})},{tag:"Kronik Ağrı",title:"Fibromiyalji ve Romatizma",desc:"Kronik ağrı yönetimi, iltihaplı romatizma, sabah tutukluğu",gradient:"from-red-100 to-red-200",pill:"bg-red-100 text-red-700",iconColor:"text-red-600",icon:l.jsxs("svg",{viewBox:"0 0 24 24",className:"w-full h-full p-12",fill:"none",stroke:"currentColor",strokeWidth:"1.5",children:[l.jsx("path",{d:"M12 2L2 7l10 5 10-5-10-5z"}),l.jsx("path",{d:"M2 17l10 5 10-5"}),l.jsx("path",{d:"M2 12l10 5 10-5"}),l.jsx("circle",{cx:"12",cy:"12",r:"1.5",fill:"currentColor"})]})},{tag:"Geriatri",title:"Sağlıklı Yaşlanma",desc:"Düşme riskini azaltma, denge egzersizleri, kireçlenme yönetimi",gradient:"from-indigo-100 to-indigo-200",pill:"bg-indigo-100 text-indigo-700",iconColor:"text-indigo-600",icon:l.jsxs("svg",{viewBox:"0 0 24 24",className:"w-full h-full p-12",fill:"none",stroke:"currentColor",strokeWidth:"1.5",children:[l.jsx("circle",{cx:"12",cy:"8",r:"5"}),l.jsx("path",{d:"M3 21c0-3.5 4-6 9-6s9 2.5 9 6"}),l.jsx("path",{d:"M16 11l2 2 4-4"})]})}],Dh=()=>{const r=g.useRef(null),[v,E]=g.useState(!1),[d,w]=g.useState(!0);g.useEffect(()=>{const S=r.current;if(!S)return;const B=()=>{E(S.scrollLeft>0),w(S.scrollLeft+S.clientWidth<S.scrollWidth-8)};return requestAnimationFrame(B),S.addEventListener("scroll",B),window.addEventListener("resize",B),()=>{S.removeEventListener("scroll",B),window.removeEventListener("resize",B)}},[]);const A=S=>{const B=r.current;if(!B)return;const b=B.querySelector(".category-card"),p=b?b.offsetWidth+32:B.clientWidth*.8;B.scrollBy({left:S==="left"?-p:p,behavior:"smooth"})};return l.jsx("section",{id:"blog",className:"py-20 bg-blue-50/50",style:{scrollMarginTop:"120px"},children:l.jsxs("div",{className:"container mx-auto px-4",children:[l.jsxs("div",{className:"flex flex-col md:flex-row justify-between items-end mb-10 gap-4",children:[l.jsxs("div",{children:[l.jsx("span",{className:"text-blue-600 font-semibold tracking-wide uppercase text-sm",children:"Blog Kategorileri"}),l.jsx("h2",{className:"text-3xl font-bold text-slate-900 mt-2",children:"Sağlık Bilgilerinizi Geliştirin"})]}),l.jsxs("button",{className:"flex items-center gap-2 text-[#263562] font-semibold hover:text-blue-600 transition",children:["Tüm Yazıları İncele ",l.jsx(ii,{size:18})]})]}),l.jsxs("div",{className:"relative",children:[l.jsx("button",{onClick:()=>A("left"),disabled:!v,className:"nav-button absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 z-10 bg-blue-600 text-white w-12 h-12 rounded-full shadow-lg flex items-center justify-center disabled:opacity-30 disabled:cursor-not-allowed",children:l.jsx(ii,{className:"rotate-180"})}),l.jsx("button",{onClick:()=>A("right"),disabled:!d,className:"nav-button absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 z-10 bg-blue-600 text-white w-12 h-12 rounded-full shadow-lg flex items-center justify-center disabled:opacity-30 disabled:cursor-not-allowed",children:l.jsx(ii,{})}),l.jsxs("div",{ref:r,className:"flex gap-8 overflow-x-auto pb-2 pt-1",style:{scrollbarWidth:"none",msOverflowStyle:"none"},children:[l.jsx("style",{children:".scroll-container::-webkit-scrollbar{display:none;}"}),Ch.map(S=>l.jsxs("div",{className:"category-card bg-white rounded-2xl overflow-hidden shadow-md flex-shrink-0",style:{width:"320px"},children:[l.jsx("div",{className:`category-image h-48 bg-gradient-to-br ${S.gradient} relative`,children:l.jsx("div",{className:`${S.iconColor} opacity-70 w-full h-full`,children:S.icon})}),l.jsxs("div",{className:"p-6",children:[l.jsx("div",{className:"flex items-center gap-2 mb-3",children:l.jsx("span",{className:`px-3 py-1 ${S.pill} text-xs font-semibold rounded-full`,children:S.tag})}),l.jsx("h3",{className:"text-xl font-bold text-slate-900 mb-2",children:S.title}),l.jsx("p",{className:"text-slate-600 text-sm mb-4",children:S.desc}),l.jsx("div",{className:"flex items-center justify-end pt-4 border-t border-slate-100",children:l.jsxs("button",{className:"flex items-center gap-1 text-blue-600 font-semibold text-sm hover:gap-2 transition-all",children:["İncele ",l.jsx(ii,{size:16,className:"arrow-icon"})]})})]})]},S.title))]})]})]})})},Mh=new URL("/assets/exercise-cards.jpg-DK_D65XL.png",import.meta.url).href,li=[`Hastanelerde adeta bir broşür gibi dağıtılan bu standart egzersiz reçeteleri, hastayı gerçekten tedavi etmek için mi, yoksa "bir şeyler önermiş olmak" için mi veriliyor?

Aynı kâğıdın, 20 yaşındaki bir sporcunun ön çapraz bağ sakatlığına da, 70 yaşındaki bir teyzenin ileri derece kireçlenmesine de (osteoartrit) şifa olması beklenebilir mi?

Elinize tutuşturulan o kâğıt, sizin ağrı eşiğinizi, kas dengesizliğinizi veya hareket kısıtlılığınızı "okuyabiliyor" mu?`,`Anatomimiz parmak izimiz kadar benzersizken, tedavimiz nasıl bir fotokopi makinesinden çıkabilir?

Herkesin kemik yapısı, eklem açısı, geçmişteki yaralanmaları ve yaşam tarzı birbirinden tamamen farklıyken; hepsini aynı hareketlerle iyileştirmeye çalışmak, farklı kilitleri aynı anahtarla açmaya çalışmak değil midir?

Bir başkasına iyi gelen "bacak kaldırma" hareketi, sizin özel durumunuzda dizinize daha fazla yük bindirip sorunu büyütüyorsa, o kâğıdın sorumluluğunu kim alacak?`,`Gerçek fizik tedavi; kâğıttan hareket bakmak değil, size özel dikilmiş bir elbise gibi tasarlanan, süreç içinde değiştirilen dinamik bir programdır.

Egzersiz ilaçtır; dozajı, sıklığı ve türü kişiye göre ayarlanmadığında zehire dönüşebilir.

Planınız, semptomlarınıza ve anatomik ihtiyacınıza göre yaşayan bir reçete olmalı.`],$i=["60 saniye uzak noktaya bakmak ekran yorgunluğunu ve baş ağrısını azaltır.","Güne 5 dakikalık boyun mobilizasyonu ile başlamak migren ataklarını düşürebilir.","Bel ağrısında her 30 dakikada 2 dakikalık yürüyüş, gerginliği belirgin azaltır.","Denge egzersizleri diz cerrahisi sonrası güvenli hareket kapasitesini artırır."],Rh=()=>{const[r,v]=g.useState(0),[E,d]=g.useState(0);g.useEffect(()=>{const b=setInterval(()=>{v(p=>(p+1)%li.length)},3e4);return()=>clearInterval(b)},[]);const w=()=>v(b=>(b-1+li.length)%li.length),A=()=>v(b=>(b+1)%li.length),S=()=>d(b=>(b-1+$i.length)%$i.length),B=()=>d(b=>(b+1)%$i.length);return l.jsxs("section",{id:"hero",className:"relative bg-gradient-to-br from-[#eff6ff] to-[#f0fdfa] py-16 lg:py-24 overflow-hidden",style:{scrollMarginTop:"140px"},children:[l.jsx("div",{className:"absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-blue-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob"}),l.jsx("div",{className:"absolute top-0 left-0 -ml-20 -mt-20 w-96 h-96 bg-teal-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-2000"}),l.jsx("div",{className:"container mx-auto px-4 relative z-10",children:l.jsxs("div",{className:"flex flex-col lg:flex-row items-center gap-12",children:[l.jsxs("div",{className:"lg:w-1/2 space-y-6",children:[l.jsxs("h1",{className:"text-4xl lg:text-6xl font-extrabold text-slate-900 leading-tight",children:["Senin Vücudun, Bizim Bilimimiz: ",l.jsx("br",{}),l.jsx("span",{className:"text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-teal-500",children:"Hareketin Yeni Formülü."})]}),l.jsx("p",{className:"text-lg text-gray-600 leading-relaxed max-w-lg",children:"Egzersiz ve rehabilitasyonun birleştiği modern sağlık platformu. Sağlığın için dilediğin yerde, dilediğin zamanda harekete geç."}),l.jsxs("div",{className:"flex flex-col sm:flex-row gap-4 mt-8",children:[l.jsxs("a",{href:"#packages",className:"group relative px-8 py-4 bg-gradient-to-r from-blue-600 via-blue-500 to-teal-500 text-white font-bold text-lg rounded-xl shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300 overflow-hidden",children:[l.jsxs("span",{className:"relative z-10 flex items-center justify-center gap-2",children:[l.jsx("span",{children:"🚀 Hemen Başla"}),l.jsx("span",{className:"group-hover:translate-x-1 transition-transform",children:"→"})]}),l.jsx("div",{className:"absolute inset-0 bg-gradient-to-r from-blue-700 via-blue-600 to-teal-600 opacity-0 group-hover:opacity-100 transition-opacity"})]}),l.jsx("a",{href:"#process",className:"px-8 py-4 bg-white text-blue-600 font-semibold text-lg rounded-xl border-2 border-blue-600 hover:bg-blue-50 transform hover:scale-105 transition-all duration-300 shadow-md",children:"Nasıl Çalışır?"})]}),l.jsxs("div",{className:"mt-6 w-full max-w-lg bg-gradient-to-br from-[#0f1c3a] via-[#0f1c3a] to-[#152c58] text-white rounded-2xl shadow-xl border border-white/10 p-6",children:[l.jsxs("div",{className:"flex items-center justify-between mb-4",children:[l.jsxs("h3",{className:"text-lg font-extrabold",children:["Bunları ",l.jsx("span",{className:"text-transparent bg-clip-text bg-gradient-to-r from-emerald-300 via-cyan-300 to-blue-300",children:"biliyor muydunuz?"})]}),l.jsxs("div",{className:"flex gap-2",children:[l.jsx("button",{onClick:S,"aria-label":"Önceki bilgi",className:"h-8 w-8 rounded-full bg-white/10 hover:bg-white/20 border border-white/10 flex items-center justify-center transition",children:l.jsx(Go,{size:14})}),l.jsx("button",{onClick:B,"aria-label":"Sonraki bilgi",className:"h-8 w-8 rounded-full bg-white/10 hover:bg-white/20 border border-white/10 flex items-center justify-center transition",children:l.jsx(Yo,{size:14})})]})]}),l.jsx("p",{className:"text-base text-white/90 leading-relaxed min-h-[72px] transition-all",children:$i[E]}),l.jsx("div",{className:"mt-4 flex items-center gap-2",children:$i.map((b,p)=>l.jsx("button",{onClick:()=>d(p),"aria-label":`Bilgi ${p+1}`,className:`h-2 rounded-full transition-all duration-300 ${E===p?"w-5 bg-emerald-400":"w-2 bg-white/30"}`},p))}),l.jsx("button",{className:"mt-6 w-full bg-white text-[#0f1c3a] font-semibold py-3 rounded-lg hover:bg-blue-50 transition",children:"Daha fazla kısa bilgi"})]})]}),l.jsxs("div",{className:"lg:w-1/2 relative",children:[l.jsxs("div",{className:"relative rounded-3xl overflow-hidden shadow-2xl border-4 border-white",children:[l.jsx("div",{className:"absolute top-6 left-6 right-6 flex justify-between items-start",children:l.jsxs("div",{className:"bg-gradient-to-r from-[#0f1c3a]/85 to-[#1c2f55]/85 text-white px-5 py-3 rounded-2xl shadow-2xl max-w-xl border border-white/10",children:[l.jsx("p",{className:"text-xs uppercase tracking-wide text-white/70 font-semibold",children:"Standart kâğıtlar işe yaradı mı?"}),l.jsx("h3",{className:"text-2xl lg:text-3xl font-extrabold leading-tight",children:"Gerçekten işe yaradı mı?"}),l.jsx("p",{className:"mt-2 text-sm text-white/85",children:"Kâğıdın sizin anatomik ihtiyacınızı okuyup okuyamadığını gelin birlikte sorgulayalım."})]})}),l.jsx("img",{src:Mh,alt:"Standart egzersiz kâğıtları",className:"w-full h-auto object-cover"})]}),l.jsxs("div",{className:"mt-6 rounded-2xl bg-gradient-to-br from-[#0f1c3a] via-[#0f1c3a] to-[#152c58] text-white shadow-xl p-5 lg:p-6 border border-white/10",children:[l.jsxs("div",{className:"flex items-center justify-between mb-3",children:[l.jsx("h3",{className:"text-lg lg:text-xl font-extrabold text-white",children:"Neden kişiye özel egzersiz?"}),l.jsxs("div",{className:"flex gap-2",children:[l.jsx("button",{"aria-label":"Önceki",onClick:w,className:"h-9 w-9 rounded-full bg-white/10 hover:bg-white/20 border border-white/10 flex items-center justify-center text-white transition",children:l.jsx(Go,{size:16})}),l.jsx("button",{"aria-label":"Sonraki",onClick:A,className:"h-9 w-9 rounded-full bg-white/10 hover:bg-white/20 border border-white/10 flex items-center justify-center text-white transition",children:l.jsx(Yo,{size:16})})]})]}),l.jsx("div",{className:"text-sm lg:text-base text-white/90 leading-relaxed min-h-[120px] transition-all duration-300 space-y-3",children:li[r].split(`
`).filter(Boolean).map((b,p)=>l.jsx("p",{className:"bg-white/5 border border-white/10 rounded-lg px-3 py-2 shadow-sm",children:b.trim()},p))}),l.jsx("div",{className:"mt-4 flex items-center gap-2",children:li.map((b,p)=>l.jsx("button",{"aria-label":`Slayt ${p+1}`,onClick:()=>v(p),className:`h-2 rounded-full transition-all duration-300 ${r===p?"w-6 bg-emerald-400":"w-2 bg-white/50"}`},p))})]}),l.jsx("div",{className:"absolute -top-6 -right-6 w-24 h-24 bg-yellow-400 rounded-full opacity-20 blur-xl"}),l.jsx("div",{className:"absolute -bottom-6 -left-6 w-32 h-32 bg-blue-600 rounded-full opacity-20 blur-xl"})]})]})})]})},Uh=[{title:"%100 Size Özel",desc:"Anatomik ihtiyacınıza uygun plan",icon:l.jsxs("svg",{xmlns:"http://www.w3.org/2000/svg",width:"32",height:"32",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[l.jsx("path",{d:"M12 10a2 2 0 0 0-2 2c0 1.02-.1 2.51-.26 4"}),l.jsx("path",{d:"M14 13.12c0 2.38 0 6.38-1 8.88"}),l.jsx("path",{d:"M17.29 21.02c.12-.6.43-2.3.5-3.02"}),l.jsx("path",{d:"M2 12a10 10 0 0 1 18-6"}),l.jsx("path",{d:"M2 16h.01"}),l.jsx("path",{d:"M21.8 16c.2-2 .131-5.354 0-6"}),l.jsx("path",{d:"M5 19.5C5.5 18 6 15 6 12a6 6 0 0 1 .34-2"}),l.jsx("path",{d:"M8.65 22c.21-.66.45-1.32.57-2"}),l.jsx("path",{d:"M9 6.8a6 6 0 0 1 9 5.2v2"})]})},{title:"Güvenli Altyapı",desc:"Sağlık verileriniz koruma altında",icon:l.jsxs("svg",{xmlns:"http://www.w3.org/2000/svg",width:"32",height:"32",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[l.jsx("path",{d:"M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"}),l.jsx("path",{d:"m9 12 2 2 4-4"})]})},{title:"Kesintisiz Destek",desc:"Süreç boyunca yanınızdayız",icon:l.jsxs("svg",{xmlns:"http://www.w3.org/2000/svg",width:"32",height:"32",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[l.jsx("path",{d:"m3 11 18-5v12L3 14v-3z"}),l.jsx("path",{d:"M11.6 16.8a3 3 0 1 1-5.8-1.6"})]})},{title:"Dilediğin Yerden",desc:"Mobilden veya bilgisayardan takip",icon:l.jsxs("svg",{xmlns:"http://www.w3.org/2000/svg",width:"32",height:"32",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[l.jsx("rect",{width:"16",height:"20",x:"4",y:"2",rx:"2",ry:"2"}),l.jsx("path",{d:"M12 18h.01"})]})}],Bh=()=>l.jsx("section",{className:"bg-[#263562] py-12",children:l.jsx("div",{className:"container mx-auto px-4",children:l.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8",children:Uh.map((r,v)=>l.jsxs("div",{className:"flex items-center gap-4 text-white group",children:[l.jsx("div",{className:"p-3 rounded-lg transition-colors bg-white/10 group-hover:bg-white/20",children:r.icon}),l.jsxs("div",{children:[l.jsx("h4",{className:"font-bold text-lg",children:r.title}),l.jsx("p",{className:"text-sm",style:{color:"#93c5fd"},children:r.desc})]})]},v))})})}),ps=[{id:1,title:"Kayıt Ol",desc:"Hesap oluştur ve sisteme giriş yap.",detail:"İlk adımda güvenli bir hesap açarak kişisel paneline erişirsin. Hesabınla birlikte ilerlemelerin ve kayıtların seninle kalır.",icon:"📝"},{id:2,title:"Bilgileri Gir",desc:"Gerekli verileri sisteme gir.",detail:"Formları doldur, gerekli dokümanları ekle ve bize ihtiyaçlarını anlat. Sistem, eksiklerini adım adım bildirir.",icon:"⚙️"},{id:3,title:"Sonuçları Al",desc:"Sistem analiz eder ve sonuçları gösterir.",detail:"Girilen bilgilere göre sana özel çıktılar, raporlar ve öneriler oluşur. Sonuçları kaydedebilir veya paylaşabilirsin.",icon:"✅"}],Lh=()=>{const[r,v]=g.useState(1),E=ps.find(d=>d.id===r)??ps[0];return l.jsx("section",{id:"process",className:"py-16",style:{scrollMarginTop:"140px"},children:l.jsx("div",{className:"container mx-auto px-4",children:l.jsxs("div",{className:"relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#dbeafe] via-[#e9ecff] to-[#e0f5ff] border border-white shadow-xl",children:[l.jsxs("div",{className:"absolute inset-0 pointer-events-none",children:[l.jsx("div",{className:"absolute -top-20 -left-10 w-56 h-56 bg-blue-200/40 rounded-full blur-3xl"}),l.jsx("div",{className:"absolute -bottom-24 -right-6 w-64 h-64 bg-indigo-200/40 rounded-full blur-3xl"})]}),l.jsxs("div",{className:"relative p-6 md:p-10 lg:p-12",children:[l.jsxs("div",{className:"text-center max-w-3xl mx-auto",children:[l.jsx("h2",{className:"text-3xl md:text-4xl font-bold text-slate-900",children:"Sistem Nasıl İşliyor?"}),l.jsx("p",{className:"mt-3 text-base md:text-lg text-slate-600",children:"Adımları keşfetmek için tıkla; her adımda ne yapman gerektiğini ve sistemin senin için ne üreteceğini gör."})]}),l.jsx("div",{className:"mt-10 flex flex-col md:flex-row items-center justify-center gap-4 md:gap-6 lg:gap-8",children:ps.map((d,w)=>l.jsxs(Vo.Fragment,{children:[l.jsxs("button",{onClick:()=>v(d.id),className:`group text-left relative w-full max-w-[320px] bg-white/90 backdrop-blur border rounded-2xl px-6 py-8 shadow-md transition transform ${r===d.id?"border-blue-200 shadow-blue-200/60 -translate-y-1 ring-2 ring-blue-300":"hover:-translate-y-1 hover:shadow-lg border-gray-100"}`,children:[l.jsx("div",{className:"flex items-center justify-center",children:l.jsx("div",{className:`w-14 h-14 rounded-full flex items-center justify-center text-xl font-bold text-white shadow-lg ${r===d.id?"bg-gradient-to-br from-blue-600 to-teal-500":"bg-gradient-to-br from-slate-400 to-slate-500"}`,children:d.id})}),l.jsx("div",{className:"text-5xl text-center mt-4",children:d.icon}),l.jsx("h3",{className:"mt-4 text-xl font-semibold text-slate-900 text-center",children:d.title}),l.jsx("p",{className:"mt-2 text-sm text-slate-600 text-center leading-relaxed",children:d.desc})]}),w<ps.length-1&&l.jsxs("div",{className:"flex items-center justify-center text-slate-500 shrink-0",children:[l.jsx(ii,{className:"hidden md:inline-block"}),l.jsx(ii,{className:"md:hidden rotate-90"})]})]},d.id))}),l.jsxs("div",{className:"mt-10 bg-white/90 border border-gray-100 rounded-2xl p-6 shadow-md",children:[l.jsxs("p",{className:"text-sm font-semibold text-blue-700 mb-2",children:["Adım ",E.id]}),l.jsx("h4",{className:"text-2xl font-bold text-slate-900 mb-3",children:E.title}),l.jsx("p",{className:"text-base text-slate-700 leading-relaxed",children:E.detail})]})]})]})})})},Hh=[{id:"basic",badge:"Basit",price:"₺499",title:"Temel Analiz",tagline:"Temel fiziksel değerlendirme ile hızlı başlangıç.",features:["Temel fiziksel değerlendirme","Ağrı haritası analizi","Genel egzersiz önerileri","Email desteği"],recommended:!1},{id:"recommended",badge:"Orta",price:"₺999",title:"Detaylı Analiz",tagline:"Kişiselleştirilmiş program ve canlı destek.",features:["Kapsamlı fiziksel değerlendirme","Detaylı ağrı haritası analizi","Kişiselleştirilmiş egzersiz programı","Video konsültasyon (30 dk)","WhatsApp desteği"],recommended:!0},{id:"premium",badge:"Premium",price:"₺1,999",title:"Premium Analiz",tagline:"AI destekli analiz ve öncelikli randevu.",features:["AI destekli ağrı analizi","Özel egzersiz programı + video rehber","Video konsültasyon (60 dk)","4 hafta takip ve destek","7/24 WhatsApp desteği","Öncelikli randevu"],recommended:!1}],Yh=({onSelectPackage:r})=>l.jsxs("section",{id:"packages",className:"relative overflow-hidden",style:{scrollMarginTop:"140px"},children:[l.jsx("div",{className:"absolute inset-0 bg-gradient-to-br from-[#e3ecff] via-[#e8eaff] to-[#e3f4ff]"}),l.jsx("div",{className:"absolute -top-24 -left-16 w-64 h-64 bg-blue-300/30 rounded-full blur-3xl"}),l.jsx("div",{className:"absolute -bottom-24 -right-10 w-72 h-72 bg-indigo-300/25 rounded-full blur-3xl"}),l.jsxs("div",{className:"relative container mx-auto px-4 py-16",children:[l.jsxs("div",{className:"text-center max-w-3xl mx-auto",children:[l.jsx("h2",{className:"text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight",children:"Hizmet Paketleri"}),l.jsx("p",{className:"mt-3 text-base md:text-lg text-slate-600",children:"Bilimsel egzersiz reçetenizi alın, iyileşme sürecinizi profesyonel kontrolde yönetin."})]}),l.jsx("div",{className:"mt-12 grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8",children:Hh.map(v=>l.jsxs("div",{className:`relative rounded-2xl p-6 shadow-lg border-2 transition transform hover:-translate-y-1 ${v.id==="basic"?"bg-gradient-to-br from-gray-50 to-gray-200 border-gray-200":v.id==="recommended"?"bg-gradient-to-br from-sky-50 to-blue-100 border-blue-200":"bg-gradient-to-br from-amber-50 to-orange-100 border-orange-200"}`,children:[l.jsxs("div",{className:"flex items-center justify-between mb-2",children:[l.jsx("span",{className:`px-3 py-1 text-xs font-bold rounded-full uppercase ${v.id==="basic"?"bg-gray-700 text-white":v.id==="recommended"?"bg-blue-600 text-white":"bg-orange-500 text-white"}`,children:v.badge}),l.jsx("span",{className:"text-xl font-extrabold text-indigo-700",children:v.price})]}),l.jsx("h3",{className:"text-2xl font-bold text-slate-900 mb-2",children:v.title}),l.jsx("p",{className:"text-slate-600 text-sm mb-6",children:v.tagline}),l.jsx("ul",{className:"space-y-2 text-sm",children:v.features.map((E,d)=>l.jsxs("li",{className:"flex items-center gap-2 text-slate-700 leading-relaxed",children:[l.jsx("span",{className:"inline-flex items-center justify-center w-5 h-5 rounded-full bg-emerald-100 text-emerald-600",children:l.jsx(W0,{size:12})}),E]},d))}),l.jsxs("div",{className:"mt-6 flex flex-col gap-2",children:[l.jsx("button",{onClick:r,className:`w-full py-3 px-6 rounded-xl font-semibold text-base transition-all duration-300 transform hover:scale-[1.02] active:scale-[0.98] shadow-md hover:shadow-lg ${v.recommended?"bg-gradient-to-r from-blue-600 to-teal-500 text-white hover:from-blue-700 hover:to-teal-600":"bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200"}`,children:v.recommended?"✨ Bu Paketi Seç":"Paketi Seç"}),v.id==="basic"&&l.jsx("button",{onClick:r,className:"w-full py-2.5 px-6 rounded-xl font-medium text-sm text-blue-600 hover:text-blue-700 border-2 border-blue-300 hover:border-blue-400 bg-blue-50 hover:bg-blue-100 transition-all duration-300",children:"🎁 Ücretsiz Dene"})]})]},v.id))}),l.jsxs("div",{className:"mt-14 grid md:grid-cols-2 gap-6",children:[l.jsx("div",{className:"bg-white border border-gray-100 rounded-2xl p-6 shadow-md",children:l.jsxs("div",{className:"flex items-start gap-3",children:[l.jsx("div",{className:"text-3xl",children:"📊"}),l.jsxs("div",{children:[l.jsx("h5",{className:"text-lg font-bold text-slate-900 mb-1",children:"Bilimsel Not"}),l.jsx("p",{className:"text-slate-700 leading-relaxed",children:"Egzersiz tedavisi ilaç gibidir; adaptasyon için zamana ihtiyaç vardır. Literatür, anlamlı iyileşme için en az 4-6 hafta düzenli uygulama önerir."})]})]})}),l.jsx("div",{className:"bg-white border border-gray-100 rounded-2xl p-6 shadow-md",children:l.jsxs("div",{className:"flex items-start gap-3",children:[l.jsx("div",{className:"text-3xl",children:"✅"}),l.jsxs("div",{children:[l.jsx("h5",{className:"text-lg font-bold text-slate-900 mb-1",children:"Memnuniyet Garantisi"}),l.jsx("p",{className:"text-slate-700 leading-relaxed",children:"Program size uymazsa ilk hafta içinde ücretsiz revizyon hakkınız var."})]})]})})]})]})]}),Gh=[{icon:"✓",label:"%100 Kişiye Özel"},{icon:"⏰",label:"7/24 Dijital Destek"},{icon:"🔬",label:"Bilimsel Metodoloji"}],Ih=[{title:"Bilimin Işığında",color:"text-blue-600",text:"Uyguladığımız tüm yöntemler ve egzersiz reçeteleri, güncel fizyoterapi literatürüne ve klinik çalışmalara dayanır."},{title:"Sürdürülebilir İyileşme",color:"text-purple-600",text:"Anlık ağrı kesici çözümler değil, sorunun kök nedenine inen ve kalıcı iyileşmeyi hedefleyen alışkanlıklar kazandırırız."},{title:"Ulaşılabilirlik",color:"text-pink-600",text:"Profesyonel sağlık desteğini lüks olmaktan çıkarıp, dilediğiniz yerde ve zamanda ulaşabileceğiniz bir hizmete dönüştürüyoruz."}],Kh=()=>l.jsxs("section",{id:"about",className:"w-full bg-white",style:{scrollMarginTop:"140px"},children:[l.jsx("div",{className:"bg-gradient-to-br from-[#4f6edc] via-[#5c5db4] to-[#6a3fb0] text-white py-16 px-4 md:px-8",children:l.jsxs("div",{className:"max-w-4xl mx-auto text-center",children:[l.jsx("h1",{className:"text-4xl md:text-5xl font-extrabold mb-4 leading-tight",children:"Hareketin Bilimsel Formülü"}),l.jsx("p",{className:"text-2xl md:text-3xl font-semibold opacity-90",children:"EgzersizLab"})]})}),l.jsx("div",{className:"bg-white py-12 px-4 md:px-8",children:l.jsx("div",{className:"max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8",children:Gh.map(r=>l.jsxs("div",{className:"stat-card bg-gradient-to-br from-blue-50 via-slate-50 to-purple-50 rounded-2xl p-8 text-center shadow-sm transition transform hover:-translate-y-1 hover:shadow-xl",children:[l.jsx("div",{className:"text-5xl mb-4",children:r.icon}),l.jsx("p",{className:"text-xl font-semibold text-slate-800",children:r.label})]},r.label))})}),l.jsx("div",{className:"bg-gradient-to-b from-gray-50 to-white py-14 px-4 md:px-8",children:l.jsxs("div",{className:"max-w-4xl mx-auto space-y-14",children:[l.jsxs("section",{children:[l.jsx("h2",{className:"text-3xl font-bold text-slate-900 mb-4",children:"Biz Kimiz?"}),l.jsx("p",{className:"text-lg text-slate-700 leading-relaxed",children:"EgzersizLab, modern tıbbın kanıta dayalı rehabilitasyon yöntemlerini, dijital teknolojinin hızı ve erişilebilirliği ile birleştiren yeni nesil bir sağlık teknolojisi girişimidir. Amacımız, coğrafi sınırları ortadan kaldırarak herkesin doğru, güvenilir ve kişiye özel sağlık danışmanlığına ulaşmasını sağlamaktır."})]}),l.jsx("div",{className:"h-0.5 bg-gradient-to-r from-transparent via-blue-400/60 to-transparent"}),l.jsxs("section",{children:[l.jsx("h2",{className:"text-3xl font-bold text-slate-900 mb-4",children:"Misyonumuz"}),l.jsx("p",{className:"text-lg text-slate-700 leading-relaxed",children:'İnternetteki bilgi kirliliği ve herkese aynı reçeteyi sunan standart yaklaşımların aksine; her bireyin anatomisinin, yaşam tarzının ve ağrı geçmişinin "parmak izi" gibi benzersiz olduğuna inanıyoruz. EgzersizLab olarak, sağlığı şansa bırakmıyor; süreci bir laboratuvar titizliğiyle analiz edip, kişiye en uygun iyileşme haritasını çıkarıyoruz.'})]}),l.jsx("div",{className:"h-0.5 bg-gradient-to-r from-transparent via-blue-400/60 to-transparent"}),l.jsxs("section",{children:[l.jsx("h2",{className:"text-3xl font-bold text-slate-900 mb-6",children:"Değerlerimiz"}),l.jsx("div",{className:"space-y-5",children:Ih.map(r=>l.jsxs("div",{className:"value-card bg-white rounded-xl p-6 shadow-sm border-l-4 border-transparent transition hover:border-l-blue-500 hover:bg-gradient-to-r hover:from-blue-50/60 hover:to-transparent",children:[l.jsx("h3",{className:`text-xl font-bold mb-2 ${r.color}`,children:r.title}),l.jsx("p",{className:"text-slate-700 leading-relaxed",children:r.text})]},r.title))})]}),l.jsx("div",{className:"h-0.5 bg-gradient-to-r from-transparent via-blue-400/60 to-transparent"}),l.jsxs("section",{className:"text-center",children:[l.jsx("p",{className:"text-xl text-slate-800 leading-relaxed mb-4",children:"Vücudunuz, içinde yaşadığınız en değerli evinizdir. EgzersizLab ekibi olarak, o eve en iyi şekilde bakmanız için gereken bilgiyi ve desteği sağlamak üzere yanınızdayız."}),l.jsx("p",{className:"text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent",children:"Hareket özgürlüktür. Bilimle hareket edin."})]}),l.jsx("div",{className:"text-center pt-6 border-t border-gray-200",children:l.jsx("p",{className:"text-lg font-semibold text-slate-800",children:"EgzersizLab Ekibi"})})]})})]}),hl=[{id:1,name:"Ayşe Yılmaz",rating:5,comment:"Bel ağrılarım için aldığım program sayesinde 2 ayda çok büyük ilerleme kaydettim. Fizyoterapist desteği harika!",date:"2 hafta önce",packageType:"Klinik Paket"},{id:2,name:"Mehmet Demir",rating:5,comment:"Diz cerrahisi sonrası rehabilitasyon sürecimde çok yardımcı oldu. Video anlatımlar çok net ve anlaşılır.",date:"1 ay önce",packageType:"Premium Paket"},{id:3,name:"Zeynep Kaya",rating:5,comment:"Boyun ağrılarım için kişiselleştirilmiş program aldım. Artık günlük hayatımda çok daha rahatım. Teşekkürler!",date:"3 hafta önce",packageType:"Temel Paket"},{id:4,name:"Ali Çelik",rating:5,comment:"Premium paket ile fizyoterapistimle sürekli iletişim halindeyim. Sorularıma anında cevap alıyorum. Mükemmel!",date:"1 hafta önce",packageType:"Premium Paket"},{id:5,name:"Fatma Özkan",rating:5,comment:"Omuz problemim için aldığım program gerçekten işe yaradı. Egzersizler çok etkili ve kolay takip edilebilir.",date:"2 ay önce",packageType:"Klinik Paket"},{id:6,name:"Can Arslan",rating:5,comment:"Spor yaralanması sonrası hızlı toparlanmamı sağladı. Profesyonel yaklaşım ve kişiselleştirilmiş program harika!",date:"3 hafta önce",packageType:"Premium Paket"}],qh=()=>{const[r,v]=g.useState(0),[E,d]=g.useState(!0);g.useEffect(()=>{if(!E)return;const b=setInterval(()=>{v(p=>(p+1)%hl.length)},5e3);return()=>clearInterval(b)},[E]);const w=()=>{v(b=>(b+1)%hl.length),d(!1)},A=()=>{v(b=>(b-1+hl.length)%hl.length),d(!1)},S=b=>{v(b),d(!1)},B=b=>l.jsx("div",{className:"flex gap-1",children:[1,2,3,4,5].map(p=>l.jsx("span",{className:`text-lg ${p<=b?"text-yellow-400":"text-gray-300"}`,children:"★"},p))});return l.jsxs("section",{id:"testimonials",className:"py-20 bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 relative overflow-hidden",style:{scrollMarginTop:"140px"},children:[l.jsx("div",{className:"absolute top-0 right-0 w-96 h-96 bg-blue-200/20 rounded-full blur-3xl"}),l.jsx("div",{className:"absolute bottom-0 left-0 w-96 h-96 bg-teal-200/20 rounded-full blur-3xl"}),l.jsxs("div",{className:"container mx-auto px-4 relative z-10",children:[l.jsxs("div",{className:"text-center mb-12",children:[l.jsx("h2",{className:"text-4xl md:text-5xl font-extrabold text-slate-900 mb-4",children:"Müşterilerimiz Ne Diyor?"}),l.jsx("p",{className:"text-lg text-slate-600 max-w-2xl mx-auto",children:"Binlerce mutlu kullanıcımızın deneyimlerini keşfedin"}),l.jsxs("div",{className:"mt-4 flex items-center justify-center gap-2",children:[l.jsx("div",{className:"flex gap-1",children:[1,2,3,4,5].map(b=>l.jsx("span",{className:"text-2xl text-yellow-400",children:"★"},b))}),l.jsx("span",{className:"text-xl font-bold text-slate-900 ml-2",children:"4.9/5"}),l.jsx("span",{className:"text-slate-600 ml-2",children:"(247 değerlendirme)"})]})]}),l.jsxs("div",{className:"relative max-w-6xl mx-auto",children:[l.jsx("div",{className:"overflow-hidden rounded-2xl",children:l.jsx("div",{className:"flex transition-transform duration-500 ease-in-out",style:{transform:`translateX(-${r*100}%)`},children:hl.map(b=>l.jsx("div",{className:"min-w-full px-4",children:l.jsx("div",{className:"bg-white rounded-2xl shadow-xl p-8 md:p-10 border border-gray-100",children:l.jsxs("div",{className:"flex flex-col md:flex-row gap-6",children:[l.jsxs("div",{className:"md:w-1/3 flex flex-col items-center md:items-start",children:[l.jsx("div",{className:"w-20 h-20 bg-gradient-to-br from-blue-500 to-teal-500 rounded-full flex items-center justify-center text-white text-2xl font-bold mb-4",children:b.name.charAt(0)}),l.jsx("h3",{className:"text-xl font-bold text-slate-900 mb-2",children:b.name}),b.packageType&&l.jsx("span",{className:"px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-semibold mb-3",children:b.packageType}),B(b.rating),l.jsx("p",{className:"text-sm text-slate-500 mt-2",children:b.date})]}),l.jsx("div",{className:"md:w-2/3 flex items-center",children:l.jsxs("div",{children:[l.jsx("div",{className:"text-4xl text-blue-200 mb-4",children:'"'}),l.jsx("p",{className:"text-lg text-slate-700 leading-relaxed italic",children:b.comment}),l.jsx("div",{className:"text-4xl text-blue-200 mt-4 text-right",children:'"'})]})})]})})},b.id))})}),l.jsx("button",{onClick:A,className:"absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 md:-translate-x-12 w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-blue-50 transition-all z-10 border border-gray-200","aria-label":"Önceki yorum",children:l.jsx(Go,{className:"w-6 h-6 text-slate-700"})}),l.jsx("button",{onClick:w,className:"absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 md:translate-x-12 w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-blue-50 transition-all z-10 border border-gray-200","aria-label":"Sonraki yorum",children:l.jsx(Yo,{className:"w-6 h-6 text-slate-700"})}),l.jsx("div",{className:"flex justify-center gap-2 mt-8",children:hl.map((b,p)=>l.jsx("button",{onClick:()=>S(p),className:`w-3 h-3 rounded-full transition-all ${p===r?"bg-blue-600 w-8":"bg-gray-300 hover:bg-gray-400"}`,"aria-label":`Yorum ${p+1}`},p))})]}),l.jsx("div",{className:"hidden lg:grid lg:grid-cols-3 gap-6 mt-12",children:hl.slice(0,3).map(b=>l.jsxs("div",{className:"bg-white rounded-xl shadow-lg p-6 border border-gray-100 hover:shadow-xl transition-shadow",children:[l.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[l.jsx("div",{className:"w-12 h-12 bg-gradient-to-br from-blue-500 to-teal-500 rounded-full flex items-center justify-center text-white font-bold",children:b.name.charAt(0)}),l.jsxs("div",{children:[l.jsx("h4",{className:"font-bold text-slate-900",children:b.name}),B(b.rating)]})]}),l.jsxs("p",{className:"text-slate-700 text-sm leading-relaxed mb-3",children:['"',b.comment,'"']}),b.packageType&&l.jsx("span",{className:"text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded-full",children:b.packageType})]},b.id))})]})]})},Vh=({email:r,name:v,password:E,phone:d,onClose:w,onSuccess:A})=>{const[S,B]=g.useState(["","","",""]),[b,p]=g.useState(!1),[U,N]=g.useState(null),[G,L]=g.useState(!1),[Z,ie]=g.useState(0),J=g.useRef([]);g.useEffect(()=>{if(Z>0){const de=setTimeout(()=>ie(Z-1),1e3);return()=>clearTimeout(de)}},[Z]);const H=(de,Q)=>{var ne;if(!/^\d*$/.test(Q))return;const Y=[...S];Y[de]=Q.slice(-1),B(Y),N(null),Q&&de<3&&((ne=J.current[de+1])==null||ne.focus())},K=(de,Q)=>{var Y;Q.key==="Backspace"&&!S[de]&&de>0&&((Y=J.current[de-1])==null||Y.focus())},ue=de=>{var Y;de.preventDefault();const Q=de.clipboardData.getData("text").slice(0,4);if(/^\d{4}$/.test(Q)){const ne=Q.split("");B([...ne,...Array(4-ne.length).fill("")].slice(0,4)),(Y=J.current[3])==null||Y.focus()}},$=async de=>{var Y,ne;de.preventDefault(),N(null);const Q=S.join("");if(Q.length!==4){N("Lütfen 4 haneli kodu giriniz");return}p(!0);try{const re=await ta.verifyAndRegister(r,Q,E,v,d);re.success?(localStorage.setItem("showLoginSuccess","true"),A(),w(),window.location.href="/#dashboard"):(N(re.error||"Kod doğrulanamadı. Lütfen tekrar deneyin."),B(["","","",""]),(Y=J.current[0])==null||Y.focus())}catch(re){N(re.message||"Bir hata oluştu. Lütfen tekrar deneyin."),B(["","","",""]),(ne=J.current[0])==null||ne.focus()}finally{p(!1)}},Ye=async()=>{var de;L(!0),N(null);try{const Q=await ta.sendVerificationCode(r,E,v,d);Q.success?(ie(60),B(["","","",""]),(de=J.current[0])==null||de.focus()):N(Q.error||"Kod gönderilemedi. Lütfen tekrar deneyin.")}catch(Q){N(Q.message||"Kod gönderilemedi. Lütfen tekrar deneyin.")}finally{L(!1)}};return l.jsx("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm px-4",children:l.jsx("div",{className:"bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden",children:l.jsxs("div",{className:"p-8",children:[l.jsx("button",{onClick:w,className:"absolute right-4 top-4 text-gray-500 hover:text-gray-700 transition text-xl","aria-label":"Kapat",children:"×"}),l.jsxs("div",{className:"text-center mb-6",children:[l.jsx("div",{className:"w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4",children:l.jsx("svg",{className:"w-8 h-8 text-white",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:l.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"})})}),l.jsx("h2",{className:"text-2xl font-bold text-gray-800 mb-2",children:"E-posta Aktivasyonu"}),l.jsxs("p",{className:"text-gray-600 text-sm",children:[l.jsx("strong",{children:r})," adresine gönderilen 4 haneli kodu giriniz"]})]}),U&&l.jsx("div",{className:"mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm",children:U}),l.jsxs("form",{onSubmit:$,className:"space-y-6",children:[l.jsxs("div",{children:[l.jsx("label",{className:"block text-sm font-semibold text-gray-700 mb-3 text-center",children:"Aktivasyon Kodu"}),l.jsx("div",{className:"flex gap-3 justify-center",onPaste:ue,children:S.map((de,Q)=>l.jsx("input",{ref:Y=>J.current[Q]=Y,type:"text",inputMode:"numeric",maxLength:1,value:de,onChange:Y=>H(Q,Y.target.value),onKeyDown:Y=>K(Q,Y),className:"w-14 h-14 text-center text-2xl font-bold border-2 border-gray-300 rounded-xl focus:outline-none focus:border-purple-500 focus:ring-2 focus:ring-purple-200 transition"},Q))}),l.jsx("p",{className:"text-xs text-gray-500 text-center mt-2",children:"Kod 10 dakika geçerlidir"})]}),l.jsx("button",{type:"submit",disabled:b||S.join("").length!==4,className:"w-full py-3 text-white font-bold rounded-lg shadow-lg bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed",children:b?"Doğrulanıyor...":"Hesabı Aktifleştir"}),l.jsx("div",{className:"text-center",children:l.jsx("button",{type:"button",onClick:Ye,disabled:G||Z>0,className:"text-sm text-purple-600 hover:text-purple-700 font-semibold disabled:text-gray-400 disabled:cursor-not-allowed",children:Z>0?`Yeni kod gönder (${Z}s)`:G?"Gönderiliyor...":"Kodu tekrar gönder"})})]})]})})})},Xh=({onClose:r,onSuccess:v,onOpenLogin:E})=>{const[d,w]=g.useState(!1),[A,S]=g.useState(!1),[B,b]=g.useState(null),[p,U]=g.useState(!1),[N,G]=g.useState(!1),[L,Z]=g.useState({name:"",email:"",phone:"",password:""}),ie={backgroundImage:'linear-gradient(135deg, rgba(102,126,234,0.95), rgba(118,75,162,0.95)), url("https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=900&q=80")',backgroundSize:"cover",backgroundPosition:"center"};return l.jsxs("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm px-4",children:[l.jsx("style",{children:`
        .floating-icon { animation: float 3s ease-in-out infinite; }
        @keyframes float { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }
        .input-field:focus {
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
        }
        .checkbox-custom {
          appearance: none;
          width: 20px;
          height: 20px;
          border: 2px solid #d1d5db;
          border-radius: 4px;
          cursor: pointer;
          transition: all 0.2s;
          flex-shrink: 0;
        }
        .checkbox-custom:checked {
          background-color: #667eea;
          border-color: #667eea;
          background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='white'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='3' d='M5 13l4 4L19 7'%3E%3C/path%3E%3C/svg%3E");
          background-size: 16px;
          background-position: center;
          background-repeat: no-repeat;
        }
        .registration-submit {
          position: relative;
          overflow: hidden;
        }
        .registration-submit::before {
          content: '';
          position: absolute;
          top: 0;
          left: -100%;
          width: 100%;
          height: 100%;
          background: linear-gradient(90deg, transparent, rgba(255,255,255,0.25), transparent);
          transition: left 0.6s ease;
        }
        .registration-submit:hover::before { left: 100%; }
      `}),l.jsxs("div",{className:"bg-white w-full max-w-5xl rounded-3xl overflow-hidden shadow-2xl grid grid-cols-1 md:grid-cols-2",children:[l.jsx("div",{className:"text-white p-8 md:p-10 flex items-center",style:ie,children:l.jsxs("div",{className:"space-y-6 max-w-md",children:[l.jsx("div",{className:"floating-icon",children:l.jsx("svg",{className:"w-16 h-16",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:l.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"})})}),l.jsx("h1",{className:"text-3xl font-bold leading-tight",children:"Ağrısız bir yaşama ilk adımı atıyorsunuz"}),l.jsx("p",{className:"text-lg opacity-90",children:"Profesyonel fizyoterapistlerimiz, size özel egzersiz programlarıyla sağlıklı yaşamınızı destekliyor."}),l.jsx("div",{className:"space-y-3 pt-4",children:["Kişiye özel egzersiz programları","7/24 Dijital Erişim imkanı","Uzman fizyoterapist danışmanlığı"].map(J=>l.jsxs("div",{className:"flex items-center gap-3",children:[l.jsx("svg",{className:"w-5 h-5 flex-shrink-0",fill:"currentColor",viewBox:"0 0 20 20",children:l.jsx("path",{fillRule:"evenodd",d:"M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z",clipRule:"evenodd"})}),l.jsx("span",{children:J})]},J))})]})}),l.jsxs("div",{className:"p-8 md:p-10 bg-gray-50 relative",children:[l.jsx("button",{onClick:r,className:"absolute right-4 top-4 text-gray-500 hover:text-gray-700 transition text-xl","aria-label":"Kapat",children:"×"}),l.jsxs("div",{className:"bg-white rounded-2xl shadow-lg p-6 md:p-8",children:[l.jsxs("div",{className:"text-center mb-6",children:[l.jsx("h2",{className:"text-2xl font-bold text-gray-800 mb-1",children:"Hesap Oluştur"}),l.jsx("p",{className:"text-gray-600 text-sm",children:"Sağlıklı yaşam yolculuğunuza başlayın"})]}),B&&l.jsx("div",{className:"mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm",children:B}),l.jsxs("form",{className:"space-y-4",onSubmit:async J=>{J.preventDefault(),b(null),S(!0);try{if(L.phone&&L.phone.trim()!==""){const K=L.phone.trim();if(!/^[0-9+\-\s()]+$/.test(K)){b("Geçerli bir telefon numarası giriniz (sadece rakam, +, -, boşluk kullanabilirsiniz)"),S(!1);return}if(K.replace(/\D/g,"").length<10){b("Telefon numarası en az 10 haneli olmalıdır (örn: 5XX XXX XX XX)"),S(!1);return}}if(L.password.length<8){b("Şifre en az 8 karakter olmalıdır"),S(!1);return}if(!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(L.password)){b("Şifre en az bir küçük harf, bir büyük harf ve bir rakam içermelidir"),S(!1);return}const H=await ta.sendVerificationCode(L.email,L.password,L.name,L.phone);H.success?U(!0):b(H.error||"Kod gönderilemedi. Lütfen tekrar deneyin.")}catch(H){b(H.message||"Bir hata oluştu. Lütfen tekrar deneyin.")}finally{S(!1)}},children:[l.jsxs("div",{children:[l.jsxs("label",{className:"block text-sm font-semibold text-gray-700 mb-2",children:["Ad Soyad ",l.jsx("span",{className:"text-red-500",children:"*"})]}),l.jsx("input",{type:"text",required:!0,value:L.name,onChange:J=>Z({...L,name:J.target.value}),className:"input-field w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-purple-500",placeholder:"Adınız ve Soyadınız"})]}),l.jsxs("div",{children:[l.jsxs("label",{className:"block text-sm font-semibold text-gray-700 mb-2",children:["E-posta Adresi ",l.jsx("span",{className:"text-red-500",children:"*"})]}),l.jsx("input",{type:"email",required:!0,value:L.email,onChange:J=>Z({...L,email:J.target.value}),className:"input-field w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-purple-500",placeholder:"ornek@email.com"})]}),l.jsxs("div",{children:[l.jsx("label",{className:"block text-sm font-semibold text-gray-700 mb-2",children:"Telefon"}),l.jsx("input",{type:"tel",value:L.phone,onChange:J=>Z({...L,phone:J.target.value}),className:"input-field w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-purple-500",placeholder:"0555 555 55 55"})]}),l.jsxs("div",{children:[l.jsxs("label",{className:"block text-sm font-semibold text-gray-700 mb-2",children:["Şifre Oluştur ",l.jsx("span",{className:"text-red-500",children:"*"})]}),l.jsxs("div",{className:"relative",children:[l.jsx("input",{type:d?"text":"password",required:!0,value:L.password,onChange:J=>Z({...L,password:J.target.value}),className:"input-field w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-purple-500",placeholder:"En az 8 karakter (büyük/küçük harf + rakam)"}),l.jsx("button",{type:"button",onClick:()=>w(J=>!J),className:"absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700 text-sm",children:d?"Gizle":"Göster"})]}),l.jsx("p",{className:"text-xs text-gray-500 mt-1",children:"En az 8 karakter, bir büyük harf, bir küçük harf ve bir rakam içermelidir"})]}),l.jsx("div",{className:"pt-2",children:l.jsxs("label",{className:"flex items-start gap-3 cursor-pointer",children:[l.jsx("input",{type:"checkbox",required:!0,className:"checkbox-custom mt-1"}),l.jsxs("span",{className:"text-sm text-gray-600 leading-relaxed",children:[l.jsx("button",{type:"button",onClick:()=>G(!0),className:"text-purple-600 hover:underline font-semibold",children:"KVKK"})," ","ve"," ",l.jsx("button",{type:"button",onClick:()=>G(!0),className:"text-purple-600 hover:underline font-semibold",children:"Aydınlatma Metni"}),"'ni okudum, kabul ediyorum."]})]})}),l.jsx("button",{type:"submit",disabled:A,className:"registration-submit w-full py-3 text-white font-bold rounded-lg shadow-lg bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300 mt-4 disabled:opacity-50 disabled:cursor-not-allowed",children:A?"Kayıt yapılıyor...":"Hesabımı Oluştur ve Değerlendirmeye Başla"})]}),l.jsxs("div",{className:"mt-5 text-center text-sm text-gray-600",children:["Zaten hesabınız var mı?"," ",l.jsx("button",{type:"button",onClick:()=>{r(),E==null||E()},className:"text-purple-600 hover:text-purple-700 font-semibold",children:"Giriş Yapın"})]})]})]})]}),p&&l.jsx(Vh,{email:L.email,name:L.name,password:L.password,phone:L.phone,onClose:()=>{U(!1),r()},onSuccess:()=>{v?v():(window.location.hash="#dashboard",setTimeout(()=>{window.location.reload()},100))}}),N&&l.jsx("div",{className:"fixed inset-0 z-[70] flex items-center justify-center bg-black/60 backdrop-blur-sm px-4",children:l.jsx("div",{className:"bg-white max-w-3xl w-full rounded-2xl shadow-2xl overflow-hidden",children:l.jsxs("div",{className:"p-6 sm:p-8 max-h-[80vh] overflow-y-auto space-y-4 text-sm text-gray-700",children:[l.jsxs("div",{className:"flex justify-between items-start",children:[l.jsx("h3",{className:"text-xl font-bold text-gray-900",children:"KVKK ve Aydınlatma Metni"}),l.jsx("button",{onClick:()=>G(!1),className:"text-gray-500 hover:text-gray-700 text-lg","aria-label":"Kapat",children:"×"})]}),l.jsx("p",{children:'EgzersizLab olarak 6698 sayılı Kişisel Verilerin Korunması Kanunu ("KVKK") kapsamında; kimlik, iletişim, işlem güvenliği ve kullanım verilerinizi hizmet sunumu, üyelik işlemleri, destek ve güvenlik süreçleri için işliyoruz. Verileriniz, açık rızanıza dayalı olarak veya KVKK m.5/2 uyarınca sözleşmenin ifası, hukuki yükümlülüklerin yerine getirilmesi, meşru menfaat ve hakların tesisi amaçlarıyla kullanılabilir.'}),l.jsx("p",{children:"Kişisel verileriniz; yetkili kamu kurumları, iş ortakları, altyapı/hosting/e-posta sağlayıcıları ve hukuken yetkili üçüncü kişilerle, hizmetlerin sağlanması ve güvenliğinin tesis edilmesi amacıyla paylaşılabilir. Verileriniz yurt içinde veya hizmet alınan altyapılar nedeniyle yurt dışında barındırılabilir."}),l.jsx("p",{className:"font-semibold",children:"Haklarınız (KVKK m.11)"}),l.jsxs("ul",{className:"list-disc pl-5 space-y-1",children:[l.jsx("li",{children:"İşlenip işlenmediğini öğrenme,"}),l.jsx("li",{children:"İşlenme amacını ve amaca uygun kullanılıp kullanılmadığını öğrenme,"}),l.jsx("li",{children:"Yurt içi/dışı aktarılan üçüncü kişileri bilme,"}),l.jsx("li",{children:"Eksik veya yanlış işlendi ise düzeltilmesini isteme,"}),l.jsx("li",{children:"Silinmesini/yok edilmesini isteme,"}),l.jsx("li",{children:"Otomatik sistemlerle analiz sonucu aleyhinize bir sonuca itiraz etme,"}),l.jsx("li",{children:"Kanuna aykırı işlem nedeniyle zarara uğrarsanız tazminat talep etme."})]}),l.jsx("p",{children:"Başvuru: kvkk@egzersizlab.com adresine kimlik doğrulamalı e-posta ile başvurabilirsiniz. Detaylı aydınlatma ve çerez politikası için lütfen bizimle iletişime geçin."}),l.jsx("div",{className:"flex justify-end",children:l.jsx("button",{onClick:()=>G(!1),className:"px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg shadow hover:shadow-lg transition",children:"Anladım"})})]})})})]})},Qh=[{id:1,title:"Vakalarla Omurgada Radyolojik Değerlendirme: MR-XRay-BT",instructor:"Dr. Ahmet Yılmaz",price:1100,rating:5,reviewCount:2,image:"https://picsum.photos/400/250?random=1",category:"Workshop",duration:"3 Saat",students:46},{id:2,title:"Diz Cerrahileri Sonrası Rehabilitasyon Sertifika Programı",instructor:"Prof. Dr. Ayşe Demir",price:3e3,rating:4.8,reviewCount:4,image:"https://picsum.photos/400/250?random=2",category:"Ortopedi",duration:"38 Ders",students:54},{id:3,title:"Fonksiyonel Bantlama Teknikleri",instructor:"Uzm. Fzt. Mehmet Kaya",price:3e3,rating:4.9,reviewCount:14,image:"https://picsum.photos/400/250?random=3",category:"Manuel Terapi",duration:"15 Ders",students:65},{id:4,title:"İnmede Fizyoterapi ve Rehabilitasyon",instructor:"Dr. Zeynep Çelik",price:1499,rating:5,reviewCount:7,image:"https://picsum.photos/400/250?random=4",category:"Nöroloji",duration:"2 Saat",students:26}];function Zh(){const[r,v]=g.useState(!1),[E,d]=g.useState(!1),[w,A]=g.useState(!1),[S,B]=g.useState(!1);return g.useEffect(()=>{const b=localStorage.getItem("token");B(!!b)},[]),g.useEffect(()=>{const b=()=>{const p=window.scrollY;A(p>400)};return window.addEventListener("scroll",b),()=>window.removeEventListener("scroll",b)},[]),l.jsxs("div",{className:"min-h-screen flex flex-col font-sans",children:[l.jsx("style",{children:`
        @keyframes fade-in {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-fade-in {
          animation: fade-in 0.5s ease-out;
        }
      `}),l.jsx(_h,{onOpenRegister:()=>v(!0),isAuthenticated:S}),l.jsx(Rh,{}),l.jsx("section",{className:"py-8 px-4",children:l.jsx("div",{className:"container mx-auto",children:l.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-4 gap-4 rounded-2xl bg-white shadow-xl border border-slate-100 p-4 md:p-6",children:[l.jsxs("div",{className:"flex items-center gap-3",children:[l.jsx("div",{className:"w-12 h-12 rounded-xl bg-gradient-to-br from-blue-600 to-teal-500 text-white font-bold flex items-center justify-center",children:"⚡"}),l.jsxs("div",{children:[l.jsx("p",{className:"text-sm text-slate-500",children:"Hızlı Başlangıç"}),l.jsx("p",{className:"text-lg font-extrabold text-slate-900",children:"3 dakikada plan"})]})]}),l.jsxs("div",{className:"flex items-center gap-3",children:[l.jsx("div",{className:"w-12 h-12 rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 text-white font-bold flex items-center justify-center",children:"⭐"}),l.jsxs("div",{children:[l.jsx("p",{className:"text-sm text-slate-500",children:"Kullanıcı memnuniyeti"}),l.jsx("p",{className:"text-lg font-extrabold text-slate-900",children:"%92 mutlu"})]})]}),l.jsxs("div",{className:"flex items-center gap-3",children:[l.jsx("div",{className:"w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-400 to-cyan-500 text-white font-bold flex items-center justify-center",children:"🛡️"}),l.jsxs("div",{children:[l.jsx("p",{className:"text-sm text-slate-500",children:"Risk tersine çevirme"}),l.jsx("p",{className:"text-lg font-extrabold text-slate-900",children:"7 gün revizyon"})]})]}),l.jsxs("div",{className:"flex items-center justify-between md:justify-end gap-3",children:[l.jsxs("div",{className:"hidden md:block text-right",children:[l.jsx("p",{className:"text-sm text-slate-500",children:"Şimdi başla"}),l.jsx("p",{className:"text-lg font-extrabold text-slate-900",children:"Bugün ilk adım"})]}),l.jsx("a",{href:"#packages",onClick:b=>{b.preventDefault(),v(!0)},className:"px-5 py-3 bg-gradient-to-r from-blue-600 to-teal-500 text-white font-semibold rounded-xl shadow-lg hover:shadow-blue-500/40 transition-transform hover:-translate-y-0.5",children:"Başla"})]})]})})}),l.jsx(Lh,{}),l.jsx(Bh,{}),l.jsx(Yh,{onSelectPackage:()=>v(!0)}),l.jsx(Dh,{courses:Qh}),l.jsx("section",{id:"faq",className:"py-16 bg-gradient-to-br from-slate-50 via-white to-blue-50",style:{scrollMarginTop:"140px"},children:l.jsxs("div",{className:"container mx-auto px-4",children:[l.jsxs("div",{className:"text-center max-w-3xl mx-auto mb-10",children:[l.jsx("h2",{className:"text-3xl md:text-4xl font-extrabold text-slate-900",children:"Sık Sorulanlar"}),l.jsx("p",{className:"text-slate-600 mt-3",children:"Karar vermeden önce en merak edilenler"})]}),l.jsx("div",{className:"grid gap-4 max-w-5xl mx-auto",children:[{q:"Ne kadar sürede sonuç alırım?",a:"Düzenli uygulamada 3-6 haftada belirgin iyileşme; ilk hafta içinde ağrı ve hareket açıklığında hafifleme beklenir."},{q:"Ağrım artarsa ne olacak?",a:"İlk 7 gün içinde ücretsiz revizyon yapıyoruz; fizyoterapistiniz planı yeniden düzenler."},{q:"İptal/iade süreci nasıl?",a:"Memnun kalmazsanız ilk hafta içinde koşulsuz revizyon; yasal iade haklarınız saklı."},{q:"Paketler arasındaki fark ne?",a:"Temel hızlı başlangıç içindir; Detaylı paket kişiselleştirilmiş program ve video görüşme ekler; Premium 7/24 destek ve öncelikli randevu sunar."}].map((b,p)=>l.jsxs("div",{className:"bg-white border border-slate-100 shadow-sm rounded-2xl p-5 hover:shadow-md transition",children:[l.jsx("p",{className:"font-bold text-slate-900 text-lg",children:b.q}),l.jsx("p",{className:"text-slate-600 mt-2",children:b.a})]},p))}),l.jsx("div",{className:"text-center mt-8",children:l.jsxs("a",{href:"#packages",onClick:b=>{b.preventDefault(),v(!0)},className:"inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-teal-500 text-white font-semibold rounded-xl shadow-lg hover:shadow-blue-500/40 transition-transform hover:-translate-y-0.5",children:["Hemen Başla",l.jsx("span",{children:"→"})]})})]})}),l.jsx(qh,{}),l.jsx(Kh,{}),l.jsx("section",{className:"py-16 bg-white",children:l.jsx("div",{className:"container mx-auto px-4",children:l.jsxs("div",{className:"grid grid-cols-2 lg:grid-cols-4 gap-8 text-center divide-x divide-gray-100",children:[l.jsxs("div",{children:[l.jsx("div",{className:"text-4xl font-bold text-teal-500 mb-2",children:"%100"}),l.jsx("div",{className:"text-gray-500 text-sm font-medium uppercase tracking-wider",children:"Kişiye Özel Analiz"})]}),l.jsxs("div",{children:[l.jsx("div",{className:"text-4xl font-bold text-pink-500 mb-2",children:"7/24"}),l.jsx("div",{className:"text-gray-500 text-sm font-medium uppercase tracking-wider",children:"Dijital Erişim ve Destek"})]}),l.jsxs("div",{children:[l.jsx("div",{className:"text-4xl font-bold text-blue-500 mb-2",children:"Kanıta Dayalı"}),l.jsx("div",{className:"text-gray-500 text-sm font-medium uppercase tracking-wider",children:"Bilimsel Egzersiz Reçetesi"})]}),l.jsxs("div",{children:[l.jsx("div",{className:"text-4xl font-bold text-orange-500 mb-2",children:"Birebir"}),l.jsx("div",{className:"text-gray-500 text-sm font-medium uppercase tracking-wider",children:"Fizyoterapist Takibi"})]})]})})}),l.jsxs("footer",{id:"contact",className:"bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-gray-300 pt-20 pb-10 w-full relative overflow-hidden",style:{scrollMarginTop:"140px"},children:[l.jsx("div",{className:"absolute top-0 left-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl"}),l.jsx("div",{className:"absolute bottom-0 right-0 w-96 h-96 bg-teal-600/10 rounded-full blur-3xl"}),l.jsxs("div",{className:"container mx-auto px-4 max-w-7xl relative z-10",children:[l.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 mb-16",children:[l.jsxs("div",{className:"lg:col-span-2",children:[l.jsxs("div",{className:"flex items-center gap-3 mb-6",children:[l.jsx("div",{className:"w-12 h-12 bg-gradient-to-br from-blue-500 to-teal-500 rounded-xl flex items-center justify-center",children:l.jsx("span",{className:"text-white text-xl font-bold",children:"E"})}),l.jsx("span",{className:"text-2xl font-bold text-white bg-gradient-to-r from-blue-400 to-teal-400 bg-clip-text text-transparent",children:"EgzersizLab"})]}),l.jsxs("p",{className:"text-sm leading-relaxed mb-6 text-gray-400",children:["EgzersizLab, bilimin ışığında kişiye özel rehabilitasyon ve egzersiz çözümleri sunan yeni nesil dijital sağlık platformudur. ",l.jsx("span",{className:"text-teal-400 font-semibold",children:"Hareket, en güçlü ilaçtır."})]}),l.jsxs("div",{className:"mb-6",children:[l.jsx("h5",{className:"text-white font-semibold mb-3 text-sm",children:"📧 Bültenimize Abone Olun"}),l.jsxs("div",{className:"flex gap-2",children:[l.jsx("input",{type:"email",placeholder:"E-posta adresiniz",className:"flex-1 px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"}),l.jsx("button",{className:"px-6 py-2 bg-gradient-to-r from-blue-600 to-teal-600 text-white rounded-lg font-semibold hover:from-blue-700 hover:to-teal-700 transition text-sm",children:"Abone Ol"})]}),l.jsx("p",{className:"text-xs text-gray-500 mt-2",children:"Sağlık ipuçları ve özel kampanyalardan haberdar olun"})]}),l.jsxs("div",{children:[l.jsx("h5",{className:"text-white font-semibold mb-3 text-sm",children:"Bizi Takip Edin"}),l.jsxs("div",{className:"flex gap-3",children:[l.jsx("a",{href:"https://instagram.com/egzersizlab",target:"_blank",rel:"noopener noreferrer",className:"social-icon w-11 h-11 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center hover:scale-110 hover:shadow-lg transition-all duration-300 cursor-pointer group",title:"Instagram",children:l.jsx("svg",{className:"w-5 h-5 text-white",fill:"currentColor",viewBox:"0 0 24 24",children:l.jsx("path",{d:"M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"})})}),l.jsx("a",{href:"https://linkedin.com/company/egzersizlab",target:"_blank",rel:"noopener noreferrer",className:"social-icon w-11 h-11 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center hover:scale-110 hover:shadow-lg transition-all duration-300 cursor-pointer group",title:"LinkedIn",children:l.jsx("svg",{className:"w-5 h-5 text-white",fill:"currentColor",viewBox:"0 0 24 24",children:l.jsx("path",{d:"M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"})})}),l.jsx("a",{href:"https://youtube.com/@egzersizlab",target:"_blank",rel:"noopener noreferrer",className:"social-icon w-11 h-11 bg-gradient-to-br from-red-600 to-red-700 rounded-xl flex items-center justify-center hover:scale-110 hover:shadow-lg transition-all duration-300 cursor-pointer group",title:"YouTube",children:l.jsx("svg",{className:"w-5 h-5 text-white",fill:"currentColor",viewBox:"0 0 24 24",children:l.jsx("path",{d:"M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"})})}),l.jsx("a",{href:"https://wa.me/905551234567",target:"_blank",rel:"noopener noreferrer",className:"social-icon w-11 h-11 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center hover:scale-110 hover:shadow-lg transition-all duration-300 cursor-pointer group",title:"WhatsApp",children:l.jsx("svg",{className:"w-5 h-5 text-white",fill:"currentColor",viewBox:"0 0 24 24",children:l.jsx("path",{d:"M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.372a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"})})})]})]})]}),l.jsxs("div",{children:[l.jsxs("h4",{className:"text-white font-bold mb-6 text-lg flex items-center gap-2",children:[l.jsx("span",{className:"w-1 h-6 bg-gradient-to-b from-blue-500 to-teal-500 rounded-full"}),"Keşfet"]}),l.jsxs("ul",{className:"space-y-2.5",children:[l.jsx("li",{children:l.jsxs("a",{href:"#process",className:"footer-link group flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-gray-800/50 transition-all duration-300",children:[l.jsx("span",{className:"footer-link-arrow text-gray-500 group-hover:text-teal-400 group-hover:translate-x-1 transition-all duration-300 text-xs",children:"→"}),l.jsx("span",{className:"footer-link-text text-gray-400 group-hover:text-white transition-colors duration-300 text-sm",children:"Sistem Nasıl İşliyor?"})]})}),l.jsx("li",{children:l.jsxs("a",{href:"#packages",className:"footer-link group flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-gray-800/50 transition-all duration-300",children:[l.jsx("span",{className:"footer-link-arrow text-gray-500 group-hover:text-teal-400 group-hover:translate-x-1 transition-all duration-300 text-xs",children:"→"}),l.jsx("span",{className:"footer-link-text text-gray-400 group-hover:text-white transition-colors duration-300 text-sm",children:"Hizmet Paketleri"})]})}),l.jsx("li",{children:l.jsxs("a",{href:"#blog",className:"footer-link group flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-gray-800/50 transition-all duration-300",children:[l.jsx("span",{className:"footer-link-arrow text-gray-500 group-hover:text-teal-400 group-hover:translate-x-1 transition-all duration-300 text-xs",children:"→"}),l.jsx("span",{className:"footer-link-text text-gray-400 group-hover:text-white transition-colors duration-300 text-sm",children:"Blog (Sağlık Rehberi)"})]})}),l.jsx("li",{children:l.jsxs("a",{href:"#",className:"footer-link group flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-gray-800/50 transition-all duration-300",children:[l.jsx("span",{className:"footer-link-arrow text-gray-500 group-hover:text-teal-400 group-hover:translate-x-1 transition-all duration-300 text-xs",children:"→"}),l.jsx("span",{className:"footer-link-text text-gray-400 group-hover:text-white transition-colors duration-300 text-sm",children:"Sıkça Sorulan Sorular"})]})}),l.jsx("li",{children:l.jsxs("a",{href:"#",className:"footer-link group flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-gray-800/50 transition-all duration-300",children:[l.jsx("span",{className:"footer-link-arrow text-gray-500 group-hover:text-teal-400 group-hover:translate-x-1 transition-all duration-300 text-xs",children:"→"}),l.jsx("span",{className:"footer-link-text text-gray-400 group-hover:text-white transition-colors duration-300 text-sm",children:"Müşteri Yorumları"})]})})]})]}),l.jsxs("div",{children:[l.jsxs("h4",{className:"text-white font-bold mb-6 text-lg flex items-center gap-2",children:[l.jsx("span",{className:"w-1 h-6 bg-gradient-to-b from-blue-500 to-teal-500 rounded-full"}),"Kurumsal"]}),l.jsxs("ul",{className:"space-y-2.5",children:[l.jsx("li",{children:l.jsxs("a",{href:"#about",className:"footer-link group flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-gray-800/50 transition-all duration-300",children:[l.jsx("span",{className:"footer-link-arrow text-gray-500 group-hover:text-teal-400 group-hover:translate-x-1 transition-all duration-300 text-xs",children:"→"}),l.jsx("span",{className:"footer-link-text text-gray-400 group-hover:text-white transition-colors duration-300 text-sm",children:"Hakkımızda"})]})}),l.jsx("li",{children:l.jsxs("a",{href:"#",className:"footer-link group flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-gray-800/50 transition-all duration-300",children:[l.jsx("span",{className:"footer-link-arrow text-gray-500 group-hover:text-teal-400 group-hover:translate-x-1 transition-all duration-300 text-xs",children:"→"}),l.jsx("span",{className:"footer-link-text text-gray-400 group-hover:text-white transition-colors duration-300 text-sm",children:"KVKK Aydınlatma Metni"})]})}),l.jsx("li",{children:l.jsxs("a",{href:"#",className:"footer-link group flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-gray-800/50 transition-all duration-300",children:[l.jsx("span",{className:"footer-link-arrow text-gray-500 group-hover:text-teal-400 group-hover:translate-x-1 transition-all duration-300 text-xs",children:"→"}),l.jsx("span",{className:"footer-link-text text-gray-400 group-hover:text-white transition-colors duration-300 text-sm",children:"Mesafeli Satış Sözleşmesi"})]})}),l.jsx("li",{children:l.jsxs("a",{href:"#",className:"footer-link group flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-gray-800/50 transition-all duration-300",children:[l.jsx("span",{className:"footer-link-arrow text-gray-500 group-hover:text-teal-400 group-hover:translate-x-1 transition-all duration-300 text-xs",children:"→"}),l.jsx("span",{className:"footer-link-text text-gray-400 group-hover:text-white transition-colors duration-300 text-sm",children:"İptal ve İade Koşulları"})]})}),l.jsx("li",{children:l.jsxs("a",{href:"#",className:"footer-link group flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-gray-800/50 transition-all duration-300",children:[l.jsx("span",{className:"footer-link-arrow text-gray-500 group-hover:text-teal-400 group-hover:translate-x-1 transition-all duration-300 text-xs",children:"→"}),l.jsx("span",{className:"footer-link-text text-gray-400 group-hover:text-white transition-colors duration-300 text-sm",children:"Kariyer"})]})})]})]}),l.jsxs("div",{children:[l.jsx("h4",{className:"text-white font-bold mb-6 text-lg",children:"Bize Ulaşın"}),l.jsxs("div",{className:"space-y-4",children:[l.jsxs("div",{className:"contact-item flex items-start gap-3 group",children:[l.jsx("div",{className:"w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center group-hover:bg-blue-600 transition",children:l.jsx("svg",{className:"w-5 h-5 text-gray-400 group-hover:text-white transition",fill:"currentColor",viewBox:"0 0 20 20",children:l.jsx("path",{fillRule:"evenodd",d:"M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z",clipRule:"evenodd"})})}),l.jsxs("div",{children:[l.jsx("p",{className:"text-sm font-medium text-white",children:"Adres"}),l.jsx("p",{className:"text-xs text-gray-400",children:"Teknopark İzmir / Türkiye"})]})]}),l.jsxs("div",{className:"contact-item flex items-start gap-3 group",children:[l.jsx("div",{className:"w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center group-hover:bg-blue-600 transition",children:l.jsxs("svg",{className:"w-5 h-5 text-gray-400 group-hover:text-white transition",fill:"currentColor",viewBox:"0 0 20 20",children:[l.jsx("path",{d:"M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"}),l.jsx("path",{d:"M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z"})]})}),l.jsxs("div",{children:[l.jsx("p",{className:"text-sm font-medium text-white",children:"E-posta"}),l.jsx("a",{href:"mailto:iletisim@egzersizlab.com",className:"text-xs text-teal-400 hover:text-teal-300 transition",children:"iletisim@egzersizlab.com"})]})]}),l.jsxs("div",{className:"contact-item flex items-start gap-3 group",children:[l.jsx("div",{className:"w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center group-hover:bg-green-600 transition",children:l.jsx("svg",{className:"w-5 h-5 text-gray-400 group-hover:text-white transition",fill:"currentColor",viewBox:"0 0 20 20",children:l.jsx("path",{d:"M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z"})})}),l.jsxs("div",{children:[l.jsx("p",{className:"text-sm font-medium text-white",children:"WhatsApp"}),l.jsx("a",{href:"https://wa.me/905551234567",target:"_blank",rel:"noopener noreferrer",className:"text-xs text-teal-400 hover:text-teal-300 transition",children:"+90 555 123 45 67"})]})]}),l.jsxs("div",{className:"contact-item flex items-start gap-3 group",children:[l.jsx("div",{className:"w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center group-hover:bg-blue-600 transition",children:l.jsx("svg",{className:"w-5 h-5 text-gray-400 group-hover:text-white transition",fill:"currentColor",viewBox:"0 0 20 20",children:l.jsx("path",{fillRule:"evenodd",d:"M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z",clipRule:"evenodd"})})}),l.jsxs("div",{children:[l.jsx("p",{className:"text-sm font-medium text-white",children:"Çalışma Saatleri"}),l.jsx("p",{className:"text-xs text-gray-400",children:"Pzt - Cuma: 09:00 - 18:00"})]})]})]})]})]}),l.jsx("div",{className:"border-t border-gray-800 pt-8 mb-8",children:l.jsxs("div",{className:"flex flex-wrap items-center justify-center gap-6",children:[l.jsxs("div",{className:"flex items-center gap-2 px-4 py-2 bg-gray-800/50 rounded-lg border border-gray-700",children:[l.jsx("span",{className:"text-green-400",children:"🔒"}),l.jsx("span",{className:"text-xs text-gray-300",children:"KVKK Uyumlu"})]}),l.jsxs("div",{className:"flex items-center gap-2 px-4 py-2 bg-gray-800/50 rounded-lg border border-gray-700",children:[l.jsx("span",{className:"text-blue-400",children:"🛡️"}),l.jsx("span",{className:"text-xs text-gray-300",children:"SSL Güvenli"})]}),l.jsxs("div",{className:"flex items-center gap-2 px-4 py-2 bg-gray-800/50 rounded-lg border border-gray-700",children:[l.jsx("span",{className:"text-yellow-400",children:"⭐"}),l.jsx("span",{className:"text-xs text-gray-300",children:"4.9/5 Müşteri Puanı"})]})]})}),l.jsxs("div",{className:"border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center text-sm gap-4",children:[l.jsx("div",{className:"flex flex-col md:flex-row items-center gap-2",children:l.jsxs("p",{className:"text-gray-400",children:["© 2024 ",l.jsx("span",{className:"text-white font-semibold",children:"EgzersizLab"}),". Tüm hakları saklıdır."]})}),l.jsxs("div",{className:"flex gap-6 flex-wrap justify-center",children:[l.jsx("a",{href:"#",className:"text-gray-400 hover:text-teal-400 transition",children:"Gizlilik Politikası"}),l.jsx("a",{href:"#",className:"text-gray-400 hover:text-teal-400 transition",children:"Kullanım Şartları"}),l.jsx("a",{href:"#",className:"text-gray-400 hover:text-teal-400 transition",children:"Çerez Politikası"})]})]})]})]}),w&&l.jsx("div",{className:"fixed bottom-6 left-6 z-[60] animate-fade-in",children:l.jsxs("a",{href:"#packages",onClick:b=>{b.preventDefault(),v(!0)},className:"group flex items-center gap-3 px-6 py-4 bg-gradient-to-r from-blue-600 via-blue-500 to-teal-500 text-white font-bold text-lg rounded-full shadow-2xl hover:shadow-blue-500/50 transform hover:scale-110 transition-all duration-300",children:[l.jsx("span",{className:"text-2xl",children:"🚀"}),l.jsx("span",{children:"Hemen Başla"}),l.jsx("span",{className:"group-hover:translate-x-1 transition-transform text-xl",children:"→"}),l.jsx("div",{className:"absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse"})]})}),l.jsx(Oh,{}),r&&l.jsx(Xh,{onClose:()=>v(!1),onOpenLogin:()=>{v(!1),d(!0)}}),E&&l.jsx(px,{onClose:()=>d(!1),onSuccess:()=>d(!1),onOpenRegister:()=>{d(!1),v(!0)}})]})}const Jh="modulepreload",Fh=function(r){return"/"+r},rx={},Ph=function(v,E,d){let w=Promise.resolve();if(E&&E.length>0){let S=function(p){return Promise.all(p.map(U=>Promise.resolve(U).then(N=>({status:"fulfilled",value:N}),N=>({status:"rejected",reason:N}))))};document.getElementsByTagName("link");const B=document.querySelector("meta[property=csp-nonce]"),b=(B==null?void 0:B.nonce)||(B==null?void 0:B.getAttribute("nonce"));w=S(E.map(p=>{if(p=Fh(p),p in rx)return;rx[p]=!0;const U=p.endsWith(".css"),N=U?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${p}"]${N}`))return;const G=document.createElement("link");if(G.rel=U?"stylesheet":Jh,U||(G.as="script"),G.crossOrigin="",G.href=p,b&&G.setAttribute("nonce",b),document.head.appendChild(G),U)return new Promise((L,Z)=>{G.addEventListener("load",L),G.addEventListener("error",()=>Z(new Error(`Unable to preload CSS for ${p}`)))})}))}function A(S){const B=new Event("vite:preloadError",{cancelable:!0});if(B.payload=S,window.dispatchEvent(B),!B.defaultPrevented)throw S}return w.then(S=>{for(const B of S||[])B.status==="rejected"&&A(B.reason);return v().catch(A)})},Wh=[{value:"female",label:"Kadın",icon:"👩"},{value:"male",label:"Erkek",icon:"👨"}],$h=[{value:"desk",label:"Masa Başı / Ofis",icon:"💻"},{value:"active",label:"Ayakta / Hareketli",icon:"🚶"},{value:"physical",label:"Bedensel Güç Gerektiren",icon:"💪"}],eg=[{value:"new",label:"Yeni Başladı",helper:"1 aydan kısa süredir",icon:"🆕"},{value:"moderate",label:"Bir Süredir Var",helper:"1-3 ay arası",icon:"⏳"},{value:"chronic",label:"Kronikleşti",helper:"3 aydan uzun süredir",icon:"⚠️"}],tg=[{value:"ache",label:"Sızlama"},{value:"sharp",label:"Batma"},{value:"burning",label:"Yanma",icon:"🔥"},{value:"numbness",label:"Uyuşma",icon:"⚡"},{value:"stiffness",label:"Tutukluk",icon:"🧱"}],ag=[{key:"surgery",question:"Son 6 ay içinde ilgili bölgede ameliyat oldunuz mu?",icon:"🏥"},{key:"chronic",question:"Tanısı konmuş romatolojik veya nörolojik bir hastalığınız var mı?",icon:"🧬",helper:"Örn: MS, Ankilozan Spondilit vb."},{key:"heart",question:"Egzersize engel kalp/tansiyon probleminiz var mı?",icon:"❤️"},{key:"pregnancy",question:"Hamilelik durumunuz veya şüpheniz var mı?",icon:"🤰"}],ox={"head-front":"Baş","head-back":"Baş (Arka)","neck-front":"Boyun","neck-back":"Boyun (Arka)","shoulder-front-left":"Sol Omuz","shoulder-front-right":"Sağ Omuz","shoulder-back-left":"Sol Omuz","shoulder-back-right":"Sağ Omuz",chest:"Göğüs",abdomen:"Karın","hip-front":"Kalça","hip-back":"Kalça","upper-back":"Üst Sırt","mid-back":"Orta Sırt","lower-back":"Bel","thigh-front-left":"Sol Uyluk","thigh-front-right":"Sağ Uyluk","thigh-back-left":"Sol Uyluk","thigh-back-right":"Sağ Uyluk","knee-front-left":"Sol Diz","knee-front-right":"Sağ Diz","knee-back-left":"Sol Diz","knee-back-right":"Sağ Diz","calf-back-left":"Sol Baldır","calf-back-right":"Sağ Baldır","ankle-front-left":"Sol Ayak Bileği","ankle-front-right":"Sağ Ayak Bileği","elbow-front-left":"Sol Dirsek","elbow-front-right":"Sağ Dirsek","elbow-back-left":"Sol Dirsek","elbow-back-right":"Sağ Dirsek","wrist-front-left":"Sol El Bileği","wrist-front-right":"Sağ El Bileği","wrist-back-left":"Sol El Bileği","wrist-back-right":"Sağ El Bileği"},lg=[{id:"head-front",label:"Baş",cx:100,cy:42,r:16},{id:"neck-front",label:"Boyun",cx:100,cy:82,r:10},{id:"shoulder-front-left",label:"Sol Omuz",cx:58,cy:105,r:12},{id:"shoulder-front-right",label:"Sağ Omuz",cx:142,cy:105,r:12},{id:"chest",label:"Göğüs",cx:100,cy:130,r:18},{id:"abdomen",label:"Karın",cx:100,cy:175,r:18},{id:"hip-front",label:"Kalça",cx:100,cy:220,r:16},{id:"elbow-front-left",label:"Sol Dirsek",cx:38,cy:165,r:10},{id:"elbow-front-right",label:"Sağ Dirsek",cx:162,cy:165,r:10},{id:"wrist-front-left",label:"Sol Bilek",cx:38,cy:200,r:8},{id:"wrist-front-right",label:"Sağ Bilek",cx:162,cy:200,r:8},{id:"thigh-front-left",label:"Sol Uyluk",cx:75,cy:280,r:14},{id:"thigh-front-right",label:"Sağ Uyluk",cx:125,cy:280,r:14},{id:"knee-front-left",label:"Sol Diz",cx:73,cy:320,r:12},{id:"knee-front-right",label:"Sağ Diz",cx:127,cy:320,r:12},{id:"ankle-front-left",label:"Sol Ayak Bileği",cx:72,cy:385,r:9},{id:"ankle-front-right",label:"Sağ Ayak Bileği",cx:128,cy:385,r:9}],ig=[{id:"head-back",label:"Baş (Arka)",cx:100,cy:42,r:16},{id:"neck-back",label:"Boyun (Arka)",cx:100,cy:82,r:10},{id:"shoulder-back-left",label:"Sol Omuz",cx:58,cy:105,r:12},{id:"shoulder-back-right",label:"Sağ Omuz",cx:142,cy:105,r:12},{id:"upper-back",label:"Üst Sırt",cx:100,cy:125,r:16},{id:"mid-back",label:"Orta Sırt",cx:100,cy:155,r:16},{id:"lower-back",label:"Bel",cx:100,cy:185,r:16},{id:"hip-back",label:"Kalça",cx:100,cy:220,r:16},{id:"elbow-back-left",label:"Sol Dirsek",cx:38,cy:165,r:10},{id:"elbow-back-right",label:"Sağ Dirsek",cx:162,cy:165,r:10},{id:"wrist-back-left",label:"Sol Bilek",cx:38,cy:200,r:8},{id:"wrist-back-right",label:"Sağ Bilek",cx:162,cy:200,r:8},{id:"thigh-back-left",label:"Sol Uyluk (Arka)",cx:75,cy:280,r:14},{id:"thigh-back-right",label:"Sağ Uyluk (Arka)",cx:125,cy:280,r:14},{id:"knee-back-left",label:"Sol Diz (Arka)",cx:73,cy:320,r:12},{id:"knee-back-right",label:"Sağ Diz (Arka)",cx:127,cy:320,r:12},{id:"calf-back-left",label:"Sol Baldır",cx:72,cy:355,r:10},{id:"calf-back-right",label:"Sağ Baldır",cx:128,cy:355,r:10}],ng=({open:r,onClose:v,onComplete:E,clinicalTestType:d})=>{const[w,A]=g.useState(1),[S,B]=g.useState(null),[b,p]=g.useState(null),[U,N]=g.useState(null),[G,L]=g.useState(null),[Z,ie]=g.useState(null),[J,H]=g.useState(""),[K,ue]=g.useState(""),[$,Ye]=g.useState([]),[de,Q]=g.useState(null),[Y,ne]=g.useState(5),[re,Oe]=g.useState([]),[ce,at]=g.useState({surgery:void 0,chronic:void 0,heart:void 0,pregnancy:void 0}),[ye,Me]=g.useState({front:null,side:null,back:null}),[_,y]=g.useState("");g.useMemo(()=>w/5*100,[w]);const te=g.useMemo(()=>Y<=2?{emoji:"😀",color:"#10b981"}:Y<=4?{emoji:"🙂",color:"#22c55e"}:Y<=6?{emoji:"😐",color:"#f59e0b"}:Y<=8?{emoji:"😣",color:"#f97316"}:{emoji:"😡",color:"#ef4444"},[Y]),ge=O=>{Ye(ee=>ee.includes(O)?ee.filter(P=>P!==O):[...ee,O])},fe=(O,ee,P)=>l.jsxs("div",{className:"body-diagram-new",children:[l.jsxs("div",{className:"body-diagram-header",children:[l.jsx("span",{className:"body-view-icon",children:P?"👤":"🔙"}),l.jsx("span",{className:"body-view-title",children:ee})]}),l.jsx("div",{className:"body-svg-container",children:l.jsxs("svg",{viewBox:"0 0 200 420",className:"body-svg-new",children:[l.jsxs("defs",{children:[l.jsxs("linearGradient",{id:`bodyGrad${P?"F":"B"}`,x1:"0%",y1:"0%",x2:"0%",y2:"100%",children:[l.jsx("stop",{offset:"0%",stopColor:"#f1f5f9"}),l.jsx("stop",{offset:"100%",stopColor:"#e2e8f0"})]}),l.jsx("filter",{id:"bodyShadow",x:"-20%",y:"-20%",width:"140%",height:"140%",children:l.jsx("feDropShadow",{dx:"0",dy:"2",stdDeviation:"3",floodOpacity:"0.1"})})]}),l.jsxs("g",{filter:"url(#bodyShadow)",children:[l.jsx("ellipse",{cx:"100",cy:"42",rx:"28",ry:"32",fill:`url(#bodyGrad${P?"F":"B"})`,stroke:"#cbd5e1",strokeWidth:"1.5"}),l.jsx("rect",{x:"88",y:"72",width:"24",height:"22",rx:"8",fill:`url(#bodyGrad${P?"F":"B"})`,stroke:"#cbd5e1",strokeWidth:"1.5"}),l.jsx("path",{d:"M52 100 Q60 88 88 92 L112 92 Q140 88 148 100 L152 120 Q100 115 48 120 Z",fill:`url(#bodyGrad${P?"F":"B"})`,stroke:"#cbd5e1",strokeWidth:"1.5"}),l.jsx("path",{d:"M52 118 L56 200 Q100 215 144 200 L148 118 Q100 125 52 118",fill:`url(#bodyGrad${P?"F":"B"})`,stroke:"#cbd5e1",strokeWidth:"1.5"}),l.jsx("ellipse",{cx:"100",cy:"220",rx:"46",ry:"28",fill:`url(#bodyGrad${P?"F":"B"})`,stroke:"#cbd5e1",strokeWidth:"1.5"}),l.jsx("path",{d:"M52 100 Q42 105 38 130 L34 175 Q32 190 38 200 L42 200 Q48 188 46 175 L50 130 Q52 115 52 100",fill:`url(#bodyGrad${P?"F":"B"})`,stroke:"#cbd5e1",strokeWidth:"1.5"}),l.jsx("path",{d:"M148 100 Q158 105 162 130 L166 175 Q168 190 162 200 L158 200 Q152 188 154 175 L150 130 Q148 115 148 100",fill:`url(#bodyGrad${P?"F":"B"})`,stroke:"#cbd5e1",strokeWidth:"1.5"}),l.jsx("path",{d:"M68 240 L62 320 Q58 350 62 380 L72 395 L82 395 L86 380 Q88 350 84 320 L78 240",fill:`url(#bodyGrad${P?"F":"B"})`,stroke:"#cbd5e1",strokeWidth:"1.5"}),l.jsx("path",{d:"M132 240 L138 320 Q142 350 138 380 L128 395 L118 395 L114 380 Q112 350 116 320 L122 240",fill:`url(#bodyGrad${P?"F":"B"})`,stroke:"#cbd5e1",strokeWidth:"1.5"})]}),O.map(ke=>{const Qe=$.includes(ke.id);return l.jsxs("g",{onClick:()=>ge(ke.id),style:{cursor:"pointer"},children:[l.jsx("circle",{cx:ke.cx,cy:ke.cy,r:ke.r+4,className:`pain-area-glow ${Qe?"active":""}`}),l.jsx("circle",{cx:ke.cx,cy:ke.cy,r:ke.r,className:`pain-area ${Qe?"selected":""}`}),Qe&&l.jsx("text",{x:ke.cx,y:ke.cy+4,textAnchor:"middle",className:"pain-check",children:"✓"}),l.jsx("title",{children:ox[ke.id]||ke.label})]},ke.id)})]})})]}),f=O=>{Oe(ee=>ee.includes(O)?ee.filter(P=>P!==O):[...ee,O])},D=()=>{const O=_.trim();O&&(Ye(ee=>[...ee,O]),y(""))},I=(O,ee)=>{if(!ee)return;const P=new FileReader;P.onload=ke=>{Me(Qe=>{var ft;return{...Qe,[O]:((ft=ke.target)==null?void 0:ft.result)||null}})},P.readAsDataURL(ee)},V=O=>{switch(O){case 1:return S&&b&&U&&G&&Z;case 2:return $.length>0;case 3:return de!==null;case 4:return(S==="male"?["surgery","chronic","heart"]:["surgery","chronic","heart","pregnancy"]).every(P=>ce[P]!==void 0);case 5:return!0;default:return!0}},oe=async()=>{if(V(w))if(w<5)A(O=>O+1);else{try{const{apiService:O}=await Ph(async()=>{const{apiService:Qe}=await Promise.resolve().then(()=>Sh);return{apiService:Qe}},void 0),ee={gender:S,age:b,height:U,weight:G,workType:Z,chronicConditions:J,medications:K,selectedAreas:$,painDuration:de,painIntensity:Y,selectedPainTypes:re,safetyAnswers:ce,manualArea:_},P={front:ye.front||null,side:ye.side||null,back:ye.back||null},ke={formData:ee,photos:P,completedAt:new Date().toISOString()};await O.saveDashboardData({assessmentResults:ke,photos:P,formData:ee})}catch(O){console.error("Dashboard verileri kaydedilirken hata:",O)}$&&$.length>0&&localStorage.setItem("userPainAreas",JSON.stringify($)),E&&E(),v()}},me=()=>A(O=>Math.max(1,O-1));return r?l.jsxs("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4","aria-modal":"true",role:"dialog",children:[l.jsxs("div",{className:"assessment-modal bg-white rounded-2xl shadow-2xl w-full max-w-7xl max-h-[98vh] overflow-hidden flex flex-col",children:[l.jsxs("div",{className:"p-8 border-b border-gray-100 sticky top-0 bg-white z-10",children:[l.jsxs("div",{className:"flex items-center justify-between gap-4",children:[l.jsxs("div",{className:"flex items-center gap-4",children:[l.jsx("div",{className:"w-16 h-16 rounded-xl bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center",children:l.jsx("span",{className:"text-white text-3xl",children:"🏥"})}),l.jsxs("div",{children:[l.jsx("h2",{className:"text-4xl font-bold text-gray-900",children:"Vücut Analizi"}),l.jsx("p",{className:"text-gray-500 text-xl mt-1",children:"Kişiselleştirilmiş program için bilgi topluyoruz"})]})]}),l.jsx("button",{onClick:v,className:"w-10 h-10 rounded-full bg-gray-100 hover:bg-red-50 text-gray-400 hover:text-red-500 flex items-center justify-center transition text-2xl","aria-label":"Kapat",children:"×"})]}),l.jsxs("div",{className:"mt-4 flex items-center gap-2",children:[[1,2,3,4,5].map(O=>l.jsx("div",{className:"flex-1 flex items-center gap-1",children:l.jsx("div",{className:`h-2 flex-1 rounded-full transition-all ${O<=w?"bg-emerald-500":"bg-gray-200"}`})},O)),l.jsxs("span",{className:"text-xl font-semibold text-gray-500 ml-2",children:[w,"/5"]})]})]}),l.jsxs("div",{className:"flex-1 overflow-hidden p-8",children:[w===1&&l.jsxs("div",{className:"step1-compact",children:[l.jsxs("div",{className:"section-header-compact",children:[l.jsx("h3",{children:"Fiziksel Profiliniz"}),l.jsx("p",{children:"Kişisel bilgileriniz tedavi planınızı şekillendirir"})]}),l.jsxs("div",{className:"profile-top-row",children:[l.jsx("div",{className:"gender-compact",children:Wh.map(O=>l.jsxs("button",{onClick:()=>B(O.value),className:`gender-btn ${S===O.value?"sel":""}`,children:[l.jsx("span",{children:O.icon}),l.jsx("span",{children:O.label})]},O.value))}),l.jsxs("div",{className:"measures-compact",children:[l.jsxs("div",{className:"meas-item",children:[l.jsx("span",{className:"meas-label",children:"Yaş"}),l.jsx("input",{type:"number",min:18,max:100,placeholder:"—",value:b??"",onChange:O=>p(O.target.value?Number(O.target.value):null)})]}),l.jsxs("div",{className:"meas-item",children:[l.jsx("span",{className:"meas-label",children:"Boy"}),l.jsx("input",{type:"number",min:100,max:250,placeholder:"—",value:U??"",onChange:O=>N(O.target.value?Number(O.target.value):null)}),l.jsx("span",{className:"meas-unit",children:"cm"})]}),l.jsxs("div",{className:"meas-item",children:[l.jsx("span",{className:"meas-label",children:"Kilo"}),l.jsx("input",{type:"number",min:30,max:300,placeholder:"—",value:G??"",onChange:O=>L(O.target.value?Number(O.target.value):null)}),l.jsx("span",{className:"meas-unit",children:"kg"})]})]})]}),l.jsxs("div",{className:"work-compact",children:[l.jsx("label",{className:"field-label-sm",children:"💼 İş Hayatınız"}),l.jsx("div",{className:"work-btns",children:$h.map(O=>l.jsxs("button",{onClick:()=>ie(O.value),className:`work-btn ${Z===O.value?"sel":""}`,children:[l.jsx("span",{children:O.icon}),l.jsx("span",{children:O.label})]},O.value))})]}),l.jsxs("div",{className:"optional-compact",children:[l.jsxs("div",{className:"opt-field",children:[l.jsxs("label",{children:["Kronik rahatsızlıklar ",l.jsx("span",{className:"opt-tag",children:"opsiyonel"})]}),l.jsx("textarea",{rows:1,placeholder:"Varsa belirtin...",value:J,onChange:O=>H(O.target.value)})]}),l.jsxs("div",{className:"opt-field",children:[l.jsxs("label",{children:["Düzenli ilaçlar ",l.jsx("span",{className:"opt-tag",children:"opsiyonel"})]}),l.jsx("textarea",{rows:1,placeholder:"Varsa belirtin...",value:K,onChange:O=>ue(O.target.value)})]})]})]}),w===2&&l.jsxs("div",{className:"step2-compact",children:[l.jsxs("div",{className:"section-header-compact",children:[l.jsx("h3",{children:"Ağrı veya Sorun Nerede?"}),l.jsx("p",{children:"Şekil üzerinde tıklayarak seçin • Birden fazla bölge seçebilirsiniz"})]}),l.jsxs("div",{className:"body-diagrams-compact",children:[fe(lg,"ÖN",!0),fe(ig,"ARKA",!1)]}),l.jsxs("div",{className:"bottom-row-compact",children:[l.jsx("div",{className:"selected-areas-compact",children:$.length===0?l.jsx("span",{className:"empty-hint-sm",children:"👆 Bölge seçin"}):$.map(O=>l.jsxs("span",{className:"area-tag-sm",children:[ox[O]||O.replace(/-/g," "),l.jsx("button",{onClick:()=>ge(O),children:"×"})]},O))}),l.jsxs("div",{className:"manual-add-compact",children:[l.jsx("input",{type:"text",value:_,onChange:O=>y(O.target.value),placeholder:"Başka bölge yazın...",className:"manual-input-sm"}),l.jsx("button",{type:"button",onClick:D,className:"manual-add-btn-sm",children:"+"})]})]})]}),w===3&&l.jsxs("div",{className:"step3-compact",children:[l.jsxs("div",{className:"section-header-compact",children:[l.jsx("h3",{children:"Süre ve Şiddet"}),l.jsx("p",{children:"Ağrınızın ne zamandır devam ettiğini ve şiddetini belirtin"})]}),l.jsxs("div",{className:"step3-grid",children:[l.jsxs("div",{className:"duration-compact",children:[l.jsx("label",{className:"field-label-sm",children:"⏱️ Ne zamandır var?"}),l.jsx("div",{className:"duration-list-compact",children:eg.map(O=>l.jsxs("button",{onClick:()=>Q(O.value),className:`duration-item-compact ${de===O.value?"selected":""}`,children:[l.jsx("span",{className:"dur-icon",children:O.icon}),l.jsxs("div",{className:"dur-text",children:[l.jsx("span",{className:"dur-title",children:O.label}),l.jsx("span",{className:"dur-sub",children:O.helper})]}),de===O.value&&l.jsx("span",{className:"dur-check",children:"✓"})]},O.value))})]}),l.jsxs("div",{className:"intensity-compact",children:[l.jsx("label",{className:"field-label-sm",children:"📊 Ağrı Şiddeti"}),l.jsxs("div",{className:"intensity-box",children:[l.jsxs("div",{className:"intensity-top",children:[l.jsx("span",{className:"int-emoji",style:{color:te.color},children:te.emoji}),l.jsxs("span",{className:"int-val",style:{color:te.color},children:[Y,"/10"]})]}),l.jsxs("div",{className:"int-labels",children:[l.jsx("span",{children:"Hafif"}),l.jsx("span",{children:"Orta"}),l.jsx("span",{children:"Şiddetli"})]}),l.jsx("input",{type:"range",min:1,max:10,value:Y,onChange:O=>ne(Number(O.target.value)),className:"int-slider"}),l.jsx("div",{className:"int-nums",children:[1,2,3,4,5,6,7,8,9,10].map(O=>l.jsx("span",{className:Y>=O?"act":"",children:O},O))})]}),l.jsxs("label",{className:"field-label-sm mt-3",children:["🎯 Ağrı Tipi ",l.jsx("span",{className:"opt-tag",children:"opsiyonel"})]}),l.jsx("div",{className:"pain-types-compact",children:tg.map(O=>l.jsxs("button",{onClick:()=>f(O.value),className:`ptype-btn ${re.includes(O.value)?"sel":""}`,children:[O.icon&&l.jsx("span",{children:O.icon}),l.jsx("span",{children:O.label})]},O.value))})]})]})]}),w===4&&l.jsxs("div",{className:"step4-compact",children:[l.jsxs("div",{className:"section-header-compact",children:[l.jsx("h3",{children:"Güvenlik Kontrolü"}),l.jsx("p",{children:"Sağlığınız için önemli sorular • Dürüstçe cevaplayın 🛡️"})]}),l.jsx("div",{className:"safety-list-compact",children:ag.map((O,ee)=>{if(O.key==="pregnancy"&&S==="male")return null;const P=ce[O.key];return l.jsxs("div",{className:"safety-item-compact",children:[l.jsxs("div",{className:"safety-left",children:[l.jsx("span",{className:"safety-num",children:ee+1}),l.jsx("span",{className:"safety-ico",children:O.icon}),l.jsxs("div",{className:"safety-txt",children:[l.jsx("span",{className:"safety-q",children:O.question}),O.helper&&l.jsx("span",{className:"safety-h",children:O.helper})]})]}),l.jsxs("div",{className:"safety-btns",children:[l.jsx("button",{onClick:()=>at(ke=>({...ke,[O.key]:"no"})),className:`saf-btn no ${P==="no"?"sel":""}`,children:"Hayır"}),l.jsx("button",{onClick:()=>at(ke=>({...ke,[O.key]:"yes"})),className:`saf-btn yes ${P==="yes"?"sel":""}`,children:"Evet"})]})]},O.key)})}),Object.values(ce).includes("yes")&&l.jsxs("div",{className:"safety-warn-compact",children:[l.jsx("span",{children:"⚠️"}),l.jsx("span",{children:"Belirttiğiniz durumlar nedeniyle, egzersiz programına başlamadan önce doktorunuza danışmanızı öneririz."})]})]}),w===5&&l.jsxs("div",{className:"step5-compact",children:[l.jsxs("div",{className:"section-header-compact",children:[l.jsx("h3",{children:"Postür Fotoğrafları"}),l.jsx("p",{children:"En doğru analiz için fotoğraf ekleyin • İsteğe bağlı"})]}),l.jsxs("div",{className:"photo-info-row",children:[l.jsx("span",{className:"info-chip",children:"🔒 KVKK korumalı"}),l.jsx("span",{className:"info-chip",children:"💡 Dar kıyafet, düz arka plan"})]}),l.jsx("div",{className:"photo-grid-compact",children:[{view:"front",title:"Önden",icon:"👤"},{view:"side",title:"Yandan",icon:"↔️"},{view:"back",title:"Arkadan",icon:"🔙"}].map(({view:O,title:ee,icon:P})=>l.jsxs("div",{className:`photo-card-compact ${ye[O]?"has-photo":""}`,onClick:()=>{var ke;return(ke=document.getElementById(`file-${O}`))==null?void 0:ke.click()},children:[ye[O]?l.jsxs("div",{className:"photo-prev-compact",children:[l.jsx("img",{src:ye[O],alt:O}),l.jsx("div",{className:"photo-badge",children:"✓"})]}):l.jsxs("div",{className:"photo-empty-compact",children:[l.jsxs("svg",{viewBox:"0 0 50 100",className:"sil-svg",children:[l.jsx("ellipse",{cx:"25",cy:"12",rx:"10",ry:"11",fill:"#d1d5db"}),l.jsx("rect",{x:"20",y:"22",width:"10",height:"8",rx:"3",fill:"#d1d5db"}),l.jsx("path",{d:"M12 30 Q25 28 38 30 L40 55 Q25 60 10 55 Z",fill:"#d1d5db"}),l.jsx("ellipse",{cx:"25",cy:"65",rx:"14",ry:"10",fill:"#d1d5db"}),l.jsx("rect",{x:"17",y:"74",width:"6",height:"20",rx:"3",fill:"#d1d5db"}),l.jsx("rect",{x:"27",y:"74",width:"6",height:"20",rx:"3",fill:"#d1d5db"})]}),l.jsx("span",{className:"photo-add-icon",children:"📷"})]}),l.jsxs("div",{className:"photo-label",children:[P," ",ee]}),l.jsx("input",{id:`file-${O}`,type:"file",accept:"image/*",className:"hidden",onChange:ke=>{var Qe;return I(O,((Qe=ke.target.files)==null?void 0:Qe[0])||null)}})]},O))}),l.jsx("div",{className:"photo-note-compact",children:"ℹ️ Fotoğraf eklemeden de devam edebilirsiniz"})]})]}),l.jsxs("div",{className:"p-8 bg-gray-50/80 border-t border-gray-100 flex items-center gap-4",children:[l.jsx("button",{onClick:me,disabled:w===1,className:"back-btn",children:"← Geri"}),l.jsx("button",{onClick:oe,className:"next-btn",children:w===5?"✓ Analizi Tamamla":"Devam Et →"})]})]}),l.jsx("style",{children:`
        .assessment-modal {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
        /* Global font size increase for readability */
        .assessment-modal * {
          font-size: inherit;
        }
        .assessment-modal {
          font-size: 18px;
        }
        
        /* Section Header */
        .section-header {
          margin-bottom: 4px;
        }
        .section-header h3 {
          font-size: 24px;
          font-weight: 700;
          color: #1e293b;
          margin: 0;
        }
        .section-header p {
          font-size: 18px;
          color: #64748b;
          margin: 6px 0 0 0;
        }
        
        /* Compact Step 1 */
        .step1-compact {
          display: flex;
          flex-direction: column;
          gap: 14px;
        }
        .profile-top-row {
          display: grid;
          grid-template-columns: auto 1fr;
          gap: 16px;
          align-items: start;
        }
        .gender-compact {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .gender-btn {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 16px 24px;
          border-radius: 12px;
          border: 2px solid #e2e8f0;
          background: #fff;
          font-size: 20px;
          font-weight: 600;
          color: #475569;
          cursor: pointer;
          transition: all 0.2s;
        }
        .gender-btn:hover, .gender-btn.sel {
          border-color: #10b981;
          background: #ecfdf5;
          color: #047857;
        }
        .measures-compact {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 10px;
        }
        .meas-item {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }
        .meas-label {
          font-size: 20px;
          font-weight: 700;
          color: #64748b;
          text-transform: uppercase;
        }
        .meas-item input {
          padding: 20px;
          border: 2px solid #e2e8f0;
          border-radius: 12px;
          font-size: 26px;
          font-weight: 600;
          color: #1e293b;
          background: #f8fafc;
          width: 100%;
        }
        .meas-item input:focus {
          outline: none;
          border-color: #10b981;
          background: #fff;
        }
        .meas-unit {
          font-size: 18px;
          color: #94a3b8;
          margin-top: 4px;
        }
        .work-compact {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .work-btns {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 8px;
        }
        .work-btn {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 10px;
          padding: 20px 16px;
          border-radius: 12px;
          border: 2px solid #e2e8f0;
          background: #fff;
          font-size: 22px;
          font-weight: 600;
          color: #475569;
          cursor: pointer;
          transition: all 0.2s;
        }
        .work-btn:hover, .work-btn.sel {
          border-color: #10b981;
          background: #ecfdf5;
          color: #047857;
        }
        .optional-compact {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 10px;
          padding-top: 10px;
          border-top: 1px dashed #e2e8f0;
        }
        .opt-field {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }
        .opt-field label {
          font-size: 22px;
          font-weight: 500;
          color: #475569;
        }
        .opt-tag {
          font-size: 16px;
          font-weight: 600;
          color: #94a3b8;
          background: #f1f5f9;
          padding: 6px 10px;
          border-radius: 6px;
          margin-left: 6px;
        }
        .opt-field textarea {
          border: 2px solid #e2e8f0;
          border-radius: 12px;
          padding: 18px 20px;
          font-size: 20px;
          color: #334155;
          background: #f8fafc;
          resize: none;
        }
        .opt-field textarea:focus {
          outline: none;
          border-color: #10b981;
          background: #fff;
        }
        
        /* Gender Cards */
        .gender-card {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 14px 18px;
          border-radius: 12px;
          border: 2px solid #e2e8f0;
          background: #fff;
          cursor: pointer;
          transition: all 0.2s;
        }
        .gender-card:hover {
          border-color: #10b981;
          background: #f0fdf4;
        }
        .gender-card.selected {
          border-color: #10b981;
          background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%);
        }
        .gender-icon {
          font-size: 32px;
        }
        .gender-label {
          font-size: 20px;
          font-weight: 600;
          color: #334155;
        }
        .gender-card.selected .gender-label {
          color: #047857;
        }
        
        /* Measurements Grid */
        .measurements-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 12px;
        }
        .measure-field {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }
        .measure-field label {
          font-size: 18px;
          font-weight: 600;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 0.3px;
        }
        .measure-input-wrap {
          display: flex;
          align-items: center;
          background: #f8fafc;
          border: 2px solid #e2e8f0;
          border-radius: 12px;
          overflow: hidden;
          transition: all 0.2s;
        }
        .measure-input-wrap:focus-within {
          border-color: #10b981;
          background: #fff;
        }
        .measure-input-wrap input {
          flex: 1;
          border: none;
          background: transparent;
          padding: 16px;
          font-size: 22px;
          font-weight: 600;
          color: #1e293b;
          width: 100%;
          outline: none;
        }
        .measure-input-wrap input::placeholder {
          color: #cbd5e1;
        }
        .measure-input-wrap .unit {
          padding: 0 16px;
          font-size: 18px;
          color: #94a3b8;
          font-weight: 500;
          background: #f1f5f9;
        }
        
        /* Work Section */
        .work-section {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }
        .field-label {
          font-size: 18px;
          font-weight: 600;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 0.3px;
        }
        .work-options {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 14px;
        }
        .work-card {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 8px;
          padding: 18px 14px;
          border-radius: 14px;
          border: 2px solid #e2e8f0;
          background: #fff;
          cursor: pointer;
          transition: all 0.2s;
        }
        .work-card:hover {
          border-color: #10b981;
          background: #f0fdf4;
        }
        .work-card.selected {
          border-color: #10b981;
          background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%);
        }
        .work-icon {
          font-size: 32px;
        }
        .work-label {
          font-size: 18px;
          font-weight: 600;
          color: #475569;
          text-align: center;
          line-height: 1.4;
        }
        .work-card.selected .work-label {
          color: #047857;
        }
        
        /* Optional Fields */
        .optional-section {
          display: flex;
          flex-direction: column;
          gap: 12px;
          padding-top: 8px;
          border-top: 1px dashed #e2e8f0;
        }
        .optional-field {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }
        .optional-field label {
          font-size: 18px;
          font-weight: 500;
          color: #475569;
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .optional-tag {
          font-size: 14px;
          font-weight: 600;
          color: #94a3b8;
          background: #f1f5f9;
          padding: 4px 8px;
          border-radius: 6px;
          text-transform: uppercase;
        }
        .optional-field textarea {
          border: 2px solid #e2e8f0;
          border-radius: 12px;
          padding: 14px 16px;
          font-size: 18px;
          color: #334155;
          background: #f8fafc;
          resize: none;
          transition: all 0.2s;
        }
        .optional-field textarea:focus {
          outline: none;
          border-color: #10b981;
          background: #fff;
        }
        .optional-field textarea::placeholder {
          color: #94a3b8;
        }
        
        /* Navigation Buttons */
        .back-btn {
          padding: 18px 28px;
          border-radius: 12px;
          border: 2px solid #e2e8f0;
          background: #fff;
          font-size: 20px;
          font-weight: 600;
          color: #64748b;
          cursor: pointer;
          transition: all 0.2s;
        }
        .back-btn:hover:not(:disabled) {
          border-color: #cbd5e1;
          color: #334155;
        }
        .back-btn:disabled {
          opacity: 0.4;
          cursor: not-allowed;
        }
        .next-btn {
          flex: 1;
          padding: 18px 32px;
          border-radius: 12px;
          border: none;
          background: linear-gradient(135deg, #10b981 0%, #059669 100%);
          font-size: 20px;
          font-weight: 700;
          color: #fff;
          cursor: pointer;
          transition: all 0.2s;
          box-shadow: 0 4px 14px rgba(16, 185, 129, 0.3);
        }
        .next-btn:hover {
          transform: translateY(-1px);
          box-shadow: 0 6px 20px rgba(16, 185, 129, 0.4);
        }
        
        /* Legacy styles for other steps */
        .wizard-option-btn {
          display: inline-flex;
          align-items: center;
          gap: 12px;
          padding: 18px 20px;
          border-radius: 12px;
          border: 2px solid #e2e8f0;
          background: #fff;
          font-size: 20px;
          font-weight: 600;
          color: #374151;
          transition: all 0.2s;
          width: 100%;
          justify-content: flex-start;
        }
        .wizard-option-btn.active {
          border-color: #10b981;
          background: #ecfdf5;
          color: #047857;
        }
        .wizard-field {
          display: flex;
          flex-direction: column;
          gap: 8px;
          font-size: 18px;
          color: #4b5563;
        }
        .wizard-field input,
        .wizard-field textarea {
          border: 2px solid #e2e8f0;
          border-radius: 12px;
          padding: 16px 18px;
          font-size: 20px;
          transition: border-color 0.2s;
        }
        .wizard-field input:focus,
        .wizard-field textarea:focus {
          outline: none;
          border-color: #10b981;
        }
        /* Compact Step 2 - Body Selection */
        .step2-compact {
          display: flex;
          flex-direction: column;
          gap: 10px;
          height: 100%;
        }
        .section-header-compact {
          margin-bottom: 0;
        }
        .section-header-compact h3 {
          font-size: 28px;
          font-weight: 700;
          color: #1e293b;
          margin: 0;
        }
        .section-header-compact p {
          font-size: 20px;
          color: #64748b;
          margin: 6px 0 0 0;
        }
        .body-diagrams-compact {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 12px;
          flex: 1;
          min-height: 0;
        }
        .bottom-row-compact {
          display: flex;
          gap: 12px;
          align-items: center;
        }
        .selected-areas-compact {
          flex: 1;
          display: flex;
          flex-wrap: wrap;
          gap: 5px;
          padding: 6px 8px;
          background: #f8fafc;
          border-radius: 8px;
          min-height: 36px;
          max-height: 100px;
          overflow-y: auto;
          overflow-x: hidden;
          align-items: flex-start;
          align-content: flex-start;
        }
        .selected-areas-compact::-webkit-scrollbar {
          width: 8px;
        }
        .selected-areas-compact::-webkit-scrollbar-track {
          background: #f1f5f9;
          border-radius: 4px;
        }
        .selected-areas-compact::-webkit-scrollbar-thumb {
          background: #94a3b8;
          border-radius: 4px;
        }
        .selected-areas-compact::-webkit-scrollbar-thumb:hover {
          background: #64748b;
        }
        .empty-hint-sm {
          font-size: 16px;
          color: #94a3b8;
        }
        .area-tag-sm {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          padding: 4px 8px;
          background: #ecfdf5;
          border: 1px solid #a7f3d0;
          border-radius: 12px;
          font-size: 13px;
          font-weight: 600;
          color: #047857;
          white-space: nowrap;
          flex-shrink: 0;
        }
        .area-tag-sm button {
          background: none;
          border: none;
          color: #059669;
          font-size: 14px;
          cursor: pointer;
          padding: 0;
          line-height: 1;
          margin-left: 2px;
        }
        .manual-add-compact {
          display: flex;
          gap: 6px;
          flex-shrink: 0;
        }
        .manual-input-sm {
          width: 160px;
          padding: 8px 12px;
          border: 2px solid #e2e8f0;
          border-radius: 10px;
          font-size: 14px;
        }
        .manual-input-sm:focus {
          outline: none;
          border-color: #10b981;
        }
        .manual-add-btn-sm {
          width: 40px;
          height: 40px;
          border: none;
          border-radius: 10px;
          background: #10b981;
          color: #fff;
          font-size: 20px;
          font-weight: 700;
          cursor: pointer;
          flex-shrink: 0;
        }
        
        /* Compact Body Diagram */
        .body-diagram-new {
          background: linear-gradient(180deg, #f8fafc 0%, #f1f5f9 100%);
          border: 2px solid #e2e8f0;
          border-radius: 14px;
          overflow: hidden;
          transition: all 0.3s;
          display: flex;
          flex-direction: column;
        }
        .body-diagram-new:hover {
          border-color: #10b981;
        }
        .body-diagram-header {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          padding: 8px;
          background: linear-gradient(135deg, #10b981 0%, #059669 100%);
        }
        .body-view-icon {
          font-size: 20px;
        }
        .body-view-title {
          font-size: 18px;
          font-weight: 700;
          color: #fff;
          letter-spacing: 0.5px;
          text-transform: uppercase;
        }
        .body-svg-container {
          padding: 8px;
          display: flex;
          justify-content: center;
          flex: 1;
          min-height: 0;
        }
        .body-svg-new {
          width: 100%;
          max-width: 160px;
          height: auto;
          max-height: 100%;
        }
        
        /* Legacy grid fallback */
        .body-diagrams-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 16px;
        }
        
        /* Pain area circles */
        .pain-area {
          fill: rgba(16, 185, 129, 0.15);
          stroke: #10b981;
          stroke-width: 2;
          stroke-dasharray: 4 2;
          cursor: pointer;
          transition: all 0.25s ease;
        }
        .pain-area:hover {
          fill: rgba(16, 185, 129, 0.35);
          stroke-width: 2.5;
          stroke-dasharray: none;
        }
        .pain-area.selected {
          fill: #10b981;
          stroke: #047857;
          stroke-width: 3;
          stroke-dasharray: none;
        }
        .pain-area-glow {
          fill: transparent;
          stroke: transparent;
          transition: all 0.25s ease;
        }
        .pain-area-glow.active {
          fill: rgba(16, 185, 129, 0.2);
          stroke: rgba(16, 185, 129, 0.4);
          stroke-width: 2;
          animation: pulseGlow 2s ease-in-out infinite;
        }
        .pain-check {
          fill: #fff;
          font-size: 16px;
          font-weight: 700;
          pointer-events: none;
        }
        
        @keyframes pulseGlow {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.6; transform: scale(1.1); }
        }
        
        /* Legacy body diagram (fallback) */
        .body-diagram {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 8px;
          background: #f8fafc;
          border: 1px solid #e5e7eb;
          border-radius: 16px;
          padding: 16px;
        }
        .body-diagram-title {
          font-size: 20px;
          font-weight: 700;
          letter-spacing: 0.5px;
          color: #6b7280;
          text-transform: uppercase;
        }
        .body-svg {
          width: 100%;
          max-width: 260px;
          height: auto;
        }
        .body-part {
          fill: #e5e7eb;
          stroke: #d1d5db;
          stroke-width: 2px;
          cursor: pointer;
          transition: all 0.2s ease;
        }
        .body-part:hover {
          fill: #a7f3d0;
          stroke: #34d399;
        }
        .body-part.selected {
          fill: #34d399;
          stroke: #059669;
        }
        .pain-slider-ui {
          -webkit-appearance: none;
          width: 100%;
          height: 12px;
          border-radius: 9999px;
          background: linear-gradient(90deg, #10b981 0%, #f59e0b 50%, #ef4444 100%);
          outline: none;
        }
        .pain-slider-ui::-webkit-slider-thumb {
          -webkit-appearance: none;
          width: 24px;
          height: 24px;
          border-radius: 50%;
          background: #fff;
          border: 3px solid #10b981;
          box-shadow: 0 2px 10px rgba(16, 185, 129, 0.4);
          cursor: pointer;
          transition: transform 0.15s;
        }
        .pain-slider-ui::-webkit-slider-thumb:hover {
          transform: scale(1.1);
        }
        .pain-slider-ui::-moz-range-thumb {
          width: 24px;
          height: 24px;
          border-radius: 50%;
          background: #fff;
          border: 3px solid #10b981;
          box-shadow: 0 2px 10px rgba(16, 185, 129, 0.4);
          cursor: pointer;
          transition: transform 0.15s;
        }
        .pain-slider-ui::-moz-range-thumb:hover {
          transform: scale(1.1);
        }
        .safety-card {
          border: 1px solid #e5e7eb;
          background: #f8fafc;
          border-radius: 16px;
          padding: 14px;
        }
        .safety-btn {
          padding: 16px 24px;
          border-radius: 12px;
          border: 2px solid #e5e7eb;
          background: #fff;
          font-size: 20px;
          font-weight: 700;
          color: #374151;
          transition: all 0.2s;
          min-width: 120px;
        }
        .safety-btn.active-yes {
          border-color: #22c55e;
          background: #dcfce7;
          color: #166534;
        }
        .safety-btn.active-no {
          border-color: #10b981;
          background: #ecfdf5;
          color: #047857;
        }
        .alert {
          border-radius: 12px;
          padding: 14px 16px;
          border: 1px solid;
        }
        .alert-warning {
          border-color: #fbbf24;
          background: #fef3c7;
        }
        .alert-info {
          border-color: #93c5fd;
          background: #eff6ff;
        }
        .alert-rules {
          border-color: #e5e7eb;
          background: #f9fafb;
        }
        
        /* Step 2 - Body Selection */
        .selected-areas-wrap {
          min-height: 36px;
          padding: 10px 14px;
          background: #f8fafc;
          border-radius: 10px;
          border: 1px dashed #e2e8f0;
        }
        .empty-hint {
          font-size: 18px;
          color: #94a3b8;
        }
        .selected-areas {
          display: flex;
          flex-wrap: wrap;
          gap: 10px;
        }
        .area-tag {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 10px 14px;
          background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%);
          border: 1px solid #a7f3d0;
          border-radius: 24px;
          font-size: 18px;
          font-weight: 600;
          color: #047857;
        }
        .area-tag button {
          background: none;
          border: none;
          color: #059669;
          font-size: 20px;
          cursor: pointer;
          padding: 0;
          line-height: 1;
          opacity: 0.6;
        }
        .area-tag button:hover {
          opacity: 1;
        }
        .manual-add-row {
          display: flex;
          gap: 10px;
        }
        .manual-input {
          flex: 1;
          padding: 16px 20px;
          border: 2px solid #e2e8f0;
          border-radius: 12px;
          font-size: 20px;
          color: #334155;
          background: #f8fafc;
          transition: all 0.2s;
        }
        .manual-input:focus {
          outline: none;
          border-color: #10b981;
          background: #fff;
        }
        .manual-input::placeholder {
          color: #94a3b8;
        }
        .manual-add-btn {
          padding: 16px 24px;
          border: none;
          border-radius: 12px;
          background: #10b981;
          color: #fff;
          font-size: 20px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
        }
        .manual-add-btn:hover {
          background: #059669;
        }
        
        /* Compact Step 3 */
        .step3-compact {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }
        .step3-grid {
          display: grid;
          grid-template-columns: 1fr 1.2fr;
          gap: 16px;
        }
        .field-label-sm {
          font-size: 20px;
          font-weight: 700;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 0.3px;
          display: block;
          margin-bottom: 8px;
        }
        .mt-3 { margin-top: 12px; }
        .opt-tag {
          font-size: 9px;
          font-weight: 600;
          color: #94a3b8;
          background: #f1f5f9;
          padding: 2px 5px;
          border-radius: 4px;
          text-transform: uppercase;
          margin-left: 4px;
        }
        
        /* Duration Compact */
        .duration-compact {
          display: flex;
          flex-direction: column;
        }
        .duration-list-compact {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .duration-item-compact {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 10px 12px;
          border-radius: 10px;
          border: 2px solid #e2e8f0;
          background: #fff;
          cursor: pointer;
          transition: all 0.2s;
          text-align: left;
        }
        .duration-item-compact:hover {
          border-color: #10b981;
          background: #f0fdf4;
        }
        .duration-item-compact.selected {
          border-color: #10b981;
          background: #ecfdf5;
        }
        .dur-icon {
          font-size: 20px;
          width: 36px;
          height: 36px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: #f1f5f9;
          border-radius: 8px;
        }
        .duration-item-compact.selected .dur-icon {
          background: rgba(16, 185, 129, 0.2);
        }
        .dur-text {
          flex: 1;
          display: flex;
          flex-direction: column;
        }
        .dur-title {
          font-size: 20px;
          font-weight: 700;
          color: #1e293b;
        }
        .dur-sub {
          font-size: 16px;
          color: #64748b;
        }
        .dur-check {
          width: 20px;
          height: 20px;
          border-radius: 50%;
          background: #10b981;
          color: #fff;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 11px;
          font-weight: 700;
        }
        
        /* Intensity Compact */
        .intensity-compact {
          display: flex;
          flex-direction: column;
        }
        .intensity-box {
          background: #f8fafc;
          border: 2px solid #e2e8f0;
          border-radius: 12px;
          padding: 12px;
        }
        .intensity-top {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 10px;
          margin-bottom: 10px;
        }
        .int-emoji {
          font-size: 32px;
          line-height: 1;
        }
        .int-val {
          font-size: 24px;
          font-weight: 800;
        }
        .int-labels {
          display: flex;
          justify-content: space-between;
          font-size: 16px;
          font-weight: 600;
          color: #94a3b8;
          text-transform: uppercase;
          margin-bottom: 4px;
        }
        .int-slider {
          -webkit-appearance: none;
          width: 100%;
          height: 8px;
          border-radius: 8px;
          background: linear-gradient(90deg, #10b981 0%, #f59e0b 50%, #ef4444 100%);
          outline: none;
        }
        .int-slider::-webkit-slider-thumb {
          -webkit-appearance: none;
          width: 22px;
          height: 22px;
          border-radius: 50%;
          background: #fff;
          border: 3px solid #1e293b;
          box-shadow: 0 2px 8px rgba(0,0,0,0.15);
          cursor: pointer;
        }
        .int-nums {
          display: flex;
          justify-content: space-between;
          padding: 0 2px;
          margin-top: 4px;
        }
        .int-nums span {
          font-size: 9px;
          font-weight: 600;
          color: #cbd5e1;
          width: 16px;
          text-align: center;
        }
        .int-nums span.act {
          color: #10b981;
        }
        
        /* Pain Types Compact */
        .pain-types-compact {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 6px;
        }
        .ptype-btn {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 4px;
          padding: 8px;
          border-radius: 8px;
          border: 2px solid #e2e8f0;
          background: #fff;
          font-size: 11px;
          font-weight: 600;
          color: #475569;
          cursor: pointer;
          transition: all 0.2s;
        }
        .ptype-btn:hover {
          border-color: #10b981;
          background: #f0fdf4;
        }
        .ptype-btn.sel {
          border-color: #10b981;
          background: #ecfdf5;
          color: #047857;
        }
        
        /* Legacy Step 3 styles */
        .step3-container {
          display: flex;
          flex-direction: column;
          gap: 20px;
        }
        .duration-section {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }
        .duration-cards {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }
        .duration-card-new {
          display: flex;
          align-items: center;
          gap: 14px;
          padding: 14px 16px;
          border-radius: 14px;
          border: 2px solid #e2e8f0;
          background: #fff;
          cursor: pointer;
          transition: all 0.2s;
          text-align: left;
        }
        .duration-card-new:hover {
          border-color: #10b981;
          background: #f0fdf4;
        }
        .duration-card-new.selected {
          border-color: #10b981;
          background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%);
        }
        .duration-icon {
          font-size: 28px;
          width: 50px;
          height: 50px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: #f1f5f9;
          border-radius: 12px;
        }
        .duration-card-new.selected .duration-icon {
          background: rgba(16, 185, 129, 0.2);
        }
        .duration-content {
          flex: 1;
        }
        .duration-title {
          font-size: 15px;
          font-weight: 700;
          color: #1e293b;
        }
        .duration-helper {
          font-size: 12px;
          color: #64748b;
          margin-top: 2px;
        }
        .duration-check {
          width: 24px;
          height: 24px;
          border-radius: 50%;
          background: #10b981;
          color: #fff;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 14px;
          font-weight: 700;
        }
        
        /* Intensity Section */
        .intensity-section {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }
        .intensity-card {
          background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
          border: 2px solid #e2e8f0;
          border-radius: 16px;
          padding: 20px;
        }
        .intensity-emoji-display {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 12px;
          margin-bottom: 16px;
        }
        .intensity-emoji {
          font-size: 48px;
          line-height: 1;
        }
        .intensity-value {
          font-size: 32px;
          font-weight: 800;
        }
        .intensity-slider-wrap {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .intensity-labels {
          display: flex;
          justify-content: space-between;
          font-size: 11px;
          font-weight: 600;
          color: #94a3b8;
          text-transform: uppercase;
        }
        .intensity-slider {
          -webkit-appearance: none;
          width: 100%;
          height: 10px;
          border-radius: 10px;
          background: linear-gradient(90deg, #10b981 0%, #f59e0b 50%, #ef4444 100%);
          outline: none;
        }
        .intensity-slider::-webkit-slider-thumb {
          -webkit-appearance: none;
          width: 28px;
          height: 28px;
          border-radius: 50%;
          background: #fff;
          border: 4px solid #1e293b;
          box-shadow: 0 4px 12px rgba(0,0,0,0.15);
          cursor: pointer;
        }
        .intensity-scale {
          display: flex;
          justify-content: space-between;
          padding: 0 4px;
        }
        .intensity-scale span {
          font-size: 11px;
          font-weight: 600;
          color: #cbd5e1;
          width: 20px;
          text-align: center;
        }
        .intensity-scale span.active {
          color: #10b981;
        }
        
        /* Pain Type Section */
        .pain-type-section {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }
        .pain-type-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
          gap: 10px;
        }
        .pain-type-btn {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          padding: 16px;
          border-radius: 12px;
          border: 2px solid #e2e8f0;
          background: #fff;
          font-size: 20px;
          font-weight: 600;
          color: #475569;
          cursor: pointer;
          transition: all 0.2s;
        }
        .pain-type-btn:hover {
          border-color: #10b981;
          background: #f0fdf4;
        }
        .pain-type-btn.selected {
          border-color: #10b981;
          background: #ecfdf5;
          color: #047857;
        }
        .pain-type-icon {
          font-size: 16px;
        }
        
        /* Compact Step 4 - Safety */
        .step4-compact {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }
        .safety-list-compact {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .safety-item-compact {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          padding: 12px 14px;
          background: #f8fafc;
          border: 2px solid #e2e8f0;
          border-radius: 12px;
        }
        .safety-left {
          display: flex;
          align-items: center;
          gap: 10px;
          flex: 1;
          min-width: 0;
        }
        .safety-num {
          width: 22px;
          height: 22px;
          border-radius: 50%;
          background: #e2e8f0;
          color: #64748b;
          font-size: 11px;
          font-weight: 700;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }
        .safety-ico {
          font-size: 20px;
          flex-shrink: 0;
        }
        .safety-txt {
          flex: 1;
          min-width: 0;
        }
        .safety-q {
          font-size: 20px;
          font-weight: 600;
          color: #1e293b;
          display: block;
          line-height: 1.4;
        }
        .safety-h {
          font-size: 16px;
          color: #64748b;
          display: block;
          margin-top: 4px;
        }
        .safety-btns {
          display: flex;
          gap: 8px;
          flex-shrink: 0;
        }
        .saf-btn {
          padding: 14px 20px;
          border-radius: 10px;
          border: 2px solid #e2e8f0;
          background: #fff;
          font-size: 18px;
          font-weight: 600;
          color: #64748b;
          cursor: pointer;
          transition: all 0.2s;
        }
        .saf-btn.no:hover, .saf-btn.no.sel {
          border-color: #10b981;
          background: #ecfdf5;
          color: #047857;
        }
        .saf-btn.yes:hover {
          border-color: #f59e0b;
          background: #fffbeb;
        }
        .saf-btn.yes.sel {
          border-color: #f59e0b;
          background: #fef3c7;
          color: #b45309;
        }
        .safety-warn-compact {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 10px 14px;
          background: #fef3c7;
          border: 1px solid #fbbf24;
          border-radius: 10px;
          font-size: 12px;
          color: #92400e;
        }
        
        /* Legacy Step 4 styles */
        .step4-container {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }
        .safety-info-banner {
          display: flex;
          align-items: center;
          gap: 14px;
          padding: 14px 18px;
          background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%);
          border: 1px solid #a7f3d0;
          border-radius: 14px;
        }
        .safety-info-icon {
          font-size: 32px;
        }
        .safety-info-text {
          display: flex;
          flex-direction: column;
          gap: 2px;
        }
        .safety-info-text strong {
          font-size: 20px;
          color: #047857;
        }
        .safety-info-text span {
          font-size: 18px;
          color: #059669;
        }
        .safety-questions-list {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }
        .safety-question-card {
          display: flex;
          align-items: center;
          gap: 14px;
          padding: 16px;
          background: #f8fafc;
          border: 2px solid #e2e8f0;
          border-radius: 14px;
          transition: all 0.2s;
        }
        .safety-question-card:hover {
          border-color: #cbd5e1;
        }
        .safety-question-number {
          width: 40px;
          height: 40px;
          border-radius: 50%;
          background: #e2e8f0;
          color: #64748b;
          font-size: 20px;
          font-weight: 700;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }
        .safety-question-icon {
          font-size: 32px;
          flex-shrink: 0;
        }
        .safety-question-content {
          flex: 1;
          min-width: 0;
        }
        .safety-question-text {
          font-size: 20px;
          font-weight: 600;
          color: #1e293b;
          line-height: 1.5;
        }
        .safety-question-helper {
          font-size: 18px;
          color: #64748b;
          margin-top: 6px;
        }
        .safety-answer-buttons {
          display: flex;
          gap: 8px;
          flex-shrink: 0;
        }
        .safety-answer-btn {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
          padding: 16px 22px;
          border-radius: 12px;
          border: 2px solid #e2e8f0;
          background: #fff;
          font-size: 20px;
          font-weight: 600;
          color: #64748b;
          cursor: pointer;
          transition: all 0.2s;
          min-width: 100px;
        }
        .safety-answer-btn .btn-icon {
          font-size: 24px;
        }
        .safety-answer-btn.no:hover {
          border-color: #10b981;
          background: #f0fdf4;
        }
        .safety-answer-btn.no.selected {
          border-color: #10b981;
          background: #ecfdf5;
          color: #047857;
        }
        .safety-answer-btn.yes:hover {
          border-color: #f59e0b;
          background: #fffbeb;
        }
        .safety-answer-btn.yes.selected {
          border-color: #f59e0b;
          background: #fef3c7;
          color: #b45309;
        }
        .safety-warning-box {
          display: flex;
          align-items: flex-start;
          gap: 14px;
          padding: 16px;
          background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
          border: 1px solid #fbbf24;
          border-radius: 14px;
        }
        .safety-warning-box .warning-icon {
          font-size: 24px;
        }
        .safety-warning-box .warning-content {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }
        .safety-warning-box .warning-content strong {
          font-size: 14px;
          color: #92400e;
        }
        .safety-warning-box .warning-content p {
          font-size: 13px;
          color: #a16207;
          margin: 0;
          line-height: 1.4;
        }
        
        /* Compact Step 5 - Photo Upload */
        .step5-compact {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }
        .photo-info-row {
          display: flex;
          gap: 10px;
          flex-wrap: wrap;
        }
        .info-chip {
          padding: 6px 12px;
          background: #f1f5f9;
          border-radius: 20px;
          font-size: 11px;
          font-weight: 600;
          color: #475569;
        }
        .photo-grid-compact {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 12px;
        }
        .photo-card-compact {
          border: 2px dashed #d1d5db;
          border-radius: 12px;
          background: #f8fafc;
          cursor: pointer;
          transition: all 0.2s;
          overflow: hidden;
        }
        .photo-card-compact:hover {
          border-color: #10b981;
          border-style: solid;
          background: #f0fdf4;
        }
        .photo-card-compact.has-photo {
          border-style: solid;
          border-color: #10b981;
        }
        .photo-empty-compact {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 16px 10px;
          gap: 6px;
          height: 130px;
        }
        .sil-svg {
          width: 50px;
          height: 80px;
        }
        .photo-add-icon {
          font-size: 20px;
        }
        .photo-prev-compact {
          position: relative;
          height: 130px;
        }
        .photo-prev-compact img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
        .photo-badge {
          position: absolute;
          top: 6px;
          right: 6px;
          width: 20px;
          height: 20px;
          border-radius: 50%;
          background: #10b981;
          color: #fff;
          font-size: 10px;
          font-weight: 700;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .photo-label {
          padding: 12px;
          background: #fff;
          text-align: center;
          font-size: 18px;
          font-weight: 600;
          color: #1e293b;
        }
        .photo-note-compact {
          font-size: 20px;
          color: #64748b;
          text-align: center;
          padding: 16px;
          background: #f1f5f9;
          border-radius: 12px;
        }
        .photo-note-compact-old {
          text-align: center;
          font-size: 18px;
          color: #64748b;
          padding: 12px;
          background: #f1f5f9;
          border-radius: 10px;
        }
        
        /* Legacy Step 5 styles */
        .step5-container {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }
        .photo-info-cards {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 12px;
        }
        .photo-info-card {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 12px 14px;
          border-radius: 12px;
        }
        .photo-info-card.privacy {
          background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%);
          border: 1px solid #93c5fd;
        }
        .photo-info-card.tips {
          background: linear-gradient(135deg, #fefce8 0%, #fef08a 100%);
          border: 1px solid #fde047;
        }
        .info-card-icon {
          font-size: 24px;
        }
        .info-card-content {
          display: flex;
          flex-direction: column;
          gap: 2px;
        }
        .info-card-content strong {
          font-size: 18px;
          color: #1e293b;
        }
        .info-card-content span {
          font-size: 16px;
          color: #64748b;
        }
        .photo-upload-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 14px;
        }
        .photo-upload-card {
          border: 2px dashed #d1d5db;
          border-radius: 16px;
          background: #f8fafc;
          cursor: pointer;
          transition: all 0.2s;
          overflow: hidden;
        }
        .photo-upload-card:hover {
          border-color: #10b981;
          border-style: solid;
          background: #f0fdf4;
        }
        .photo-upload-card.has-photo {
          border-style: solid;
          border-color: #10b981;
        }
        .photo-placeholder {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 24px 16px;
          gap: 8px;
        }
        .photo-silhouette {
          width: 60px;
          height: 100px;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .silhouette-svg {
          width: 100%;
          height: 100%;
        }
        .photo-upload-icon {
          font-size: 24px;
        }
        .photo-upload-text {
          font-size: 18px;
          font-weight: 600;
          color: #64748b;
        }
        .photo-preview-wrap {
          position: relative;
          height: 140px;
        }
        .photo-preview-img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
        .photo-preview-overlay {
          position: absolute;
          inset: 0;
          background: rgba(0,0,0,0.5);
          display: flex;
          align-items: center;
          justify-content: center;
          opacity: 0;
          transition: opacity 0.2s;
        }
        .photo-upload-card:hover .photo-preview-overlay {
          opacity: 1;
        }
        .photo-change-btn {
          padding: 8px 14px;
          background: #fff;
          border-radius: 8px;
          font-size: 12px;
          font-weight: 600;
          color: #1e293b;
        }
        .photo-success-badge {
          position: absolute;
          top: 8px;
          right: 8px;
          width: 24px;
          height: 24px;
          border-radius: 50%;
          background: #10b981;
          color: #fff;
          font-size: 12px;
          font-weight: 700;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .photo-card-footer {
          padding: 12px;
          background: #fff;
          text-align: center;
        }
        .photo-card-title {
          font-size: 22px;
          font-weight: 700;
          color: #1e293b;
        }
        .photo-card-hint {
          font-size: 18px;
          color: #64748b;
          margin-top: 4px;
        }
        .photo-skip-note {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          padding: 12px;
          background: #f1f5f9;
          border-radius: 10px;
        }
        .photo-skip-note .skip-icon {
          font-size: 16px;
        }
        .photo-skip-note span {
          font-size: 12px;
          color: #64748b;
        }
        
        /* Legacy Duration Cards */
        .duration-card {
          padding: 16px;
          border-radius: 12px;
          border: 2px solid #e2e8f0;
          background: #fff;
          cursor: pointer;
          transition: all 0.2s;
          text-align: left;
        }
        .duration-card:hover {
          border-color: #10b981;
          background: #f0fdf4;
        }
        .duration-card.selected {
          border-color: #10b981;
          background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%);
        }
        
        @media (max-width: 640px) {
          .measurements-grid {
            grid-template-columns: 1fr;
          }
          .work-options {
            grid-template-columns: 1fr;
          }
          .body-diagrams-grid, .body-diagrams-compact {
            grid-template-columns: 1fr;
          }
          .body-svg-new {
            max-width: 180px;
          }
          .photo-info-cards {
            grid-template-columns: 1fr;
          }
          .photo-upload-grid {
            grid-template-columns: 1fr;
          }
          .safety-question-card {
            flex-wrap: wrap;
          }
          .safety-answer-buttons {
            width: 100%;
            margin-top: 10px;
          }
          .safety-answer-btn {
            flex: 1;
          }
          .step3-grid {
            grid-template-columns: 1fr;
          }
        }
      `})]}):null},sg=[{id:"basic",badge:"Temel",name:"Temel Analiz & Egzersiz Planı",subtitle:"Vücudunuzun neye ihtiyacı olduğunu öğrenin ve hemen başlayın.",price:"599",features:["Detaylı anamnez değerlendirmesi","Fizyoterapist tarafından vaka analizi","4-6 haftalık kişiye özel egzersiz reçetesi","Egzersiz videoları ve açıklamaları"],gradient:"from-white to-slate-50",accent:"text-gray-700"},{id:"medium",badge:"⭐ Önerilen",name:"Klinik Takip & İlerleme Paketi",subtitle:"Sadece bir liste değil, dinamik bir iyileşme süreci.",price:"1.299",features:["Temel paketteki tüm hizmetler","Haftalık kontrol ve değerlendirme","Ağrı ve gelişime göre program revizyonu","Sistem üzerinden soru-cevap hakkı","1 aylık aktif takip"],gradient:"from-emerald-50 to-teal-50",accent:"text-emerald-700"},{id:"premium",badge:"👑 Premium",name:"Premium Danışmanlık & Video Analizi",subtitle:"Fizyoterapistiniz cebinizde; yanlış yapma riskini sıfıra indirin.",price:"2.499",features:["Tüm paketlerdeki hizmetler","Video analizi: egzersizlerinizi kaydedin, geri bildirim alın","Hızlı destek (chat/WhatsApp)","Öncelikli değerlendirme (aynı gün dönüş)","Sınırsız program güncellemesi"],gradient:"from-amber-50 to-orange-50",accent:"text-orange-700"}],rg=[{icon:"🛡️",title:"Detaylı Kas Kuvvet Analizi",subtitle:"Manuel kas testi simülasyonu",desc:"Hangi kaslarınız uykuda, hangileri aşırı çalışıyor? (Gluteal amnezi, core stabilizasyonu vb.)"},{icon:"📏",title:"Kas Kısalık ve Esneklik Testleri",subtitle:"Ağrısının sebebi kas kısalığı mı?",desc:"Hamstring, pektoral, iliopsoas, piriformis gerginlik testleri."},{icon:"📐",title:"Eklem Hareket Açıklığı",subtitle:"Gonyometrik analiz",desc:"Eklemler tam açıyla hareket ediyor mu, kısıtlılık derecesi nedir?"},{icon:"🧠",title:"Nörodinamik Testler",subtitle:"Sinir germe testleri",desc:"Ağrı kas kaynaklı mı yoksa sinir sıkışması mı (Fıtık/Siyatik)?"},{icon:"⚖️",title:"Fonksiyonel Denge ve Propriosepsiyon",subtitle:"Vücudun uzaydaki konum algısı ve denge stratejisi",desc:"Vücudun uzaydaki konum algısı ve denge stratejisi."},{icon:"🩺",title:"Hareket Kalitesi Analizi",subtitle:"Çömelme, eğilme ve uzanma sırasında omurga biyomekaniği kontrolü",desc:"Çömelme, eğilme ve uzanma sırasında omurga biyomekaniği kontrolü."}],og=({open:r,onClose:v,onAddToCart:E,cartItems:d=[]})=>{const[w,A]=g.useState(0),S=U=>d.some(N=>N.id===U),B=U=>{!S(U.id)&&E&&E(U)},b=()=>{w<1&&A(w+1)},p=()=>{w>0&&A(w-1)};return r?l.jsx("div",{className:"fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4",children:l.jsxs("div",{className:"bg-white w-full max-w-[95vw] h-[95vh] rounded-2xl shadow-2xl overflow-hidden relative",children:[l.jsx("button",{onClick:v,className:"absolute top-4 right-4 h-12 w-12 rounded-full bg-white border-2 border-gray-200 shadow-lg flex items-center justify-center text-gray-500 hover:text-gray-700 hover:bg-gray-50 z-30 text-2xl font-bold","aria-label":"Kapat",children:"×"}),l.jsx("div",{className:"carousel-container",children:l.jsxs("div",{className:"carousel-wrapper",style:{transform:`translateX(calc(-${w} * 50%))`},children:[l.jsx("div",{className:"carousel-page",children:l.jsxs("div",{className:"page-content",children:[l.jsxs("div",{className:"success-badge",children:[l.jsx("span",{className:"success-check",children:"✓"}),l.jsx("span",{children:"Ön Profiliniz Sisteme İşlendi"})]}),l.jsxs("div",{className:"status-card",children:[l.jsx("div",{className:"status-icon",children:"📤"}),l.jsx("h3",{className:"status-title",children:"Verileriniz Fizyoterapiste İletildi"}),l.jsx("p",{className:"status-sub",children:"✓ Tüm fotoğraflar ve ağrı haritanız başarıyla gönderildi"}),l.jsxs("div",{className:"ai-banner",children:[l.jsx("span",{className:"ai-icon",children:"🤖"}),l.jsxs("div",{className:"ai-text",children:[l.jsx("strong",{children:"Yapay Zeka Ön Analizi Devam Ediyor"}),l.jsx("span",{children:"Duruş analizi, kas dengesizlik tespiti işleniyor..."})]})]})]}),l.jsxs("div",{className:"cta-card",children:[l.jsx("span",{className:"cta-badge",children:"🎯 SON ADIM"}),l.jsxs("p",{className:"cta-text",children:["Fizyoterapistinizin egzersiz reçetenizi hazırlayabilmesi için ",l.jsx("strong",{children:"size uygun paketi seçin"})]})]}),l.jsxs("div",{className:"progress-card",children:[l.jsxs("div",{className:"progress-header",children:[l.jsx("span",{children:"Süreç İlerlemesi"}),l.jsx("span",{className:"progress-pct",children:"75%"})]}),l.jsx("div",{className:"progress-track",children:l.jsx("div",{className:"progress-fill",style:{width:"75%"}})}),l.jsxs("div",{className:"progress-steps",children:[l.jsx("span",{className:"step done",children:"✓ Bilgiler Gönderildi"}),l.jsx("span",{className:"step current",children:"⏳ Paket Seçimi"})]})]})]})}),l.jsx("div",{className:"carousel-page",children:l.jsxs("div",{className:"page-content-two-columns",children:[l.jsxs("div",{className:"packages-column",children:[l.jsx("h2",{className:"column-title",children:"🎁 Hizmet Paketleri"}),l.jsx("div",{className:"packages-list-vertical",children:sg.map(U=>{const N=S(U.id);return l.jsxs("div",{className:`package-card-vertical ${U.id==="medium"?"recommended":""} ${N?"in-cart":""}`,children:[l.jsxs("div",{className:"package-header",children:[l.jsx("span",{className:`package-badge ${U.id}`,children:U.badge}),l.jsxs("span",{className:"package-price",children:[U.price,l.jsx("small",{children:"₺"})]})]}),l.jsx("h3",{className:"package-name",children:U.name}),l.jsx("ul",{className:"package-features",children:U.features.map((G,L)=>l.jsxs("li",{children:[l.jsx("span",{className:"feat-check",children:"✓"}),G]},L))}),N?l.jsx("button",{className:"cart-btn added",children:"✓ Sepete Eklendi"}):l.jsx("button",{className:`cart-btn ${U.id==="medium"?"green":""}`,onClick:()=>B(U),children:"🛒 Sepete Ekle"})]},U.id)})})]}),l.jsx("div",{className:"center-arrow",children:l.jsx("button",{onClick:p,className:"arrow-button","aria-label":"Önceki sayfa",children:"→"})}),l.jsxs("div",{className:"tests-column",children:[l.jsxs("div",{className:"tests-header",children:[l.jsx("h2",{className:"column-title",children:"🔒 Paket Sonrası Klinik Testler"}),l.jsx("p",{className:"column-subtitle",children:"Bu testler olmadan reçete yazmayız; paket alımından sonra uygulayacağız."})]}),l.jsx("div",{className:"tests-list-vertical",children:rg.map((U,N)=>l.jsxs("div",{className:"test-card-vertical",children:[l.jsxs("div",{className:"test-header",children:[l.jsx("span",{className:"test-icon",children:U.icon}),l.jsx("span",{className:"lock-icon",children:"🔒"})]}),l.jsxs("div",{className:"test-content",children:[l.jsx("h4",{className:"test-title",children:U.title}),U.subtitle&&l.jsx("p",{className:"test-subtitle",children:U.subtitle}),l.jsx("p",{className:"test-desc",children:U.desc})]})]},N))}),l.jsxs("div",{className:"info-box",children:[l.jsx("span",{className:"info-icon",children:"💡"}),l.jsxs("div",{children:[l.jsx("strong",{children:"Neden bu testler?"}),l.jsx("p",{children:"Egzersiz bir ilaçtır; rastgele verilemez. Bu testlerle nokta atışı tedavi protokolü oluşturuyoruz."})]})]})]})]})})]})}),w===0&&l.jsx("button",{onClick:b,className:"nav-btn nav-btn-right","aria-label":"Sonraki",children:"→"}),l.jsx("div",{className:"page-indicators",children:[0,1].map(U=>l.jsx("button",{onClick:()=>A(U),className:`indicator ${w===U?"active":""}`,"aria-label":`Sayfa ${U+1}`},U))}),l.jsx("style",{children:`
          .carousel-container {
            width: 100%;
          height: 100%;
            overflow: hidden;
            position: relative;
          }
          .carousel-wrapper {
          display: flex;
            width: 200%;
            height: 100%;
            transition: transform 0.5s cubic-bezier(0.4, 0, 0.2, 1);
            will-change: transform;
        }
          .carousel-page {
            width: 50%;
            min-width: 50%;
            max-width: 50%;
            height: 100%;
            flex-shrink: 0;
          overflow: hidden;
            position: relative;
          }
          .page-content {
            padding: 40px;
            max-width: 1200px;
            width: 100%;
            margin: 0 auto;
            height: 100%;
          display: flex;
          flex-direction: column;
            gap: 24px;
            box-sizing: border-box;
            overflow-y: auto;
          }
          .page-content-two-columns {
            padding: 30px;
            width: 100%;
          height: 100%;
            display: grid;
            grid-template-columns: 1fr auto 1fr;
            gap: 20px;
            box-sizing: border-box;
            overflow: hidden;
        }
          
          /* Page 1 Styles */
          .success-badge {
          display: inline-flex;
          align-items: center;
            gap: 12px;
          background: linear-gradient(135deg, #10b981, #059669);
          color: #fff;
            padding: 14px 24px;
          border-radius: 50px;
            font-size: 18px;
          font-weight: 700;
          width: fit-content;
            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.4);
        }
        .success-check {
            width: 28px;
            height: 28px;
          background: #fff;
          color: #10b981;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
            font-size: 16px;
          font-weight: 800;
        }
          .status-card {
          background: #fff;
            border: 2px solid #e2e8f0;
            border-radius: 20px;
            padding: 32px;
          text-align: center;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        }
          .status-icon {
            font-size: 64px;
            margin-bottom: 16px;
        }
          .status-title {
            font-size: 28px;
          font-weight: 800;
          color: #1e293b;
            margin: 0 0 12px 0;
        }
          .status-sub {
            font-size: 18px;
          color: #10b981;
          font-weight: 600;
            margin: 0 0 20px 0;
        }
          .ai-banner {
          background: linear-gradient(135deg, #4f46e5, #7c3aed);
            padding: 20px 24px;
            border-radius: 16px;
          display: flex;
          align-items: center;
            gap: 16px;
          text-align: left;
            margin-top: 20px;
        }
          .ai-icon {
            font-size: 40px;
            flex-shrink: 0;
        }
          .ai-text {
          color: #fff;
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
          .ai-text strong {
          display: block;
            font-size: 20px;
            font-weight: 700;
        }
          .ai-text span {
            font-size: 16px;
          opacity: 0.9;
        }
          .cta-card {
          background: linear-gradient(135deg, #fbbf24, #f97316);
            padding: 24px 32px;
            border-radius: 20px;
          text-align: center;
            box-shadow: 0 4px 20px rgba(249, 115, 22, 0.3);
        }
          .cta-badge {
          display: inline-block;
          background: rgba(255,255,255,0.9);
          color: #ea580c;
            padding: 6px 16px;
          border-radius: 20px;
            font-size: 14px;
          font-weight: 800;
            letter-spacing: 0.5px;
            margin-bottom: 12px;
        }
          .cta-text {
            font-size: 20px;
          color: #fff;
          margin: 0;
            line-height: 1.5;
        }
          .cta-text strong {
            display: block;
            font-size: 24px;
            margin-top: 8px;
        }
          .progress-card {
          background: #f8fafc;
            border: 2px solid #e2e8f0;
            border-radius: 16px;
            padding: 24px;
        }
          .progress-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
            font-size: 18px;
          font-weight: 600;
          color: #64748b;
            margin-bottom: 12px;
        }
          .progress-pct {
          background: #10b981;
          color: #fff;
            padding: 6px 16px;
          border-radius: 20px;
            font-size: 16px;
          font-weight: 700;
        }
          .progress-track {
            height: 12px;
          background: #e2e8f0;
            border-radius: 12px;
          overflow: hidden;
            margin-bottom: 16px;
        }
          .progress-fill {
          height: 100%;
          background: linear-gradient(90deg, #10b981, #34d399);
            border-radius: 12px;
            transition: width 0.5s ease;
        }
          .progress-steps {
          display: flex;
          justify-content: center;
            gap: 16px;
        }
          .step {
            font-size: 16px;
          font-weight: 600;
            padding: 10px 20px;
            border-radius: 10px;
          background: #fff;
            border: 2px solid #e2e8f0;
          color: #64748b;
        }
          .step.done {
          background: #ecfdf5;
          border-color: #a7f3d0;
          color: #047857;
        }
          .step.current {
          background: #fef3c7;
          border-color: #fde047;
          color: #a16207;
        }
        
          /* Page 2 Styles - Two Column Layout */
          .packages-column, .tests-column {
          display: flex;
          flex-direction: column;
            height: 100%;
            overflow-y: auto;
            overflow-x: hidden;
          }
          .packages-column {
            padding-right: 10px;
          }
          .tests-column {
            padding-left: 10px;
            position: relative;
          }
          .tests-header {
            margin-bottom: 16px;
            filter: blur(0.5px);
            opacity: 0.9;
          }
          .tests-list-vertical {
            filter: blur(1.5px);
            opacity: 0.85;
          }
          .tests-column .info-box {
            filter: blur(0.5px);
            opacity: 0.9;
        }
          .column-title {
            font-size: 28px;
            font-weight: 800;
          color: #1e293b;
          text-align: center;
            margin: 0 0 16px 0;
        }
          .column-subtitle {
            font-size: 16px;
          color: #64748b;
          text-align: center;
            margin: 0 0 20px 0;
            line-height: 1.5;
        }
          .packages-list-vertical, .tests-list-vertical {
          display: flex;
          flex-direction: column;
            gap: 16px;
          flex: 1;
            overflow-y: auto;
        }
          .package-card-vertical {
            background: #fff;
          border: 2px solid #e2e8f0;
            border-radius: 16px;
            padding: 20px;
          display: flex;
          flex-direction: column;
            transition: all 0.3s;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
          }
          .package-card-vertical:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
          .package-card-vertical.recommended {
          border-color: #10b981;
          background: linear-gradient(135deg, #f0fdf4, #ecfdf5);
            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.15);
        }
          .package-card-vertical.in-cart {
            border-color: #10b981 !important;
            box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.2);
          }
          .package-card-vertical .package-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
            margin-bottom: 12px;
        }
          .package-card-vertical .package-badge {
            font-size: 12px;
          font-weight: 700;
            padding: 4px 10px;
          border-radius: 20px;
          background: #e2e8f0;
          color: #64748b;
        }
          .package-card-vertical .package-badge.medium {
          background: linear-gradient(135deg, #10b981, #059669);
          color: #fff;
        }
          .package-card-vertical .package-badge.premium {
          background: linear-gradient(135deg, #f59e0b, #d97706);
          color: #fff;
        }
          .package-card-vertical .package-price {
            font-size: 24px;
          font-weight: 800;
          color: #1e293b;
        }
          .package-card-vertical .package-price small {
            font-size: 16px;
          color: #64748b;
        }
          .package-card-vertical .package-name {
            font-size: 20px;
          font-weight: 700;
          color: #1e293b;
            margin: 0 0 12px 0;
            line-height: 1.3;
        }
          .package-card-vertical .package-features {
          list-style: none;
          padding: 0;
            margin: 0 0 16px 0;
          flex: 1;
        }
          .package-card-vertical .package-features li {
            font-size: 15px;
          color: #475569;
            padding: 6px 0;
          display: flex;
          align-items: flex-start;
            gap: 8px;
            line-height: 1.4;
        }
          .package-card-vertical .feat-check {
          color: #10b981;
          font-weight: 700;
          flex-shrink: 0;
            font-size: 16px;
        }
          .package-card-vertical .cart-btn {
          width: 100%;
            padding: 14px;
          border: none;
            border-radius: 10px;
          background: linear-gradient(135deg, #3b82f6, #2563eb);
          color: #fff;
            font-size: 16px;
          font-weight: 700;
          cursor: pointer;
          transition: all 0.2s;
            box-shadow: 0 2px 10px rgba(37, 99, 235, 0.3);
        }
          .package-card-vertical .cart-btn:hover {
          transform: translateY(-1px);
            box-shadow: 0 4px 15px rgba(37, 99, 235, 0.4);
        }
          .package-card-vertical .cart-btn.green {
          background: linear-gradient(135deg, #10b981, #059669);
            box-shadow: 0 2px 10px rgba(16, 185, 129, 0.3);
        }
          .package-card-vertical .cart-btn.added {
          background: linear-gradient(135deg, #6b7280, #4b5563);
        }
          .center-arrow {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0 10px;
        }
          .arrow-button {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            border: none;
            background: #10b981;
            color: #fff;
            font-size: 24px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3);
            display: flex;
            align-items: center;
            justify-content: center;
          }
          .arrow-button:hover {
            background: #059669;
            transform: scale(1.1);
            box-shadow: 0 6px 20px rgba(16, 185, 129, 0.4);
          }
          .test-card-vertical {
            background: #fff;
            border: 2px solid #e2e8f0;
            border-radius: 14px;
            padding: 16px;
          display: flex;
            flex-direction: column;
            gap: 12px;
            transition: all 0.2s;
          }
          .test-card-vertical:hover {
            border-color: #10b981;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
          }
          .test-card-vertical .test-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
          .test-card-vertical .test-icon {
            font-size: 32px;
        }
          .test-card-vertical .lock-icon {
            font-size: 20px;
            opacity: 0.5;
          }
          .test-card-vertical .test-title {
            font-size: 18px;
          font-weight: 700;
          color: #1e293b;
            margin: 0 0 6px 0;
            line-height: 1.3;
        }
          .test-card-vertical .test-subtitle {
            font-size: 15px;
          color: #6366f1;
          font-weight: 600;
            margin: 0 0 6px 0;
        }
          .test-card-vertical .test-desc {
            font-size: 14px;
          color: #64748b;
            line-height: 1.4;
            margin: 0;
          }
          .tests-column .info-box {
            margin-top: 16px;
            padding: 16px;
          flex-shrink: 0;
        }
          .tests-column .info-box strong {
            font-size: 16px;
          color: #92400e;
            margin-bottom: 6px;
        }
          .tests-column .info-box p {
            font-size: 14px;
          color: #a16207;
            margin: 0;
            line-height: 1.4;
          }
          .package-card {
            background: #fff;
            border: 2px solid #e2e8f0;
            border-radius: 20px;
            padding: 32px;
          display: flex;
            flex-direction: column;
            transition: all 0.3s;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
          }
          .package-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 30px rgba(0,0,0,0.12);
        }
          .package-card.recommended {
            border-color: #10b981;
            background: linear-gradient(135deg, #f0fdf4, #ecfdf5);
            box-shadow: 0 8px 30px rgba(16, 185, 129, 0.2);
          }
          .package-card.in-cart {
            border-color: #10b981 !important;
            box-shadow: 0 0 0 4px rgba(16, 185, 129, 0.2);
        }
          .package-header {
          display: flex;
            justify-content: space-between;
          align-items: center;
            margin-bottom: 16px;
        }
          .package-badge {
          font-size: 14px;
            font-weight: 700;
            padding: 6px 14px;
            border-radius: 20px;
            background: #e2e8f0;
            color: #64748b;
        }
          .package-badge.medium {
            background: linear-gradient(135deg, #10b981, #059669);
          color: #fff;
        }
          .package-badge.premium {
            background: linear-gradient(135deg, #f59e0b, #d97706);
          color: #fff;
        }
          .package-price {
            font-size: 32px;
          font-weight: 800;
            color: #1e293b;
          }
          .package-price small {
            font-size: 20px;
            color: #64748b;
          }
          .package-name {
            font-size: 24px;
            font-weight: 700;
          color: #1e293b;
            margin: 0 0 20px 0;
            line-height: 1.3;
        }
          .package-features {
            list-style: none;
            padding: 0;
            margin: 0 0 24px 0;
            flex: 1;
          }
          .package-features li {
            font-size: 18px;
            color: #475569;
            padding: 8px 0;
          display: flex;
            align-items: flex-start;
          gap: 10px;
            line-height: 1.5;
        }
          .package-features .more-feat {
            color: #94a3b8;
            font-style: italic;
            padding-left: 24px;
        }
          .feat-check {
            color: #10b981;
          font-weight: 700;
            flex-shrink: 0;
            font-size: 20px;
          }
          .cart-btn {
            width: 100%;
            padding: 18px;
            border: none;
            border-radius: 12px;
            background: linear-gradient(135deg, #3b82f6, #2563eb);
          color: #fff;
            font-size: 18px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
            box-shadow: 0 4px 15px rgba(37, 99, 235, 0.3);
        }
          .cart-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(37, 99, 235, 0.4);
          }
          .cart-btn.green {
            background: linear-gradient(135deg, #10b981, #059669);
            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3);
          }
          .cart-btn.green:hover {
            box-shadow: 0 6px 20px rgba(16, 185, 129, 0.4);
        }
          .cart-btn.added {
            background: linear-gradient(135deg, #6b7280, #4b5563);
        }
          .cart-btn.added:hover {
            background: linear-gradient(135deg, #ef4444, #dc2626);
        }
          
          /* Info Box (used in Page 2) */
          .info-box {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            background: linear-gradient(135deg, #fef3c7, #fde68a);
            border: 2px solid #fbbf24;
          border-radius: 12px;
            padding: 16px;
        }
          .info-icon {
            font-size: 24px;
            flex-shrink: 0;
          }
          
          /* Navigation */
          .nav-btn {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            width: 60px;
            height: 60px;
            border-radius: 50%;
            border: none;
            background: #fff;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
            font-size: 28px;
            color: #10b981;
            cursor: pointer;
            z-index: 20;
            transition: all 0.2s;
          display: flex;
          align-items: center;
            justify-content: center;
        }
          .nav-btn:hover {
          background: #10b981;
          color: #fff;
            transform: translateY(-50%) scale(1.1);
            box-shadow: 0 6px 25px rgba(16, 185, 129, 0.4);
        }
          .nav-btn-left {
            left: 20px;
        }
          .nav-btn-right {
            right: 20px;
          }
          
          /* Page Indicators */
          .page-indicators {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
          display: flex;
          gap: 12px;
            z-index: 20;
        }
          .indicator {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            border: 2px solid #10b981;
            background: transparent;
            cursor: pointer;
          transition: all 0.2s;
            padding: 0;
        }
          .indicator.active {
            background: #10b981;
            width: 32px;
            border-radius: 6px;
        }
          
          @media (max-width: 1400px) {
            .page-content-two-columns {
              grid-template-columns: 1fr auto 1fr;
              gap: 15px;
              padding: 20px;
        }
            .column-title {
              font-size: 24px;
        }
            .package-card-vertical .package-name {
              font-size: 18px;
        }
            .package-card-vertical .package-features li {
              font-size: 14px;
        }
            .test-card-vertical .test-title {
              font-size: 16px;
            }
            .test-card-vertical .test-desc {
              font-size: 13px;
        }
          }
          @media (max-width: 1024px) {
            .page-content-two-columns {
              grid-template-columns: 1fr;
              gap: 20px;
        }
            .center-arrow {
              display: none;
            }
            .page-content {
              padding: 24px;
            }
        }
      `})]})}):null},en={technical:{label:"Teknik",icon:"🔧"},payment:{label:"Ödeme",icon:"💳"},exercise:{label:"Egzersiz",icon:"🏋️"},other:{label:"Diğer",icon:"📝"}},cg=[{id:"TKT-001",subject:"Video oynatma sorunu",category:"technical",priority:"medium",message:"Egzersiz videolarını oynatamıyorum.",status:"pending",createdAt:new Date("2024-12-01")},{id:"TKT-002",subject:"Paket yenileme",category:"payment",priority:"low",message:"Paketimi nasıl yenileyebilirim?",status:"resolved",createdAt:new Date("2024-11-28")}],dg=({open:r,onClose:v})=>{const[E,d]=g.useState("new"),[w,A]=g.useState(""),[S,B]=g.useState("technical"),[b,p]=g.useState(""),[U,N]=g.useState(!1),[G,L]=g.useState(!1),[Z]=g.useState(cg);if(!r)return null;const ie=H=>{H.preventDefault(),N(!0),setTimeout(()=>{N(!1),L(!0),A(""),p(""),setTimeout(()=>{L(!1),d("history")},1500)},1e3)},J=H=>{const ue={open:{bg:"#dbeafe",text:"#1d4ed8",label:"Açık"},pending:{bg:"#fef3c7",text:"#b45309",label:"İnceleniyor"},resolved:{bg:"#d1fae5",text:"#047857",label:"Çözüldü"}}[H];return l.jsx("span",{style:{background:ue.bg,color:ue.text,padding:"3px 10px",borderRadius:"12px",fontSize:"11px",fontWeight:600},children:ue.label})};return l.jsxs("div",{className:"support-modal-overlay",children:[l.jsx("style",{children:`
        .support-modal-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.5);
          backdrop-filter: blur(6px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
          padding: 16px;
          animation: fadeIn 0.2s ease;
        }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        
        .support-modal {
          background: #fff;
          border-radius: 20px;
          width: 100%;
          max-width: 580px;
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
          animation: slideUp 0.3s ease;
        }
        
        .modal-header {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          padding: 20px 24px;
          color: white;
          position: relative;
          border-radius: 20px 20px 0 0;
        }
        .modal-header h2 {
          font-size: 20px;
          font-weight: 700;
          margin: 0;
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .close-btn {
          position: absolute;
          top: 14px;
          right: 14px;
          width: 32px;
          height: 32px;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.2);
          border: none;
          color: white;
          font-size: 20px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
        }
        .close-btn:hover { background: rgba(255, 255, 255, 0.3); transform: rotate(90deg); }
        
        .tab-bar {
          display: flex;
          background: #f8fafc;
          border-bottom: 1px solid #e2e8f0;
        }
        .tab-btn {
          flex: 1;
          padding: 12px;
          border: none;
          background: transparent;
          font-size: 13px;
          font-weight: 600;
          color: #64748b;
          cursor: pointer;
          transition: all 0.2s;
          position: relative;
        }
        .tab-btn:hover { color: #667eea; }
        .tab-btn.active { color: #667eea; background: white; }
        .tab-btn.active::after {
          content: '';
          position: absolute;
          bottom: -1px;
          left: 0;
          right: 0;
          height: 2px;
          background: #667eea;
        }
        
        .modal-content { padding: 20px 24px; }
        
        .form-row { display: flex; gap: 16px; margin-bottom: 16px; }
        .form-group { flex: 1; }
        .form-group.full { flex: none; width: 100%; margin-bottom: 16px; }
        
        .form-label {
          display: block;
          font-size: 12px;
          font-weight: 600;
          color: #475569;
          margin-bottom: 6px;
        }
        .form-label span { color: #ef4444; }
        
        .form-input {
          width: 100%;
          padding: 10px 14px;
          border: 2px solid #e2e8f0;
          border-radius: 10px;
          font-size: 14px;
          transition: all 0.2s;
          outline: none;
        }
        .form-input:focus { border-color: #667eea; }
        .form-input::placeholder { color: #94a3b8; }
        textarea.form-input { min-height: 80px; resize: none; font-family: inherit; }
        
        .category-options { display: flex; gap: 10px; }
        .category-chip {
          flex: 1;
          padding: 12px 8px;
          border: 2px solid #e2e8f0;
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s;
          background: #fff;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
        }
        .category-chip:hover { border-color: #c7d2fe; background: #f8fafc; }
        .category-chip.selected { border-color: #667eea; background: #eef2ff; }
        .cat-icon { font-size: 20px; }
        .cat-label { font-size: 11px; font-weight: 600; color: #64748b; }
        .category-chip.selected .cat-label { color: #667eea; }
        
        .submit-btn {
          width: 100%;
          padding: 14px;
          border: none;
          border-radius: 12px;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          font-size: 15px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          margin-top: 8px;
        }
        .submit-btn:hover:not(:disabled) { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4); }
        .submit-btn:disabled { opacity: 0.6; cursor: not-allowed; }
        
        .spinner {
          width: 18px;
          height: 18px;
          border: 2px solid rgba(255, 255, 255, 0.3);
          border-top-color: white;
          border-radius: 50%;
          animation: spin 0.8s linear infinite;
        }
        @keyframes spin { to { transform: rotate(360deg); } }
        
        .success-box {
          background: linear-gradient(135deg, #10b981, #059669);
          color: white;
          padding: 24px;
          border-radius: 12px;
          text-align: center;
        }
        .success-box h3 { margin: 0; font-size: 18px; }
        
        .ticket-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 14px;
          border: 1px solid #e2e8f0;
          border-radius: 12px;
          margin-bottom: 10px;
          transition: all 0.2s;
        }
        .ticket-item:hover { border-color: #c7d2fe; background: #fafafa; }
        .ticket-info h4 { margin: 0 0 4px 0; font-size: 14px; color: #1e293b; }
        .ticket-info p { margin: 0; font-size: 12px; color: #64748b; display: flex; align-items: center; gap: 8px; }
        
        .empty-box { text-align: center; padding: 32px; color: #94a3b8; }
        .empty-box span { font-size: 40px; display: block; margin-bottom: 8px; }
      `}),l.jsxs("div",{className:"support-modal",children:[l.jsxs("div",{className:"modal-header",children:[l.jsx("button",{className:"close-btn",onClick:v,children:"×"}),l.jsx("h2",{children:"🎟️ Destek Talebi"})]}),l.jsxs("div",{className:"tab-bar",children:[l.jsx("button",{className:`tab-btn ${E==="new"?"active":""}`,onClick:()=>d("new"),children:"✨ Yeni Talep"}),l.jsxs("button",{className:`tab-btn ${E==="history"?"active":""}`,onClick:()=>d("history"),children:["📋 Taleplerim (",Z.length,")"]})]}),l.jsx("div",{className:"modal-content",children:E==="new"?G?l.jsx("div",{className:"success-box",children:l.jsx("h3",{children:"✅ Talebiniz Alındı!"})}):l.jsxs("form",{onSubmit:ie,children:[l.jsxs("div",{className:"form-group full",children:[l.jsxs("label",{className:"form-label",children:["Konu ",l.jsx("span",{children:"*"})]}),l.jsx("input",{type:"text",className:"form-input",placeholder:"Sorununuzu kısaca özetleyin...",value:w,onChange:H=>A(H.target.value),required:!0})]}),l.jsxs("div",{className:"form-group full",children:[l.jsx("label",{className:"form-label",children:"Kategori"}),l.jsx("div",{className:"category-options",children:Object.keys(en).map(H=>l.jsxs("div",{className:`category-chip ${S===H?"selected":""}`,onClick:()=>B(H),children:[l.jsx("span",{className:"cat-icon",children:en[H].icon}),l.jsx("span",{className:"cat-label",children:en[H].label})]},H))})]}),l.jsxs("div",{className:"form-group full",children:[l.jsxs("label",{className:"form-label",children:["Mesaj ",l.jsx("span",{children:"*"})]}),l.jsx("textarea",{className:"form-input",placeholder:"Detaylı açıklayın...",value:b,onChange:H=>p(H.target.value),required:!0})]}),l.jsx("button",{type:"submit",className:"submit-btn",disabled:U||!w||!b,children:U?l.jsxs(l.Fragment,{children:[l.jsx("div",{className:"spinner"})," Gönderiliyor..."]}):l.jsx(l.Fragment,{children:"📤 Gönder"})})]}):l.jsx("div",{children:Z.length===0?l.jsxs("div",{className:"empty-box",children:[l.jsx("span",{children:"📭"}),l.jsx("p",{children:"Henüz talebiniz yok"})]}):Z.map(H=>l.jsxs("div",{className:"ticket-item",children:[l.jsxs("div",{className:"ticket-info",children:[l.jsx("h4",{children:H.subject}),l.jsxs("p",{children:[en[H.category].icon," ",en[H.category].label,l.jsx("span",{children:"•"}),H.createdAt.toLocaleDateString("tr-TR")]})]}),J(H.status)]},H.id))})})]})]})},cx={general:{label:"Genel",icon:"📌"},exercise:{label:"Egzersiz",icon:"🏋️"},payment:{label:"Ödeme",icon:"💳"},account:{label:"Hesap",icon:"👤"}},ug=[{id:"1",question:"EgzersizLab nasıl çalışır?",answer:"EgzersizLab, size özel egzersiz programları oluşturan dijital bir sağlık platformudur. Önce kısa bir değerlendirme yapılır, ardından uzman fizyoterapistlerimiz size özel bir program hazırlar.",category:"general"},{id:"2",question:"Egzersiz programım ne kadar sürede hazırlanır?",answer:"Değerlendirmenizi tamamladıktan sonra egzersiz programınız 24-48 saat içinde hazırlanır ve size bildirim gönderilir.",category:"exercise"},{id:"3",question:"Egzersizleri günde kaç kez yapmalıyım?",answer:"Bu, programınıza ve durumunuza göre değişir. Genellikle günde 1-2 seans önerilir. Detaylar programınızda belirtilecektir.",category:"exercise"},{id:"4",question:"Ödeme yöntemleri nelerdir?",answer:"Kredi kartı, banka kartı ve havale/EFT ile ödeme yapabilirsiniz. Tüm ödemeler 256-bit SSL ile güvence altındadır.",category:"payment"},{id:"5",question:"İptal ve iade politikası nedir?",answer:"Satın alma tarihinden itibaren 14 gün içinde, program başlamadıysa tam iade yapılır. Detaylar için destek ekibimize ulaşabilirsiniz.",category:"payment"},{id:"6",question:"Şifremi nasıl değiştirebilirim?",answer:'Profil menüsünden "Şifre Değiştir" seçeneğine tıklayarak şifrenizi güncelleyebilirsiniz.',category:"account"},{id:"7",question:"Fizyoterapistle nasıl iletişime geçebilirim?",answer:'Premium paket kullanıcıları "Fizyoterapiste Sor" özelliğini kullanabilir. Diğer kullanıcılar destek talebi oluşturabilir.',category:"general"},{id:"8",question:"Egzersiz videolarını indirebilir miyim?",answer:"Şu an için videolar yalnızca çevrimiçi izlenebilmektedir. Offline erişim özelliği yakında eklenecektir.",category:"exercise"}],fg=({open:r,onClose:v,onOpenSupport:E})=>{const[d,w]=g.useState(""),[A,S]=g.useState(null),[B,b]=g.useState(null);if(!r)return null;const p=ug.filter(N=>{const G=N.question.toLowerCase().includes(d.toLowerCase())||N.answer.toLowerCase().includes(d.toLowerCase()),L=!A||N.category===A;return G&&L}),U=N=>{b(B===N?null:N)};return l.jsxs("div",{className:"faq-overlay",children:[l.jsx("style",{children:`
        .faq-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.5);
          backdrop-filter: blur(6px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
          padding: 16px;
          animation: fadeIn 0.2s ease;
        }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        
        .faq-modal {
          background: #fff;
          border-radius: 20px;
          width: 100%;
          max-width: 600px;
          max-height: 85vh;
          display: flex;
          flex-direction: column;
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
          animation: slideUp 0.3s ease;
        }
        
        .faq-header {
          background: linear-gradient(135deg, #10b981 0%, #059669 100%);
          padding: 20px 24px;
          color: white;
          position: relative;
          border-radius: 20px 20px 0 0;
        }
        .faq-header h2 {
          font-size: 20px;
          font-weight: 700;
          margin: 0 0 4px 0;
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .faq-header p {
          margin: 0;
          font-size: 13px;
          opacity: 0.9;
        }
        .close-btn {
          position: absolute;
          top: 14px;
          right: 14px;
          width: 32px;
          height: 32px;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.2);
          border: none;
          color: white;
          font-size: 20px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
        }
        .close-btn:hover { background: rgba(255, 255, 255, 0.3); transform: rotate(90deg); }
        
        .search-box {
          padding: 16px 20px;
          background: #f8fafc;
          border-bottom: 1px solid #e2e8f0;
        }
        .search-input {
          width: 100%;
          padding: 12px 16px 12px 40px;
          border: 2px solid #e2e8f0;
          border-radius: 10px;
          font-size: 14px;
          outline: none;
          transition: all 0.2s;
          background: white url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%2394a3b8'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z'%3E%3C/path%3E%3C/svg%3E") 12px center no-repeat;
          background-size: 18px;
        }
        .search-input:focus { border-color: #10b981; }
        .search-input::placeholder { color: #94a3b8; }
        
        .category-tabs {
          display: flex;
          gap: 6px;
          padding: 12px 20px;
          background: #fff;
          border-bottom: 1px solid #e2e8f0;
          overflow-x: auto;
        }
        .cat-tab {
          padding: 8px 14px;
          border: none;
          border-radius: 20px;
          background: #f1f5f9;
          font-size: 13px;
          font-weight: 500;
          color: #64748b;
          cursor: pointer;
          transition: all 0.2s;
          white-space: nowrap;
          display: flex;
          align-items: center;
          gap: 6px;
        }
        .cat-tab:hover { background: #e2e8f0; }
        .cat-tab.active { background: #10b981; color: white; }
        
        .faq-content {
          flex: 1;
          overflow-y: auto;
          padding: 16px 20px;
        }
        
        .faq-item {
          border: 1px solid #e2e8f0;
          border-radius: 12px;
          margin-bottom: 10px;
          overflow: hidden;
          transition: all 0.2s;
        }
        .faq-item:hover { border-color: #c7d2fe; }
        .faq-item.expanded { border-color: #10b981; }
        
        .faq-question {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 14px 16px;
          background: #fff;
          cursor: pointer;
          gap: 12px;
        }
        .faq-question:hover { background: #f8fafc; }
        .faq-item.expanded .faq-question { background: #f0fdf4; }
        
        .q-text {
          font-size: 14px;
          font-weight: 600;
          color: #1e293b;
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .q-icon {
          width: 24px;
          height: 24px;
          border-radius: 6px;
          background: #f1f5f9;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 12px;
          flex-shrink: 0;
        }
        .faq-item.expanded .q-icon { background: #10b981; color: white; }
        
        .expand-icon {
          width: 24px;
          height: 24px;
          border-radius: 50%;
          background: #f1f5f9;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.3s;
          flex-shrink: 0;
          font-size: 14px;
          color: #64748b;
        }
        .faq-item.expanded .expand-icon { transform: rotate(180deg); background: #10b981; color: white; }
        
        .faq-answer {
          max-height: 0;
          overflow: hidden;
          transition: max-height 0.3s ease;
        }
        .faq-item.expanded .faq-answer { max-height: 200px; }
        
        .answer-content {
          padding: 0 16px 16px 50px;
          font-size: 13px;
          line-height: 1.6;
          color: #475569;
        }
        
        .no-results {
          text-align: center;
          padding: 40px 20px;
          color: #94a3b8;
        }
        .no-results span { font-size: 40px; display: block; margin-bottom: 12px; }
        .no-results p { margin: 0; font-size: 14px; }
        
        .help-footer {
          padding: 16px 20px;
          background: #f8fafc;
          border-top: 1px solid #e2e8f0;
          border-radius: 0 0 20px 20px;
          text-align: center;
        }
        .help-footer p {
          margin: 0 0 10px 0;
          font-size: 13px;
          color: #64748b;
        }
        .contact-btn {
          padding: 10px 20px;
          border: none;
          border-radius: 8px;
          background: linear-gradient(135deg, #667eea, #764ba2);
          color: white;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
        }
        .contact-btn:hover { transform: translateY(-1px); box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3); }
      `}),l.jsxs("div",{className:"faq-modal",children:[l.jsxs("div",{className:"faq-header",children:[l.jsx("button",{className:"close-btn",onClick:v,children:"×"}),l.jsx("h2",{children:"❓ Yardım / SSS"}),l.jsx("p",{children:"Sık sorulan sorular ve cevapları"})]}),l.jsx("div",{className:"search-box",children:l.jsx("input",{type:"text",className:"search-input",placeholder:"Soru ara...",value:d,onChange:N=>w(N.target.value)})}),l.jsxs("div",{className:"category-tabs",children:[l.jsx("button",{className:`cat-tab ${A?"":"active"}`,onClick:()=>S(null),children:"📋 Tümü"}),Object.entries(cx).map(([N,{label:G,icon:L}])=>l.jsxs("button",{className:`cat-tab ${A===N?"active":""}`,onClick:()=>S(N),children:[L," ",G]},N))]}),l.jsx("div",{className:"faq-content",children:p.length===0?l.jsxs("div",{className:"no-results",children:[l.jsx("span",{children:"🔍"}),l.jsx("p",{children:"Sonuç bulunamadı"})]}):p.map(N=>l.jsxs("div",{className:`faq-item ${B===N.id?"expanded":""}`,children:[l.jsxs("div",{className:"faq-question",onClick:()=>U(N.id),children:[l.jsxs("span",{className:"q-text",children:[l.jsx("span",{className:"q-icon",children:cx[N.category].icon}),N.question]}),l.jsx("span",{className:"expand-icon",children:"▼"})]}),l.jsx("div",{className:"faq-answer",children:l.jsx("div",{className:"answer-content",children:N.answer})})]},N.id))}),l.jsxs("div",{className:"help-footer",children:[l.jsx("p",{children:"Aradığınızı bulamadınız mı?"}),l.jsx("button",{className:"contact-btn",onClick:()=>{v(),E()},children:"🎟️ Destek Talebi Oluştur"})]})]})]})},dx=[{id:"basic",name:"Temel Analiz & Egzersiz Planı",price:599,duration:"Tek Seferlik",description:"Vücudunuzun neye ihtiyacı olduğunu öğrenin ve hemen başlayın.",features:["Detaylı anamnez değerlendirmesi","Fizyoterapist tarafından vaka analizi","4-6 haftalık kişiye özel egzersiz reçetesi","Egzersiz videoları ve açıklamaları"],notIncluded:["Takip ve revizyon hizmeti içermez"]},{id:"pro",name:"Klinik Takip & İlerleme Paketi",price:1299,duration:"1 Aylık",description:"Sadece bir liste değil, dinamik bir iyileşme süreci.",features:["Temel paketteki tüm hizmetler","Haftalık kontrol ve değerlendirme","Ağrı ve gelişime göre program revizyonu","Sistem üzerinden soru-cevap hakkı","1 aylık aktif takip"],popular:!0},{id:"premium",name:"Premium Danışmanlık & Video Analizi",price:2499,duration:"Aylık",description:"Fizyoterapistiniz cebinizde - yanlış yapma riskini sıfıra indirin.",features:["Tüm paketlerdeki hizmetler","Video analizi: Egzersizlerinizi kaydedin, geri bildirim alın","Hızlı destek (chat/WhatsApp)","Öncelikli değerlendirme (aynı gün dönüş)","Sınırsız program güncellemesi"]}],ux=[{id:"1",date:new Date("2024-12-01"),amount:699,description:"Profesyonel Paket - 3 Ay",status:"success"},{id:"2",date:new Date("2024-09-01"),amount:299,description:"Başlangıç Paket - 1 Ay",status:"success"}],mg=({open:r,onClose:v,onPurchase:E,onCancelPackage:d,hasPackage:w,onAddToCart:A,cartItems:S=[]})=>{const[B,b]=g.useState(w?"current":"packages"),[p,U]=g.useState(!1),[N,G]=g.useState(!1),L=H=>S.some(K=>K.id===H),Z=H=>{!L(H.id)&&A&&A({id:H.id,name:H.name,price:H.price.toLocaleString()})};if(!r)return null;const ie=dx[1],J=45;return l.jsxs("div",{className:"pkg-overlay",children:[l.jsx("style",{children:`
        .pkg-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.5);
          backdrop-filter: blur(6px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
          padding: 16px;
          animation: fadeIn 0.2s ease;
        }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        
        .pkg-modal {
          background: #fff;
          border-radius: 20px;
          width: 100%;
          max-width: 900px;
          max-height: 85vh;
          display: flex;
          flex-direction: column;
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
          animation: slideUp 0.3s ease;
        }
        
        .pkg-header {
          background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
          padding: 20px 24px;
          color: white;
          position: relative;
          border-radius: 20px 20px 0 0;
        }
        .pkg-header h2 {
          font-size: 20px;
          font-weight: 700;
          margin: 0;
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .close-btn {
          position: absolute;
          top: 14px;
          right: 14px;
          width: 32px;
          height: 32px;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.2);
          border: none;
          color: white;
          font-size: 20px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
        }
        .close-btn:hover { background: rgba(255, 255, 255, 0.3); transform: rotate(90deg); }
        
        .tab-bar {
          display: flex;
          background: #f8fafc;
          border-bottom: 1px solid #e2e8f0;
        }
        .tab-btn {
          flex: 1;
          padding: 12px;
          border: none;
          background: transparent;
          font-size: 13px;
          font-weight: 600;
          color: #64748b;
          cursor: pointer;
          transition: all 0.2s;
          position: relative;
        }
        .tab-btn:hover { color: #f59e0b; }
        .tab-btn.active { color: #f59e0b; background: white; }
        .tab-btn.active::after {
          content: '';
          position: absolute;
          bottom: -1px;
          left: 0;
          right: 0;
          height: 2px;
          background: #f59e0b;
        }
        
        .pkg-content {
          flex: 1;
          overflow-y: auto;
          padding: 20px;
        }
        
        /* Current Package */
        .current-pkg {
          background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
          border-radius: 16px;
          padding: 20px;
          border: 2px solid #f59e0b;
        }
        .current-badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          background: #f59e0b;
          color: white;
          padding: 4px 12px;
          border-radius: 20px;
          font-size: 11px;
          font-weight: 700;
          margin-bottom: 12px;
        }
        .current-name {
          font-size: 24px;
          font-weight: 700;
          color: #92400e;
          margin: 0 0 8px 0;
        }
        .current-info {
          display: flex;
          gap: 20px;
          margin-bottom: 16px;
        }
        .info-item {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 13px;
          color: #92400e;
        }
        .days-bar {
          background: rgba(255,255,255,0.6);
          border-radius: 8px;
          height: 8px;
          overflow: hidden;
        }
        .days-fill {
          height: 100%;
          background: #f59e0b;
          border-radius: 8px;
          transition: width 0.3s;
        }
        .days-text {
          font-size: 12px;
          color: #92400e;
          margin-top: 6px;
        }
        
        /* Package Cards */
        .packages-grid {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }
        .pkg-card {
          border: 2px solid #e2e8f0;
          border-radius: 14px;
          padding: 16px;
          display: flex;
          align-items: center;
          gap: 16px;
          transition: all 0.2s;
          cursor: pointer;
          position: relative;
        }
        .pkg-card:hover { border-color: #f59e0b; background: #fffbeb; }
        .pkg-card.popular { border-color: #f59e0b; }
        .popular-tag {
          position: absolute;
          top: -10px;
          right: 16px;
          background: #f59e0b;
          color: white;
          padding: 3px 10px;
          border-radius: 10px;
          font-size: 10px;
          font-weight: 700;
        }
        .pkg-icon {
          width: 48px;
          height: 48px;
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 24px;
          flex-shrink: 0;
        }
        .pkg-card:nth-child(1) .pkg-icon { background: #dbeafe; }
        .pkg-card:nth-child(2) .pkg-icon { background: #fef3c7; }
        .pkg-card:nth-child(3) .pkg-icon { background: #f3e8ff; }
        .pkg-info { flex: 1; }
        .pkg-name {
          font-size: 16px;
          font-weight: 700;
          color: #1e293b;
          margin: 0 0 4px 0;
        }
        .pkg-features {
          font-size: 12px;
          color: #64748b;
          margin: 0;
        }
        .pkg-price {
          text-align: right;
        }
        .price-amount {
          font-size: 22px;
          font-weight: 700;
          color: #f59e0b;
        }
        .price-duration {
          font-size: 11px;
          color: #94a3b8;
        }
        
        /* Payment History */
        .payment-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 14px;
          border: 1px solid #e2e8f0;
          border-radius: 12px;
          margin-bottom: 10px;
        }
        .payment-item:hover { background: #f8fafc; }
        .payment-left {
          display: flex;
          align-items: center;
          gap: 12px;
        }
        .payment-icon {
          width: 40px;
          height: 40px;
          border-radius: 10px;
          background: #d1fae5;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 18px;
        }
        .payment-info h4 {
          margin: 0 0 2px 0;
          font-size: 14px;
          color: #1e293b;
        }
        .payment-info p {
          margin: 0;
          font-size: 12px;
          color: #64748b;
        }
        .payment-right {
          text-align: right;
        }
        .payment-amount {
          font-size: 15px;
          font-weight: 700;
          color: #1e293b;
        }
        .payment-status {
          font-size: 11px;
          padding: 2px 8px;
          border-radius: 10px;
          font-weight: 600;
        }
        .payment-status.success { background: #d1fae5; color: #047857; }
        .payment-status.pending { background: #fef3c7; color: #b45309; }
        .payment-status.failed { background: #fee2e2; color: #dc2626; }
        
        .empty-history {
          text-align: center;
          padding: 32px;
          color: #94a3b8;
        }
        .empty-history span { font-size: 40px; display: block; margin-bottom: 8px; }
        
        .buy-btn {
          margin-top: 12px;
          padding: 10px 16px;
          border: none;
          border-radius: 8px;
          background: linear-gradient(135deg, #f59e0b, #d97706);
          color: white;
          font-size: 13px;
          font-weight: 700;
          cursor: pointer;
          transition: all 0.2s;
          width: 100%;
        }
        .buy-btn:hover:not(:disabled) {
          transform: translateY(-1px);
          box-shadow: 0 4px 12px rgba(245, 158, 11, 0.4);
        }
        .buy-btn:disabled {
          opacity: 0.7;
          cursor: wait;
        }
        .pkg-card {
          flex-direction: column;
          align-items: stretch;
        }
        
        .cancel-btn {
          margin-top: 20px;
          padding: 12px 16px;
          border: 2px solid #fca5a5;
          border-radius: 10px;
          background: #fef2f2;
          color: #dc2626;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
          width: 100%;
        }
        .cancel-btn:hover {
          background: #fee2e2;
          border-color: #f87171;
        }
        
        /* New Package Cards */
        .packages-new-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 16px;
        }
        
        .package-card {
          background: #f8fafc;
          border: 1px solid #e2e8f0;
          border-radius: 16px;
          padding: 20px;
          display: flex;
          flex-direction: column;
          transition: all 0.2s;
          position: relative;
        }
        .package-card:hover {
          border-color: #10b981;
          box-shadow: 0 4px 12px rgba(16, 185, 129, 0.1);
        }
        .package-card.recommended {
          border-color: #10b981;
          border-width: 2px;
        }
        
        .recommended-badge {
          position: absolute;
          top: -12px;
          left: 50%;
          transform: translateX(-50%);
          background: #10b981;
          color: white;
          padding: 4px 12px;
          border-radius: 12px;
          font-size: 11px;
          font-weight: 600;
          white-space: nowrap;
        }
        
        .package-title {
          font-size: 16px;
          font-weight: 700;
          color: #1e293b;
          margin: 0 0 8px 0;
        }
        
        .package-desc {
          font-size: 12px;
          color: #64748b;
          margin: 0 0 16px 0;
          line-height: 1.4;
        }
        
        .package-features {
          flex: 1;
        }
        
        .features-label {
          font-size: 10px;
          font-weight: 700;
          color: #10b981;
          letter-spacing: 0.5px;
          margin-bottom: 10px;
        }
        
        .feature-item {
          display: flex;
          align-items: flex-start;
          gap: 8px;
          font-size: 12px;
          margin-bottom: 8px;
          line-height: 1.4;
        }
        .feature-item.included {
          color: #334155;
        }
        .feature-item.not-included {
          color: #ef4444;
        }
        
        .feature-icon {
          flex-shrink: 0;
          width: 16px;
          height: 16px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 10px;
          font-weight: 700;
        }
        .feature-item.included .feature-icon {
          background: #d1fae5;
          color: #10b981;
        }
        .feature-item.not-included .feature-icon {
          background: #fee2e2;
          color: #ef4444;
        }
        
        .package-footer {
          margin-top: 16px;
          padding-top: 16px;
          border-top: 1px solid #e2e8f0;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        
        .package-price {
          display: flex;
          flex-direction: column;
        }
        .price-value {
          font-size: 20px;
          font-weight: 700;
          color: #1e293b;
        }
        .price-period {
          font-size: 11px;
          color: #94a3b8;
        }
        
        .select-btn {
          padding: 10px 20px;
          border: none;
          border-radius: 8px;
          background: #10b981;
          color: white;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
        }
        .select-btn:hover:not(:disabled):not(.added) {
          background: #059669;
        }
        .select-btn:disabled {
          opacity: 0.6;
          cursor: wait;
        }
        .select-btn.added {
          background: #6b7280;
          cursor: default;
        }
        
        @media (max-width: 768px) {
          .packages-new-grid {
            grid-template-columns: 1fr;
          }
        }
      `}),l.jsxs("div",{className:"pkg-modal",children:[l.jsxs("div",{className:"pkg-header",children:[l.jsx("button",{className:"close-btn",onClick:v,children:"×"}),l.jsx("h2",{children:"📦 Paketlerim & Ödemeler"})]}),l.jsxs("div",{className:"tab-bar",children:[l.jsx("button",{className:`tab-btn ${B==="current"?"active":""}`,onClick:()=>b("current"),children:"✨ Aktif Paket"}),l.jsx("button",{className:`tab-btn ${B==="packages"?"active":""}`,onClick:()=>b("packages"),children:"🎁 Paketler"}),l.jsx("button",{className:`tab-btn ${B==="history"?"active":""}`,onClick:()=>b("history"),children:"📋 Geçmiş"})]}),l.jsxs("div",{className:"pkg-content",children:[B==="current"&&(w?l.jsxs("div",{className:"current-pkg",children:[l.jsx("div",{className:"current-badge",children:"⭐ AKTİF PAKET"}),l.jsxs("h3",{className:"current-name",children:[ie.name," Paket"]}),l.jsxs("div",{className:"current-info",children:[l.jsxs("div",{className:"info-item",children:["💰 ",ie.price,"₺"]}),l.jsxs("div",{className:"info-item",children:["📅 ",ie.duration]}),l.jsxs("div",{className:"info-item",children:["🔥 ",J," gün kaldı"]})]}),l.jsx("div",{className:"days-bar",children:l.jsx("div",{className:"days-fill",style:{width:`${J/90*100}%`}})}),l.jsx("div",{className:"days-text",children:"Bitiş: 15 Şubat 2025"}),l.jsxs("div",{style:{marginTop:20,paddingTop:16,borderTop:"1px dashed #d97706"},children:[l.jsx("div",{style:{fontSize:13,fontWeight:600,color:"#92400e",marginBottom:10},children:"Paket Özellikleri:"}),ie.features.map((H,K)=>l.jsxs("div",{style:{display:"flex",alignItems:"center",gap:8,fontSize:13,color:"#92400e",marginBottom:6},children:[l.jsx("span",{children:"✓"})," ",H]},K))]}),l.jsx("button",{className:"cancel-btn",onClick:()=>{d&&(d(),v())},children:"🗑️ Paketi İptal Et (Demo)"})]}):l.jsxs("div",{style:{textAlign:"center",padding:40},children:[l.jsx("div",{style:{fontSize:64,marginBottom:16},children:"📦"}),l.jsx("h3",{style:{margin:"0 0 8px 0",color:"#64748b"},children:"Aktif paketiniz yok"}),l.jsx("p",{style:{color:"#94a3b8",marginBottom:20},children:"Paketler sekmesinden bir paket satın alabilirsiniz."}),l.jsx("button",{style:{padding:"12px 24px",background:"#f59e0b",color:"white",border:"none",borderRadius:10,fontWeight:600,cursor:"pointer"},onClick:()=>b("packages"),children:"🎁 Paketlere Git"})]})),B==="packages"&&l.jsx("div",{className:"packages-new-grid",children:N?l.jsxs("div",{style:{textAlign:"center",padding:40,gridColumn:"1 / -1"},children:[l.jsx("div",{style:{fontSize:64,marginBottom:16},children:"🎉"}),l.jsx("h3",{style:{margin:"0 0 8px 0",color:"#10b981"},children:"Satın Alma Başarılı!"}),l.jsx("p",{style:{color:"#64748b",marginBottom:20},children:"Egzersiz programınız hazırlanıyor..."})]}):dx.map(H=>{var K;return l.jsxs("div",{className:`package-card ${H.popular?"recommended":""}`,children:[H.popular&&l.jsx("div",{className:"recommended-badge",children:"Fizyoterapist önerisi"}),l.jsx("h3",{className:"package-title",children:H.name}),l.jsx("p",{className:"package-desc",children:H.description}),l.jsxs("div",{className:"package-features",children:[l.jsx("div",{className:"features-label",children:"PAKET İÇERİĞİ"}),H.features.map((ue,$)=>l.jsxs("div",{className:"feature-item included",children:[l.jsx("span",{className:"feature-icon",children:"✓"}),l.jsx("span",{children:ue})]},$)),(K=H.notIncluded)==null?void 0:K.map((ue,$)=>l.jsxs("div",{className:"feature-item not-included",children:[l.jsx("span",{className:"feature-icon",children:"✕"}),l.jsx("span",{children:ue})]},$))]}),l.jsxs("div",{className:"package-footer",children:[l.jsxs("div",{className:"package-price",children:[l.jsxs("span",{className:"price-value",children:[H.price,"₺"]}),l.jsx("span",{className:"price-period",children:H.duration})]}),L(H.id)?l.jsx("button",{className:"select-btn added",children:"✓ Sepette"}):l.jsx("button",{className:"select-btn",onClick:()=>Z(H),children:"🛒 Sepete Ekle"})]})]},H.id)})}),B==="history"&&l.jsx("div",{children:ux.length===0?l.jsxs("div",{className:"empty-history",children:[l.jsx("span",{children:"📭"}),l.jsx("p",{children:"Henüz ödeme geçmişiniz yok"})]}):ux.map(H=>l.jsxs("div",{className:"payment-item",children:[l.jsxs("div",{className:"payment-left",children:[l.jsx("div",{className:"payment-icon",children:"✓"}),l.jsxs("div",{className:"payment-info",children:[l.jsx("h4",{children:H.description}),l.jsx("p",{children:H.date.toLocaleDateString("tr-TR",{day:"numeric",month:"long",year:"numeric"})})]})]}),l.jsxs("div",{className:"payment-right",children:[l.jsxs("div",{className:"payment-amount",children:[H.amount,"₺"]}),l.jsx("span",{className:`payment-status ${H.status}`,children:H.status==="success"?"Başarılı":H.status==="pending"?"Bekliyor":"Başarısız"})]})]},H.id))})]})]})]})},xg=({open:r,onClose:v})=>{const[E,d]=g.useState("profile"),[w,A]=g.useState("Ahmet Yılmaz"),[S,B]=g.useState("ahmet@email.com"),[b,p]=g.useState("0555 123 45 67"),[U,N]=g.useState(!0),[G,L]=g.useState(!1),[Z,ie]=g.useState(!0),[J,H]=g.useState(!0),[K,ue]=g.useState(!0),[$,Ye]=g.useState(!1),[de,Q]=g.useState("light"),[Y,ne]=g.useState("medium"),[re,Oe]=g.useState(!1);if(!r)return null;const ce=()=>{Oe(!0),setTimeout(()=>Oe(!1),2e3)},at=[{id:"profile",label:"Profil",icon:"👤"},{id:"notifications",label:"Bildirimler",icon:"🔔"},{id:"privacy",label:"Gizlilik",icon:"🔒"},{id:"appearance",label:"Görünüm",icon:"🎨"}];return l.jsxs("div",{className:"settings-overlay",children:[l.jsx("style",{children:`
        .settings-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.5);
          backdrop-filter: blur(6px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
          padding: 16px;
          animation: fadeIn 0.2s ease;
        }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        
        .settings-modal {
          background: #fff;
          border-radius: 20px;
          width: 100%;
          max-width: 600px;
          max-height: 85vh;
          display: flex;
          flex-direction: column;
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
          animation: slideUp 0.3s ease;
        }
        
        .settings-header {
          background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%);
          padding: 20px 24px;
          color: white;
          position: relative;
          border-radius: 20px 20px 0 0;
        }
        .settings-header h2 {
          font-size: 20px;
          font-weight: 700;
          margin: 0;
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .close-btn {
          position: absolute;
          top: 14px;
          right: 14px;
          width: 32px;
          height: 32px;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.2);
          border: none;
          color: white;
          font-size: 20px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
        }
        .close-btn:hover { background: rgba(255, 255, 255, 0.3); transform: rotate(90deg); }
        
        .settings-body {
          display: flex;
          flex: 1;
          overflow: hidden;
        }
        
        .settings-nav {
          width: 140px;
          background: #f8fafc;
          border-right: 1px solid #e2e8f0;
          padding: 12px 8px;
          flex-shrink: 0;
        }
        .nav-item {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
          padding: 12px 8px;
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s;
          margin-bottom: 4px;
        }
        .nav-item:hover { background: #e2e8f0; }
        .nav-item.active { background: #6366f1; color: white; }
        .nav-icon { font-size: 20px; }
        .nav-label { font-size: 11px; font-weight: 600; }
        
        .settings-content {
          flex: 1;
          padding: 20px;
          overflow-y: auto;
        }
        
        .section-title {
          font-size: 16px;
          font-weight: 700;
          color: #1e293b;
          margin: 0 0 16px 0;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        
        .form-group {
          margin-bottom: 16px;
        }
        .form-label {
          display: block;
          font-size: 12px;
          font-weight: 600;
          color: #64748b;
          margin-bottom: 6px;
        }
        .form-input {
          width: 100%;
          padding: 10px 14px;
          border: 2px solid #e2e8f0;
          border-radius: 10px;
          font-size: 14px;
          transition: all 0.2s;
          outline: none;
        }
        .form-input:focus { border-color: #6366f1; }
        
        .toggle-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 12px 0;
          border-bottom: 1px solid #f1f5f9;
        }
        .toggle-row:last-child { border-bottom: none; }
        .toggle-info h4 {
          margin: 0 0 2px 0;
          font-size: 14px;
          color: #1e293b;
        }
        .toggle-info p {
          margin: 0;
          font-size: 12px;
          color: #94a3b8;
        }
        
        .toggle-switch {
          width: 44px;
          height: 24px;
          background: #e2e8f0;
          border-radius: 12px;
          position: relative;
          cursor: pointer;
          transition: all 0.2s;
        }
        .toggle-switch.active { background: #6366f1; }
        .toggle-switch::after {
          content: '';
          position: absolute;
          width: 20px;
          height: 20px;
          background: white;
          border-radius: 50%;
          top: 2px;
          left: 2px;
          transition: all 0.2s;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .toggle-switch.active::after { left: 22px; }
        
        .option-cards {
          display: flex;
          gap: 10px;
        }
        .option-card {
          flex: 1;
          padding: 14px;
          border: 2px solid #e2e8f0;
          border-radius: 12px;
          text-align: center;
          cursor: pointer;
          transition: all 0.2s;
        }
        .option-card:hover { border-color: #c7d2fe; }
        .option-card.active { border-color: #6366f1; background: #eef2ff; }
        .option-icon { font-size: 24px; margin-bottom: 6px; }
        .option-label { font-size: 12px; font-weight: 600; color: #475569; }
        .option-card.active .option-label { color: #6366f1; }
        
        .save-bar {
          padding: 16px 20px;
          background: #f8fafc;
          border-top: 1px solid #e2e8f0;
          border-radius: 0 0 20px 20px;
          display: flex;
          justify-content: flex-end;
          gap: 10px;
        }
        .btn {
          padding: 10px 20px;
          border: none;
          border-radius: 10px;
          font-size: 14px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
        }
        .btn-secondary {
          background: #e2e8f0;
          color: #475569;
        }
        .btn-secondary:hover { background: #cbd5e1; }
        .btn-primary {
          background: linear-gradient(135deg, #6366f1, #4f46e5);
          color: white;
        }
        .btn-primary:hover { transform: translateY(-1px); box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3); }
        
        .saved-toast {
          position: fixed;
          top: 20px;
          right: 20px;
          background: #10b981;
          color: white;
          padding: 12px 20px;
          border-radius: 10px;
          font-size: 14px;
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 8px;
          box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
          animation: slideIn 0.3s ease;
          z-index: 1001;
        }
        @keyframes slideIn { from { opacity: 0; transform: translateX(20px); } to { opacity: 1; transform: translateX(0); } }
      `}),l.jsxs("div",{className:"settings-modal",children:[l.jsxs("div",{className:"settings-header",children:[l.jsx("button",{className:"close-btn",onClick:v,children:"×"}),l.jsx("h2",{children:"⚙️ Ayarlar"})]}),l.jsxs("div",{className:"settings-body",children:[l.jsx("div",{className:"settings-nav",children:at.map(ye=>l.jsxs("div",{className:`nav-item ${E===ye.id?"active":""}`,onClick:()=>d(ye.id),children:[l.jsx("span",{className:"nav-icon",children:ye.icon}),l.jsx("span",{className:"nav-label",children:ye.label})]},ye.id))}),l.jsxs("div",{className:"settings-content",children:[E==="profile"&&l.jsxs(l.Fragment,{children:[l.jsx("h3",{className:"section-title",children:"👤 Profil Bilgileri"}),l.jsxs("div",{className:"form-group",children:[l.jsx("label",{className:"form-label",children:"Ad Soyad"}),l.jsx("input",{type:"text",className:"form-input",value:w,onChange:ye=>A(ye.target.value)})]}),l.jsxs("div",{className:"form-group",children:[l.jsx("label",{className:"form-label",children:"E-posta"}),l.jsx("input",{type:"email",className:"form-input",value:S,onChange:ye=>B(ye.target.value)})]}),l.jsxs("div",{className:"form-group",children:[l.jsx("label",{className:"form-label",children:"Telefon"}),l.jsx("input",{type:"tel",className:"form-input",value:b,onChange:ye=>p(ye.target.value)})]})]}),E==="notifications"&&l.jsxs(l.Fragment,{children:[l.jsx("h3",{className:"section-title",children:"🔔 Bildirim Tercihleri"}),l.jsxs("div",{className:"toggle-row",children:[l.jsxs("div",{className:"toggle-info",children:[l.jsx("h4",{children:"E-posta Bildirimleri"}),l.jsx("p",{children:"Önemli güncellemeler için e-posta al"})]}),l.jsx("div",{className:`toggle-switch ${U?"active":""}`,onClick:()=>N(!U)})]}),l.jsxs("div",{className:"toggle-row",children:[l.jsxs("div",{className:"toggle-info",children:[l.jsx("h4",{children:"SMS Bildirimleri"}),l.jsx("p",{children:"Randevu hatırlatmaları için SMS al"})]}),l.jsx("div",{className:`toggle-switch ${G?"active":""}`,onClick:()=>L(!G)})]}),l.jsxs("div",{className:"toggle-row",children:[l.jsxs("div",{className:"toggle-info",children:[l.jsx("h4",{children:"Push Bildirimleri"}),l.jsx("p",{children:"Anlık bildirimler al"})]}),l.jsx("div",{className:`toggle-switch ${Z?"active":""}`,onClick:()=>ie(!Z)})]}),l.jsxs("div",{className:"toggle-row",children:[l.jsxs("div",{className:"toggle-info",children:[l.jsx("h4",{children:"Egzersiz Hatırlatıcı"}),l.jsx("p",{children:"Günlük egzersiz hatırlatması"})]}),l.jsx("div",{className:`toggle-switch ${J?"active":""}`,onClick:()=>H(!J)})]})]}),E==="privacy"&&l.jsxs(l.Fragment,{children:[l.jsx("h3",{className:"section-title",children:"🔒 Gizlilik Ayarları"}),l.jsxs("div",{className:"toggle-row",children:[l.jsxs("div",{className:"toggle-info",children:[l.jsx("h4",{children:"Profil Görünürlüğü"}),l.jsx("p",{children:"Profilim diğer kullanıcılara görünsün"})]}),l.jsx("div",{className:`toggle-switch ${K?"active":""}`,onClick:()=>ue(!K)})]}),l.jsxs("div",{className:"toggle-row",children:[l.jsxs("div",{className:"toggle-info",children:[l.jsx("h4",{children:"İlerleme Paylaşımı"}),l.jsx("p",{children:"Egzersiz ilerlememizi fizyoterapistle paylaş"})]}),l.jsx("div",{className:`toggle-switch ${$?"active":""}`,onClick:()=>Ye(!$)})]})]}),E==="appearance"&&l.jsxs(l.Fragment,{children:[l.jsx("h3",{className:"section-title",children:"🎨 Görünüm"}),l.jsxs("div",{className:"form-group",children:[l.jsx("label",{className:"form-label",children:"Tema"}),l.jsxs("div",{className:"option-cards",children:[l.jsxs("div",{className:`option-card ${de==="light"?"active":""}`,onClick:()=>Q("light"),children:[l.jsx("div",{className:"option-icon",children:"☀️"}),l.jsx("div",{className:"option-label",children:"Açık"})]}),l.jsxs("div",{className:`option-card ${de==="dark"?"active":""}`,onClick:()=>Q("dark"),children:[l.jsx("div",{className:"option-icon",children:"🌙"}),l.jsx("div",{className:"option-label",children:"Koyu"})]}),l.jsxs("div",{className:`option-card ${de==="auto"?"active":""}`,onClick:()=>Q("auto"),children:[l.jsx("div",{className:"option-icon",children:"🔄"}),l.jsx("div",{className:"option-label",children:"Otomatik"})]})]})]}),l.jsxs("div",{className:"form-group",style:{marginTop:20},children:[l.jsx("label",{className:"form-label",children:"Yazı Boyutu"}),l.jsxs("div",{className:"option-cards",children:[l.jsxs("div",{className:`option-card ${Y==="small"?"active":""}`,onClick:()=>ne("small"),children:[l.jsx("div",{className:"option-icon",style:{fontSize:16},children:"A"}),l.jsx("div",{className:"option-label",children:"Küçük"})]}),l.jsxs("div",{className:`option-card ${Y==="medium"?"active":""}`,onClick:()=>ne("medium"),children:[l.jsx("div",{className:"option-icon",style:{fontSize:22},children:"A"}),l.jsx("div",{className:"option-label",children:"Orta"})]}),l.jsxs("div",{className:`option-card ${Y==="large"?"active":""}`,onClick:()=>ne("large"),children:[l.jsx("div",{className:"option-icon",style:{fontSize:28},children:"A"}),l.jsx("div",{className:"option-label",children:"Büyük"})]})]})]})]})]})]}),l.jsxs("div",{className:"save-bar",children:[l.jsx("button",{className:"btn btn-secondary",onClick:v,children:"İptal"}),l.jsx("button",{className:"btn btn-primary",onClick:ce,children:"💾 Kaydet"})]})]}),re&&l.jsx("div",{className:"saved-toast",children:"✓ Ayarlar kaydedildi!"})]})},pg=({open:r,onClose:v})=>{const[E,d]=g.useState(!1);if(!r)return null;const w="gC_L9qAHVJ8",A=[{icon:"📝",title:"Değerlendirme",desc:"3 dakikalık form"},{icon:"🔍",title:"Analiz",desc:"Uzman incelemesi"},{icon:"📋",title:"Program",desc:"Kişiye özel plan"},{icon:"🏋️",title:"Egzersiz",desc:"Video rehberlik"}];return l.jsxs("div",{className:"video-overlay",onClick:v,children:[l.jsx("style",{children:`
        .video-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.85);
          backdrop-filter: blur(8px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
          padding: 20px;
          animation: fadeIn 0.3s ease;
        }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.1); } }
        
        .video-modal {
          background: #fff;
          border-radius: 24px;
          width: 100%;
          max-width: 800px;
          overflow: hidden;
          box-shadow: 0 25px 60px rgba(0, 0, 0, 0.4);
          animation: slideUp 0.4s ease;
        }
        
        .video-header {
          background: linear-gradient(135deg, #ec4899 0%, #8b5cf6 100%);
          padding: 20px 24px;
          color: white;
          position: relative;
        }
        .video-header h2 {
          font-size: 20px;
          font-weight: 700;
          margin: 0 0 4px 0;
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .video-header p {
          margin: 0;
          font-size: 13px;
          opacity: 0.9;
        }
        .close-btn {
          position: absolute;
          top: 14px;
          right: 14px;
          width: 36px;
          height: 36px;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.2);
          border: none;
          color: white;
          font-size: 22px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
        }
        .close-btn:hover { background: rgba(255, 255, 255, 0.3); transform: rotate(90deg); }
        
        .video-container {
          position: relative;
          background: #000;
          aspect-ratio: 16/9;
        }
        
        .video-placeholder {
          position: absolute;
          inset: 0;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          background: linear-gradient(135deg, #1e1b4b 0%, #312e81 100%);
          cursor: pointer;
        }
        
        .play-button {
          width: 80px;
          height: 80px;
          border-radius: 50%;
          background: linear-gradient(135deg, #ec4899, #8b5cf6);
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: all 0.3s;
          box-shadow: 0 8px 30px rgba(236, 72, 153, 0.5);
          animation: pulse 2s infinite;
        }
        .play-button:hover {
          transform: scale(1.1);
          box-shadow: 0 12px 40px rgba(236, 72, 153, 0.6);
        }
        .play-icon {
          width: 0;
          height: 0;
          border-left: 28px solid white;
          border-top: 18px solid transparent;
          border-bottom: 18px solid transparent;
          margin-left: 6px;
        }
        
        .video-title-overlay {
          color: white;
          margin-top: 20px;
          text-align: center;
        }
        .video-title-overlay h3 {
          margin: 0 0 6px 0;
          font-size: 18px;
        }
        .video-title-overlay p {
          margin: 0;
          font-size: 13px;
          opacity: 0.7;
        }
        
        .video-iframe {
          width: 100%;
          height: 100%;
          border: none;
        }
        
        .video-footer {
          padding: 20px 24px;
          background: #f8fafc;
        }
        .footer-title {
          font-size: 14px;
          font-weight: 700;
          color: #1e293b;
          margin: 0 0 16px 0;
          text-align: center;
        }
        
        .steps-row {
          display: flex;
          justify-content: space-between;
          gap: 12px;
        }
        .step-item {
          flex: 1;
          text-align: center;
          padding: 12px 8px;
          background: white;
          border-radius: 12px;
          border: 1px solid #e2e8f0;
          position: relative;
        }
        .step-item:not(:last-child)::after {
          content: '→';
          position: absolute;
          right: -14px;
          top: 50%;
          transform: translateY(-50%);
          color: #cbd5e1;
          font-size: 16px;
        }
        .step-icon {
          font-size: 24px;
          margin-bottom: 6px;
        }
        .step-title {
          font-size: 12px;
          font-weight: 700;
          color: #1e293b;
          margin-bottom: 2px;
        }
        .step-desc {
          font-size: 10px;
          color: #94a3b8;
        }
        
        .cta-section {
          margin-top: 16px;
          text-align: center;
        }
        .cta-btn {
          padding: 12px 28px;
          border: none;
          border-radius: 12px;
          background: linear-gradient(135deg, #ec4899, #8b5cf6);
          color: white;
          font-size: 14px;
          font-weight: 700;
          cursor: pointer;
          transition: all 0.2s;
        }
        .cta-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 20px rgba(236, 72, 153, 0.4);
        }
      `}),l.jsxs("div",{className:"video-modal",onClick:S=>S.stopPropagation(),children:[l.jsxs("div",{className:"video-header",children:[l.jsx("button",{className:"close-btn",onClick:v,children:"×"}),l.jsx("h2",{children:"🎬 Sistem Nasıl İşliyor?"}),l.jsx("p",{children:"1 dakikalık tanıtım videosu"})]}),l.jsx("div",{className:"video-container",children:E?l.jsx("iframe",{className:"video-iframe",src:`https://www.youtube.com/embed/${w}?autoplay=1&rel=0`,allow:"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",allowFullScreen:!0,title:"EgzersizLab Tanıtım Videosu"}):l.jsxs("div",{className:"video-placeholder",onClick:()=>d(!0),children:[l.jsx("div",{className:"play-button",children:l.jsx("div",{className:"play-icon"})}),l.jsxs("div",{className:"video-title-overlay",children:[l.jsx("h3",{children:"Videoyu İzle"}),l.jsx("p",{children:"Tıklayarak başlat • 1:24"})]})]})}),l.jsxs("div",{className:"video-footer",children:[l.jsx("h4",{className:"footer-title",children:"4 Adımda Sağlıklı Yaşam"}),l.jsx("div",{className:"steps-row",children:A.map((S,B)=>l.jsxs("div",{className:"step-item",children:[l.jsx("div",{className:"step-icon",children:S.icon}),l.jsx("div",{className:"step-title",children:S.title}),l.jsx("div",{className:"step-desc",children:S.desc})]},B))}),l.jsx("div",{className:"cta-section",children:l.jsx("button",{className:"cta-btn",onClick:v,children:"▶ Hemen Başla"})})]})]})]})},hs=[{id:1,name:"Boyun Germe",duration:"5 dk",icon:"🦴",status:"todo"},{id:2,name:"Omuz Rotasyonu",duration:"3 dk",icon:"💪",status:"todo"},{id:3,name:"Sırt Esneme",duration:"5 dk",icon:"🔙",status:"done"},{id:4,name:"Bel Güçlendirme",duration:"8 dk",icon:"⬇️",status:"todo"},{id:5,name:"Kalça Açma",duration:"4 dk",icon:"🦵",status:"done"},{id:6,name:"Nefes Egzersizi",duration:"3 dk",icon:"🧘",status:"todo"}],hg=({open:r,onClose:v})=>{if(!r)return null;const E=hs.filter(w=>w.status==="done").length,d=E/hs.length*100;return l.jsxs("div",{className:"modal-overlay",children:[l.jsx("style",{children:`
        .modal-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.5);
          backdrop-filter: blur(6px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
          padding: 16px;
          animation: fadeIn 0.2s ease;
        }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        
        .modal-box {
          background: #fff;
          border-radius: 20px;
          width: 100%;
          max-width: 500px;
          max-height: 85vh;
          overflow: hidden;
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
          animation: slideUp 0.3s ease;
        }
        
        .modal-header {
          background: linear-gradient(135deg, #10b981 0%, #059669 100%);
          padding: 20px 24px;
          color: white;
          position: relative;
        }
        .modal-header h2 {
          font-size: 20px;
          font-weight: 700;
          margin: 0 0 8px 0;
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .close-btn {
          position: absolute;
          top: 14px;
          right: 14px;
          width: 32px;
          height: 32px;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.2);
          border: none;
          color: white;
          font-size: 20px;
          cursor: pointer;
          transition: all 0.2s;
        }
        .close-btn:hover { background: rgba(255, 255, 255, 0.3); }
        
        .progress-bar {
          height: 6px;
          background: rgba(255,255,255,0.3);
          border-radius: 3px;
          overflow: hidden;
        }
        .progress-fill {
          height: 100%;
          background: white;
          border-radius: 3px;
          transition: width 0.3s;
        }
        .progress-text {
          font-size: 13px;
          margin-top: 6px;
          opacity: 0.9;
        }
        
        .modal-content {
          padding: 20px;
          max-height: 60vh;
          overflow-y: auto;
        }
        
        .exercise-item {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 14px;
          border: 2px solid #e2e8f0;
          border-radius: 12px;
          margin-bottom: 10px;
          cursor: pointer;
          transition: all 0.2s;
        }
        .exercise-item:hover { border-color: #10b981; background: #f0fdf4; }
        .exercise-item.done { border-color: #10b981; background: #ecfdf5; }
        
        .exercise-icon {
          width: 44px;
          height: 44px;
          border-radius: 12px;
          background: #f1f5f9;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 22px;
        }
        .exercise-item.done .exercise-icon { background: #d1fae5; }
        
        .exercise-info { flex: 1; }
        .exercise-name { font-size: 15px; font-weight: 600; color: #1e293b; }
        .exercise-duration { font-size: 12px; color: #64748b; }
        
        .exercise-status {
          width: 28px;
          height: 28px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 14px;
        }
        .exercise-item.done .exercise-status { background: #10b981; color: white; }
        .exercise-item:not(.done) .exercise-status { background: #e2e8f0; color: #94a3b8; }
      `}),l.jsxs("div",{className:"modal-box",children:[l.jsxs("div",{className:"modal-header",children:[l.jsx("button",{className:"close-btn",onClick:v,children:"×"}),l.jsx("h2",{children:"🧘 Egzersiz Programım"}),l.jsx("div",{className:"progress-bar",children:l.jsx("div",{className:"progress-fill",style:{width:`${d}%`}})}),l.jsxs("div",{className:"progress-text",children:[E,"/",hs.length," tamamlandı"]})]}),l.jsx("div",{className:"modal-content",children:hs.map(w=>l.jsxs("div",{className:`exercise-item ${w.status==="done"?"done":""}`,children:[l.jsx("div",{className:"exercise-icon",children:w.icon}),l.jsxs("div",{className:"exercise-info",children:[l.jsx("div",{className:"exercise-name",children:w.name}),l.jsxs("div",{className:"exercise-duration",children:["⏱️ ",w.duration]})]}),l.jsx("div",{className:"exercise-status",children:w.status==="done"?"✓":"▶"})]},w.id))})]})]})},gg=[{day:"Pzt",done:!0},{day:"Sal",done:!0},{day:"Çar",done:!1},{day:"Per",done:!0},{day:"Cum",done:!1},{day:"Cmt",done:!1,today:!0},{day:"Paz",done:!1}],bg=[{label:"Toplam Gün",value:"12",icon:"📅"},{label:"Seri",value:"3",icon:"🔥"},{label:"Egzersiz",value:"45",icon:"🏋️"},{label:"Dakika",value:"180",icon:"⏱️"}],yg=({open:r,onClose:v})=>r?l.jsxs("div",{className:"modal-overlay",children:[l.jsx("style",{children:`
        .modal-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.5);
          backdrop-filter: blur(6px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
          padding: 16px;
          animation: fadeIn 0.2s ease;
        }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        
        .modal-box {
          background: #fff;
          border-radius: 20px;
          width: 100%;
          max-width: 480px;
          overflow: hidden;
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
          animation: slideUp 0.3s ease;
        }
        
        .modal-header {
          background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%);
          padding: 20px 24px;
          color: white;
          position: relative;
        }
        .modal-header h2 {
          font-size: 20px;
          font-weight: 700;
          margin: 0;
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .close-btn {
          position: absolute;
          top: 14px;
          right: 14px;
          width: 32px;
          height: 32px;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.2);
          border: none;
          color: white;
          font-size: 20px;
          cursor: pointer;
          transition: all 0.2s;
        }
        .close-btn:hover { background: rgba(255, 255, 255, 0.3); }
        
        .modal-content {
          padding: 20px;
        }
        
        .stats-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 10px;
          margin-bottom: 20px;
        }
        .stat-card {
          text-align: center;
          padding: 12px 8px;
          background: #f8fafc;
          border-radius: 12px;
        }
        .stat-icon { font-size: 20px; margin-bottom: 4px; }
        .stat-value { font-size: 20px; font-weight: 700; color: #1e293b; }
        .stat-label { font-size: 10px; color: #64748b; }
        
        .week-section h3 {
          font-size: 14px;
          color: #64748b;
          margin: 0 0 12px 0;
        }
        .week-grid {
          display: flex;
          gap: 8px;
        }
        .day-item {
          flex: 1;
          text-align: center;
          padding: 12px 8px;
          border-radius: 12px;
          background: #f1f5f9;
          transition: all 0.2s;
        }
        .day-item.done { background: #d1fae5; }
        .day-item.today { border: 2px solid #6366f1; background: #eef2ff; }
        .day-name { font-size: 11px; color: #64748b; margin-bottom: 6px; }
        .day-status { font-size: 18px; }
        
        .motivation {
          margin-top: 20px;
          padding: 16px;
          background: linear-gradient(135deg, #fef3c7, #fde68a);
          border-radius: 12px;
          text-align: center;
        }
        .motivation-text {
          font-size: 14px;
          color: #92400e;
          font-weight: 600;
        }
      `}),l.jsxs("div",{className:"modal-box",children:[l.jsxs("div",{className:"modal-header",children:[l.jsx("button",{className:"close-btn",onClick:v,children:"×"}),l.jsx("h2",{children:"📅 Takvim / İlerleme"})]}),l.jsxs("div",{className:"modal-content",children:[l.jsx("div",{className:"stats-grid",children:bg.map((E,d)=>l.jsxs("div",{className:"stat-card",children:[l.jsx("div",{className:"stat-icon",children:E.icon}),l.jsx("div",{className:"stat-value",children:E.value}),l.jsx("div",{className:"stat-label",children:E.label})]},d))}),l.jsxs("div",{className:"week-section",children:[l.jsx("h3",{children:"Bu Hafta"}),l.jsx("div",{className:"week-grid",children:gg.map((E,d)=>l.jsxs("div",{className:`day-item ${E.done?"done":""} ${E.today?"today":""}`,children:[l.jsx("div",{className:"day-name",children:E.day}),l.jsx("div",{className:"day-status",children:E.done?"✅":E.today?"📍":"⚪"})]},d))})]}),l.jsx("div",{className:"motivation",children:l.jsx("div",{className:"motivation-text",children:"🔥 3 günlük serin var! Devam et!"})})]})]})]}):null,vg={"muscle-strength":{title:"Kas Kuvveti Değerlendirmesi",icon:"💪",instructions:["Kamerayı yan profilden konumlandırın (vücudunuzun yarısı görünsün)","Rahat kıyafetler giyin, hareketi engellemesin","Testi yaparken ağrı olursa durun","Her hareketi 3 kez tekrarlayın"],tests:[{id:"squat",name:"Çömelme Testi (Squat)",description:"Ayaklar omuz genişliğinde, eller önde, yavaşça çömelin ve kalkın",duration:"30 saniye",videoTips:"Yan profilden çekin, diz ve kalça hareketini görebilmeli",relevantBodyAreas:["knee-front-left","knee-front-right","knee-back-left","knee-back-right","hip-front","hip-back","lower-back","thigh-front-left","thigh-front-right","thigh-back-left","thigh-back-right","ankle-front-left","ankle-front-right","ankle-back-left","ankle-back-right","calf-back-left","calf-back-right"],instructions:["Kamerayı yan profilden konumlandırın","Rahat kıyafetler giyin, hareketi engellemesin","Testi yaparken ağrı olursa durun","Hareketi 30 saniye boyunca yapabildiğiniz kadar yapın"],detailedInstructions:{startPosition:{title:"1. Başlangıç Pozisyonu",items:[{label:"Ayaklar",text:"Ayaklarınızı omuz genişliğinde açın. Ayak parmak uçlarınız hafifçe dışa baksın."},{label:"Duruş",text:"Dik durun, göğsünüzü yukarıda tutun ve karşıya bakın."},{label:"Kollar",text:"Dengeyi sağlamak için kollarınızı öne doğru uzatabilir veya ellerinizi belinize koyabilirsiniz."}]},movementDown:{title:"2. Hareketin Yapılışı (İniş)",items:[{label:"Sandalyeye Oturma Hissi",text:"Hareketi dizlerinizi bükerek değil, kalçanızı geriye doğru iterek başlatın. Tıpkı arkanızda görünmez bir sandalye varmış ve ona oturacakmışsınız gibi düşünün."},{label:"Dizler",text:"Çömelirken dizlerinizin içeriye doğru çökmesine izin vermeyin; dizlerinizi hafifçe dışa doğru iterek ayak parmaklarınızla aynı hizada tutun."},{label:"Derinlik",text:"Uyluklarınız yere paralel olana kadar (veya ağrı hissetmediğiniz, doktorunuzun izin verdiği seviyeye kadar) inin."},{label:"Topuklar",text:"Topuklarınızın yerden kalkmasına asla izin vermeyin, ağırlığınızı topuklarınıza verin."}]},movementUp:{title:"3. Hareketin Yapılışı (Kalkış)",items:[{label:"İtme",text:"Topuklarınızdan kuvvet alarak vücudunuzu yukarı doğru itin."},{label:"Bitiş",text:"Tamamen dik konuma geldiğinizde kalçanızı hafifçe sıkın."}]}},evaluationPoints:["Dizler içe dönüyor mu?","Kalça yeterince geri gidiyor mu?","Topuklar yerden kalkıyor mu?","Gövde öne eğiliyor mu?"]},{id:"calf-raise",name:"Topuk Yükseltme (Calf Raise)",description:"Tek ayak üzerinde durun, bir yerden destek alarak 30 saniye boyunca parmak ucuna yükselip inin",duration:"30 saniye",videoTips:"Yandan çekin, topuk yükselme hareketini görebilmeli",relevantBodyAreas:["ankle-front-left","ankle-front-right","ankle-back-left","ankle-back-right","calf-back-left","calf-back-right","lower-back","mid-back","upper-back","hip-front","hip-back","knee-front-left","knee-front-right","knee-back-left","knee-back-right"],instructions:["Kamerayı yandan konumlandırın","Rahat kıyafetler giyin, hareketi engellemesin","Testi yaparken ağrı olursa durun","Tek ayak üzerinde durun, bir yerden destek alarak 30 saniye boyunca parmak ucuna yükselip inin"],evaluationPoints:["Topuk tam kalkıyor mu?","Yorulunca titreme başlıyor mu?"]},{id:"heel-walk",name:"Topuk Üzerinde Yürüyüş (Heel Walk)",description:"Ayakkabılarını çıkar. Olduğun yerde veya odada ileri geri giderek, parmak uçlarını havaya kaldır ve sadece topukların üzerinde yürü",duration:"20 saniye",videoTips:"Önden veya yandan çekin, ayak pozisyonunu ve parmak yüksekliğini görebilmeli",relevantBodyAreas:["ankle-front-left","ankle-front-right","ankle-back-left","ankle-back-right","calf-back-left","calf-back-right","lower-back","hip-front","hip-back","knee-front-left","knee-front-right","knee-back-left","knee-back-right"],instructions:["Kamerayı önden veya yandan konumlandırın","Ayakkabılarını çıkar","Rahat kıyafetler giyin, hareketi engellemesin","Testi yaparken ağrı olursa durun","Olduğun yerde veya odada ileri geri giderek, parmak uçlarını havaya kaldır ve sadece topukların üzerinde yürü (20 saniye)"],evaluationPoints:['Parmak yüksekliği: Ayak ucunu yerden ne kadar kesebiliyor? (Düşükse "Düşük Ayak" riski veya ön kas zayıflığı)',"Ağrı ifadesi: Bunu yaparken kaval kemiği önünde ağrı oluyor mu? (Shin Splints şüphesi)"]}]},flexibility:{title:"Esneklik Testleri",icon:"📏",instructions:["Her testi dikkatli bir şekilde uygulayın","Hareketi yavaş yapın, zorlamayın","Ağrı olursa durun"],tests:[{id:"knee-wall-distance",name:"Diz-Duvar Mesafesi Testi",description:"Baldır ve ayak bileği esnekliği için altın standart test. Sadece cetvel yeterli!",duration:"2 dakika",testMode:"measurement",measurementUnit:"cm",measurementLabel:"Ayak Bileği",relevantBodyAreas:["ankle-front-left","ankle-front-right","ankle-back-left","ankle-back-right","calf-back-left","calf-back-right"],instructions:["Görsel talimatlara bakarak testi uygulayın."],evaluationCriteria:{good:{min:10,label:"Normal",color:"#10b981",icon:"✅",description:"Esneklik normal."},moderate:{min:5,max:9,label:"Hafif Kısıtlı",color:"#f59e0b",icon:"⚠️",description:"Germe önerilir."},poor:{max:4,label:"Kısıtlı",color:"#ef4444",icon:"❌",description:"Yoğun esneklik çalışması gerekli."}},evaluationPoints:[]},{id:"hamstring",name:"Hamstring Esneklik",description:"Bacak düz, öne eğilin, ne kadar uzanabiliyorsunuz?",duration:"15 saniye",videoTips:"Yandan çekin, eğilme açısını görebilmeli",relevantBodyAreas:["lower-back","hip-front","hip-back","thigh-back-left","thigh-back-right"],evaluationPoints:["Ne kadar eğilebildi?","Diz bükülüyor mu?","Ağrı var mı?"]}]},rom:{title:"Eklem Hareket Açıklığı (EHA)",icon:"📐",instructions:["Kamerayı eklemi net görecek şekilde konumlandırın","Hareketi yavaş ve kontrollü yapın"],tests:[{id:"ankle-dorsiflexion-rom",name:"Ayak Bileği Dorsifleksiyon EHA",description:"Ayak bileğinizi yukarı çekme hareketinizi kaydedin. Görsel açı rehberi ile karşılaştırın.",duration:"15 saniye",videoTips:"Yandan çekin, ayak ve baldır net görünsün",relevantBodyAreas:["ankle-front-left","ankle-front-right","ankle-back-left","ankle-back-right","calf-back-left","calf-back-right"],instructions:["Yere oturun, bacağınızı düz uzatın","Kamerayı yandan konumlandırın (ayak profili görünsün)","Ayak ucunuzu kendinize doğru çekin (dorsifleksiyon)","Maksimum noktada 3 saniye tutun","Hareketi yavaş ve kontrollü yapın"],evaluationPoints:["Ayak ucu baldıra yaklaşabiliyor mu? (Normal: 20°+)","Hareket sırasında ağrı var mı?","Sol-sağ fark var mı?","Topuk yerden kalkıyor mu?"],angleGuide:{title:"Dorsifleksiyon Açı Rehberi",ranges:[{angle:"20°+",status:"Normal",color:"#10b981",description:"Ayak ucu rahatça yukarı çıkıyor"},{angle:"10-20°",status:"Hafif Kısıtlı",color:"#f59e0b",description:"Ayak ucu biraz yukarı çıkıyor"},{angle:"<10°",status:"Kısıtlı",color:"#ef4444",description:"Ayak ucu çok az hareket ediyor"}]}},{id:"ankle-plantarflexion-rom",name:"Ayak Bileği Plantarfleksiyon EHA",description:"Ayak bileğinizi aşağı indirme (parmak ucuna basma) hareketinizi kaydedin.",duration:"15 saniye",videoTips:"Yandan çekin, ayak ve baldır net görünsün",relevantBodyAreas:["ankle-front-left","ankle-front-right","ankle-back-left","ankle-back-right","calf-back-left","calf-back-right"],instructions:["Yere oturun, bacağınızı düz uzatın","Kamerayı yandan konumlandırın","Ayak ucunuzu ileri doğru uzatın (bale hareketi gibi)","Maksimum noktada 3 saniye tutun"],evaluationPoints:["Ayak ucu tam uzanabiliyor mu? (Normal: 40-50°)","Hareket sırasında ağrı var mı?","Sol-sağ fark var mı?"],angleGuide:{title:"Plantarfleksiyon Açı Rehberi",ranges:[{angle:"40°+",status:"Normal",color:"#10b981",description:"Ayak ucu tam uzanıyor"},{angle:"30-40°",status:"Hafif Kısıtlı",color:"#f59e0b",description:"Ayak ucu biraz uzanıyor"},{angle:"<30°",status:"Kısıtlı",color:"#ef4444",description:"Ayak ucu az uzanıyor"}]}},{id:"shoulder",name:"Omuz EHA",description:"Kolu yukarı kaldırın, ne kadar açılabiliyor?",duration:"20 saniye",videoTips:"Önden çekin, omuz açısını görebilmeli",relevantBodyAreas:["shoulder-front-left","shoulder-front-right","shoulder-back-left","shoulder-back-right"],evaluationPoints:["Tam açılabiliyor mu?","Ağrı var mı?","Kısıtlılık var mı?"]}]},neurodynamic:{title:"Nörodinamik Testler (Sinir Germe)",icon:"🧠",instructions:["Testi yavaş ve kontrollü yapın","Ağrı veya uyuşma olursa hareketi durdurun","Her testte hissettiğinizi seçin"],tests:[{id:"tibial-nerve-test",name:"Tibial Sinir Testi",description:"Baldır arkası, topuk ve ayak tabanı ağrıları için. Tarsal Tünel Sendromu veya topuk dikeni sanılan sinir ağrılarını tespit eder.",duration:"30 saniye",testMode:"response",relevantBodyAreas:["ankle-front-left","ankle-front-right","ankle-back-left","ankle-back-right","calf-back-left","calf-back-right"],targetArea:"Baldırın tam arkası, topuk ve ayak tabanı",detailedSteps:[{step:1,title:"Başlangıç Pozisyonu",instruction:"Sırtüstü yat, kolların yanlarda rahat olsun."},{step:2,title:"Bacak Kaldırma",instruction:"Test edeceğin bacağı dizini BÜKMEDEN dümdüz yukarı kaldır. Diğer bacak yerde düz kalsın."},{step:3,title:"Ayağı Çekme",instruction:"Ayak ucunu kendine doğru çek (sanki ayak tabanıyla tavana bakmaya çalışıyorsun)."},{step:4,title:"Ayağı Döndürme",instruction:"Ayak tabanını DIŞA doğru çevirmeye çalış (ayak tabanı dışarı baksın)."},{step:5,title:"Bekle ve Hisset",instruction:"5 saniye bu pozisyonda kal. Ne hissediyorsun?"}],responseOptions:[{id:"normal",label:"Sadece gerilme hissettim",icon:"✅",result:"Negatif",description:"Normal kas esnekliği. Sinir sorunu yok.",color:"#10b981"},{id:"nerve",label:"Elektrik çarpması / Karıncalanma oldu",icon:"⚡",result:"Pozitif",description:"Tibial sinir hassasiyeti tespit edildi. Fizyoterapist değerlendirmesi önerilir.",color:"#f59e0b"},{id:"back",label:"Belimde ağrı oldu",icon:"🔴",result:"Dikkat",description:"Bel fıtığı riski olabilir. Doktor kontrolü önerilir.",color:"#ef4444"}]},{id:"peroneal-nerve-test",name:"Peroneal (Fibular) Sinir Testi",description:"Kaval kemiği önü, ayak bileği ön-dış kısmı ve ayak sırtı ağrıları için. Düşük ayak başlangıcı veya Shin Splints ile karışan sinir sorunlarını tespit eder.",duration:"30 saniye",testMode:"response",relevantBodyAreas:["ankle-front-left","ankle-front-right","ankle-back-left","ankle-back-right","calf-back-left","calf-back-right"],targetArea:"Kaval kemiği önü, ayak bileği ön-dış kısmı, ayak sırtı",detailedSteps:[{step:1,title:"Başlangıç Pozisyonu",instruction:"Sırtüstü yat, rahatla."},{step:2,title:"Bacak Kaldırma",instruction:"Test edeceğin bacağı dizini BÜKMEDEN düz kaldır."},{step:3,title:"Ayağı Uzatma",instruction:"Gaz pedalına basar gibi ayağını ileri uzat (bale hareketi gibi)."},{step:4,title:"Ayağı Döndürme",instruction:"Ayak tabanını İÇERİ doğru döndür (ayak tabanı diğer ayağa baksın)."},{step:5,title:"Bekle ve Hisset",instruction:"5 saniye bu pozisyonda kal. Ne hissediyorsun?"}],responseOptions:[{id:"normal",label:"Sadece gerilme hissettim",icon:"✅",result:"Negatif",description:"Normal kas esnekliği. Sinir sorunu yok.",color:"#10b981"},{id:"nerve",label:"Elektrik çarpması / Uyuşma oldu",icon:"⚡",result:"Pozitif",description:"Peroneal sinir hassasiyeti tespit edildi. Fizyoterapist değerlendirmesi önerilir.",color:"#f59e0b"},{id:"back",label:"Belimde ağrı oldu",icon:"🔴",result:"Dikkat",description:"Bel fıtığı riski olabilir. Doktor kontrolü önerilir.",color:"#ef4444"}]},{id:"sural-nerve-test",name:"Sural Sinir Testi",description:"Ayak bileği dış topuk kısmı ve baldır dış yan ağrıları için. Kronik burkulma sonrası geçmeyen ağrıların sinir kaynaklı olup olmadığını tespit eder.",duration:"30 saniye",testMode:"response",relevantBodyAreas:["ankle-front-left","ankle-front-right","ankle-back-left","ankle-back-right","calf-back-left","calf-back-right"],targetArea:"Ayak bileği dış topuk (lateral malleol) çevresi, baldır dış yanı",detailedSteps:[{step:1,title:"Başlangıç Pozisyonu",instruction:"Sırtüstü yat, rahatla."},{step:2,title:"Bacak Kaldırma",instruction:"Test edeceğin bacağı dizini BÜKMEDEN düz kaldır."},{step:3,title:"Ayağı Çekme",instruction:"Ayak ucunu kendine doğru çek (dorsifleksiyon)."},{step:4,title:"Ayağı Döndürme",instruction:"Ayak tabanını İÇERİ doğru döndür (ayak tabanı diğer ayağa baksın)."},{step:5,title:"Bekle ve Hisset",instruction:"5 saniye bu pozisyonda kal. Ne hissediyorsun?"}],responseOptions:[{id:"normal",label:"Sadece gerilme hissettim",icon:"✅",result:"Negatif",description:"Normal kas esnekliği. Sinir sorunu yok.",color:"#10b981"},{id:"nerve",label:"Elektrik çarpması / Yanma oldu",icon:"⚡",result:"Pozitif",description:"Sural sinir hassasiyeti tespit edildi. Kronik burkulma sonrası sinir hasarı olabilir.",color:"#f59e0b"},{id:"back",label:"Belimde ağrı oldu",icon:"🔴",result:"Dikkat",description:"Bel fıtığı riski olabilir. Doktor kontrolü önerilir.",color:"#ef4444"}]}]},balance:{title:"Denge Testleri",icon:"⚖️",instructions:["Güvenli bir alanda yapın","Yanınızda destek olsun"],tests:[{id:"tandem",name:"Tandem Yürüyüş",description:"Ayaklar bir önde bir arkada, düz çizgide yürüyün",duration:"30 saniye",videoTips:"Ardından çekin, yürüyüşü görebilmeli",evaluationPoints:["Dengede kalabiliyor mu?","Sallanıyor mu?","Kaç adım yürüyebildi?"]}]},movement:{title:"Hareket Analizi",icon:"🩺",instructions:["Günlük hareketleri yapın","Doğal hareket edin"],tests:[{id:"squat-daily",name:"Günlük Çömelme",description:"Yerden bir şey alır gibi çömelin",duration:"20 saniye",videoTips:"Yandan çekin, tüm hareket görünmeli",evaluationPoints:["Bel eğiliyor mu?","Dizler içe mi?","Asimetri var mı?"]}]}},fx=(r,v)=>r>=v.good.min?{value:r,status:"good",...v.good}:r>=v.moderate.min&&r<=v.moderate.max?{value:r,status:"moderate",...v.moderate}:{value:r,status:"poor",...v.poor},kg=({isOpen:r,onClose:v,testType:E,userPainAreas:d=[]})=>{var ke,Qe,ft,Za,bt,va,ka,ni,yt,ja,Xt,st;const[w,A]=g.useState("instructions"),[S,B]=g.useState(0),[b,p]=g.useState({}),[U,N]=g.useState({}),[G,L]=g.useState(!1),[Z,ie]=g.useState(0),[J,H]=g.useState(new Set),[K,ue]=g.useState({}),[$,Ye]=g.useState({}),[de,Q]=g.useState(!1),[Y,ne]=g.useState({}),re=g.useRef(null),Oe=g.useRef(null),ce=g.useRef([]),at=g.useRef(null);g.useRef(null),g.useRef(null);const ye=vg[E],Me=Vo.useMemo(()=>{if(!d||d.length===0)return ye.tests;const X=Ce=>Ce.includes("hip")?"hip":Ce.includes("thigh")?"thigh":Ce.includes("knee")?"knee":Ce.includes("ankle")?"ankle":Ce.includes("calf")?"calf":Ce,ae=d.map(X),xe=ye.tests.filter(Ce=>!Ce.relevantBodyAreas||Ce.relevantBodyAreas.length===0?!0:Ce.relevantBodyAreas.some(Ft=>{const Et=X(Ft);return ae.some(Na=>Et===Na?!0:Na.includes(Et)||Et.includes(Na))}));return xe.length===0?(console.log("Filtrelenmiş test bulunamadı, tüm testler gösteriliyor"),ye.tests):xe},[ye.tests,d]),_={...ye,tests:Me};if(_.tests.length===0)return l.jsx("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm px-4",children:l.jsx("div",{className:"bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden p-6",children:l.jsxs("div",{className:"text-center",children:[l.jsx("div",{className:"text-4xl mb-4",children:"⚠️"}),l.jsx("h3",{className:"text-xl font-bold text-gray-900 mb-2",children:"Test Bulunamadı"}),l.jsx("p",{className:"text-gray-600 mb-4",children:"Seçtiğiniz şikayet için uygun test bulunamadı. Lütfen farklı bir test kategorisi deneyin."}),l.jsx("button",{onClick:v,className:"w-full bg-blue-600 text-white py-3 rounded-xl font-semibold hover:bg-blue-700 transition",children:"Kapat"})]})})});const y=_.tests[S],te=Object.keys($).filter(X=>{var ae,xe;return((ae=$[X])==null?void 0:ae.left)||((xe=$[X])==null?void 0:xe.right)}).length,ge=Object.keys(b).length+te;if(S>=_.tests.length-1,!r)return null;const fe=async()=>{try{const X=await navigator.mediaDevices.getUserMedia({video:{width:{ideal:1280},height:{ideal:720},facingMode:"user"},audio:!1});L(!0),ie(0),re.current&&(re.current.srcObject=X,await new Promise(xe=>{re.current&&(re.current.onloadedmetadata=()=>{var Ce;(Ce=re.current)==null||Ce.play().then(()=>{console.log("Video oynatılıyor"),xe(!0)}).catch(Pe=>{console.error("Video play hatası:",Pe),xe(!1)})})}));const ae=new MediaRecorder(X,{mimeType:"video/webm;codecs=vp9"});ce.current=[],ae.ondataavailable=xe=>{xe.data.size>0&&ce.current.push(xe.data)},ae.onstop=()=>{const xe=new Blob(ce.current,{type:"video/webm"}),Ce=URL.createObjectURL(xe);p(Pe=>({...Pe,[y.id]:Ce})),N(Pe=>({...Pe,[y.id]:xe})),L(!1),ie(0),at.current&&clearInterval(at.current),X.getTracks().forEach(Pe=>Pe.stop())},Oe.current=ae,ae.start(),at.current=setInterval(()=>{ie(xe=>xe+1)},1e3)}catch(X){console.error("Kamera erişim hatası:",X),alert("Kameraya erişilemedi. Lütfen izin verin.")}},f=()=>{Oe.current&&G&&(Oe.current.stop(),re.current&&re.current.srcObject&&(re.current.srcObject.getTracks().forEach(ae=>ae.stop()),re.current.srcObject=null))},D=async()=>{const X=U[y.id];X&&(console.log("Video gönderiliyor:",y.id,X),O())},I=()=>{p(X=>{const ae={...X};return delete ae[y.id],ae}),N(X=>{const ae={...X};return delete ae[y.id],ae}),L(!1),ie(0),fe()},V=()=>{p(X=>{const ae={...X};return delete ae[y.id],ae}),N(X=>{const ae={...X};return delete ae[y.id],ae}),A("instructions")},oe=X=>{var xe;const ae=(xe=X.target.files)==null?void 0:xe[0];if(ae&&ae.type.startsWith("video/")){N(Pe=>({...Pe,[y.id]:ae}));const Ce=URL.createObjectURL(ae);p(Pe=>({...Pe,[y.id]:Ce})),A("review")}},me=()=>{H(X=>new Set([...X,y.id])),S<_.tests.length-1?(B(S+1),A("instructions")):A("completed")},O=()=>{S<_.tests.length-1?(B(S+1),A("instructions")):A("completed")},ee=()=>{A("completed")},P=()=>{if(ge<1){alert("En az 1 test tamamlamanız gerekiyor. Lütfen bir test yapın."),B(0),A("instructions");return}console.log("Videolar gönderiliyor:",U),console.log("Tamamlanan testler:",ge),console.log("Atlanan testler:",J.size),v()};return l.jsx("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm px-4",children:l.jsxs("div",{className:"bg-white w-full max-w-7xl rounded-3xl shadow-2xl overflow-hidden max-h-[95vh] flex flex-col",children:[l.jsxs("div",{className:"bg-gradient-to-r from-blue-600 to-purple-600 text-white p-6 flex justify-between items-center",children:[l.jsxs("div",{className:"flex items-center gap-3",children:[l.jsx("span",{className:"text-3xl",children:_.icon}),l.jsxs("div",{children:[l.jsx("h2",{className:"text-2xl font-bold",children:_.title}),l.jsxs("p",{className:"text-blue-100 text-sm",children:["Test ",S+1," / ",_.tests.length]})]})]}),l.jsx("button",{onClick:v,className:"text-white/80 hover:text-white transition",children:l.jsx(Xo,{size:24})})]}),l.jsxs("div",{className:"flex-1 overflow-y-auto p-6",children:[w==="instructions"&&l.jsxs("div",{className:`grid gap-6 ${y.testMode==="measurement"?"grid-cols-1":y.testMode==="response"||["squat","calf-raise","heel-walk","ankle-dorsiflexion-rom","ankle-plantarflexion-rom"].includes(y.id)?"grid-cols-1 lg:grid-cols-2":"grid-cols-1"}`,children:[y.testMode==="response"&&l.jsxs("div",{className:"space-y-4",children:[l.jsxs("div",{className:"bg-gradient-to-br from-purple-50 to-indigo-50 rounded-xl p-5 border border-purple-200",children:[l.jsxs("div",{className:"flex items-center gap-3 mb-3",children:[l.jsx("div",{className:"w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center text-white font-bold text-lg",children:S+1}),l.jsxs("div",{children:[l.jsx("h3",{className:"text-xl font-bold text-gray-900",children:y.name}),l.jsxs("p",{className:"text-gray-600 text-sm",children:["Süre: ",y.duration]})]})]}),l.jsx("p",{className:"text-gray-700 text-sm",children:y.description})]}),l.jsxs("div",{className:"bg-amber-50 border border-amber-200 rounded-xl p-4",children:[l.jsxs("div",{className:"flex items-center gap-2 mb-1",children:[l.jsx("span",{className:"text-lg",children:"🎯"}),l.jsx("span",{className:"font-bold text-amber-800",children:"Hedef Bölge"})]}),l.jsx("p",{className:"text-sm text-gray-700",children:y.targetArea})]}),l.jsxs("div",{className:"bg-white border-2 border-purple-200 rounded-xl p-4",children:[l.jsxs("h4",{className:"font-bold text-purple-700 mb-4 flex items-center gap-2",children:[l.jsx("span",{className:"text-lg",children:"📋"})," Adım Adım Uygulama"]}),l.jsx("div",{className:"space-y-3",children:(ke=y.detailedSteps)==null?void 0:ke.map(X=>l.jsxs("div",{className:"flex items-start gap-3",children:[l.jsx("div",{className:"w-7 h-7 bg-purple-600 text-white rounded-full flex items-center justify-center font-bold text-sm flex-shrink-0",children:X.step}),l.jsxs("div",{children:[l.jsx("p",{className:"font-semibold text-gray-800 text-sm",children:X.title}),l.jsx("p",{className:"text-sm text-gray-600",children:X.instruction})]})]},X.step))})]})]}),y.testMode!=="measurement"&&y.testMode!=="response"&&l.jsxs("div",{className:"space-y-4",children:[l.jsxs("div",{className:"bg-gradient-to-br from-purple-50 to-blue-50 rounded-xl p-5 border border-purple-200",children:[l.jsxs("div",{className:"flex items-center gap-3 mb-3",children:[l.jsx("div",{className:"w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center text-white font-bold text-lg",children:S+1}),l.jsxs("div",{children:[l.jsx("h3",{className:"text-xl font-bold text-gray-900",children:y.name}),l.jsxs("p",{className:"text-gray-600 text-sm",children:["Süre: ",y.duration]})]})]}),l.jsx("p",{className:"text-gray-700 text-base mb-3",children:y.description}),y.videoTips&&l.jsxs("div",{className:"bg-white rounded-lg p-3 border border-purple-100",children:[l.jsx("p",{className:"text-sm font-semibold text-purple-700 mb-1",children:"📹 Video İpuçları:"}),l.jsx("p",{className:"text-sm text-gray-600",children:y.videoTips})]})]}),l.jsxs("div",{className:"bg-blue-50 border-l-4 border-blue-600 p-4 rounded-lg",children:[l.jsx("h3",{className:"font-bold text-base mb-3",children:"📋 Genel Talimatlar"}),l.jsx("ul",{className:"space-y-2 text-sm mb-3",children:(y.instructions||_.instructions).map((X,ae)=>l.jsxs("li",{className:"flex items-start gap-2",children:[l.jsx("span",{className:"text-blue-600 mt-1",children:"•"}),l.jsx("span",{children:X})]},ae))}),l.jsx("div",{className:"bg-yellow-50 border border-yellow-200 rounded p-3 mt-3",children:l.jsxs("p",{className:"text-sm text-yellow-800",children:[l.jsx("strong",{children:"💡 Önemli:"})," En az ",l.jsx("strong",{children:"1 test"})," yeterlidir. Ağrı olursa durun."]})})]})]}),y.id==="squat"&&l.jsx("div",{className:"flex flex-col",children:l.jsxs("div",{className:"bg-white border-2 border-purple-200 rounded-xl p-4 shadow-lg flex-1 flex flex-col",children:[l.jsx("h4",{className:"text-lg font-bold text-gray-900 mb-4 text-center",children:"🎥 Squat Nasıl Yapılır?"}),l.jsxs("div",{className:"relative bg-black rounded-lg overflow-hidden aspect-video flex items-center justify-center",children:[l.jsxs("video",{autoPlay:!0,loop:!0,muted:!0,playsInline:!0,className:"w-full h-full object-contain",onError:()=>{},children:[l.jsx("source",{src:"/animations/squat-animation.mp4",type:"video/mp4"}),l.jsx("source",{src:"/animations/squat-animation.webm",type:"video/webm"})]}),l.jsx("div",{className:"absolute inset-0 flex items-center justify-center bg-gradient-to-br from-purple-900 to-blue-900 text-white",children:l.jsxs("div",{className:"text-center p-6",children:[l.jsx("p",{className:"text-4xl mb-3",children:"🏋️"}),l.jsx("p",{className:"text-sm opacity-90",children:"Squat animasyonu yüklenecek"}),l.jsx("p",{className:"text-xs opacity-70 mt-2",children:"public/animations/squat-animation.mp4"})]})})]}),l.jsx("p",{className:"text-xs text-gray-500 text-center mt-3",children:"Video otomatik olarak tekrar eder"})]})}),y.id==="calf-raise"&&l.jsx("div",{className:"flex flex-col",children:l.jsxs("div",{className:"bg-white border-2 border-purple-200 rounded-xl p-4 shadow-lg flex-1 flex flex-col",children:[l.jsx("h4",{className:"text-lg font-bold text-gray-900 mb-4 text-center",children:"🎥 Topuk Yükseltme Nasıl Yapılır?"}),l.jsxs("div",{className:"relative bg-black rounded-lg overflow-hidden aspect-video flex items-center justify-center",children:[l.jsxs("video",{autoPlay:!0,loop:!0,muted:!0,playsInline:!0,className:"w-full h-full object-contain",onError:()=>{},children:[l.jsx("source",{src:"/animations/calf-raise-animation.mp4",type:"video/mp4"}),l.jsx("source",{src:"/animations/calf-raise-animation.webm",type:"video/webm"})]}),l.jsx("div",{className:"absolute inset-0 flex items-center justify-center bg-gradient-to-br from-purple-900 to-blue-900 text-white",children:l.jsxs("div",{className:"text-center p-6",children:[l.jsx("p",{className:"text-4xl mb-3",children:"🦵"}),l.jsx("p",{className:"text-sm opacity-90",children:"Topuk Yükseltme animasyonu yüklenecek"}),l.jsx("p",{className:"text-xs opacity-70 mt-2",children:"public/animations/calf-raise-animation.mp4"})]})})]}),l.jsx("p",{className:"text-xs text-gray-500 text-center mt-3",children:"Video otomatik olarak tekrar eder"})]})}),y.id==="heel-walk"&&l.jsx("div",{className:"flex flex-col",children:l.jsxs("div",{className:"bg-white border-2 border-purple-200 rounded-xl p-4 shadow-lg flex-1 flex flex-col",children:[l.jsx("h4",{className:"text-lg font-bold text-gray-900 mb-4 text-center",children:"🎥 Topuk Üzerinde Yürüyüş Nasıl Yapılır?"}),l.jsxs("div",{className:"relative bg-black rounded-lg overflow-hidden aspect-video flex items-center justify-center",children:[l.jsxs("video",{autoPlay:!0,loop:!0,muted:!0,playsInline:!0,className:"w-full h-full object-contain",onError:()=>{},children:[l.jsx("source",{src:"/animations/heel-walk-animation.mp4",type:"video/mp4"}),l.jsx("source",{src:"/animations/heel-walk-animation.webm",type:"video/webm"})]}),l.jsx("div",{className:"absolute inset-0 flex items-center justify-center bg-gradient-to-br from-purple-900 to-blue-900 text-white",children:l.jsxs("div",{className:"text-center p-6",children:[l.jsx("p",{className:"text-4xl mb-3",children:"🚶"}),l.jsx("p",{className:"text-sm opacity-90",children:"Topuk Üzerinde Yürüyüş animasyonu yüklenecek"}),l.jsx("p",{className:"text-xs opacity-70 mt-2",children:"public/animations/heel-walk-animation.mp4"})]})})]}),l.jsx("p",{className:"text-xs text-gray-500 text-center mt-3",children:"Video otomatik olarak tekrar eder"})]})}),y.id==="ankle-dorsiflexion-rom"&&l.jsxs("div",{className:"flex flex-col gap-4",children:[l.jsxs("div",{className:"bg-white border-2 border-cyan-200 rounded-xl p-4 shadow-lg",children:[l.jsx("h4",{className:"text-lg font-bold text-gray-900 mb-4 text-center",children:"🦶 Dorsifleksiyon Nasıl Yapılır?"}),l.jsxs("div",{className:"relative bg-gradient-to-br from-cyan-900 to-blue-900 rounded-lg overflow-hidden aspect-video flex items-center justify-center",children:[l.jsx("video",{autoPlay:!0,loop:!0,muted:!0,playsInline:!0,className:"w-full h-full object-contain",children:l.jsx("source",{src:"/animations/dorsiflexion.mp4",type:"video/mp4"})}),l.jsx("div",{className:"absolute inset-0 flex items-center justify-center text-white",children:l.jsxs("div",{className:"text-center p-6",children:[l.jsx("p",{className:"text-5xl mb-3",children:"🦶⬆️"}),l.jsx("p",{className:"text-lg font-semibold",children:"Ayak Ucunu Yukarı Çek"}),l.jsx("p",{className:"text-sm opacity-70 mt-2",children:"Video buraya eklenecek"})]})})]}),l.jsx("p",{className:"text-xs text-gray-500 text-center mt-3",children:"Video otomatik olarak tekrar eder"})]}),l.jsxs("div",{className:"bg-gradient-to-br from-cyan-50 to-blue-50 border-2 border-cyan-200 rounded-xl p-4",children:[l.jsxs("h4",{className:"font-bold text-cyan-700 mb-3 flex items-center gap-2",children:[l.jsx("span",{className:"text-xl",children:"📐"})," Açı Rehberi"]}),l.jsxs("div",{className:"space-y-2",children:[l.jsxs("div",{className:"flex items-center gap-3 p-3 bg-white rounded-lg",children:[l.jsx("div",{className:"w-14 h-10 bg-green-500 rounded flex items-center justify-center text-white font-bold text-sm",children:"20°+"}),l.jsxs("div",{className:"flex-1",children:[l.jsx("span",{className:"font-semibold text-green-600",children:"Normal"}),l.jsx("span",{className:"text-sm text-gray-600 ml-2",children:"Ayak ucu rahatça yukarı çıkıyor"})]}),l.jsx("span",{className:"text-xl",children:"✅"})]}),l.jsxs("div",{className:"flex items-center gap-3 p-3 bg-white rounded-lg",children:[l.jsx("div",{className:"w-14 h-10 bg-yellow-500 rounded flex items-center justify-center text-white font-bold text-sm",children:"10-20°"}),l.jsxs("div",{className:"flex-1",children:[l.jsx("span",{className:"font-semibold text-yellow-600",children:"Hafif Kısıtlı"}),l.jsx("span",{className:"text-sm text-gray-600 ml-2",children:"Biraz yukarı çıkıyor"})]}),l.jsx("span",{className:"text-xl",children:"⚠️"})]}),l.jsxs("div",{className:"flex items-center gap-3 p-3 bg-white rounded-lg",children:[l.jsx("div",{className:"w-14 h-10 bg-red-500 rounded flex items-center justify-center text-white font-bold text-sm",children:"<10°"}),l.jsxs("div",{className:"flex-1",children:[l.jsx("span",{className:"font-semibold text-red-600",children:"Kısıtlı"}),l.jsx("span",{className:"text-sm text-gray-600 ml-2",children:"Çok az hareket"})]}),l.jsx("span",{className:"text-xl",children:"❌"})]})]})]})]}),y.id==="ankle-plantarflexion-rom"&&l.jsxs("div",{className:"flex flex-col gap-4",children:[l.jsxs("div",{className:"bg-white border-2 border-cyan-200 rounded-xl p-4 shadow-lg",children:[l.jsx("h4",{className:"text-lg font-bold text-gray-900 mb-4 text-center",children:"🦶 Plantarfleksiyon Nasıl Yapılır?"}),l.jsxs("div",{className:"relative bg-gradient-to-br from-cyan-900 to-blue-900 rounded-lg overflow-hidden aspect-video flex items-center justify-center",children:[l.jsx("video",{autoPlay:!0,loop:!0,muted:!0,playsInline:!0,className:"w-full h-full object-contain",children:l.jsx("source",{src:"/animations/plantarflexion.mp4",type:"video/mp4"})}),l.jsx("div",{className:"absolute inset-0 flex items-center justify-center text-white",children:l.jsxs("div",{className:"text-center p-6",children:[l.jsx("p",{className:"text-5xl mb-3",children:"🦶⬇️"}),l.jsx("p",{className:"text-lg font-semibold",children:"Ayak Ucunu Aşağı Uzat"}),l.jsx("p",{className:"text-sm opacity-70 mt-2",children:"Video buraya eklenecek"})]})})]}),l.jsx("p",{className:"text-xs text-gray-500 text-center mt-3",children:"Video otomatik olarak tekrar eder"})]}),l.jsxs("div",{className:"bg-gradient-to-br from-cyan-50 to-blue-50 border-2 border-cyan-200 rounded-xl p-4",children:[l.jsxs("h4",{className:"font-bold text-cyan-700 mb-3 flex items-center gap-2",children:[l.jsx("span",{className:"text-xl",children:"📐"})," Açı Rehberi"]}),l.jsxs("div",{className:"space-y-2",children:[l.jsxs("div",{className:"flex items-center gap-3 p-3 bg-white rounded-lg",children:[l.jsx("div",{className:"w-14 h-10 bg-green-500 rounded flex items-center justify-center text-white font-bold text-sm",children:"40°+"}),l.jsxs("div",{className:"flex-1",children:[l.jsx("span",{className:"font-semibold text-green-600",children:"Normal"}),l.jsx("span",{className:"text-sm text-gray-600 ml-2",children:"Ayak ucu tam uzanıyor"})]}),l.jsx("span",{className:"text-xl",children:"✅"})]}),l.jsxs("div",{className:"flex items-center gap-3 p-3 bg-white rounded-lg",children:[l.jsx("div",{className:"w-14 h-10 bg-yellow-500 rounded flex items-center justify-center text-white font-bold text-sm",children:"30-40°"}),l.jsxs("div",{className:"flex-1",children:[l.jsx("span",{className:"font-semibold text-yellow-600",children:"Hafif Kısıtlı"}),l.jsx("span",{className:"text-sm text-gray-600 ml-2",children:"Biraz uzanıyor"})]}),l.jsx("span",{className:"text-xl",children:"⚠️"})]}),l.jsxs("div",{className:"flex items-center gap-3 p-3 bg-white rounded-lg",children:[l.jsx("div",{className:"w-14 h-10 bg-red-500 rounded flex items-center justify-center text-white font-bold text-sm",children:"<30°"}),l.jsxs("div",{className:"flex-1",children:[l.jsx("span",{className:"font-semibold text-red-600",children:"Kısıtlı"}),l.jsx("span",{className:"text-sm text-gray-600 ml-2",children:"Az uzanıyor"})]}),l.jsx("span",{className:"text-xl",children:"❌"})]})]})]})]}),y.testMode==="response"&&l.jsxs("div",{className:"flex flex-col gap-4",children:[l.jsxs("div",{className:"bg-white border-2 border-purple-200 rounded-xl p-4 shadow-lg",children:[l.jsx("h4",{className:"text-lg font-bold text-gray-900 mb-3 text-center",children:"🎥 Nasıl Yapılır?"}),l.jsxs("div",{className:"relative bg-gradient-to-br from-purple-900 to-indigo-900 rounded-lg overflow-hidden aspect-video flex items-center justify-center",children:[l.jsx("video",{autoPlay:!0,loop:!0,muted:!0,playsInline:!0,className:"w-full h-full object-contain",children:l.jsx("source",{src:`/animations/${y.id}.mp4`,type:"video/mp4"})}),l.jsx("div",{className:"absolute inset-0 flex items-center justify-center text-white",children:l.jsxs("div",{className:"text-center p-6",children:[l.jsx("p",{className:"text-5xl mb-3",children:"🦵⬆️"}),l.jsx("p",{className:"text-lg font-semibold",children:"Bacak Kaldırma + Ayak Hareketi"}),l.jsx("p",{className:"text-sm opacity-70 mt-2",children:"Video buraya eklenecek"})]})})]})]}),l.jsxs("div",{className:"bg-gradient-to-br from-purple-50 to-indigo-50 border-2 border-purple-300 rounded-xl p-4",children:[l.jsx("h4",{className:"font-bold text-purple-700 mb-3 text-center",children:"🤔 Testi yaptıktan sonra ne hissettiniz?"}),l.jsx("div",{className:"space-y-2",children:(Qe=y.responseOptions)==null?void 0:Qe.map(X=>{var ae,xe;return l.jsx("button",{onClick:()=>{ne(Ce=>({...Ce,[y.id]:{responseId:X.id,result:X.result,description:X.description,color:X.color}}))},className:`w-full p-3 rounded-lg border-2 text-left transition-all ${((ae=Y[y.id])==null?void 0:ae.responseId)===X.id?"border-purple-500 bg-white shadow-md":"border-gray-200 bg-white hover:border-purple-300"}`,children:l.jsxs("div",{className:"flex items-center gap-3",children:[l.jsx("span",{className:"text-2xl",children:X.icon}),l.jsx("span",{className:"font-medium text-gray-800",children:X.label}),((xe=Y[y.id])==null?void 0:xe.responseId)===X.id&&l.jsx(ai,{size:20,className:"text-purple-600 ml-auto"})]})},X.id)})}),Y[y.id]&&l.jsx("div",{className:"mt-3 p-3 rounded-lg text-sm",style:{backgroundColor:Y[y.id].color+"20",borderLeft:`4px solid ${Y[y.id].color}`},children:l.jsx("p",{className:"text-gray-700",children:Y[y.id].description})}),l.jsxs("div",{className:"flex gap-2 mt-4",children:[l.jsxs("button",{onClick:()=>{Y[y.id]&&(S<Me.length-1?B(S+1):ee())},disabled:!Y[y.id],className:"flex-1 bg-gradient-to-r from-green-600 to-emerald-600 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2",children:[l.jsx(ai,{size:18}),S<Me.length-1?"Kaydet ve İlerle":"Tamamla"]}),l.jsx("button",{onClick:me,className:"px-5 bg-white border-2 border-gray-200 text-gray-600 py-3 rounded-xl font-semibold hover:bg-gray-50 transition",children:"Atla"})]})]})]}),y.testMode==="measurement"?l.jsx("div",{className:"lg:col-span-2",children:l.jsxs("div",{className:"grid lg:grid-cols-2 gap-6",children:[l.jsxs("div",{className:"space-y-4",children:[l.jsxs("div",{className:"bg-white border-2 border-purple-200 rounded-xl p-4 shadow-lg",children:[l.jsx("h4",{className:"text-lg font-bold text-gray-900 mb-4 text-center",children:"🎥 Diz-Duvar Mesafesi Testi"}),l.jsxs("div",{className:"relative bg-gradient-to-br from-purple-900 to-blue-900 rounded-lg overflow-hidden aspect-video flex items-center justify-center",children:[l.jsx("video",{autoPlay:!0,loop:!0,muted:!0,playsInline:!0,className:"w-full h-full object-contain absolute inset-0",style:{display:"none"},children:l.jsx("source",{src:"/animations/knee-wall-test.mp4",type:"video/mp4"})}),l.jsxs("div",{className:"text-center text-white p-6",children:[l.jsx("p",{className:"text-5xl mb-3",children:"📏"}),l.jsx("p",{className:"text-lg font-semibold",children:"Diz-Duvar Mesafesi Testi"}),l.jsx("p",{className:"text-sm opacity-70 mt-2",children:"Video veya görsel buraya eklenecek"})]})]})]}),l.jsxs("div",{className:"bg-blue-50 border-l-4 border-blue-600 p-5 rounded-lg",children:[l.jsx("h3",{className:"font-bold text-base mb-4 text-blue-800",children:"📋 Adım Adım Uygulama"}),l.jsxs("div",{className:"space-y-4",children:[l.jsxs("div",{className:"flex items-start gap-3",children:[l.jsx("span",{className:"w-7 h-7 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0",children:"1"}),l.jsxs("div",{children:[l.jsx("p",{className:"font-semibold text-gray-800",children:"Hazırlık"}),l.jsx("p",{className:"text-sm text-gray-600",children:"Yüzünü duvara dön. Ayakkabı ve çoraplarını çıkar. Yanına cetvel veya mezura al."})]})]}),l.jsxs("div",{className:"flex items-start gap-3",children:[l.jsx("span",{className:"w-7 h-7 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0",children:"2"}),l.jsxs("div",{children:[l.jsx("p",{className:"font-semibold text-gray-800",children:"Pozisyon Al"}),l.jsxs("p",{className:"text-sm text-gray-600",children:["Test edeceğin ayağının ",l.jsx("strong",{children:"başparmağını duvara değdir"}),". Diğer ayağını denge için geriye al."]})]})]}),l.jsxs("div",{className:"flex items-start gap-3",children:[l.jsx("span",{className:"w-7 h-7 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0",children:"3"}),l.jsxs("div",{children:[l.jsx("p",{className:"font-semibold text-gray-800",children:"Hareketi Yap"}),l.jsxs("p",{className:"text-sm text-gray-600",children:[l.jsx("strong",{children:"Topuğunu yerden kaldırmadan"})," dizini bükerek duvara değdirmeye çalış. Kolay gelirse ayağı geriye kaydır."]})]})]}),l.jsxs("div",{className:"flex items-start gap-3",children:[l.jsx("span",{className:"w-7 h-7 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0",children:"4"}),l.jsxs("div",{children:[l.jsx("p",{className:"font-semibold text-gray-800",children:"Ölç ve Kaydet"}),l.jsxs("p",{className:"text-sm text-gray-600",children:["Topuğun kalkmadan dizin değebildiği son noktada dur. ",l.jsx("strong",{children:"Parmak ucu - duvar mesafesini"})," cetvel ile ölç."]})]})]})]}),l.jsx("div",{className:"mt-4 bg-yellow-50 border border-yellow-300 rounded-lg p-3",children:l.jsxs("p",{className:"text-sm text-yellow-800",children:[l.jsx("strong",{children:"⚠️ Dikkat:"})," Topuğun yerden kalkarsa, ayağını biraz duvara yaklaştır ve tekrar dene."]})})]})]}),l.jsxs("div",{className:"bg-white rounded-2xl p-6 border-2 border-green-200 shadow-lg h-fit",children:[l.jsx("h4",{className:"text-lg font-bold text-gray-800 mb-5",children:"📏 Ölçüm Sonuçlarını Gir"}),l.jsxs("div",{className:"space-y-4",children:[l.jsxs("div",{className:"bg-gray-50 rounded-xl p-4",children:[l.jsxs("label",{className:"block text-sm font-semibold text-gray-600 mb-2",children:["🦶 Sol ",y.measurementLabel||"Ayak Bileği"]}),l.jsxs("div",{className:"flex items-center gap-3",children:[l.jsx("input",{type:"number",min:"0",max:y.measurementUnit==="°"?60:25,step:y.measurementUnit==="°"?1:.5,placeholder:"0",value:((ft=K[y.id])==null?void 0:ft.left)||"",onChange:X=>ue(ae=>({...ae,[y.id]:{...ae[y.id],left:X.target.value}})),className:"w-24 px-4 py-3 border-2 border-gray-300 rounded-xl text-2xl font-bold text-center focus:outline-none focus:border-purple-500"}),l.jsx("span",{className:"text-xl text-gray-500 font-semibold",children:y.measurementUnit||"cm"}),((Za=$[y.id])==null?void 0:Za.left)&&l.jsx("span",{className:"text-2xl",children:$[y.id].left.icon})]})]}),l.jsxs("div",{className:"bg-gray-50 rounded-xl p-4",children:[l.jsxs("label",{className:"block text-sm font-semibold text-gray-600 mb-2",children:["🦶 Sağ ",y.measurementLabel||"Ayak Bileği"]}),l.jsxs("div",{className:"flex items-center gap-3",children:[l.jsx("input",{type:"number",min:"0",max:y.measurementUnit==="°"?60:25,step:y.measurementUnit==="°"?1:.5,placeholder:"0",value:((bt=K[y.id])==null?void 0:bt.right)||"",onChange:X=>ue(ae=>({...ae,[y.id]:{...ae[y.id],right:X.target.value}})),className:"w-24 px-4 py-3 border-2 border-gray-300 rounded-xl text-2xl font-bold text-center focus:outline-none focus:border-purple-500"}),l.jsx("span",{className:"text-xl text-gray-500 font-semibold",children:y.measurementUnit||"cm"}),((va=$[y.id])==null?void 0:va.right)&&l.jsx("span",{className:"text-2xl",children:$[y.id].right.icon})]})]})]}),(((ka=$[y.id])==null?void 0:ka.left)||((ni=$[y.id])==null?void 0:ni.right))&&l.jsxs("div",{className:"mt-4 space-y-2",children:[((yt=$[y.id])==null?void 0:yt.left)&&l.jsx("div",{className:"p-3 rounded-lg",style:{backgroundColor:$[y.id].left.color+"15"},children:l.jsxs("span",{className:"font-semibold",style:{color:$[y.id].left.color},children:["Sol: ",$[y.id].left.label," - ",$[y.id].left.description]})}),((ja=$[y.id])==null?void 0:ja.right)&&l.jsx("div",{className:"p-3 rounded-lg",style:{backgroundColor:$[y.id].right.color+"15"},children:l.jsxs("span",{className:"font-semibold",style:{color:$[y.id].right.color},children:["Sağ: ",$[y.id].right.label," - ",$[y.id].right.description]})})]}),l.jsxs("div",{className:"mt-5 bg-gray-100 rounded-lg p-3",children:[l.jsx("p",{className:"text-xs font-semibold text-gray-600 mb-2",children:"📊 Değerlendirme:"}),l.jsxs("div",{className:"flex items-center justify-between text-xs",children:[l.jsxs("span",{className:"flex items-center gap-1",children:[l.jsx("span",{className:"w-3 h-3 bg-red-500 rounded-full"})," <5cm Kısıtlı"]}),l.jsxs("span",{className:"flex items-center gap-1",children:[l.jsx("span",{className:"w-3 h-3 bg-yellow-500 rounded-full"})," 5-9cm Hafif"]}),l.jsxs("span",{className:"flex items-center gap-1",children:[l.jsx("span",{className:"w-3 h-3 bg-green-500 rounded-full"})," 10+cm Normal"]})]})]}),l.jsxs("div",{className:"mt-5 flex gap-3",children:[l.jsx("button",{onClick:()=>{var Ce,Pe;const X=parseFloat(((Ce=K[y.id])==null?void 0:Ce.left)||"0"),ae=parseFloat(((Pe=K[y.id])==null?void 0:Pe.right)||"0"),xe=y.evaluationCriteria;if(xe&&(X>0||ae>0)){const Ft={};X>0&&(Ft.left=fx(X,xe)),ae>0&&(Ft.right=fx(ae,xe)),Ye(Et=>({...Et,[y.id]:Ft}))}},disabled:!((Xt=K[y.id])!=null&&Xt.left)&&!((st=K[y.id])!=null&&st.right),className:"flex-1 bg-gradient-to-r from-green-500 to-teal-500 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition disabled:opacity-50",children:"✓ Değerlendir"}),l.jsx("button",{onClick:S<Me.length-1?()=>{B(S+1),A("instructions")}:ee,className:"px-5 bg-purple-100 text-purple-600 py-3 rounded-xl font-semibold hover:bg-purple-200 transition",children:S<Me.length-1?"İleri →":"Bitir"})]})]})]})}):y.testMode!=="response"?l.jsxs("div",{className:"flex flex-col gap-3",children:[l.jsxs("div",{className:"flex gap-3",children:[l.jsxs("button",{onClick:()=>A("recording"),className:"flex-1 bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition flex items-center justify-center gap-2",children:[l.jsx(tm,{size:20}),"Kamera ile Kaydet"]}),l.jsxs("button",{onClick:()=>A("upload"),className:"flex-1 bg-white border-2 border-blue-600 text-blue-600 py-3 rounded-xl font-semibold hover:bg-blue-50 transition flex items-center justify-center gap-2",children:[l.jsx(em,{size:20}),"Video Yükle"]})]}),l.jsx("div",{className:"flex gap-3",children:S<Me.length-1?l.jsx("button",{onClick:me,className:"flex-1 bg-gray-100 text-gray-600 py-3 rounded-xl font-semibold hover:bg-gray-200 transition",children:"Bu Testi Atla"}):l.jsx("button",{onClick:ee,className:"flex-1 bg-gray-100 text-gray-600 py-3 rounded-xl font-semibold hover:bg-gray-200 transition",children:ge>0?"Testleri Tamamla":"Bu Testi Atla"})})]}):null]}),w==="recording"&&l.jsxs("div",{className:"space-y-4",children:[l.jsxs("div",{className:"bg-gray-900 rounded-2xl overflow-hidden relative",style:{minHeight:"500px"},children:[l.jsx("video",{ref:re,autoPlay:!0,muted:!0,playsInline:!0,style:{width:"100%",height:"auto",minHeight:"500px",maxHeight:"600px",backgroundColor:"#000",display:"block",objectFit:"cover"},onLoadedMetadata:X=>{const ae=X.currentTarget;console.log("Video metadata yüklendi:",ae.videoWidth,ae.videoHeight),ae.play().catch(xe=>console.error("Play hatası:",xe))},onError:X=>{console.error("Video hatası:",X)},onCanPlay:()=>{console.log("Video oynatılabilir")}}),G&&l.jsxs("div",{className:"absolute top-4 left-4 bg-red-600 text-white px-4 py-2 rounded-full flex items-center gap-2 z-20",children:[l.jsx("div",{className:"w-3 h-3 bg-white rounded-full animate-pulse"}),l.jsxs("span",{className:"font-semibold",children:["Kayıt: ",Math.floor(Z/60),":",(Z%60).toString().padStart(2,"0")]})]})]}),G&&l.jsxs("div",{className:"flex gap-3",children:[l.jsxs("button",{onClick:f,className:"flex-1 bg-gray-600 text-white py-3 rounded-xl font-semibold hover:bg-gray-700 transition flex items-center justify-center gap-2",children:[l.jsx(uh,{size:20}),"Kaydı Durdur"]}),l.jsx("button",{onClick:()=>{f(),A("instructions")},className:"px-6 bg-gray-200 text-gray-700 py-3 rounded-xl font-semibold hover:bg-gray-300 transition",children:"İptal"})]}),!G&&!b[y.id]&&l.jsxs("div",{className:"flex gap-3",children:[l.jsxs("button",{onClick:fe,className:"flex-1 bg-red-600 text-white py-3 rounded-xl font-semibold hover:bg-red-700 transition flex items-center justify-center gap-2",children:[l.jsx(tm,{size:20}),"Kaydı Başlat"]}),l.jsx("button",{onClick:()=>A("instructions"),className:"px-6 bg-gray-200 text-gray-700 py-3 rounded-xl font-semibold hover:bg-gray-300 transition",children:"İptal"})]}),!G&&b[y.id]&&l.jsxs("div",{className:"bg-green-50 border border-green-200 rounded-xl p-5",children:[l.jsxs("div",{className:"flex items-center gap-2 text-green-700 mb-4",children:[l.jsx(ai,{size:24}),l.jsx("span",{className:"font-semibold text-lg",children:"Video kaydedildi!"})]}),l.jsxs("div",{className:"flex gap-3",children:[l.jsxs("button",{onClick:()=>A("review"),className:"flex-1 bg-blue-600 text-white py-3 rounded-xl font-semibold hover:bg-blue-700 transition flex items-center justify-center gap-2",children:[l.jsx(mh,{size:20}),"İncele"]}),l.jsxs("button",{onClick:I,className:"flex-1 bg-gray-200 text-gray-700 py-3 rounded-xl font-semibold hover:bg-gray-300 transition flex items-center justify-center gap-2",children:[l.jsx(Io,{size:20}),"Tekrar Kaydet"]}),l.jsxs("button",{onClick:D,className:"flex-1 bg-gradient-to-r from-green-600 to-emerald-600 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition flex items-center justify-center gap-2",children:[l.jsx(ai,{size:20}),"Gönder"]})]}),l.jsxs("button",{onClick:V,className:"w-full bg-red-600 text-white py-3 rounded-xl font-semibold hover:bg-red-700 transition flex items-center justify-center gap-2 mt-3",children:[l.jsx(Ko,{size:20}),"Kaydedilen Videoyu Sil"]})]})]}),w==="upload"&&l.jsxs("div",{className:"space-y-4",children:[l.jsxs("div",{className:"border-2 border-dashed border-blue-300 rounded-2xl p-12 text-center bg-blue-50",children:[l.jsx(em,{size:48,className:"mx-auto text-blue-600 mb-4"}),l.jsx("h3",{className:"text-xl font-bold text-gray-900 mb-2",children:"Video Dosyası Yükle"}),l.jsx("p",{className:"text-gray-600 mb-6",children:"MP4, MOV veya WebM formatında video yükleyin"}),l.jsxs("label",{className:"inline-block bg-blue-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-blue-700 transition cursor-pointer",children:["Dosya Seç",l.jsx("input",{type:"file",accept:"video/*",onChange:oe,className:"hidden"})]})]}),l.jsx("button",{onClick:()=>A("instructions"),className:"w-full bg-gray-200 text-gray-700 py-2 rounded-xl font-semibold hover:bg-gray-300 transition",children:"Geri"})]}),w==="review"&&b[y.id]&&l.jsxs("div",{className:"space-y-4",children:[l.jsxs("button",{onClick:()=>A("instructions"),className:"flex items-center gap-2 text-gray-600 hover:text-gray-900 transition mb-2",children:[l.jsx(Q0,{size:20}),l.jsx("span",{className:"font-semibold",children:"Geri"})]}),l.jsx("div",{className:"bg-gray-900 rounded-2xl overflow-hidden",children:l.jsx("video",{src:b[y.id],controls:!0,className:"w-full h-auto max-h-[400px]"})}),l.jsxs("div",{className:"bg-yellow-50 border border-yellow-200 rounded-xl p-4",children:[l.jsxs("div",{className:"flex items-center gap-2 text-yellow-700 mb-3",children:[l.jsx(ah,{size:20}),l.jsx("span",{className:"font-semibold",children:"Değerlendirme Kriterleri"})]}),l.jsx("ul",{className:"space-y-2 text-sm",children:y.evaluationPoints.map((X,ae)=>l.jsxs("li",{className:"flex items-start gap-2",children:[l.jsx("span",{className:"text-yellow-600 mt-1",children:"•"}),l.jsx("span",{className:"text-gray-700",children:X})]},ae))})]}),y.angleGuide&&l.jsxs("div",{className:"bg-gradient-to-br from-blue-50 to-cyan-50 border border-blue-200 rounded-xl p-4",children:[l.jsxs("div",{className:"flex items-center gap-2 text-blue-700 mb-3",children:[l.jsx("span",{className:"text-xl",children:"📐"}),l.jsx("span",{className:"font-semibold",children:y.angleGuide.title})]}),l.jsx("div",{className:"space-y-2",children:y.angleGuide.ranges.map((X,ae)=>l.jsxs("div",{className:"flex items-center gap-3 p-3 rounded-lg",style:{backgroundColor:X.color+"15"},children:[l.jsx("div",{className:"w-12 h-12 rounded-lg flex items-center justify-center font-bold text-white text-sm",style:{backgroundColor:X.color},children:X.angle}),l.jsxs("div",{className:"flex-1",children:[l.jsx("div",{className:"font-semibold",style:{color:X.color},children:X.status}),l.jsx("div",{className:"text-sm text-gray-600",children:X.description})]})]},ae))})]}),l.jsxs("div",{className:"flex flex-col gap-3",children:[l.jsxs("div",{className:"flex gap-3",children:[l.jsxs("button",{onClick:D,className:"flex-1 bg-gradient-to-r from-green-600 to-emerald-600 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition flex items-center justify-center gap-2",children:[l.jsx(ai,{size:20}),"Gönder"]}),l.jsxs("button",{onClick:I,className:"flex-1 bg-gray-200 text-gray-700 py-3 rounded-xl font-semibold hover:bg-gray-300 transition flex items-center justify-center gap-2",children:[l.jsx(Io,{size:20}),"Tekrar Kaydet"]})]}),l.jsxs("button",{onClick:V,className:"w-full bg-red-600 text-white py-3 rounded-xl font-semibold hover:bg-red-700 transition flex items-center justify-center gap-2",children:[l.jsx(Ko,{size:20}),"Kaydedilen Videoyu Sil"]})]})]}),w==="completed"&&l.jsxs("div",{className:"text-center py-12",children:[l.jsx("div",{className:"w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6",children:l.jsx(ai,{size:48,className:"text-green-600"})}),l.jsx("h3",{className:"text-2xl font-bold text-gray-900 mb-2",children:ge>0?"Testler Tamamlandı!":"Test Atlandı"}),l.jsxs("div",{className:"bg-blue-50 rounded-xl p-4 mb-4",children:[l.jsxs("p",{className:"text-sm text-gray-700 mb-2",children:[l.jsx("strong",{children:"Tamamlanan Testler:"})," ",ge," / ",_.tests.length]}),J.size>0&&l.jsxs("p",{className:"text-sm text-gray-600",children:[l.jsx("strong",{children:"Atlanan Testler:"})," ",J.size]})]}),ge>0?l.jsxs(l.Fragment,{children:[l.jsx("p",{className:"text-gray-600 mb-6",children:"Videolarınız fizyoterapistiniz tarafından değerlendirilecek."}),l.jsx("div",{className:"bg-blue-50 rounded-xl p-4 mb-6",children:l.jsxs("p",{className:"text-sm text-gray-700",children:[l.jsx("strong",{children:"Sonraki Adım:"})," Fizyoterapistiniz videoları inceleyip 24-48 saat içinde size özel egzersiz programınızı hazırlayacak."]})}),l.jsx("button",{onClick:P,className:"bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-3 rounded-xl font-semibold hover:shadow-lg transition",children:"Testleri Gönder"})]}):l.jsxs(l.Fragment,{children:[l.jsx("p",{className:"text-gray-600 mb-6",children:"Henüz hiçbir test tamamlanmadı. En az 1 test yapmanız önerilir."}),l.jsxs("div",{className:"flex gap-3 justify-center",children:[l.jsx("button",{onClick:()=>{B(0),A("instructions")},className:"bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-xl font-semibold hover:shadow-lg transition",children:"Test Yapmaya Başla"}),l.jsx("button",{onClick:v,className:"bg-gray-200 text-gray-700 px-6 py-3 rounded-xl font-semibold hover:bg-gray-300 transition",children:"İptal Et"})]})]})]})]})]})})},pt={user_name:"Ahmet",welcome_subtitle:"Bugün, ağrısız bir yaşam için harika bir başlangıç.",cta_title:"Henüz Vücut Analizinizi Yapmadık",cta_description:"Size en uygun tedavi paketini belirleyebilmemiz ve ağrı haritanızı çıkarabilmemiz için 3 dakikalık ücretsiz ön değerlendirmeyi tamamlayın.",cta_button_text:"Analizi Başlat",cta_duration:"Yaklaşık 3 dakika sürer",video_title:"Süreci İzleyin",tip_title:"Biliyor muydunuz?",tip_text:"Kronik ağrıların %80'i doğru duruş ve egzersizle ameliyatsız iyileşebilir.",background_color:"#667eea",card_background:"#ffffff",text_color:"#1f2937",button_color:"#f59e0b",accent_color:"#764ba2"},jg=()=>{var Fa,Pa;const[r,v]=g.useState(pt),[E,d]=g.useState(!1),[w,A]=g.useState(null),[S,B]=g.useState(!1),[b,p]=g.useState(!1),[U,N]=g.useState(null),[G,L]=g.useState(!1),[Z,ie]=g.useState(!1),[J,H]=g.useState(!1),[K,ue]=g.useState(!1),[$,Ye]=g.useState(!1),[de,Q]=g.useState(!1),[Y,ne]=g.useState(!1),[re,Oe]=g.useState(0),[ce,at]=g.useState(()=>localStorage.getItem("packageType")||"none"),ye=ce!=="none",Me=x=>{at(x),localStorage.setItem("packageType",x)},[_,y]=g.useState(!1),[te,ge]=g.useState(!1),[fe,f]=g.useState([]),[D,I]=g.useState(!1),[V,oe]=g.useState(!1),[me,O]=g.useState(!1),[ee,P]=g.useState(()=>{try{const x=localStorage.getItem("userPainAreas");return x?JSON.parse(x):[]}catch{return[]}});g.useEffect(()=>{const x=localStorage.getItem("userPainAreas");if(x)try{P(JSON.parse(x))}catch{P([])}},[G]);const[ke,Qe]=g.useState([{id:"n1",title:"Fizyoterapistiniz programınızı güncelledi.",message:"Yeni hareket planınız hazır, detayları görmek için tıklayın.",type:"clinical",read:!1,date:"2 saat önce"},{id:"n2",title:"Ödemeniz başarıyla alındı.",message:"Klinik Takip Paketi hesabınıza tanımlandı, faturanızı görüntüleyebilirsiniz.",type:"admin",read:!1,date:"1 gün önce"},{id:"n3",title:"Egzersiz Vakti! 🏃‍♂️",message:"Bugünkü programını henüz yapmadın. 15 dakikanı ayırmayı unutma.",type:"motivation",read:!0,date:"3 gün önce"}]),[ft,Za]=g.useState({todayExercises:3,todayCompleted:1,weeklyCompleted:12,weeklyTotal:18,progressPercentage:68,streak:5,totalExercises:47}),[bt,va]=g.useState([{id:"t1",name:"Boyun Germe Egzersizi",duration:"10 dk",completed:!0,time:"09:00"},{id:"t2",name:"Omuz Rotasyonu",duration:"5 dk",completed:!1,time:"14:00"},{id:"t3",name:"Bel Güçlendirme",duration:"15 dk",completed:!1,time:"18:00"}]),ka=x=>{va(q=>{const pe=q.map(Ee=>Ee.id===x?{...Ee,completed:!Ee.completed}:Ee),Te=pe.filter(Ee=>Ee.completed).length;return Za(Ee=>({...Ee,todayCompleted:Te})),pe})},yt=(()=>{const x=new Date,q=new Date(x);q.setMonth(q.getMonth()+1);const pe=Ee=>Ee.toLocaleDateString("tr-TR",{day:"numeric",month:"long",year:"numeric"}),Te=Math.ceil((q.getTime()-x.getTime())/(1e3*60*60*24));switch(ce){case"basic":return{name:"Temel Analiz & Egzersiz Planı",startDate:pe(x),endDate:"Tek Seferlik",daysRemaining:null,features:["Detaylı anamnez değerlendirmesi","Fizyoterapist tarafından vaka analizi","4-6 haftalık kişiye özel egzersiz reçetesi","Egzersiz videoları ve açıklamaları"],price:"599₺"};case"pro":return{name:"Klinik Takip & İlerleme Paketi",startDate:pe(x),endDate:pe(q),daysRemaining:Te,features:["Temel paketteki tüm hizmetler","Haftalık kontrol ve değerlendirme","Ağrı ve gelişime göre program revizyonu","Sistem üzerinden soru-cevap hakkı","1 aylık aktif takip"],price:"1.299₺"};case"premium":return{name:"Premium Danışmanlık & Video Analizi",startDate:pe(x),endDate:pe(q),daysRemaining:Te,features:["Tüm paketlerdeki hizmetler","Video analizi: Egzersizlerinizi kaydedin, geri bildirim alın","Hızlı destek (chat/WhatsApp)","Öncelikli değerlendirme (aynı gün dönüş)","Sınırsız program güncellemesi"],price:"2.499₺"};default:return{name:"",startDate:"",endDate:"",daysRemaining:null,features:[],price:""}}})(),ja=[{id:"a1",type:"exercise",text:"Boyun Germe Egzersizi tamamlandı",time:"2 saat önce",icon:"✅"},{id:"a2",type:"message",text:"Fizyoterapistinizden yeni mesaj",time:"1 gün önce",icon:"💬"},{id:"a3",type:"program",text:"Egzersiz programınız güncellendi",time:"2 gün önce",icon:"📝"},{id:"a4",type:"achievement",text:"5 günlük streak kazandınız!",time:"3 gün önce",icon:"🏆"}],Xt=[{day:"Pzt",value:80},{day:"Sal",value:65},{day:"Çar",value:90},{day:"Per",value:70},{day:"Cum",value:85},{day:"Cmt",value:60},{day:"Paz",value:45}],st=[{id:"b1",name:"İlk Adım",icon:"🎯",earned:!0,description:"İlk egzersizini tamamladın!"},{id:"b2",name:"5 Gün Streak",icon:"🔥",earned:!0,description:"5 gün üst üste egzersiz yaptın!"},{id:"b3",name:"Haftalık Şampiyon",icon:"👑",earned:!1,description:"Bir hafta boyunca tüm egzersizleri tamamla"},{id:"b4",name:"100 Egzersiz",icon:"💯",earned:!1,description:"Toplam 100 egzersiz tamamla"},{id:"b5",name:"Sabah Kahramanı",icon:"🌅",earned:!1,description:"7 sabah egzersiz yap"},{id:"b6",name:"Hafta Sonu Savaşçısı",icon:"⚔️",earned:!1,description:"Hafta sonu egzersizlerini tamamla"},{id:"b7",name:"Mükemmel Hafta",icon:"⭐",earned:!1,description:"Bir hafta hiç egzersiz kaçırma"},{id:"b8",name:"30 Günlük Efsane",icon:"🏆",earned:!1,description:"30 gün üst üste devam et"},{id:"b9",name:"Hızlı Başlangıç",icon:"⚡",earned:!1,description:"İlk 3 günü tamamla"},{id:"b10",name:"Gece Kuşu",icon:"🦉",earned:!1,description:"10 akşam egzersiz yap"},{id:"b11",name:"İlerleme Ustası",icon:"📈",earned:!1,description:"İlerleme skorunu %80'e çıkar"},{id:"b12",name:"Sosyal Kelebek",icon:"🦋",earned:!1,description:"10 arkadaşını davet et"}],X=x=>{fe.find(q=>q.id===x.id)||(f([...fe,{id:x.id,name:x.name,price:x.price||"0"}]),L(!1),Ye(!1),setTimeout(()=>I(!0),300))},ae=x=>{f(fe.filter(q=>q.id!==x))},xe=()=>fe.reduce((x,q)=>x+parseInt(q.price.replace(/\./g,"")),0),Ce=[{icon:"💡",title:"Biliyor muydunuz?",text:"Kronik ağrıların %80'i doğru duruş ve egzersizle ameliyatsız iyileşebilir."},{icon:"🧘",title:"Günlük İpucu",text:"Her gün 10 dakika germe egzersizi, kas gerginliğini %40 azaltır."},{icon:"🚶",title:"Hareket Şart!",text:"Her 45 dakikada bir 5 dakika yürümek, bel ağrısı riskini %50 düşürür."},{icon:"💧",title:"Su İçin",text:"Günde 2 litre su içmek, eklem sağlığını korur ve kas kramplarını önler."},{icon:"😴",title:"Uyku Önemli",text:"Kaliteli 7-8 saat uyku, kas onarımı ve ağrı yönetimi için kritiktir."},{icon:"🏋️",title:"Düzenli Egzersiz",text:"Haftada 3 gün egzersiz, kronik ağrıyı %60 oranında azaltabilir."},{icon:"🪑",title:"Doğru Oturuş",text:"Ergonomik oturma pozisyonu, boyun ve sırt ağrılarını önler."},{icon:"🌿",title:"Stres Yönetimi",text:"Stres kas gerginliğini artırır. Nefes egzersizleri rahatlamanıza yardımcı olur."}],[Pe,Ft]=g.useState(0),Et=g.useRef(null),Na=g.useRef(null),si=g.useRef(null),tn=g.useRef(null);g.useEffect(()=>{const x=window.elementSdk;x&&x.init({defaultConfig:pt,onConfigChange:q=>{v(pe=>({...pe,...q}))},mapToCapabilities:q=>({recolorables:[{get:()=>q.background_color||pt.background_color,set:pe=>v(Te=>({...Te,background_color:pe}))},{get:()=>q.card_background||pt.card_background,set:pe=>v(Te=>({...Te,card_background:pe}))},{get:()=>q.text_color||pt.text_color,set:pe=>v(Te=>({...Te,text_color:pe}))},{get:()=>q.button_color||pt.button_color,set:pe=>v(Te=>({...Te,button_color:pe}))},{get:()=>q.accent_color||pt.accent_color,set:pe=>v(Te=>({...Te,accent_color:pe}))}],borderables:[],fontEditable:void 0,fontSizeable:void 0}),mapToEditPanelValues:q=>new Map([["user_name",q.user_name||pt.user_name],["welcome_subtitle",q.welcome_subtitle||pt.welcome_subtitle],["cta_title",q.cta_title||pt.cta_title],["cta_description",q.cta_description||pt.cta_description],["cta_button_text",q.cta_button_text||pt.cta_button_text],["cta_duration",q.cta_duration||pt.cta_duration],["video_title",q.video_title||pt.video_title],["tip_title",q.tip_title||pt.tip_title],["tip_text",q.tip_text||pt.tip_text]])})},[]),g.useEffect(()=>{if(!w)return;const x=setTimeout(()=>A(null),3500);return()=>clearTimeout(x)},[w]),g.useEffect(()=>{if(localStorage.getItem("showLoginSuccess")==="true"){B(!0),localStorage.removeItem("showLoginSuccess");const q=setTimeout(()=>{B(!1)},3e3);return()=>clearTimeout(q)}},[]),g.useEffect(()=>{(async()=>{var q;try{const pe=await ta.getCurrentUser();if(pe.success&&pe.user){const Ee=pe.user,ri=(((q=Ee.name)==null?void 0:q.split(" ")[0])||"Kullanıcı").toUpperCase();v(Wa=>({...Wa,user_name:ri})),Ee.packageType&&(at(Ee.packageType),localStorage.setItem("packageType",Ee.packageType))}const Te=await ta.getDashboardData();if(Te.success&&Te.data){const Ee=Te.data;Ee.assessmentResults&&console.log("Assessment sonuçları yüklendi:",Ee.assessmentResults),Ee.photos&&console.log("Fotoğraflar yüklendi:",Ee.photos),Ee.formData&&console.log("Form verileri yüklendi:",Ee.formData),Ee.notifications&&Array.isArray(Ee.notifications)&&Qe(Ee.notifications)}}catch(pe){console.error("Kullanıcı verileri yüklenirken hata:",pe)}})()},[]);const gs=g.useMemo(()=>`linear-gradient(135deg, ${r.background_color} 0%, ${r.accent_color} 100%)`,[r.background_color,r.accent_color]),Ja=g.useMemo(()=>`linear-gradient(135deg, ${r.button_color} 0%, #f97316 100%)`,[r.button_color]),ht=()=>{d(!0),setTimeout(()=>{d(!1),p(!0)},600)},Rt=x=>{A(x?"Premium özellik: Fizyoterapistinizle mesajlaşmak için premium paket gerekir.":"Bu özelliği kullanmak için önce paket satın almalısınız.")},mt=()=>{window.location.href="/"},bs=()=>{ie(x=>!x)};g.useEffect(()=>{const x=q=>{var Te,Ee;const pe=q.target;(Te=Na.current)!=null&&Te.contains(pe)||(Ee=Et.current)!=null&&Ee.contains(pe)||ie(!1)};return document.addEventListener("click",x),()=>document.removeEventListener("click",x)},[]),g.useEffect(()=>{const x=q=>{var Te,Ee;const pe=q.target;(Te=si.current)!=null&&Te.contains(pe)||(Ee=tn.current)!=null&&Ee.contains(pe)||oe(!1)};return document.addEventListener("click",x),()=>document.removeEventListener("click",x)},[]);const ys=x=>{Qe(q=>q.map(pe=>pe.id===x?{...pe,read:!0}:pe))},gl=ke.filter(x=>!x.read).length;return g.useEffect(()=>{const x=()=>{const q=document.documentElement,pe=q.scrollHeight-q.clientHeight,Te=pe>0?q.scrollTop/pe*100:0;Ft(Te)};return window.addEventListener("scroll",x),x(),()=>window.removeEventListener("scroll",x)},[]),g.useEffect(()=>{const x=setInterval(()=>{Oe(q=>(q+1)%Ce.length)},8e3);return()=>clearInterval(x)},[Ce.length]),l.jsxs("div",{className:"dashboard-wrapper",style:{minHeight:"100vh",background:gs},children:[S&&l.jsxs("div",{style:{position:"fixed",top:20,left:"50%",transform:"translateX(-50%)",zIndex:1e4,background:"#10b981",color:"white",padding:"12px 24px",borderRadius:"8px",boxShadow:"0 4px 12px rgba(0,0,0,0.15)",display:"flex",alignItems:"center",gap:"12px",animation:"fadeIn 0.3s ease-in"},children:[l.jsx("svg",{style:{width:20,height:20},fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:l.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M5 13l4 4L19 7"})}),l.jsx("span",{style:{fontWeight:600,fontSize:14},children:"Giriş yapıldı"}),l.jsx("button",{onClick:()=>B(!1),style:{marginLeft:8,background:"transparent",border:"none",color:"white",cursor:"pointer",fontSize:18,lineHeight:1,padding:0,width:20,height:20},children:"×"})]}),l.jsx("style",{children:`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateX(-50%) translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateX(-50%) translateY(0);
          }
        }
        body { margin: 0; padding: 0; box-sizing: border-box; }
        * { box-sizing: inherit; }
        .dashboard-wrapper { display: flex; height: 100%; width: 100%; position: relative; }
        .sidebar { width: 260px; background: #fff; box-shadow: 2px 0 20px rgba(0,0,0,0.08); display: flex; flex-direction: column; height: 100%; border-radius: 0 24px 24px 0; overflow: hidden; }
        .sidebar-header { padding: 24px; border-bottom: 1px solid #e5e7eb; background: #fff; }
        .logo { display: flex; align-items: center; gap: 12px; }
        .logo-progress { width: 100%; height: 3px; background: #e5e7eb; border-radius: 999px; margin-top: 10px; overflow: hidden; }
        .logo-progress-inner { height: 100%; background: linear-gradient(90deg, #667eea, #22c55e); transition: width 0.15s ease-out; }
        .menu-items { flex: 1; padding: 16px 0; overflow-y: auto; }
        .menu-section-title { padding: 20px 24px 8px 36px; font-size: 11px; font-weight: 700; letter-spacing: 1px; color: #9ca3af; text-transform: uppercase; }
        .menu-divider { height: 1px; background: linear-gradient(90deg, transparent, #e5e7eb, transparent); margin: 12px 24px; border: none; }
        .menu-item { display: flex; align-items: center; padding: 14px 24px; color: #4b5563; cursor: pointer; transition: all 0.2s; font-size: 15px; gap: 12px; margin: 0 12px; border-radius: 12px; }
        .menu-item:hover { background: #f3f4f6; color: #667eea; }
        .menu-item.active { background: linear-gradient(135deg, #eef2ff, #f0f9ff); color: #667eea; border-left: 4px solid #667eea; box-shadow: 0 2px 8px rgba(102, 126, 234, 0.15); }
        .menu-item.locked { opacity: 0.55; cursor: not-allowed; }
        .menu-item.premium-feature { position: relative; }
        .menu-item.premium-feature::after { content: 'PREMIUM'; position: absolute; right: 50px; font-size: 9px; font-weight: 700; color: #f59e0b; background: #fef3c7; padding: 2px 6px; border-radius: 4px; letter-spacing: 0.5px; }
        .main-content { flex: 1; overflow-y: auto; height: 100%; background: transparent; }
        .top-bar { background: #fff; padding: 20px 32px 20px 48px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 12px rgba(0,0,0,0.06); position: relative; border-radius: 24px; margin: 24px 24px 24px 32px; }
        .welcome-section { display: flex; align-items: center; gap: 24px; flex: 1; }
        .welcome-text { padding-left: 16px; }
        .welcome-text h1 { font-size: 28px; font-weight: 600; color: ${r.text_color}; margin: 0 0 4px 0; }
        .welcome-text p { font-size: 15px; color: #6b7280; margin: 0; }
        .welcome-badges { display: flex; flex-direction: column; gap: 8px; padding: 12px 16px; background: linear-gradient(135deg, #fef3c7, #fde68a); border-radius: 12px; border: 2px solid #fbbf24; }
        .welcome-badges-title { font-size: 11px; font-weight: 700; color: #92400e; text-transform: uppercase; letter-spacing: 0.5px; }
        .welcome-badges-list { display: flex; align-items: center; gap: 8px; }
        .welcome-badge-item { width: 40px; height: 40px; border-radius: 50%; background: linear-gradient(135deg, #fef3c7, #fde68a); border: 2px solid #f59e0b; display: flex; align-items: center; justify-content: center; font-size: 20px; cursor: pointer; transition: all 0.2s; box-shadow: 0 2px 8px rgba(245, 158, 11, 0.2); }
        .welcome-badge-item:hover { transform: scale(1.1); box-shadow: 0 4px 12px rgba(245, 158, 11, 0.3); }
        .welcome-badge-icon { display: flex; align-items: center; justify-content: center; }
        .welcome-badge-more { width: 40px; height: 40px; border-radius: 50%; background: #e5e7eb; border: 2px solid #9ca3af; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700; color: #6b7280; cursor: pointer; transition: all 0.2s; }
        .welcome-badge-more:hover { background: #d1d5db; }
        .top-bar-right { display: flex; align-items: center; gap: 20px; position: relative; }
        .notification-bell { width: 40px; height: 40px; border-radius: 50%; background: #f3f4f6; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: all 0.2s; font-size: 18px; position: relative; }
        .notification-bell:hover { background: #e5e7eb; }
        .notification-badge { position: absolute; top: -2px; right: -2px; min-width: 18px; height: 18px; background: #ef4444; color: #fff; border-radius: 999px; font-size: 10px; font-weight: 700; display: flex; align-items: center; justify-content: center; padding: 0 5px; border: 2px solid #fff; }
        .notification-wrapper { position: relative; }
        .notification-dropdown { position: absolute; top: 50px; right: 0; width: 360px; background: #fff; border-radius: 20px; box-shadow: 0 10px 40px rgba(0,0,0,0.15); border: 1px solid #e5e7eb; overflow: hidden; z-index: 1000; animation: slideDown 0.2s ease; max-height: 500px; display: flex; flex-direction: column; }
        .notification-header { background: linear-gradient(135deg, #667eea, #764ba2); color: #fff; padding: 14px 16px; font-size: 15px; font-weight: 700; display: flex; justify-content: space-between; align-items: center; }
        .notification-items { max-height: 400px; overflow-y: auto; }
        .notification-item { padding: 12px 16px; border-bottom: 1px solid #f3f4f6; cursor: pointer; transition: all 0.2s; margin: 0 8px; border-radius: 12px; }
        .notification-item:hover { background: #f9fafb; margin: 4px 8px; }
        .notification-item.read { background: #fff; opacity: 0.7; }
        .notification-item.unread { background: #f0f9ff; }
        .notification-item-title { font-size: 13px; font-weight: 700; color: #1f2937; margin-bottom: 4px; }
        .notification-item-message { font-size: 12px; color: #6b7280; line-height: 1.4; margin-bottom: 4px; }
        .notification-item-meta { display: flex; justify-content: space-between; align-items: center; margin-top: 6px; }
        .notification-item-type { font-size: 10px; font-weight: 700; padding: 3px 8px; border-radius: 12px; }
        .notification-item-type.clinical { background: #dbeafe; color: #1d4ed8; }
        .notification-item-type.admin { background: #fee2e2; color: #b91c1c; }
        .notification-item-type.motivation { background: #dcfce7; color: #15803d; }
        .notification-item-date { font-size: 11px; color: #9ca3af; }
        .notification-empty { padding: 40px 20px; text-align: center; color: #9ca3af; font-size: 14px; }
        .notification-footer { padding: 12px 16px; background: #f9fafb; border-top: 1px solid #e5e7eb; text-align: center; }
        .notification-footer-btn { background: none; border: none; color: #667eea; font-size: 13px; font-weight: 600; cursor: pointer; padding: 4px 8px; }
        .notification-footer-btn:hover { text-decoration: underline; }
        
        /* Cart Styles */
        .cart-wrapper { position: relative; }
        .cart-bell { width: 40px; height: 40px; border-radius: 50%; background: #f3f4f6; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: all 0.2s; font-size: 18px; position: relative; flex-shrink: 0; }
        .cart-bell:hover { background: #d1fae5; }
        .cart-badge { position: absolute; top: -4px; right: -4px; width: 20px; height: 20px; background: #ef4444; color: #fff; font-size: 11px; font-weight: 700; border-radius: 50%; display: flex; align-items: center; justify-content: center; animation: bounce 0.5s ease; }
        @keyframes bounce { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.2); } }
        .cart-overlay { position: fixed; inset: 0; z-index: 999; }
        .cart-dropdown { position: absolute; top: 50px; right: 0; width: 320px; background: #fff; border-radius: 20px; box-shadow: 0 10px 40px rgba(0,0,0,0.15); border: 1px solid #e5e7eb; overflow: hidden; z-index: 1000; animation: slideDown 0.2s ease; }
        @keyframes slideDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
        .cart-header { background: linear-gradient(135deg, #10b981, #059669); color: #fff; padding: 14px 16px; font-size: 15px; font-weight: 700; }
        .cart-empty { padding: 30px; text-align: center; color: #9ca3af; font-size: 14px; }
        .cart-items { max-height: 240px; overflow-y: auto; }
        .cart-item { display: flex; align-items: center; justify-content: space-between; padding: 12px 16px; border-bottom: 1px solid #f3f4f6; margin: 0 8px; border-radius: 12px; }
        .cart-item-info { display: flex; flex-direction: column; gap: 2px; }
        .cart-item-name { font-size: 13px; font-weight: 600; color: #1f2937; }
        .cart-item-price { font-size: 14px; font-weight: 700; color: #10b981; }
        .cart-item-remove { background: none; border: none; color: #ef4444; font-size: 16px; cursor: pointer; padding: 4px; border-radius: 4px; }
        .cart-item-remove:hover { background: #fef2f2; }
        .cart-footer { padding: 14px 16px; background: #f9fafb; border-top: 1px solid #e5e7eb; }
        .cart-total { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
        .cart-total span:first-child { font-size: 14px; color: #6b7280; font-weight: 500; }
        .cart-total-price { font-size: 20px; font-weight: 800; color: #10b981; }
        .cart-checkout-btn { width: 100%; padding: 12px; background: linear-gradient(135deg, #10b981, #059669); border: none; border-radius: 10px; color: #fff; font-size: 14px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
        .cart-checkout-btn:hover { transform: translateY(-1px); box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3); }
        .profile-pic { width: 44px; height: 44px; border-radius: 50%; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center; color: #fff; font-weight: 600; font-size: 16px; cursor: pointer; position: relative; flex-shrink: 0; }
        .content-area { padding: 32px; max-width: 1200px; margin: 0 auto; }
        .main-cta-card { background: ${r.card_background}; border-radius: 16px; padding: 40px; box-shadow: 0 4px 20px rgba(0,0,0,0.08); margin-bottom: 32px; display: flex; gap: 32px; align-items: center; }
        .cta-illustration { width: 180px; height: 180px; flex-shrink: 0; }
        .cta-content h2 { font-size: 26px; font-weight: 600; color: ${r.text_color}; margin: 0 0 12px 0; }
        .cta-content p { font-size: 16px; color: #6b7280; line-height: 1.6; margin: 0 0 24px 0; }
        .cta-button { background: ${Ja}; color: #fff; border: none; padding: 16px 32px; font-size: 17px; font-weight: 600; border-radius: 12px; cursor: pointer; transition: all 0.3s; box-shadow: 0 4px 12px rgba(245, 158, 11, 0.3); display: inline-flex; align-items: center; gap: 8px; }
        .cta-button:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(245, 158, 11, 0.4); }
        .duration-hint { display: inline-block; margin-left: 12px; font-size: 14px; color: #9ca3af; font-weight: normal; }
        .info-cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 24px; }
        .info-card { background: ${r.card_background}; border-radius: 12px; padding: 24px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); transition: all 0.3s; cursor: pointer; }
        .info-card:hover { transform: translateY(-4px); box-shadow: 0 6px 16px rgba(0,0,0,0.1); }
        .info-card-icon { width: 56px; height: 56px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 28px; margin-bottom: 16px; }
        .video-card .info-card-icon { background: linear-gradient(135deg, #ec4899 0%, #8b5cf6 100%); }
        .tip-card .info-card-icon { background: linear-gradient(135deg, #10b981 0%, #059669 100%); }
        .info-card h3 { font-size: 18px; font-weight: 600; color: #1f2937; margin: 0 0 8px 0; }
        .info-card p { font-size: 14px; color: #6b7280; line-height: 1.6; margin: 0; }
        .tip-carousel { position: relative; overflow: hidden; }
        .tip-carousel .info-card-icon { transition: transform 0.5s ease; }
        .tip-title-animated, .tip-text-animated { 
          animation: tipFadeIn 0.5s ease; 
        }
        @keyframes tipFadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .tip-dots {
          display: flex;
          justify-content: center;
          gap: 6px;
          margin-top: 12px;
        }
        .tip-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #d1d5db;
          cursor: pointer;
          transition: all 0.3s;
        }
        .tip-dot:hover { background: #9ca3af; }
        .tip-dot.active { 
          background: #10b981; 
          width: 24px; 
          border-radius: 4px; 
        }
        .profile-dropdown { position: absolute; top: 70px; right: 32px; width: 320px; background: #fff; border-radius: 20px; box-shadow: 0 8px 32px rgba(0, 0, 0, 0.12); opacity: 0; visibility: hidden; transform: translateY(-10px); transition: all 0.25s ease; z-index: 1000; border: 1px solid #e5e7eb; overflow: hidden; }
        .profile-dropdown.active { opacity: 1; visibility: visible; transform: translateY(0); }
        .profile-card-header { padding: 20px; border-bottom: 1px solid rgba(255,255,255,0.2); text-align: center; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; }
        .profile-avatar-large { width: 70px; height: 70px; border-radius: 50%; background: #fff; color: #667eea; display: flex; align-items: center; justify-content: center; font-size: 30px; font-weight: 700; margin: 0 auto 10px auto; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15); }
        .profile-name { font-size: 18px; font-weight: 700; margin: 0 0 4px 0; }
        .premium-badge-inline { display: inline-flex; align-items: center; gap: 6px; background: rgba(251, 191, 36, 0.18); color: #b45309; padding: 4px 10px; border-radius: 16px; font-size: 11px; font-weight: 700; border: 1px solid rgba(251, 191, 36, 0.35); }
        .profile-menu-section { padding: 14px 0; }
        .profile-menu-section:not(:last-child) { border-bottom: 1px solid #f3f4f6; }
        .profile-section-title { padding: 8px 16px; font-size: 11px; font-weight: 700; color: #9ca3af; letter-spacing: 1px; text-transform: uppercase; }
        .profile-menu-item { display: flex; align-items: center; gap: 12px; padding: 12px 16px; color: #374151; cursor: pointer; transition: all 0.2s; font-size: 14px; margin: 0 12px; border-radius: 12px; }
        .profile-menu-item:hover { background: #f9fafb; color: #4f46e5; }
        .profile-menu-item.danger:hover { background: #fef2f2; color: #dc2626; }
        .profile-menu-icon { font-size: 18px; width: 22px; text-align: center; }
        .profile-menu-text { flex: 1; }
        .profile-menu-text .subtitle { font-size: 11px; color: #9ca3af; margin-top: 2px; }
        
        /* İstatistik Kartları */
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }
        .stat-card { background: ${r.card_background}; border-radius: 16px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); display: flex; align-items: center; gap: 16px; transition: all 0.3s; }
        .stat-card:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        .stat-icon { width: 56px; height: 56px; border-radius: 14px; display: flex; align-items: center; justify-content: center; font-size: 28px; flex-shrink: 0; }
        .stat-content { flex: 1; }
        .stat-value { font-size: 28px; font-weight: 800; color: #1f2937; margin-bottom: 4px; }
        .stat-label { font-size: 13px; color: #6b7280; font-weight: 500; }
        
        /* Hızlı Erişim Butonları */
        .quick-actions { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px; margin-bottom: 24px; }
        .quick-action-btn { background: ${r.card_background}; border: 2px solid #e5e7eb; border-radius: 14px; padding: 16px; display: flex; align-items: center; gap: 12px; cursor: pointer; transition: all 0.2s; text-align: left; }
        .quick-action-btn:hover { border-color: #667eea; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(102, 126, 234, 0.15); }
        .quick-action-btn.primary { background: linear-gradient(135deg, #667eea, #764ba2); border-color: transparent; color: #fff; }
        .quick-action-btn.primary:hover { box-shadow: 0 6px 20px rgba(102, 126, 234, 0.3); }
        .quick-action-icon { font-size: 32px; flex-shrink: 0; }
        .quick-action-text { flex: 1; }
        .quick-action-title { font-size: 15px; font-weight: 700; color: #1f2937; margin-bottom: 2px; }
        .quick-action-btn.primary .quick-action-title { color: #fff; }
        .quick-action-subtitle { font-size: 12px; color: #6b7280; }
        .quick-action-btn.primary .quick-action-subtitle { color: rgba(255,255,255,0.9); }
        
        /* Dashboard Grid */
        .dashboard-grid { display: grid; grid-template-columns: 1fr 400px; gap: 24px; margin-bottom: 24px; }
        .dashboard-left, .dashboard-right { display: flex; flex-direction: column; gap: 24px; }
        
        /* Görev Kartı */
        .task-card, .progress-chart-card, .package-status-card, .activities-card, .badges-card { background: ${r.card_background}; border-radius: 16px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
        .card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
        .card-title { font-size: 18px; font-weight: 700; color: #1f2937; margin: 0; }
        .card-badge { background: #eef2ff; color: #667eea; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 700; }
        .task-list { display: flex; flex-direction: column; gap: 12px; margin-bottom: 16px; }
        .task-item { display: flex; align-items: center; gap: 12px; padding: 12px; border-radius: 12px; background: #f9fafb; transition: all 0.2s; }
        .task-item:hover { background: #f3f4f6; }
        .task-item.completed { opacity: 0.6; }
        .task-checkbox { font-size: 20px; cursor: pointer; flex-shrink: 0; }
        .task-info { flex: 1; }
        .task-name { font-size: 14px; font-weight: 600; color: #1f2937; margin-bottom: 4px; }
        .task-item.completed .task-name { text-decoration: line-through; color: #9ca3af; }
        .task-meta { display: flex; gap: 12px; font-size: 12px; color: #6b7280; }
        .task-duration, .task-time { display: flex; align-items: center; gap: 4px; }
        .task-view-all { width: 100%; padding: 10px; background: #f3f4f6; border: none; border-radius: 10px; color: #667eea; font-weight: 600; cursor: pointer; transition: all 0.2s; }
        .task-view-all:hover { background: #eef2ff; }
        
        /* İlerleme Grafiği */
        .chart-container { margin-bottom: 16px; }
        .chart-bars { display: flex; align-items: flex-end; justify-content: space-between; gap: 8px; height: 200px; padding: 0 8px; }
        .chart-bar-wrapper { flex: 1; display: flex; flex-direction: column; align-items: center; height: 100%; }
        .chart-bar { width: 100%; max-width: 50px; background: linear-gradient(180deg, #667eea, #764ba2); border-radius: 8px 8px 0 0; position: relative; transition: all 0.3s; min-height: 20px; }
        .chart-bar:hover { opacity: 0.8; }
        .chart-value { position: absolute; top: -24px; left: 50%; transform: translateX(-50%); font-size: 11px; font-weight: 700; color: #667eea; white-space: nowrap; }
        .chart-label { margin-top: 8px; font-size: 11px; color: #6b7280; font-weight: 600; }
        .chart-footer { display: flex; justify-content: space-between; padding-top: 16px; border-top: 1px solid #e5e7eb; }
        .chart-stat { display: flex; flex-direction: column; gap: 4px; }
        .chart-stat-label { font-size: 12px; color: #6b7280; }
        .chart-stat-value { font-size: 16px; font-weight: 700; color: #1f2937; }
        
        /* Paket Durumu */
        .package-badge { padding: 4px 12px; border-radius: 12px; font-size: 11px; font-weight: 700; }
        .package-badge.active { background: #dcfce7; color: #15803d; }
        .package-info { margin-bottom: 16px; }
        .package-name { font-size: 16px; font-weight: 700; color: #1f2937; margin-bottom: 8px; }
        .package-dates { font-size: 13px; color: #6b7280; margin-bottom: 12px; }
        .package-countdown { display: flex; align-items: center; gap: 8px; padding: 10px; background: #fef3c7; border-radius: 10px; margin-bottom: 12px; }
        .countdown-icon { font-size: 18px; }
        .countdown-text { font-size: 13px; font-weight: 700; color: #92400e; }
        .package-features { display: flex; flex-direction: column; gap: 6px; }
        .package-feature { display: flex; align-items: center; gap: 8px; font-size: 13px; color: #4b5563; }
        .package-feature span { color: #10b981; font-weight: 700; }
        .package-manage-btn { width: 100%; padding: 10px; background: #f3f4f6; border: none; border-radius: 10px; color: #667eea; font-weight: 600; cursor: pointer; transition: all 0.2s; }
        .package-manage-btn:hover { background: #eef2ff; }
        
        /* Son Aktiviteler */
        .activities-list { display: flex; flex-direction: column; gap: 12px; margin-bottom: 16px; }
        .activity-item { display: flex; align-items: flex-start; gap: 12px; padding: 12px; border-radius: 12px; background: #f9fafb; transition: all 0.2s; }
        .activity-item:hover { background: #f3f4f6; }
        .activity-icon { font-size: 20px; flex-shrink: 0; }
        .activity-content { flex: 1; }
        .activity-text { font-size: 13px; font-weight: 600; color: #1f2937; margin-bottom: 4px; }
        .activity-time { font-size: 11px; color: #9ca3af; }
        .activities-view-all { width: 100%; padding: 10px; background: #f3f4f6; border: none; border-radius: 10px; color: #667eea; font-weight: 600; cursor: pointer; transition: all 0.2s; }
        .activities-view-all:hover { background: #eef2ff; }
        
        /* Rozetler */
        .badges-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
        .badge-item { position: relative; background: #f9fafb; border: 2px solid #e5e7eb; border-radius: 12px; padding: 16px; text-align: center; transition: all 0.2s; }
        .badge-item.earned { background: linear-gradient(135deg, #fef3c7, #fde68a); border-color: #fbbf24; }
        .badge-item.locked { opacity: 0.5; }
        .badge-icon { font-size: 32px; margin-bottom: 8px; }
        .badge-name { font-size: 12px; font-weight: 700; color: #1f2937; }
        .badge-lock { position: absolute; top: 8px; right: 8px; font-size: 16px; opacity: 0.6; }
        
        /* Klinik Testler Bölümü */
        .clinical-tests-section {
          background: #fff;
          border-radius: 16px;
          padding: 24px;
          margin-bottom: 24px;
          box-shadow: 0 2px 8px rgba(0,0,0,0.06);
          width: 100%;
          max-width: 100%;
          overflow: visible;
        }
        .clinical-tests-title {
          font-size: 18px;
          font-weight: 700;
          color: #1f2937;
          margin-bottom: 16px;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .clinical-tests-buttons {
          display: flex;
          gap: 12px;
          flex-wrap: nowrap;
          align-items: stretch;
          justify-content: flex-start;
        }
        .clinical-test-btn {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 12px 14px;
          background: linear-gradient(135deg, #667eea, #764ba2);
          border: 2px solid transparent;
          border-radius: 12px;
          color: #fff;
          cursor: pointer;
          transition: all 0.3s;
          flex: 1 1 0;
          min-width: 120px;
          box-shadow: 0 2px 8px rgba(102, 126, 234, 0.2);
        }
        .clinical-test-btn:hover:not(:disabled) {
          background: linear-gradient(135deg, #764ba2, #667eea);
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }
        .clinical-test-btn:disabled {
          opacity: 0.7;
          cursor: not-allowed;
        }
        .test-btn-icon {
          font-size: 24px;
          flex-shrink: 0;
        }
        .test-btn-content {
          display: flex;
          flex-direction: column;
          gap: 2px;
          flex: 1;
          min-width: 0;
          overflow: visible;
        }
        .test-btn-text {
          font-size: 13px;
          font-weight: 700;
          line-height: 1.2;
          white-space: normal;
          overflow: visible;
          word-wrap: break-word;
          hyphens: auto;
        }
        .test-btn-desc {
          font-size: 10px;
          font-weight: 500;
          opacity: 0.9;
          line-height: 1.2;
          white-space: normal;
          overflow: visible;
          word-wrap: break-word;
        }
        
        @media (max-width: 1200px) {
          .clinical-test-btn {
            padding: 10px 10px;
            min-width: 100px;
          }
          .test-btn-icon {
            font-size: 20px;
          }
          .test-btn-text {
            font-size: 11px;
          }
          .test-btn-desc {
            font-size: 9px;
          }
        }
        
        @media (max-width: 768px) {
          .clinical-tests-buttons {
            flex-wrap: wrap;
            gap: 8px;
          }
          .clinical-test-btn {
            flex: 1 1 calc(50% - 4px);
            min-width: 0;
            padding: 10px 12px;
          }
          .test-btn-icon {
            font-size: 20px;
          }
          .test-btn-text {
            font-size: 12px;
          }
          .test-btn-desc {
            font-size: 10px;
          }
          .sidebar { position: fixed; left: -260px; z-index: 100; transition: left 0.3s; }
          .sidebar.open { left: 0; }
          .main-cta-card { flex-direction: column; text-align: center; }
          .cta-illustration { width: 140px; height: 140px; }
          .profile-dropdown { right: 16px; width: calc(100% - 32px); }
          .stats-grid { grid-template-columns: repeat(2, 1fr); gap: 12px; }
          .quick-actions { grid-template-columns: 1fr; }
          .dashboard-grid { grid-template-columns: 1fr; }
          .chart-bars { height: 150px; }
          .badges-grid { grid-template-columns: repeat(2, 1fr); }
          .welcome-section { flex-direction: column; align-items: flex-start; gap: 16px; }
          .welcome-badges { width: 100%; }
        }
      `}),l.jsxs("div",{className:"sidebar",children:[l.jsxs("div",{className:"sidebar-header",children:[l.jsxs("div",{className:"logo",children:[l.jsx(hx,{size:56}),l.jsx("span",{style:{fontSize:20,fontWeight:"bold",background:"linear-gradient(135deg, #667eea, #10b981)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"},children:"EgzersizLab"})]}),l.jsx("div",{className:"logo-progress",children:l.jsx("div",{className:"logo-progress-inner",style:{width:`${Pe}%`}})})]}),l.jsxs("div",{className:"menu-items",children:[l.jsx("div",{className:"menu-section-title",children:"PANEL"}),l.jsxs("div",{className:"menu-item active",children:[l.jsx("span",{role:"img","aria-label":"home",children:"🏠"}),l.jsx("span",{children:"Ana Sayfa"})]}),ye?l.jsxs("div",{className:"menu-item",onClick:()=>y(!0),children:[l.jsx("span",{role:"img","aria-label":"exercise",children:"🧘"}),l.jsx("span",{children:"Egzersiz Programım"}),l.jsx("span",{children:"✅"})]}):l.jsxs("div",{className:"menu-item locked",onClick:()=>Rt(!1),children:[l.jsx("span",{role:"img","aria-label":"exercise",children:"🧘"}),l.jsx("span",{children:"Egzersiz Programım"}),l.jsx("span",{children:"🔒"})]}),ye?l.jsxs("div",{className:"menu-item",onClick:()=>ge(!0),children:[l.jsx("span",{role:"img","aria-label":"calendar",children:"📅"}),l.jsx("span",{children:"Takvim / İlerleme"}),l.jsx("span",{children:"✅"})]}):l.jsxs("div",{className:"menu-item locked",onClick:()=>Rt(!1),children:[l.jsx("span",{role:"img","aria-label":"calendar",children:"📅"}),l.jsx("span",{children:"Takvim / İlerleme"}),l.jsx("span",{children:"🔒"})]}),l.jsx("div",{className:"menu-divider"}),l.jsx("div",{className:"menu-section-title",children:"DESTEK & İLETİŞİM"}),ce==="premium"?l.jsxs("div",{className:"menu-item",onClick:()=>{const x="905551234567",q=encodeURIComponent("Merhaba, EgzersizLab fizyoterapist desteği için yazıyorum.");window.open(`https://wa.me/${x}?text=${q}`,"_blank")},children:[l.jsx("span",{role:"img","aria-label":"chat",children:"💬"}),l.jsx("span",{children:"Fizyoterapiste Sor"}),l.jsx("span",{children:"✅"})]}):l.jsxs("div",{className:"menu-item locked premium-feature",onClick:()=>Rt(!0),children:[l.jsx("span",{role:"img","aria-label":"chat",children:"💬"}),l.jsx("span",{children:"Fizyoterapiste Sor"}),l.jsx("span",{children:"🔒"})]}),l.jsxs("div",{className:"menu-item",onClick:()=>H(!0),children:[l.jsx("span",{role:"img","aria-label":"ticket",children:"🎟️"}),l.jsx("span",{children:"Destek Talebi"})]}),l.jsxs("div",{className:"menu-item",onClick:()=>ue(!0),children:[l.jsx("span",{role:"img","aria-label":"help",children:"❓"}),l.jsx("span",{children:"Yardım / SSS"})]}),l.jsx("div",{className:"menu-divider"}),l.jsx("div",{className:"menu-section-title",children:"HESAP & AYARLAR"}),l.jsxs("div",{className:"menu-item",onClick:()=>Ye(!0),children:[l.jsx("span",{role:"img","aria-label":"package",children:"📦"}),l.jsx("span",{children:"Paketlerim & Ödemeler"})]}),l.jsxs("div",{className:"menu-item",onClick:()=>Q(!0),children:[l.jsx("span",{role:"img","aria-label":"settings",children:"⚙️"}),l.jsx("span",{children:"Ayarlar"})]}),l.jsxs("div",{className:"menu-item",onClick:mt,children:[l.jsx("span",{role:"img","aria-label":"logout",children:"🚪"}),l.jsx("span",{children:"Çıkış Yap"})]})]})]}),l.jsxs("div",{className:"main-content",children:[l.jsxs("div",{className:"top-bar",children:[l.jsxs("div",{className:"welcome-section",children:[l.jsxs("div",{className:"welcome-text",children:[l.jsxs("h1",{id:"welcome-title",children:["Merhaba, ",r.user_name," 👋"]}),l.jsx("p",{id:"welcome-subtitle",children:r.welcome_subtitle})]}),ye&&l.jsxs("div",{className:"welcome-badges",onClick:()=>O(!0),style:{cursor:"pointer"},children:[l.jsx("div",{className:"welcome-badges-title",children:"🏆 Başarılarım"}),l.jsxs("div",{className:"welcome-badges-list",children:[st.filter(x=>x.earned).slice(0,3).map(x=>l.jsx("div",{className:"welcome-badge-item",title:x.name,children:l.jsx("span",{className:"welcome-badge-icon",children:x.icon})},x.id)),st.filter(x=>x.earned).length>3&&l.jsxs("div",{className:"welcome-badge-more",title:`+${st.filter(x=>x.earned).length-3} daha fazla`,children:["+",st.filter(x=>x.earned).length-3]}),st.filter(x=>x.earned).length===0&&l.jsx("div",{style:{fontSize:"12px",color:"#92400e",fontStyle:"italic"},children:"İlk başarınızı kazanın!"})]})]})]}),l.jsxs("div",{style:{position:"fixed",top:"80px",right:"20px",zIndex:1e3,display:"flex",flexDirection:"column",gap:"8px"},children:[l.jsx("div",{style:{background:ce==="none"?"#ef4444":"#e5e7eb",color:ce==="none"?"#fff":"#6b7280",padding:"6px 12px",borderRadius:"8px",fontSize:"11px",fontWeight:700,cursor:"pointer",boxShadow:"0 2px 8px rgba(0,0,0,0.2)",transition:"all 0.2s",textAlign:"center",minWidth:"120px"},onClick:()=>Me("none"),title:"Paket yok görünümü",children:"❌ Paket Yok"}),l.jsx("div",{style:{background:ce==="basic"?"#3b82f6":"#e5e7eb",color:ce==="basic"?"#fff":"#6b7280",padding:"6px 12px",borderRadius:"8px",fontSize:"11px",fontWeight:700,cursor:"pointer",boxShadow:"0 2px 8px rgba(0,0,0,0.2)",transition:"all 0.2s",textAlign:"center",minWidth:"120px"},onClick:()=>Me("basic"),title:"Temel paket görünümü",children:"📦 Temel Paket"}),l.jsx("div",{style:{background:ce==="pro"?"#10b981":"#e5e7eb",color:ce==="pro"?"#fff":"#6b7280",padding:"6px 12px",borderRadius:"8px",fontSize:"11px",fontWeight:700,cursor:"pointer",boxShadow:"0 2px 8px rgba(0,0,0,0.2)",transition:"all 0.2s",textAlign:"center",minWidth:"120px"},onClick:()=>Me("pro"),title:"Klinik takip paketi görünümü",children:"⭐ Klinik Paket"}),l.jsx("div",{style:{background:ce==="premium"?"#f59e0b":"#e5e7eb",color:ce==="premium"?"#fff":"#6b7280",padding:"6px 12px",borderRadius:"8px",fontSize:"11px",fontWeight:700,cursor:"pointer",boxShadow:"0 2px 8px rgba(0,0,0,0.2)",transition:"all 0.2s",textAlign:"center",minWidth:"120px"},onClick:()=>Me("premium"),title:"Premium paket görünümü",children:"👑 Premium Paket"}),l.jsxs("div",{style:{marginTop:"16px",borderTop:"1px solid rgba(255,255,255,0.3)",paddingTop:"12px"},children:[l.jsx("div",{style:{background:"linear-gradient(135deg, #8b5cf6, #6366f1)",color:"#fff",padding:"6px 12px",borderRadius:"8px",fontSize:"10px",fontWeight:700,cursor:"pointer",boxShadow:"0 2px 8px rgba(0,0,0,0.2)",textAlign:"center",marginBottom:"8px"},onClick:()=>{const x=document.getElementById("dev-pain-areas");x&&(x.style.display=x.style.display==="none"?"block":"none")},title:"Geliştirici: Ağrı bölgesi seçici",children:"🔧 Bölge Seç"}),l.jsxs("div",{id:"dev-pain-areas",style:{display:"none",background:"#fff",borderRadius:"8px",padding:"8px",boxShadow:"0 4px 12px rgba(0,0,0,0.3)",maxHeight:"300px",overflowY:"auto",fontSize:"10px"},children:[l.jsx("div",{style:{fontWeight:700,marginBottom:"8px",color:"#6366f1"},children:"📍 Hızlı Bölge Seç:"}),l.jsxs("div",{style:{display:"flex",flexDirection:"column",gap:"4px"},children:[l.jsx("button",{style:{padding:"6px 8px",background:ee.some(x=>x.includes("calf")||x.includes("ankle"))?"#8b5cf6":"#f3f4f6",color:ee.some(x=>x.includes("calf")||x.includes("ankle"))?"#fff":"#374151",border:"none",borderRadius:"6px",cursor:"pointer",fontSize:"10px",fontWeight:600,textAlign:"left"},onClick:()=>{const x=["calf-back-left","calf-back-right","ankle-front-left","ankle-front-right"];P(x),localStorage.setItem("userPainAreas",JSON.stringify(x))},children:"🦵 Baldır + Ayak Bileği"}),l.jsx("button",{style:{padding:"6px 8px",background:ee.some(x=>x.includes("knee"))?"#8b5cf6":"#f3f4f6",color:ee.some(x=>x.includes("knee"))?"#fff":"#374151",border:"none",borderRadius:"6px",cursor:"pointer",fontSize:"10px",fontWeight:600,textAlign:"left"},onClick:()=>{const x=["knee-front-left","knee-front-right","knee-back-left","knee-back-right"];P(x),localStorage.setItem("userPainAreas",JSON.stringify(x))},children:"🦿 Diz (Sol + Sağ)"}),l.jsx("button",{style:{padding:"6px 8px",background:ee.some(x=>x.includes("lower-back"))?"#8b5cf6":"#f3f4f6",color:ee.some(x=>x.includes("lower-back"))?"#fff":"#374151",border:"none",borderRadius:"6px",cursor:"pointer",fontSize:"10px",fontWeight:600,textAlign:"left"},onClick:()=>{const x=["lower-back"];P(x),localStorage.setItem("userPainAreas",JSON.stringify(x))},children:"🔙 Bel"}),l.jsx("button",{style:{padding:"6px 8px",background:ee.some(x=>x.includes("neck"))?"#8b5cf6":"#f3f4f6",color:ee.some(x=>x.includes("neck"))?"#fff":"#374151",border:"none",borderRadius:"6px",cursor:"pointer",fontSize:"10px",fontWeight:600,textAlign:"left"},onClick:()=>{const x=["neck-front","neck-back"];P(x),localStorage.setItem("userPainAreas",JSON.stringify(x))},children:"🦒 Boyun"}),l.jsx("button",{style:{padding:"6px 8px",background:ee.some(x=>x.includes("shoulder"))?"#8b5cf6":"#f3f4f6",color:ee.some(x=>x.includes("shoulder"))?"#fff":"#374151",border:"none",borderRadius:"6px",cursor:"pointer",fontSize:"10px",fontWeight:600,textAlign:"left"},onClick:()=>{const x=["shoulder-front-left","shoulder-front-right","shoulder-back-left","shoulder-back-right"];P(x),localStorage.setItem("userPainAreas",JSON.stringify(x))},children:"💪 Omuz (Sol + Sağ)"}),l.jsx("button",{style:{padding:"6px 8px",background:ee.some(x=>x.includes("hip"))?"#8b5cf6":"#f3f4f6",color:ee.some(x=>x.includes("hip"))?"#fff":"#374151",border:"none",borderRadius:"6px",cursor:"pointer",fontSize:"10px",fontWeight:600,textAlign:"left"},onClick:()=>{const x=["hip-front","hip-back"];P(x),localStorage.setItem("userPainAreas",JSON.stringify(x))},children:"🍑 Kalça"}),l.jsx("div",{style:{borderTop:"1px solid #e5e7eb",marginTop:"4px",paddingTop:"4px"},children:l.jsx("button",{style:{padding:"6px 8px",background:"#ef4444",color:"#fff",border:"none",borderRadius:"6px",cursor:"pointer",fontSize:"10px",fontWeight:600,width:"100%"},onClick:()=>{P([]),localStorage.removeItem("userPainAreas")},children:"🗑️ Temizle"})})]}),ee.length>0&&l.jsxs("div",{style:{marginTop:"8px",padding:"6px",background:"#f0fdf4",borderRadius:"6px",fontSize:"9px",color:"#166534"},children:[l.jsx("strong",{children:"Aktif:"})," ",ee.join(", ")]})]})]})]}),l.jsxs("div",{className:"top-bar-right",children:[l.jsxs("div",{className:"notification-wrapper",children:[l.jsxs("div",{className:"notification-bell",title:"Bildirimler",ref:tn,onClick:x=>{x.stopPropagation(),oe(!V)},children:["🔔",gl>0&&l.jsx("span",{className:"notification-badge",children:gl})]}),V&&l.jsxs(l.Fragment,{children:[l.jsx("div",{className:"cart-overlay",onClick:()=>oe(!1)}),l.jsxs("div",{className:"notification-dropdown",ref:si,children:[l.jsxs("div",{className:"notification-header",children:[l.jsx("span",{children:"🔔 Bildirimler"}),gl>0&&l.jsxs("span",{style:{fontSize:"12px",opacity:.9},children:[gl," okunmamış"]})]}),l.jsx("div",{className:"notification-items",children:ke.length===0?l.jsxs("div",{className:"notification-empty",children:[l.jsx("div",{style:{fontSize:"32px",marginBottom:"8px"},children:"🔕"}),l.jsx("div",{children:"Yeni bildiriminiz yok"})]}):ke.map(x=>l.jsxs("div",{className:`notification-item ${x.read?"read":"unread"}`,onClick:()=>ys(x.id),children:[l.jsx("div",{className:"notification-item-title",children:x.title}),l.jsx("div",{className:"notification-item-message",children:x.message}),l.jsxs("div",{className:"notification-item-meta",children:[l.jsx("span",{className:`notification-item-type ${x.type}`,children:x.type==="clinical"?"Klinik":x.type==="admin"?"İdari":"Motivasyon"}),l.jsx("span",{className:"notification-item-date",children:x.date})]})]},x.id))}),ke.length>0&&l.jsx("div",{className:"notification-footer",children:l.jsx("button",{className:"notification-footer-btn",children:"Tümünü Gör"})})]})]})]}),l.jsxs("div",{className:"cart-wrapper",children:[l.jsxs("div",{className:"cart-bell",title:"Sepetim",onClick:()=>I(!D),children:["🛒",fe.length>0&&l.jsx("span",{className:"cart-badge",children:fe.length})]}),D&&l.jsxs(l.Fragment,{children:[l.jsx("div",{className:"cart-overlay",onClick:()=>I(!1)}),l.jsxs("div",{className:"cart-dropdown",children:[l.jsxs("div",{className:"cart-header",children:["🛒 Sepetim (",fe.length,")"]}),fe.length===0?l.jsx("div",{className:"cart-empty",children:"Sepetiniz boş"}):l.jsxs(l.Fragment,{children:[l.jsx("div",{className:"cart-items",children:fe.map(x=>l.jsxs("div",{className:"cart-item",children:[l.jsxs("div",{className:"cart-item-info",children:[l.jsx("span",{className:"cart-item-name",children:x.name}),l.jsxs("span",{className:"cart-item-price",children:[x.price,"₺"]})]}),l.jsx("button",{className:"cart-item-remove",onClick:()=>ae(x.id),children:"✕"})]},x.id))}),l.jsxs("div",{className:"cart-footer",children:[l.jsxs("div",{className:"cart-total",children:[l.jsx("span",{children:"Toplam:"}),l.jsxs("span",{className:"cart-total-price",children:[xe().toLocaleString(),"₺"]})]}),l.jsx("button",{className:"cart-checkout-btn",children:"💳 Ödemeye Geç"})]})]})]})]})]}),l.jsx("div",{className:"profile-pic",title:"Profil",onClick:x=>{x.stopPropagation(),bs()},ref:Et,"aria-label":"Profil menüsü",children:(Fa=r.user_name)==null?void 0:Fa.charAt(0).toUpperCase()}),l.jsxs("div",{className:`profile-dropdown ${Z?"active":""}`,ref:Na,children:[l.jsxs("div",{className:"profile-card-header",children:[l.jsx("div",{className:"profile-avatar-large",children:(Pa=r.user_name)==null?void 0:Pa.charAt(0).toUpperCase()}),l.jsx("div",{className:"profile-name",children:r.user_name}),l.jsx("span",{className:"premium-badge-inline",children:"⭐ Premium Üye"})]}),l.jsxs("div",{className:"profile-menu-section",children:[l.jsx("div",{className:"profile-section-title",children:"Kişisel Sağlık Verileri"}),l.jsxs("div",{className:"profile-menu-item",children:[l.jsx("span",{className:"profile-menu-icon",children:"📸"}),l.jsxs("div",{className:"profile-menu-text",children:[l.jsx("div",{children:"Vücut Fotoğraflarım"}),l.jsx("div",{className:"subtitle",children:"Postür fotoğraflarını görüntüle"})]})]}),l.jsxs("div",{className:"profile-menu-item",children:[l.jsx("span",{className:"profile-menu-icon",children:"📋"}),l.jsxs("div",{className:"profile-menu-text",children:[l.jsx("div",{children:"Anamnez Bilgilerim"}),l.jsx("div",{className:"subtitle",children:"Ağrı haritası ve sağlık geçmişi"})]})]}),l.jsxs("div",{className:"profile-menu-item",children:[l.jsx("span",{className:"profile-menu-icon",children:"📏"}),l.jsxs("div",{className:"profile-menu-text",children:[l.jsx("div",{children:"Fiziksel Ölçümlerim"}),l.jsx("div",{className:"subtitle",children:"Boy, kilo, BMI ve ölçüler"})]})]})]}),l.jsxs("div",{className:"profile-menu-section",children:[l.jsx("div",{className:"profile-section-title",children:"Hesap Yönetimi"}),l.jsxs("div",{className:"profile-menu-item",children:[l.jsx("span",{className:"profile-menu-icon",children:"🔒"}),l.jsx("div",{className:"profile-menu-text",children:l.jsx("div",{children:"Şifre Değiştir"})})]}),l.jsxs("div",{className:"profile-menu-item danger",onClick:mt,children:[l.jsx("span",{className:"profile-menu-icon",children:"🚪"}),l.jsx("div",{className:"profile-menu-text",children:l.jsx("div",{children:"Güvenli Çıkış"})})]})]})]})]})]}),l.jsxs("div",{className:"content-area",children:[!ye&&l.jsxs("div",{className:"main-cta-card",children:[l.jsx("div",{className:"cta-illustration",children:l.jsxs("svg",{viewBox:"0 0 200 200",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[l.jsx("circle",{cx:"100",cy:"60",r:"30",fill:"#667eea",opacity:"0.2"}),l.jsx("circle",{cx:"100",cy:"60",r:"20",fill:"#667eea"}),l.jsx("rect",{x:"75",y:"90",width:"50",height:"70",rx:"5",fill:"#667eea"}),l.jsx("rect",{x:"70",y:"100",width:"15",height:"40",rx:"7",fill:"#f59e0b"}),l.jsx("rect",{x:"115",y:"100",width:"15",height:"40",rx:"7",fill:"#f59e0b"}),l.jsx("rect",{x:"85",y:"155",width:"12",height:"35",rx:"6",fill:"#667eea"}),l.jsx("rect",{x:"103",y:"155",width:"12",height:"35",rx:"6",fill:"#667eea"}),l.jsx("rect",{x:"130",y:"80",width:"50",height:"70",rx:"4",fill:"white",stroke:"#667eea",strokeWidth:"2"}),l.jsx("line",{x1:"140",y1:"100",x2:"170",y2:"100",stroke:"#667eea",strokeWidth:"2"}),l.jsx("line",{x1:"140",y1:"115",x2:"170",y2:"115",stroke:"#667eea",strokeWidth:"2"}),l.jsx("line",{x1:"140",y1:"130",x2:"165",y2:"130",stroke:"#667eea",strokeWidth:"2"})]})}),l.jsxs("div",{className:"cta-content",children:[l.jsx("h2",{id:"cta-title",children:r.cta_title}),l.jsx("p",{id:"cta-description",children:r.cta_description}),l.jsxs("button",{className:"cta-button",onClick:ht,disabled:E,children:[l.jsx("span",{children:"▶"}),l.jsx("span",{id:"cta-button-text",children:E?"Yönlendiriliyorsunuz...":r.cta_button_text})]}),l.jsx("span",{className:"duration-hint",id:"cta-duration",children:r.cta_duration})]})]}),ye?l.jsxs(l.Fragment,{children:[l.jsxs("div",{className:"clinical-tests-section",children:[l.jsx("div",{className:"clinical-tests-title",children:"🔬 Klinik Testler"}),l.jsxs("div",{className:"clinical-tests-buttons",children:[l.jsxs("button",{className:"clinical-test-btn",onClick:()=>N("muscle-strength"),title:"Manuel kas testi simülasyonu - Hangi kaslarınız uykuda, hangileri aşırı çalışıyor? (Gluteal amnezi, core stabilizasyonu vb.)",children:[l.jsx("span",{className:"test-btn-icon",children:"💪"}),l.jsxs("div",{className:"test-btn-content",children:[l.jsx("span",{className:"test-btn-text",children:"Kas Kuvveti"}),l.jsx("span",{className:"test-btn-desc",children:"Manuel test"})]})]}),l.jsxs("button",{className:"clinical-test-btn",onClick:()=>N("flexibility"),title:"Ağrısının sebebi kas kısalığı mı? Hamstring, pektoral, iliopsoas, piriformis gerginlik testleri.",children:[l.jsx("span",{className:"test-btn-icon",children:"📏"}),l.jsxs("div",{className:"test-btn-content",children:[l.jsx("span",{className:"test-btn-text",children:"Esneklik"}),l.jsx("span",{className:"test-btn-desc",children:"Kas kısalığı"})]})]}),l.jsxs("button",{className:"clinical-test-btn",onClick:()=>N("rom"),title:"Gonyometrik analiz - Eklemler tam açıyla hareket ediyor mu, kısıtlılık derecesi nedir?",children:[l.jsx("span",{className:"test-btn-icon",children:"📐"}),l.jsxs("div",{className:"test-btn-content",children:[l.jsx("span",{className:"test-btn-text",children:"EHA"}),l.jsx("span",{className:"test-btn-desc",children:"Gonyometri"})]})]}),l.jsxs("button",{className:"clinical-test-btn",onClick:()=>N("neurodynamic"),title:"Sinir germe testleri - Ağrı kas kaynaklı mı yoksa sinir sıkışması mı (Fıtık/Siyatik)?",children:[l.jsx("span",{className:"test-btn-icon",children:"🧠"}),l.jsxs("div",{className:"test-btn-content",children:[l.jsx("span",{className:"test-btn-text",children:"Nörodinamik"}),l.jsx("span",{className:"test-btn-desc",children:"Sinir testi"})]})]}),l.jsxs("button",{className:"clinical-test-btn",onClick:()=>N("balance"),title:"Vücudun uzaydaki konum algısı ve denge stratejisi",children:[l.jsx("span",{className:"test-btn-icon",children:"⚖️"}),l.jsxs("div",{className:"test-btn-content",children:[l.jsx("span",{className:"test-btn-text",children:"Denge"}),l.jsx("span",{className:"test-btn-desc",children:"Fonksiyonel"})]})]}),l.jsxs("button",{className:"clinical-test-btn",onClick:()=>N("movement"),title:"Çömelme, eğilme ve uzanma sırasında omurga biyomekaniği kontrolü",children:[l.jsx("span",{className:"test-btn-icon",children:"🩺"}),l.jsxs("div",{className:"test-btn-content",children:[l.jsx("span",{className:"test-btn-text",children:"Hareket Analizi"}),l.jsx("span",{className:"test-btn-desc",children:"Biyomekanik"})]})]})]})]}),l.jsxs("div",{className:"stats-grid",children:[l.jsxs("div",{className:"stat-card",children:[l.jsx("div",{className:"stat-icon",style:{background:"linear-gradient(135deg, #667eea, #764ba2)"},children:"📊"}),l.jsxs("div",{className:"stat-content",children:[l.jsxs("div",{className:"stat-value",children:[ft.todayCompleted,"/",ft.todayExercises]}),l.jsx("div",{className:"stat-label",children:"Bugünkü Egzersizler"})]})]}),l.jsxs("div",{className:"stat-card",children:[l.jsx("div",{className:"stat-icon",style:{background:"linear-gradient(135deg, #10b981, #059669)"},children:"📈"}),l.jsxs("div",{className:"stat-content",children:[l.jsxs("div",{className:"stat-value",children:[ft.weeklyCompleted,"/",ft.weeklyTotal]}),l.jsx("div",{className:"stat-label",children:"Bu Hafta Tamamlanan"})]})]}),l.jsxs("div",{className:"stat-card",children:[l.jsx("div",{className:"stat-icon",style:{background:"linear-gradient(135deg, #f59e0b, #d97706)"},children:"🎯"}),l.jsxs("div",{className:"stat-content",children:[l.jsxs("div",{className:"stat-value",children:[ft.progressPercentage,"%"]}),l.jsx("div",{className:"stat-label",children:"Genel İlerleme"})]})]}),l.jsxs("div",{className:"stat-card",children:[l.jsx("div",{className:"stat-icon",style:{background:"linear-gradient(135deg, #ef4444, #dc2626)"},children:"🔥"}),l.jsxs("div",{className:"stat-content",children:[l.jsxs("div",{className:"stat-value",children:[ft.streak," gün"]}),l.jsx("div",{className:"stat-label",children:"Streak"})]})]})]}),l.jsxs("div",{className:"quick-actions",children:[l.jsxs("button",{className:"quick-action-btn primary",onClick:()=>y(!0),children:[l.jsx("span",{className:"quick-action-icon",children:"🏃‍♂️"}),l.jsxs("div",{className:"quick-action-text",children:[l.jsx("div",{className:"quick-action-title",children:"Egzersiz Yap"}),l.jsx("div",{className:"quick-action-subtitle",children:"Bugünkü programını başlat"})]})]}),l.jsxs("button",{className:"quick-action-btn",onClick:()=>ge(!0),children:[l.jsx("span",{className:"quick-action-icon",children:"📊"}),l.jsxs("div",{className:"quick-action-text",children:[l.jsx("div",{className:"quick-action-title",children:"İlerlememi Gör"}),l.jsx("div",{className:"quick-action-subtitle",children:"Detaylı analiz"})]})]})]}),l.jsxs("div",{className:"dashboard-grid",children:[l.jsxs("div",{className:"dashboard-left",children:[l.jsxs("div",{className:"task-card",children:[l.jsxs("div",{className:"card-header",children:[l.jsx("h3",{className:"card-title",children:"📅 Bugünkü Görevler"}),l.jsxs("span",{className:"card-badge",children:[bt.filter(x=>x.completed).length,"/",bt.length]})]}),l.jsx("div",{className:"task-list",children:bt.map(x=>l.jsxs("div",{className:`task-item ${x.completed?"completed":""}`,children:[l.jsx("div",{className:"task-checkbox",onClick:()=>ka(x.id),children:x.completed?"✅":"⭕"}),l.jsxs("div",{className:"task-info",children:[l.jsx("div",{className:"task-name",children:x.name}),l.jsxs("div",{className:"task-meta",children:[l.jsxs("span",{className:"task-duration",children:["⏱️ ",x.duration]}),l.jsxs("span",{className:"task-time",children:["🕐 ",x.time]})]})]})]},x.id))}),l.jsx("button",{className:"task-view-all",onClick:()=>y(!0),children:"Tüm Programı Gör →"})]}),l.jsxs("div",{className:"progress-chart-card",children:[l.jsx("div",{className:"card-header",children:l.jsx("h3",{className:"card-title",children:"📈 Haftalık İlerleme"})}),l.jsx("div",{className:"chart-container",children:l.jsx("div",{className:"chart-bars",children:Xt.map((x,q)=>l.jsxs("div",{className:"chart-bar-wrapper",children:[l.jsx("div",{className:"chart-bar",style:{height:`${x.value}%`},children:l.jsxs("span",{className:"chart-value",children:[x.value,"%"]})}),l.jsx("div",{className:"chart-label",children:x.day})]},q))})}),l.jsxs("div",{className:"chart-footer",children:[l.jsxs("div",{className:"chart-stat",children:[l.jsx("span",{className:"chart-stat-label",children:"Ortalama:"}),l.jsxs("span",{className:"chart-stat-value",children:[Math.round(Xt.reduce((x,q)=>x+q.value,0)/Xt.length),"%"]})]}),l.jsxs("div",{className:"chart-stat",children:[l.jsx("span",{className:"chart-stat-label",children:"En Yüksek:"}),l.jsxs("span",{className:"chart-stat-value",children:[Math.max(...Xt.map(x=>x.value)),"%"]})]})]})]})]}),l.jsxs("div",{className:"dashboard-right",children:[l.jsxs("div",{className:"package-status-card",children:[l.jsxs("div",{className:"card-header",children:[l.jsx("h3",{className:"card-title",children:"📦 Aktif Paket"}),l.jsx("span",{className:"package-badge active",style:{background:ce==="premium"?"#fef3c7":ce==="pro"?"#dcfce7":"#dbeafe",color:ce==="premium"?"#92400e":ce==="pro"?"#15803d":"#1e40af"},children:ce==="premium"?"👑 Premium":ce==="pro"?"⭐ Klinik":ce==="basic"?"📦 Temel":"Aktif"})]}),l.jsxs("div",{className:"package-info",children:[l.jsx("div",{className:"package-name",children:yt.name}),l.jsx("div",{className:"package-dates",children:l.jsxs("span",{children:["📅 ",yt.startDate," ",yt.endDate!=="Tek Seferlik"?`- ${yt.endDate}`:""]})}),yt.daysRemaining!==null&&l.jsxs("div",{className:"package-countdown",children:[l.jsx("span",{className:"countdown-icon",children:"⏳"}),l.jsxs("span",{className:"countdown-text",children:[yt.daysRemaining," gün kaldı"]})]}),l.jsxs("div",{style:{marginBottom:"12px",fontSize:"14px",fontWeight:700,color:"#10b981"},children:["💰 ",yt.price]}),l.jsx("div",{className:"package-features",children:yt.features.map((x,q)=>l.jsxs("div",{className:"package-feature",children:[l.jsx("span",{children:"✓"})," ",x]},q))})]}),l.jsx("button",{className:"package-manage-btn",onClick:()=>Ye(!0),children:"Paketi Yönet →"})]}),l.jsxs("div",{className:"activities-card",children:[l.jsx("div",{className:"card-header",children:l.jsx("h3",{className:"card-title",children:"🕐 Son Aktiviteler"})}),l.jsx("div",{className:"activities-list",children:ja.map(x=>l.jsxs("div",{className:"activity-item",children:[l.jsx("div",{className:"activity-icon",children:x.icon}),l.jsxs("div",{className:"activity-content",children:[l.jsx("div",{className:"activity-text",children:x.text}),l.jsx("div",{className:"activity-time",children:x.time})]})]},x.id))}),l.jsx("button",{className:"activities-view-all",children:"Tüm Aktiviteleri Gör →"})]})]})]})]}):null,l.jsxs("div",{className:"info-cards",children:[l.jsxs("div",{className:"info-card video-card",onClick:()=>ne(!0),children:[l.jsx("div",{className:"info-card-icon",children:"🎬"}),l.jsx("h3",{id:"video-title",children:r.video_title}),l.jsx("p",{children:'1 dakikalık "Sistem Nasıl İşliyor?" videosunu izleyerek süreci daha iyi anlayabilirsiniz.'})]}),l.jsxs("div",{className:"info-card tip-card tip-carousel",children:[l.jsx("div",{className:"info-card-icon",children:Ce[re].icon}),l.jsx("h3",{className:"tip-title-animated",children:Ce[re].title}),l.jsx("p",{className:"tip-text-animated",children:Ce[re].text}),l.jsx("div",{className:"tip-dots",children:Ce.map((x,q)=>l.jsx("span",{className:`tip-dot ${q===re?"active":""}`,onClick:()=>Oe(q)},q))})]})]})]})]}),w&&l.jsx("div",{style:{position:"fixed",top:20,right:20,background:"#fef3c7",color:"#92400e",padding:"16px 20px",borderRadius:8,boxShadow:"0 4px 12px rgba(0,0,0,0.15)",zIndex:1e3,fontSize:14,maxWidth:320,lineHeight:1.5},children:w}),l.jsx(ng,{open:b,clinicalTestType:U,onClose:()=>{p(!1),N(null)},onComplete:()=>{L(!0)}}),l.jsx(og,{open:G,onClose:()=>L(!1),onAddToCart:X,cartItems:fe}),l.jsx(dg,{open:J,onClose:()=>H(!1)}),l.jsx(fg,{open:K,onClose:()=>ue(!1),onOpenSupport:()=>H(!0)}),l.jsx(mg,{open:$,onClose:()=>Ye(!1),onPurchase:x=>{x==="basic"?Me("basic"):x==="pro"?Me("pro"):x==="premium"&&Me("premium"),Ye(!1)},onCancelPackage:()=>Me("none"),hasPackage:ye,onAddToCart:X,cartItems:fe}),l.jsx(xg,{open:de,onClose:()=>Q(!1)}),l.jsx(pg,{open:Y,onClose:()=>ne(!1)}),l.jsx(hg,{open:_,onClose:()=>y(!1)}),l.jsx(yg,{open:te,onClose:()=>ge(!1)}),U&&l.jsx(kg,{isOpen:!!U,onClose:()=>N(null),testType:U,userPainAreas:ee}),me&&l.jsxs(l.Fragment,{children:[l.jsx("div",{style:{position:"fixed",inset:0,background:"rgba(0, 0, 0, 0.5)",zIndex:2e3},onClick:()=>O(!1)}),l.jsxs("div",{style:{position:"fixed",top:"50%",left:"50%",transform:"translate(-50%, -50%)",background:"#fff",borderRadius:"20px",padding:"32px",maxWidth:"900px",width:"90%",maxHeight:"85vh",overflowY:"auto",zIndex:2001,boxShadow:"0 20px 60px rgba(0,0,0,0.3)"},children:[l.jsxs("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"24px"},children:[l.jsx("h2",{style:{fontSize:"24px",fontWeight:700,color:"#1f2937",margin:0},children:"🏆 Başarılarım"}),l.jsx("button",{onClick:()=>O(!1),style:{background:"none",border:"none",fontSize:"24px",cursor:"pointer",color:"#6b7280",padding:"4px 8px"},children:"✕"})]}),l.jsx("div",{style:{display:"grid",gridTemplateColumns:"repeat(auto-fit, minmax(160px, 1fr))",gap:"16px"},children:st.map(x=>l.jsxs("div",{style:{background:x.earned?"linear-gradient(135deg, #fef3c7, #fde68a)":"#f9fafb",border:`2px solid ${x.earned?"#f59e0b":"#e5e7eb"}`,borderRadius:"16px",padding:"20px",textAlign:"center",position:"relative",opacity:x.earned?1:.7,transition:"all 0.2s",cursor:x.earned?"default":"pointer"},onMouseEnter:q=>{x.earned||(q.currentTarget.style.transform="scale(1.05)",q.currentTarget.style.boxShadow="0 4px 12px rgba(0,0,0,0.1)")},onMouseLeave:q=>{x.earned||(q.currentTarget.style.transform="scale(1)",q.currentTarget.style.boxShadow="none")},children:[l.jsx("div",{style:{fontSize:"48px",marginBottom:"12px"},children:x.icon}),l.jsx("div",{style:{fontSize:"15px",fontWeight:700,color:x.earned?"#92400e":"#6b7280",marginBottom:"6px"},children:x.name}),x.description&&l.jsx("div",{style:{fontSize:"11px",color:x.earned?"#b45309":"#9ca3af",marginBottom:"8px",lineHeight:"1.4",minHeight:"30px"},children:x.description}),!x.earned&&l.jsx("div",{style:{position:"absolute",top:"8px",right:"8px",fontSize:"20px",opacity:.5},children:"🔒"}),x.earned&&l.jsx("div",{style:{fontSize:"12px",color:"#92400e",fontWeight:700,marginTop:"8px",background:"rgba(251, 191, 36, 0.2)",padding:"4px 8px",borderRadius:"8px",display:"inline-block"},children:"✓ Kazanıldı"})]},x.id))}),l.jsxs("div",{style:{marginTop:"24px",padding:"20px",background:"linear-gradient(135deg, #fef3c7, #fde68a)",borderRadius:"16px",textAlign:"center",border:"2px solid #fbbf24"},children:[l.jsxs("div",{style:{fontSize:"18px",color:"#92400e",fontWeight:700,marginBottom:"6px"},children:[st.filter(x=>x.earned).length," / ",st.length," başarı kazandınız! 🎉"]}),l.jsx("div",{style:{fontSize:"13px",color:"#b45309",marginTop:"4px"},children:"Devam edin, daha fazla başarı sizi bekliyor! Her rozet seni hedefine bir adım daha yaklaştırıyor! 💪"}),l.jsx("div",{style:{marginTop:"12px",width:"100%",height:"8px",background:"#e5e7eb",borderRadius:"999px",overflow:"hidden"},children:l.jsx("div",{style:{width:`${st.filter(x=>x.earned).length/st.length*100}%`,height:"100%",background:"linear-gradient(90deg, #f59e0b, #d97706)",borderRadius:"999px",transition:"width 0.3s ease"}})})]})]})]})]})},gx=document.getElementById("root");if(!gx)throw new Error("Could not find root element to mount to");const Ng=()=>{const[r,v]=g.useState(()=>window.location.pathname.includes("dashboard")||window.location.hash==="#dashboard");return g.useEffect(()=>{const E=()=>{v(window.location.pathname.includes("dashboard")||window.location.hash==="#dashboard")};return window.addEventListener("hashchange",E),E(),()=>window.removeEventListener("hashchange",E)},[]),l.jsx(Vo.StrictMode,{children:r?l.jsx(jg,{}):l.jsx(Zh,{})})},zg=Y0.createRoot(gx);zg.render(l.jsx(Ng,{}));
