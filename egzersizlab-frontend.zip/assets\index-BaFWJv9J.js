(function(){const v=document.createElement("link").relList;if(v&&v.supports&&v.supports("modulepreload"))return;for(const k of document.querySelectorAll('link[rel="modulepreload"]'))d(k);new MutationObserver(k=>{for(const E of k)if(E.type==="childList")for(const S of E.addedNodes)S.tagName==="LINK"&&S.rel==="modulepreload"&&d(S)}).observe(document,{childList:!0,subtree:!0});function _(k){const E={};return k.integrity&&(E.integrity=k.integrity),k.referrerPolicy&&(E.referrerPolicy=k.referrerPolicy),k.crossOrigin==="use-credentials"?E.credentials="include":k.crossOrigin==="anonymous"?E.credentials="omit":E.credentials="same-origin",E}function d(k){if(k.ep)return;k.ep=!0;const E=_(k);fetch(k.href,E)}})();function xx(r){return r&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r}var Mo={exports:{}},Pi={};/**
 * @license React
 * react-jsx-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var qf;function Op(){if(qf)return Pi;qf=1;var r=Symbol.for("react.transitional.element"),v=Symbol.for("react.fragment");function _(d,k,E){var S=null;if(E!==void 0&&(S=""+E),k.key!==void 0&&(S=""+k.key),"key"in k){E={};for(var U in k)U!=="key"&&(E[U]=k[U])}else E=k;return k=E.ref,{$$typeof:r,type:d,key:S,ref:k!==void 0?k:null,props:E}}return Pi.Fragment=v,Pi.jsx=_,Pi.jsxs=_,Pi}var Vf;function Cp(){return Vf||(Vf=1,Mo.exports=Op()),Mo.exports}var a=Cp(),Ro={exports:{}},be={};/**
 * @license React
 * react.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Xf;function Dp(){if(Xf)return be;Xf=1;var r=Symbol.for("react.transitional.element"),v=Symbol.for("react.portal"),_=Symbol.for("react.fragment"),d=Symbol.for("react.strict_mode"),k=Symbol.for("react.profiler"),E=Symbol.for("react.consumer"),S=Symbol.for("react.context"),U=Symbol.for("react.forward_ref"),b=Symbol.for("react.suspense"),h=Symbol.for("react.memo"),L=Symbol.for("react.lazy"),N=Symbol.for("react.activity"),Y=Symbol.iterator;function H(m){return m===null||typeof m!="object"?null:(m=Y&&m[Y]||m["@@iterator"],typeof m=="function"?m:null)}var B={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},ae=Object.assign,Z={};function G(m,D,K){this.props=m,this.context=D,this.refs=Z,this.updater=K||B}G.prototype.isReactComponent={},G.prototype.setState=function(m,D){if(typeof m!="object"&&typeof m!="function"&&m!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,m,D,"setState")},G.prototype.forceUpdate=function(m){this.updater.enqueueForceUpdate(this,m,"forceUpdate")};function q(){}q.prototype=G.prototype;function fe(m,D,K){this.props=m,this.context=D,this.refs=Z,this.updater=K||B}var ee=fe.prototype=new q;ee.constructor=fe,ae(ee,G.prototype),ee.isPureReactComponent=!0;var Re=Array.isArray;function oe(){}var X={H:null,A:null,T:null,S:null},I=Object.prototype.hasOwnProperty;function ne(m,D,K){var J=K.ref;return{$$typeof:r,type:m,key:D,ref:J!==void 0?J:null,props:K}}function se(m,D){return ne(m.type,D,m.props)}function Se(m){return typeof m=="object"&&m!==null&&m.$$typeof===r}function re(m){var D={"=":"=0",":":"=2"};return"$"+m.replace(/[=:]/g,function(K){return D[K]})}var Ve=/\/+/g;function xe(m,D){return typeof m=="object"&&m!==null&&m.key!=null?re(""+m.key):D.toString(36)}function _e(m){switch(m.status){case"fulfilled":return m.value;case"rejected":throw m.reason;default:switch(typeof m.status=="string"?m.then(oe,oe):(m.status="pending",m.then(function(D){m.status==="pending"&&(m.status="fulfilled",m.value=D)},function(D){m.status==="pending"&&(m.status="rejected",m.reason=D)})),m.status){case"fulfilled":return m.value;case"rejected":throw m.reason}}throw m}function T(m,D,K,J,ue){var pe=typeof m;(pe==="undefined"||pe==="boolean")&&(m=null);var O=!1;if(m===null)O=!0;else switch(pe){case"bigint":case"string":case"number":O=!0;break;case"object":switch(m.$$typeof){case r:case v:O=!0;break;case L:return O=m._init,T(O(m._payload),D,K,J,ue)}}if(O)return ue=ue(m),O=J===""?"."+xe(m,0):J,Re(ue)?(K="",O!=null&&(K=O.replace(Ve,"$&/")+"/"),T(ue,D,K,"",function(ke){return ke})):ue!=null&&(Se(ue)&&(ue=se(ue,K+(ue.key==null||m&&m.key===ue.key?"":(""+ue.key).replace(Ve,"$&/")+"/")+O)),D.push(ue)),1;O=0;var te=J===""?".":J+":";if(Re(m))for(var W=0;W<m.length;W++)J=m[W],pe=te+xe(J,W),O+=T(J,D,K,pe,ue);else if(W=H(m),typeof W=="function")for(m=W.call(m),W=0;!(J=m.next()).done;)J=J.value,pe=te+xe(J,W++),O+=T(J,D,K,pe,ue);else if(pe==="object"){if(typeof m.then=="function")return T(_e(m),D,K,J,ue);throw D=String(m),Error("Objects are not valid as a React child (found: "+(D==="[object Object]"?"object with keys {"+Object.keys(m).join(", ")+"}":D)+"). If you meant to render a collection of children, use an array instead.")}return O}function f(m,D,K){if(m==null)return m;var J=[],ue=0;return T(m,J,"","",function(pe){return D.call(K,pe,ue++)}),J}function Q(m){if(m._status===-1){var D=m._result;D=D(),D.then(function(K){(m._status===0||m._status===-1)&&(m._status=1,m._result=K)},function(K){(m._status===0||m._status===-1)&&(m._status=2,m._result=K)}),m._status===-1&&(m._status=0,m._result=D)}if(m._status===1)return m._result.default;throw m._result}var ce=typeof reportError=="function"?reportError:function(m){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var D=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof m=="object"&&m!==null&&typeof m.message=="string"?String(m.message):String(m),error:m});if(!window.dispatchEvent(D))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",m);return}console.error(m)},me={map:f,forEach:function(m,D,K){f(m,function(){D.apply(this,arguments)},K)},count:function(m){var D=0;return f(m,function(){D++}),D},toArray:function(m){return f(m,function(D){return D})||[]},only:function(m){if(!Se(m))throw Error("React.Children.only expected to receive a single React element child.");return m}};return be.Activity=N,be.Children=me,be.Component=G,be.Fragment=_,be.Profiler=k,be.PureComponent=fe,be.StrictMode=d,be.Suspense=b,be.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=X,be.__COMPILER_RUNTIME={__proto__:null,c:function(m){return X.H.useMemoCache(m)}},be.cache=function(m){return function(){return m.apply(null,arguments)}},be.cacheSignal=function(){return null},be.cloneElement=function(m,D,K){if(m==null)throw Error("The argument must be a React element, but you passed "+m+".");var J=ae({},m.props),ue=m.key;if(D!=null)for(pe in D.key!==void 0&&(ue=""+D.key),D)!I.call(D,pe)||pe==="key"||pe==="__self"||pe==="__source"||pe==="ref"&&D.ref===void 0||(J[pe]=D[pe]);var pe=arguments.length-2;if(pe===1)J.children=K;else if(1<pe){for(var O=Array(pe),te=0;te<pe;te++)O[te]=arguments[te+2];J.children=O}return ne(m.type,ue,J)},be.createContext=function(m){return m={$$typeof:S,_currentValue:m,_currentValue2:m,_threadCount:0,Provider:null,Consumer:null},m.Provider=m,m.Consumer={$$typeof:E,_context:m},m},be.createElement=function(m,D,K){var J,ue={},pe=null;if(D!=null)for(J in D.key!==void 0&&(pe=""+D.key),D)I.call(D,J)&&J!=="key"&&J!=="__self"&&J!=="__source"&&(ue[J]=D[J]);var O=arguments.length-2;if(O===1)ue.children=K;else if(1<O){for(var te=Array(O),W=0;W<O;W++)te[W]=arguments[W+2];ue.children=te}if(m&&m.defaultProps)for(J in O=m.defaultProps,O)ue[J]===void 0&&(ue[J]=O[J]);return ne(m,pe,ue)},be.createRef=function(){return{current:null}},be.forwardRef=function(m){return{$$typeof:U,render:m}},be.isValidElement=Se,be.lazy=function(m){return{$$typeof:L,_payload:{_status:-1,_result:m},_init:Q}},be.memo=function(m,D){return{$$typeof:h,type:m,compare:D===void 0?null:D}},be.startTransition=function(m){var D=X.T,K={};X.T=K;try{var J=m(),ue=X.S;ue!==null&&ue(K,J),typeof J=="object"&&J!==null&&typeof J.then=="function"&&J.then(oe,ce)}catch(pe){ce(pe)}finally{D!==null&&K.types!==null&&(D.types=K.types),X.T=D}},be.unstable_useCacheRefresh=function(){return X.H.useCacheRefresh()},be.use=function(m){return X.H.use(m)},be.useActionState=function(m,D,K){return X.H.useActionState(m,D,K)},be.useCallback=function(m,D){return X.H.useCallback(m,D)},be.useContext=function(m){return X.H.useContext(m)},be.useDebugValue=function(){},be.useDeferredValue=function(m,D){return X.H.useDeferredValue(m,D)},be.useEffect=function(m,D){return X.H.useEffect(m,D)},be.useEffectEvent=function(m){return X.H.useEffectEvent(m)},be.useId=function(){return X.H.useId()},be.useImperativeHandle=function(m,D,K){return X.H.useImperativeHandle(m,D,K)},be.useInsertionEffect=function(m,D){return X.H.useInsertionEffect(m,D)},be.useLayoutEffect=function(m,D){return X.H.useLayoutEffect(m,D)},be.useMemo=function(m,D){return X.H.useMemo(m,D)},be.useOptimistic=function(m,D){return X.H.useOptimistic(m,D)},be.useReducer=function(m,D,K){return X.H.useReducer(m,D,K)},be.useRef=function(m){return X.H.useRef(m)},be.useState=function(m){return X.H.useState(m)},be.useSyncExternalStore=function(m,D,K){return X.H.useSyncExternalStore(m,D,K)},be.useTransition=function(){return X.H.useTransition()},be.version="19.2.0",be}var Qf;function Vo(){return Qf||(Qf=1,Ro.exports=Dp()),Ro.exports}var g=Vo();const Xo=xx(g);var Uo={exports:{}},Wi={},Lo={exports:{}},Bo={};/**
 * @license React
 * scheduler.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Zf;function Mp(){return Zf||(Zf=1,(function(r){function v(T,f){var Q=T.length;T.push(f);e:for(;0<Q;){var ce=Q-1>>>1,me=T[ce];if(0<k(me,f))T[ce]=f,T[Q]=me,Q=ce;else break e}}function _(T){return T.length===0?null:T[0]}function d(T){if(T.length===0)return null;var f=T[0],Q=T.pop();if(Q!==f){T[0]=Q;e:for(var ce=0,me=T.length,m=me>>>1;ce<m;){var D=2*(ce+1)-1,K=T[D],J=D+1,ue=T[J];if(0>k(K,Q))J<me&&0>k(ue,K)?(T[ce]=ue,T[J]=Q,ce=J):(T[ce]=K,T[D]=Q,ce=D);else if(J<me&&0>k(ue,Q))T[ce]=ue,T[J]=Q,ce=J;else break e}}return f}function k(T,f){var Q=T.sortIndex-f.sortIndex;return Q!==0?Q:T.id-f.id}if(r.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var E=performance;r.unstable_now=function(){return E.now()}}else{var S=Date,U=S.now();r.unstable_now=function(){return S.now()-U}}var b=[],h=[],L=1,N=null,Y=3,H=!1,B=!1,ae=!1,Z=!1,G=typeof setTimeout=="function"?setTimeout:null,q=typeof clearTimeout=="function"?clearTimeout:null,fe=typeof setImmediate<"u"?setImmediate:null;function ee(T){for(var f=_(h);f!==null;){if(f.callback===null)d(h);else if(f.startTime<=T)d(h),f.sortIndex=f.expirationTime,v(b,f);else break;f=_(h)}}function Re(T){if(ae=!1,ee(T),!B)if(_(b)!==null)B=!0,oe||(oe=!0,re());else{var f=_(h);f!==null&&_e(Re,f.startTime-T)}}var oe=!1,X=-1,I=5,ne=-1;function se(){return Z?!0:!(r.unstable_now()-ne<I)}function Se(){if(Z=!1,oe){var T=r.unstable_now();ne=T;var f=!0;try{e:{B=!1,ae&&(ae=!1,q(X),X=-1),H=!0;var Q=Y;try{t:{for(ee(T),N=_(b);N!==null&&!(N.expirationTime>T&&se());){var ce=N.callback;if(typeof ce=="function"){N.callback=null,Y=N.priorityLevel;var me=ce(N.expirationTime<=T);if(T=r.unstable_now(),typeof me=="function"){N.callback=me,ee(T),f=!0;break t}N===_(b)&&d(b),ee(T)}else d(b);N=_(b)}if(N!==null)f=!0;else{var m=_(h);m!==null&&_e(Re,m.startTime-T),f=!1}}break e}finally{N=null,Y=Q,H=!1}f=void 0}}finally{f?re():oe=!1}}}var re;if(typeof fe=="function")re=function(){fe(Se)};else if(typeof MessageChannel<"u"){var Ve=new MessageChannel,xe=Ve.port2;Ve.port1.onmessage=Se,re=function(){xe.postMessage(null)}}else re=function(){G(Se,0)};function _e(T,f){X=G(function(){T(r.unstable_now())},f)}r.unstable_IdlePriority=5,r.unstable_ImmediatePriority=1,r.unstable_LowPriority=4,r.unstable_NormalPriority=3,r.unstable_Profiling=null,r.unstable_UserBlockingPriority=2,r.unstable_cancelCallback=function(T){T.callback=null},r.unstable_forceFrameRate=function(T){0>T||125<T?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):I=0<T?Math.floor(1e3/T):5},r.unstable_getCurrentPriorityLevel=function(){return Y},r.unstable_next=function(T){switch(Y){case 1:case 2:case 3:var f=3;break;default:f=Y}var Q=Y;Y=f;try{return T()}finally{Y=Q}},r.unstable_requestPaint=function(){Z=!0},r.unstable_runWithPriority=function(T,f){switch(T){case 1:case 2:case 3:case 4:case 5:break;default:T=3}var Q=Y;Y=T;try{return f()}finally{Y=Q}},r.unstable_scheduleCallback=function(T,f,Q){var ce=r.unstable_now();switch(typeof Q=="object"&&Q!==null?(Q=Q.delay,Q=typeof Q=="number"&&0<Q?ce+Q:ce):Q=ce,T){case 1:var me=-1;break;case 2:me=250;break;case 5:me=1073741823;break;case 4:me=1e4;break;default:me=5e3}return me=Q+me,T={id:L++,callback:f,priorityLevel:T,startTime:Q,expirationTime:me,sortIndex:-1},Q>ce?(T.sortIndex=Q,v(h,T),_(b)===null&&T===_(h)&&(ae?(q(X),X=-1):ae=!0,_e(Re,Q-ce))):(T.sortIndex=me,v(b,T),B||H||(B=!0,oe||(oe=!0,re()))),T},r.unstable_shouldYield=se,r.unstable_wrapCallback=function(T){var f=Y;return function(){var Q=Y;Y=f;try{return T.apply(this,arguments)}finally{Y=Q}}}})(Bo)),Bo}var Jf;function Rp(){return Jf||(Jf=1,Lo.exports=Mp()),Lo.exports}var Ho={exports:{}},xt={};/**
 * @license React
 * react-dom.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Ff;function Up(){if(Ff)return xt;Ff=1;var r=Vo();function v(b){var h="https://react.dev/errors/"+b;if(1<arguments.length){h+="?args[]="+encodeURIComponent(arguments[1]);for(var L=2;L<arguments.length;L++)h+="&args[]="+encodeURIComponent(arguments[L])}return"Minified React error #"+b+"; visit "+h+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function _(){}var d={d:{f:_,r:function(){throw Error(v(522))},D:_,C:_,L:_,m:_,X:_,S:_,M:_},p:0,findDOMNode:null},k=Symbol.for("react.portal");function E(b,h,L){var N=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:k,key:N==null?null:""+N,children:b,containerInfo:h,implementation:L}}var S=r.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function U(b,h){if(b==="font")return"";if(typeof h=="string")return h==="use-credentials"?h:""}return xt.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=d,xt.createPortal=function(b,h){var L=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!h||h.nodeType!==1&&h.nodeType!==9&&h.nodeType!==11)throw Error(v(299));return E(b,h,null,L)},xt.flushSync=function(b){var h=S.T,L=d.p;try{if(S.T=null,d.p=2,b)return b()}finally{S.T=h,d.p=L,d.d.f()}},xt.preconnect=function(b,h){typeof b=="string"&&(h?(h=h.crossOrigin,h=typeof h=="string"?h==="use-credentials"?h:"":void 0):h=null,d.d.C(b,h))},xt.prefetchDNS=function(b){typeof b=="string"&&d.d.D(b)},xt.preinit=function(b,h){if(typeof b=="string"&&h&&typeof h.as=="string"){var L=h.as,N=U(L,h.crossOrigin),Y=typeof h.integrity=="string"?h.integrity:void 0,H=typeof h.fetchPriority=="string"?h.fetchPriority:void 0;L==="style"?d.d.S(b,typeof h.precedence=="string"?h.precedence:void 0,{crossOrigin:N,integrity:Y,fetchPriority:H}):L==="script"&&d.d.X(b,{crossOrigin:N,integrity:Y,fetchPriority:H,nonce:typeof h.nonce=="string"?h.nonce:void 0})}},xt.preinitModule=function(b,h){if(typeof b=="string")if(typeof h=="object"&&h!==null){if(h.as==null||h.as==="script"){var L=U(h.as,h.crossOrigin);d.d.M(b,{crossOrigin:L,integrity:typeof h.integrity=="string"?h.integrity:void 0,nonce:typeof h.nonce=="string"?h.nonce:void 0})}}else h==null&&d.d.M(b)},xt.preload=function(b,h){if(typeof b=="string"&&typeof h=="object"&&h!==null&&typeof h.as=="string"){var L=h.as,N=U(L,h.crossOrigin);d.d.L(b,L,{crossOrigin:N,integrity:typeof h.integrity=="string"?h.integrity:void 0,nonce:typeof h.nonce=="string"?h.nonce:void 0,type:typeof h.type=="string"?h.type:void 0,fetchPriority:typeof h.fetchPriority=="string"?h.fetchPriority:void 0,referrerPolicy:typeof h.referrerPolicy=="string"?h.referrerPolicy:void 0,imageSrcSet:typeof h.imageSrcSet=="string"?h.imageSrcSet:void 0,imageSizes:typeof h.imageSizes=="string"?h.imageSizes:void 0,media:typeof h.media=="string"?h.media:void 0})}},xt.preloadModule=function(b,h){if(typeof b=="string")if(h){var L=U(h.as,h.crossOrigin);d.d.m(b,{as:typeof h.as=="string"&&h.as!=="script"?h.as:void 0,crossOrigin:L,integrity:typeof h.integrity=="string"?h.integrity:void 0})}else d.d.m(b)},xt.requestFormReset=function(b){d.d.r(b)},xt.unstable_batchedUpdates=function(b,h){return b(h)},xt.useFormState=function(b,h,L){return S.H.useFormState(b,h,L)},xt.useFormStatus=function(){return S.H.useHostTransitionStatus()},xt.version="19.2.0",xt}var Pf;function Lp(){if(Pf)return Ho.exports;Pf=1;function r(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r)}catch(v){console.error(v)}}return r(),Ho.exports=Up(),Ho.exports}/**
 * @license React
 * react-dom-client.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Wf;function Bp(){if(Wf)return Wi;Wf=1;var r=Rp(),v=Vo(),_=Lp();function d(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var l=2;l<arguments.length;l++)t+="&args[]="+encodeURIComponent(arguments[l])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function k(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function E(e){var t=e,l=e;if(e.alternate)for(;t.return;)t=t.return;else{e=t;do t=e,(t.flags&4098)!==0&&(l=t.return),e=t.return;while(e)}return t.tag===3?l:null}function S(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function U(e){if(e.tag===31){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function b(e){if(E(e)!==e)throw Error(d(188))}function h(e){var t=e.alternate;if(!t){if(t=E(e),t===null)throw Error(d(188));return t!==e?null:e}for(var l=e,i=t;;){var n=l.return;if(n===null)break;var s=n.alternate;if(s===null){if(i=n.return,i!==null){l=i;continue}break}if(n.child===s.child){for(s=n.child;s;){if(s===l)return b(n),e;if(s===i)return b(n),t;s=s.sibling}throw Error(d(188))}if(l.return!==i.return)l=n,i=s;else{for(var o=!1,c=n.child;c;){if(c===l){o=!0,l=n,i=s;break}if(c===i){o=!0,i=n,l=s;break}c=c.sibling}if(!o){for(c=s.child;c;){if(c===l){o=!0,l=s,i=n;break}if(c===i){o=!0,i=s,l=n;break}c=c.sibling}if(!o)throw Error(d(189))}}if(l.alternate!==i)throw Error(d(190))}if(l.tag!==3)throw Error(d(188));return l.stateNode.current===l?e:t}function L(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e;for(e=e.child;e!==null;){if(t=L(e),t!==null)return t;e=e.sibling}return null}var N=Object.assign,Y=Symbol.for("react.element"),H=Symbol.for("react.transitional.element"),B=Symbol.for("react.portal"),ae=Symbol.for("react.fragment"),Z=Symbol.for("react.strict_mode"),G=Symbol.for("react.profiler"),q=Symbol.for("react.consumer"),fe=Symbol.for("react.context"),ee=Symbol.for("react.forward_ref"),Re=Symbol.for("react.suspense"),oe=Symbol.for("react.suspense_list"),X=Symbol.for("react.memo"),I=Symbol.for("react.lazy"),ne=Symbol.for("react.activity"),se=Symbol.for("react.memo_cache_sentinel"),Se=Symbol.iterator;function re(e){return e===null||typeof e!="object"?null:(e=Se&&e[Se]||e["@@iterator"],typeof e=="function"?e:null)}var Ve=Symbol.for("react.client.reference");function xe(e){if(e==null)return null;if(typeof e=="function")return e.$$typeof===Ve?null:e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case ae:return"Fragment";case G:return"Profiler";case Z:return"StrictMode";case Re:return"Suspense";case oe:return"SuspenseList";case ne:return"Activity"}if(typeof e=="object")switch(e.$$typeof){case B:return"Portal";case fe:return e.displayName||"Context";case q:return(e._context.displayName||"Context")+".Consumer";case ee:var t=e.render;return e=e.displayName,e||(e=t.displayName||t.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case X:return t=e.displayName||null,t!==null?t:xe(e.type)||"Memo";case I:t=e._payload,e=e._init;try{return xe(e(t))}catch{}}return null}var _e=Array.isArray,T=v.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,f=_.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,Q={pending:!1,data:null,method:null,action:null},ce=[],me=-1;function m(e){return{current:e}}function D(e){0>me||(e.current=ce[me],ce[me]=null,me--)}function K(e,t){me++,ce[me]=e.current,e.current=t}var J=m(null),ue=m(null),pe=m(null),O=m(null);function te(e,t){switch(K(pe,t),K(ue,e),K(J,null),t.nodeType){case 9:case 11:e=(e=t.documentElement)&&(e=e.namespaceURI)?mf(e):0;break;default:if(e=t.tagName,t=t.namespaceURI)t=mf(t),e=xf(t,e);else switch(e){case"svg":e=1;break;case"math":e=2;break;default:e=0}}D(J),K(J,e)}function W(){D(J),D(ue),D(pe)}function ke(e){e.memoizedState!==null&&K(O,e);var t=J.current,l=xf(t,e.type);t!==l&&(K(ue,e),K(J,l))}function Ze(e){ue.current===e&&(D(J),D(ue)),O.current===e&&(D(O),Qi._currentValue=Q)}var ft,Za;function bt(e){if(ft===void 0)try{throw Error()}catch(l){var t=l.stack.trim().match(/\n( *(at )?)/);ft=t&&t[1]||"",Za=-1<l.stack.indexOf(`
    at`)?" (<anonymous>)":-1<l.stack.indexOf("@")?"@unknown:0:0":""}return`
`+ft+e+Za}var va=!1;function ka(e,t){if(!e||va)return"";va=!0;var l=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var i={DetermineComponentFrameRoot:function(){try{if(t){var R=function(){throw Error()};if(Object.defineProperty(R.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(R,[])}catch(A){var w=A}Reflect.construct(e,[],R)}else{try{R.call()}catch(A){w=A}e.call(R.prototype)}}else{try{throw Error()}catch(A){w=A}(R=e())&&typeof R.catch=="function"&&R.catch(function(){})}}catch(A){if(A&&w&&typeof A.stack=="string")return[A.stack,w.stack]}return[null,null]}};i.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var n=Object.getOwnPropertyDescriptor(i.DetermineComponentFrameRoot,"name");n&&n.configurable&&Object.defineProperty(i.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var s=i.DetermineComponentFrameRoot(),o=s[0],c=s[1];if(o&&c){var u=o.split(`
`),z=c.split(`
`);for(n=i=0;i<u.length&&!u[i].includes("DetermineComponentFrameRoot");)i++;for(;n<z.length&&!z[n].includes("DetermineComponentFrameRoot");)n++;if(i===u.length||n===z.length)for(i=u.length-1,n=z.length-1;1<=i&&0<=n&&u[i]!==z[n];)n--;for(;1<=i&&0<=n;i--,n--)if(u[i]!==z[n]){if(i!==1||n!==1)do if(i--,n--,0>n||u[i]!==z[n]){var C=`
`+u[i].replace(" at new "," at ");return e.displayName&&C.includes("<anonymous>")&&(C=C.replace("<anonymous>",e.displayName)),C}while(1<=i&&0<=n);break}}}finally{va=!1,Error.prepareStackTrace=l}return(l=e?e.displayName||e.name:"")?bt(l):""}function ni(e,t){switch(e.tag){case 26:case 27:case 5:return bt(e.type);case 16:return bt("Lazy");case 13:return e.child!==t&&t!==null?bt("Suspense Fallback"):bt("Suspense");case 19:return bt("SuspenseList");case 0:case 15:return ka(e.type,!1);case 11:return ka(e.type.render,!1);case 1:return ka(e.type,!0);case 31:return bt("Activity");default:return""}}function yt(e){try{var t="",l=null;do t+=ni(e,l),l=e,e=e.return;while(e);return t}catch(i){return`
Error generating stack: `+i.message+`
`+i.stack}}var ja=Object.prototype.hasOwnProperty,Xt=r.unstable_scheduleCallback,st=r.unstable_cancelCallback,F=r.unstable_shouldYield,le=r.unstable_requestPaint,he=r.unstable_now,De=r.unstable_getCurrentPriorityLevel,We=r.unstable_ImmediatePriority,Ft=r.unstable_UserBlockingPriority,Et=r.unstable_NormalPriority,Na=r.unstable_LowPriority,si=r.unstable_IdlePriority,an=r.log,bs=r.unstable_setDisableYieldValue,Ja=null,ht=null;function Rt(e){if(typeof an=="function"&&bs(e),ht&&typeof ht.setStrictMode=="function")try{ht.setStrictMode(Ja,e)}catch{}}var mt=Math.clz32?Math.clz32:gl,ys=Math.log,vs=Math.LN2;function gl(e){return e>>>=0,e===0?32:31-(ys(e)/vs|0)|0}var Fa=256,Pa=262144,p=4194304;function V(e){var t=e&42;if(t!==0)return t;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&261888;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function ge(e,t,l){var i=e.pendingLanes;if(i===0)return 0;var n=0,s=e.suspendedLanes,o=e.pingedLanes;e=e.warmLanes;var c=i&134217727;return c!==0?(i=c&~s,i!==0?n=V(i):(o&=c,o!==0?n=V(o):l||(l=c&~e,l!==0&&(n=V(l))))):(c=i&~s,c!==0?n=V(c):o!==0?n=V(o):l||(l=i&~e,l!==0&&(n=V(l)))),n===0?0:t!==0&&t!==n&&(t&s)===0&&(s=n&-n,l=t&-t,s>=l||s===32&&(l&4194048)!==0)?t:n}function Ae(e,t){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&t)===0}function Te(e,t){switch(e){case 1:case 2:case 4:case 8:case 64:return t+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function ks(){var e=p;return p<<=1,(p&62914560)===0&&(p=4194304),e}function ri(e){for(var t=[],l=0;31>l;l++)t.push(e);return t}function Wa(e,t){e.pendingLanes|=t,t!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function yx(e,t,l,i,n,s){var o=e.pendingLanes;e.pendingLanes=l,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=l,e.entangledLanes&=l,e.errorRecoveryDisabledLanes&=l,e.shellSuspendCounter=0;var c=e.entanglements,u=e.expirationTimes,z=e.hiddenUpdates;for(l=o&~l;0<l;){var C=31-mt(l),R=1<<C;c[C]=0,u[C]=-1;var w=z[C];if(w!==null)for(z[C]=null,C=0;C<w.length;C++){var A=w[C];A!==null&&(A.lane&=-536870913)}l&=~R}i!==0&&Zo(e,i,0),s!==0&&n===0&&e.tag!==0&&(e.suspendedLanes|=s&~(o&~t))}function Zo(e,t,l){e.pendingLanes|=t,e.suspendedLanes&=~t;var i=31-mt(t);e.entangledLanes|=t,e.entanglements[i]=e.entanglements[i]|1073741824|l&261930}function Jo(e,t){var l=e.entangledLanes|=t;for(e=e.entanglements;l;){var i=31-mt(l),n=1<<i;n&t|e[i]&t&&(e[i]|=t),l&=~n}}function Fo(e,t){var l=t&-t;return l=(l&42)!==0?1:js(l),(l&(e.suspendedLanes|t))!==0?0:l}function js(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function Ns(e){return e&=-e,2<e?8<e?(e&134217727)!==0?32:268435456:8:2}function Po(){var e=f.p;return e!==0?e:(e=window.event,e===void 0?32:Lf(e.type))}function Wo(e,t){var l=f.p;try{return f.p=e,t()}finally{f.p=l}}var za=Math.random().toString(36).slice(2),rt="__reactFiber$"+za,vt="__reactProps$"+za,bl="__reactContainer$"+za,zs="__reactEvents$"+za,vx="__reactListeners$"+za,kx="__reactHandles$"+za,$o="__reactResources$"+za,oi="__reactMarker$"+za;function ws(e){delete e[rt],delete e[vt],delete e[zs],delete e[vx],delete e[kx]}function yl(e){var t=e[rt];if(t)return t;for(var l=e.parentNode;l;){if(t=l[bl]||l[rt]){if(l=t.alternate,t.child!==null||l!==null&&l.child!==null)for(e=kf(e);e!==null;){if(l=e[rt])return l;e=kf(e)}return t}e=l,l=e.parentNode}return null}function vl(e){if(e=e[rt]||e[bl]){var t=e.tag;if(t===5||t===6||t===13||t===31||t===26||t===27||t===3)return e}return null}function ci(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e.stateNode;throw Error(d(33))}function kl(e){var t=e[$o];return t||(t=e[$o]={hoistableStyles:new Map,hoistableScripts:new Map}),t}function it(e){e[oi]=!0}var ec=new Set,tc={};function $a(e,t){jl(e,t),jl(e+"Capture",t)}function jl(e,t){for(tc[e]=t,e=0;e<t.length;e++)ec.add(t[e])}var jx=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),ac={},lc={};function Nx(e){return ja.call(lc,e)?!0:ja.call(ac,e)?!1:jx.test(e)?lc[e]=!0:(ac[e]=!0,!1)}function ln(e,t,l){if(Nx(t))if(l===null)e.removeAttribute(t);else{switch(typeof l){case"undefined":case"function":case"symbol":e.removeAttribute(t);return;case"boolean":var i=t.toLowerCase().slice(0,5);if(i!=="data-"&&i!=="aria-"){e.removeAttribute(t);return}}e.setAttribute(t,""+l)}}function nn(e,t,l){if(l===null)e.removeAttribute(t);else{switch(typeof l){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(t);return}e.setAttribute(t,""+l)}}function aa(e,t,l,i){if(i===null)e.removeAttribute(l);else{switch(typeof i){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(l);return}e.setAttributeNS(t,l,""+i)}}function Ut(e){switch(typeof e){case"bigint":case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function ic(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(t==="checkbox"||t==="radio")}function zx(e,t,l){var i=Object.getOwnPropertyDescriptor(e.constructor.prototype,t);if(!e.hasOwnProperty(t)&&typeof i<"u"&&typeof i.get=="function"&&typeof i.set=="function"){var n=i.get,s=i.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return n.call(this)},set:function(o){l=""+o,s.call(this,o)}}),Object.defineProperty(e,t,{enumerable:i.enumerable}),{getValue:function(){return l},setValue:function(o){l=""+o},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function Ss(e){if(!e._valueTracker){var t=ic(e)?"checked":"value";e._valueTracker=zx(e,t,""+e[t])}}function nc(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var l=t.getValue(),i="";return e&&(i=ic(e)?e.checked?"true":"false":e.value),e=i,e!==l?(t.setValue(e),!0):!1}function sn(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}var wx=/[\n"\\]/g;function Lt(e){return e.replace(wx,function(t){return"\\"+t.charCodeAt(0).toString(16)+" "})}function Es(e,t,l,i,n,s,o,c){e.name="",o!=null&&typeof o!="function"&&typeof o!="symbol"&&typeof o!="boolean"?e.type=o:e.removeAttribute("type"),t!=null?o==="number"?(t===0&&e.value===""||e.value!=t)&&(e.value=""+Ut(t)):e.value!==""+Ut(t)&&(e.value=""+Ut(t)):o!=="submit"&&o!=="reset"||e.removeAttribute("value"),t!=null?Ts(e,o,Ut(t)):l!=null?Ts(e,o,Ut(l)):i!=null&&e.removeAttribute("value"),n==null&&s!=null&&(e.defaultChecked=!!s),n!=null&&(e.checked=n&&typeof n!="function"&&typeof n!="symbol"),c!=null&&typeof c!="function"&&typeof c!="symbol"&&typeof c!="boolean"?e.name=""+Ut(c):e.removeAttribute("name")}function sc(e,t,l,i,n,s,o,c){if(s!=null&&typeof s!="function"&&typeof s!="symbol"&&typeof s!="boolean"&&(e.type=s),t!=null||l!=null){if(!(s!=="submit"&&s!=="reset"||t!=null)){Ss(e);return}l=l!=null?""+Ut(l):"",t=t!=null?""+Ut(t):l,c||t===e.value||(e.value=t),e.defaultValue=t}i=i??n,i=typeof i!="function"&&typeof i!="symbol"&&!!i,e.checked=c?e.checked:!!i,e.defaultChecked=!!i,o!=null&&typeof o!="function"&&typeof o!="symbol"&&typeof o!="boolean"&&(e.name=o),Ss(e)}function Ts(e,t,l){t==="number"&&sn(e.ownerDocument)===e||e.defaultValue===""+l||(e.defaultValue=""+l)}function Nl(e,t,l,i){if(e=e.options,t){t={};for(var n=0;n<l.length;n++)t["$"+l[n]]=!0;for(l=0;l<e.length;l++)n=t.hasOwnProperty("$"+e[l].value),e[l].selected!==n&&(e[l].selected=n),n&&i&&(e[l].defaultSelected=!0)}else{for(l=""+Ut(l),t=null,n=0;n<e.length;n++){if(e[n].value===l){e[n].selected=!0,i&&(e[n].defaultSelected=!0);return}t!==null||e[n].disabled||(t=e[n])}t!==null&&(t.selected=!0)}}function rc(e,t,l){if(t!=null&&(t=""+Ut(t),t!==e.value&&(e.value=t),l==null)){e.defaultValue!==t&&(e.defaultValue=t);return}e.defaultValue=l!=null?""+Ut(l):""}function oc(e,t,l,i){if(t==null){if(i!=null){if(l!=null)throw Error(d(92));if(_e(i)){if(1<i.length)throw Error(d(93));i=i[0]}l=i}l==null&&(l=""),t=l}l=Ut(t),e.defaultValue=l,i=e.textContent,i===l&&i!==""&&i!==null&&(e.value=i),Ss(e)}function zl(e,t){if(t){var l=e.firstChild;if(l&&l===e.lastChild&&l.nodeType===3){l.nodeValue=t;return}}e.textContent=t}var Sx=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function cc(e,t,l){var i=t.indexOf("--")===0;l==null||typeof l=="boolean"||l===""?i?e.setProperty(t,""):t==="float"?e.cssFloat="":e[t]="":i?e.setProperty(t,l):typeof l!="number"||l===0||Sx.has(t)?t==="float"?e.cssFloat=l:e[t]=(""+l).trim():e[t]=l+"px"}function dc(e,t,l){if(t!=null&&typeof t!="object")throw Error(d(62));if(e=e.style,l!=null){for(var i in l)!l.hasOwnProperty(i)||t!=null&&t.hasOwnProperty(i)||(i.indexOf("--")===0?e.setProperty(i,""):i==="float"?e.cssFloat="":e[i]="");for(var n in t)i=t[n],t.hasOwnProperty(n)&&l[n]!==i&&cc(e,n,i)}else for(var s in t)t.hasOwnProperty(s)&&cc(e,s,t[s])}function _s(e){if(e.indexOf("-")===-1)return!1;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var Ex=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),Tx=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function rn(e){return Tx.test(""+e)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":e}function la(){}var As=null;function Os(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var wl=null,Sl=null;function uc(e){var t=vl(e);if(t&&(e=t.stateNode)){var l=e[vt]||null;e:switch(e=t.stateNode,t.type){case"input":if(Es(e,l.value,l.defaultValue,l.defaultValue,l.checked,l.defaultChecked,l.type,l.name),t=l.name,l.type==="radio"&&t!=null){for(l=e;l.parentNode;)l=l.parentNode;for(l=l.querySelectorAll('input[name="'+Lt(""+t)+'"][type="radio"]'),t=0;t<l.length;t++){var i=l[t];if(i!==e&&i.form===e.form){var n=i[vt]||null;if(!n)throw Error(d(90));Es(i,n.value,n.defaultValue,n.defaultValue,n.checked,n.defaultChecked,n.type,n.name)}}for(t=0;t<l.length;t++)i=l[t],i.form===e.form&&nc(i)}break e;case"textarea":rc(e,l.value,l.defaultValue);break e;case"select":t=l.value,t!=null&&Nl(e,!!l.multiple,t,!1)}}}var Cs=!1;function fc(e,t,l){if(Cs)return e(t,l);Cs=!0;try{var i=e(t);return i}finally{if(Cs=!1,(wl!==null||Sl!==null)&&(Zn(),wl&&(t=wl,e=Sl,Sl=wl=null,uc(t),e)))for(t=0;t<e.length;t++)uc(e[t])}}function di(e,t){var l=e.stateNode;if(l===null)return null;var i=l[vt]||null;if(i===null)return null;l=i[t];e:switch(t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(i=!i.disabled)||(e=e.type,i=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!i;break e;default:e=!1}if(e)return null;if(l&&typeof l!="function")throw Error(d(231,t,typeof l));return l}var ia=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),Ds=!1;if(ia)try{var ui={};Object.defineProperty(ui,"passive",{get:function(){Ds=!0}}),window.addEventListener("test",ui,ui),window.removeEventListener("test",ui,ui)}catch{Ds=!1}var wa=null,Ms=null,on=null;function mc(){if(on)return on;var e,t=Ms,l=t.length,i,n="value"in wa?wa.value:wa.textContent,s=n.length;for(e=0;e<l&&t[e]===n[e];e++);var o=l-e;for(i=1;i<=o&&t[l-i]===n[s-i];i++);return on=n.slice(e,1<i?1-i:void 0)}function cn(e){var t=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function dn(){return!0}function xc(){return!1}function kt(e){function t(l,i,n,s,o){this._reactName=l,this._targetInst=n,this.type=i,this.nativeEvent=s,this.target=o,this.currentTarget=null;for(var c in e)e.hasOwnProperty(c)&&(l=e[c],this[c]=l?l(s):s[c]);return this.isDefaultPrevented=(s.defaultPrevented!=null?s.defaultPrevented:s.returnValue===!1)?dn:xc,this.isPropagationStopped=xc,this}return N(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var l=this.nativeEvent;l&&(l.preventDefault?l.preventDefault():typeof l.returnValue!="unknown"&&(l.returnValue=!1),this.isDefaultPrevented=dn)},stopPropagation:function(){var l=this.nativeEvent;l&&(l.stopPropagation?l.stopPropagation():typeof l.cancelBubble!="unknown"&&(l.cancelBubble=!0),this.isPropagationStopped=dn)},persist:function(){},isPersistent:dn}),t}var el={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},un=kt(el),fi=N({},el,{view:0,detail:0}),_x=kt(fi),Rs,Us,mi,fn=N({},fi,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Bs,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==mi&&(mi&&e.type==="mousemove"?(Rs=e.screenX-mi.screenX,Us=e.screenY-mi.screenY):Us=Rs=0,mi=e),Rs)},movementY:function(e){return"movementY"in e?e.movementY:Us}}),pc=kt(fn),Ax=N({},fn,{dataTransfer:0}),Ox=kt(Ax),Cx=N({},fi,{relatedTarget:0}),Ls=kt(Cx),Dx=N({},el,{animationName:0,elapsedTime:0,pseudoElement:0}),Mx=kt(Dx),Rx=N({},el,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),Ux=kt(Rx),Lx=N({},el,{data:0}),hc=kt(Lx),Bx={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},Hx={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},Yx={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function Gx(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=Yx[e])?!!t[e]:!1}function Bs(){return Gx}var Ix=N({},fi,{key:function(e){if(e.key){var t=Bx[e.key]||e.key;if(t!=="Unidentified")return t}return e.type==="keypress"?(e=cn(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?Hx[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Bs,charCode:function(e){return e.type==="keypress"?cn(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?cn(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),Kx=kt(Ix),qx=N({},fn,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),gc=kt(qx),Vx=N({},fi,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Bs}),Xx=kt(Vx),Qx=N({},el,{propertyName:0,elapsedTime:0,pseudoElement:0}),Zx=kt(Qx),Jx=N({},fn,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),Fx=kt(Jx),Px=N({},el,{newState:0,oldState:0}),Wx=kt(Px),$x=[9,13,27,32],Hs=ia&&"CompositionEvent"in window,xi=null;ia&&"documentMode"in document&&(xi=document.documentMode);var e0=ia&&"TextEvent"in window&&!xi,bc=ia&&(!Hs||xi&&8<xi&&11>=xi),yc=" ",vc=!1;function kc(e,t){switch(e){case"keyup":return $x.indexOf(t.keyCode)!==-1;case"keydown":return t.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function jc(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var El=!1;function t0(e,t){switch(e){case"compositionend":return jc(t);case"keypress":return t.which!==32?null:(vc=!0,yc);case"textInput":return e=t.data,e===yc&&vc?null:e;default:return null}}function a0(e,t){if(El)return e==="compositionend"||!Hs&&kc(e,t)?(e=mc(),on=Ms=wa=null,El=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return bc&&t.locale!=="ko"?null:t.data;default:return null}}var l0={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Nc(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t==="input"?!!l0[e.type]:t==="textarea"}function zc(e,t,l,i){wl?Sl?Sl.push(i):Sl=[i]:wl=i,t=ts(t,"onChange"),0<t.length&&(l=new un("onChange","change",null,l,i),e.push({event:l,listeners:t}))}var pi=null,hi=null;function i0(e){rf(e,0)}function mn(e){var t=ci(e);if(nc(t))return e}function wc(e,t){if(e==="change")return t}var Sc=!1;if(ia){var Ys;if(ia){var Gs="oninput"in document;if(!Gs){var Ec=document.createElement("div");Ec.setAttribute("oninput","return;"),Gs=typeof Ec.oninput=="function"}Ys=Gs}else Ys=!1;Sc=Ys&&(!document.documentMode||9<document.documentMode)}function Tc(){pi&&(pi.detachEvent("onpropertychange",_c),hi=pi=null)}function _c(e){if(e.propertyName==="value"&&mn(hi)){var t=[];zc(t,hi,e,Os(e)),fc(i0,t)}}function n0(e,t,l){e==="focusin"?(Tc(),pi=t,hi=l,pi.attachEvent("onpropertychange",_c)):e==="focusout"&&Tc()}function s0(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return mn(hi)}function r0(e,t){if(e==="click")return mn(t)}function o0(e,t){if(e==="input"||e==="change")return mn(t)}function c0(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var Tt=typeof Object.is=="function"?Object.is:c0;function gi(e,t){if(Tt(e,t))return!0;if(typeof e!="object"||e===null||typeof t!="object"||t===null)return!1;var l=Object.keys(e),i=Object.keys(t);if(l.length!==i.length)return!1;for(i=0;i<l.length;i++){var n=l[i];if(!ja.call(t,n)||!Tt(e[n],t[n]))return!1}return!0}function Ac(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function Oc(e,t){var l=Ac(e);e=0;for(var i;l;){if(l.nodeType===3){if(i=e+l.textContent.length,e<=t&&i>=t)return{node:l,offset:t-e};e=i}e:{for(;l;){if(l.nextSibling){l=l.nextSibling;break e}l=l.parentNode}l=void 0}l=Ac(l)}}function Cc(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?Cc(e,t.parentNode):"contains"in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function Dc(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var t=sn(e.document);t instanceof e.HTMLIFrameElement;){try{var l=typeof t.contentWindow.location.href=="string"}catch{l=!1}if(l)e=t.contentWindow;else break;t=sn(e.document)}return t}function Is(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||t==="textarea"||e.contentEditable==="true")}var d0=ia&&"documentMode"in document&&11>=document.documentMode,Tl=null,Ks=null,bi=null,qs=!1;function Mc(e,t,l){var i=l.window===l?l.document:l.nodeType===9?l:l.ownerDocument;qs||Tl==null||Tl!==sn(i)||(i=Tl,"selectionStart"in i&&Is(i)?i={start:i.selectionStart,end:i.selectionEnd}:(i=(i.ownerDocument&&i.ownerDocument.defaultView||window).getSelection(),i={anchorNode:i.anchorNode,anchorOffset:i.anchorOffset,focusNode:i.focusNode,focusOffset:i.focusOffset}),bi&&gi(bi,i)||(bi=i,i=ts(Ks,"onSelect"),0<i.length&&(t=new un("onSelect","select",null,t,l),e.push({event:t,listeners:i}),t.target=Tl)))}function tl(e,t){var l={};return l[e.toLowerCase()]=t.toLowerCase(),l["Webkit"+e]="webkit"+t,l["Moz"+e]="moz"+t,l}var _l={animationend:tl("Animation","AnimationEnd"),animationiteration:tl("Animation","AnimationIteration"),animationstart:tl("Animation","AnimationStart"),transitionrun:tl("Transition","TransitionRun"),transitionstart:tl("Transition","TransitionStart"),transitioncancel:tl("Transition","TransitionCancel"),transitionend:tl("Transition","TransitionEnd")},Vs={},Rc={};ia&&(Rc=document.createElement("div").style,"AnimationEvent"in window||(delete _l.animationend.animation,delete _l.animationiteration.animation,delete _l.animationstart.animation),"TransitionEvent"in window||delete _l.transitionend.transition);function al(e){if(Vs[e])return Vs[e];if(!_l[e])return e;var t=_l[e],l;for(l in t)if(t.hasOwnProperty(l)&&l in Rc)return Vs[e]=t[l];return e}var Uc=al("animationend"),Lc=al("animationiteration"),Bc=al("animationstart"),u0=al("transitionrun"),f0=al("transitionstart"),m0=al("transitioncancel"),Hc=al("transitionend"),Yc=new Map,Xs="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");Xs.push("scrollEnd");function Qt(e,t){Yc.set(e,t),$a(t,[e])}var xn=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)},Bt=[],Al=0,Qs=0;function pn(){for(var e=Al,t=Qs=Al=0;t<e;){var l=Bt[t];Bt[t++]=null;var i=Bt[t];Bt[t++]=null;var n=Bt[t];Bt[t++]=null;var s=Bt[t];if(Bt[t++]=null,i!==null&&n!==null){var o=i.pending;o===null?n.next=n:(n.next=o.next,o.next=n),i.pending=n}s!==0&&Gc(l,n,s)}}function hn(e,t,l,i){Bt[Al++]=e,Bt[Al++]=t,Bt[Al++]=l,Bt[Al++]=i,Qs|=i,e.lanes|=i,e=e.alternate,e!==null&&(e.lanes|=i)}function Zs(e,t,l,i){return hn(e,t,l,i),gn(e)}function ll(e,t){return hn(e,null,null,t),gn(e)}function Gc(e,t,l){e.lanes|=l;var i=e.alternate;i!==null&&(i.lanes|=l);for(var n=!1,s=e.return;s!==null;)s.childLanes|=l,i=s.alternate,i!==null&&(i.childLanes|=l),s.tag===22&&(e=s.stateNode,e===null||e._visibility&1||(n=!0)),e=s,s=s.return;return e.tag===3?(s=e.stateNode,n&&t!==null&&(n=31-mt(l),e=s.hiddenUpdates,i=e[n],i===null?e[n]=[t]:i.push(t),t.lane=l|536870912),s):null}function gn(e){if(50<Yi)throw Yi=0,lo=null,Error(d(185));for(var t=e.return;t!==null;)e=t,t=e.return;return e.tag===3?e.stateNode:null}var Ol={};function x0(e,t,l,i){this.tag=e,this.key=l,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=i,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function _t(e,t,l,i){return new x0(e,t,l,i)}function Js(e){return e=e.prototype,!(!e||!e.isReactComponent)}function na(e,t){var l=e.alternate;return l===null?(l=_t(e.tag,t,e.key,e.mode),l.elementType=e.elementType,l.type=e.type,l.stateNode=e.stateNode,l.alternate=e,e.alternate=l):(l.pendingProps=t,l.type=e.type,l.flags=0,l.subtreeFlags=0,l.deletions=null),l.flags=e.flags&65011712,l.childLanes=e.childLanes,l.lanes=e.lanes,l.child=e.child,l.memoizedProps=e.memoizedProps,l.memoizedState=e.memoizedState,l.updateQueue=e.updateQueue,t=e.dependencies,l.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},l.sibling=e.sibling,l.index=e.index,l.ref=e.ref,l.refCleanup=e.refCleanup,l}function Ic(e,t){e.flags&=65011714;var l=e.alternate;return l===null?(e.childLanes=0,e.lanes=t,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=l.childLanes,e.lanes=l.lanes,e.child=l.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=l.memoizedProps,e.memoizedState=l.memoizedState,e.updateQueue=l.updateQueue,e.type=l.type,t=l.dependencies,e.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext}),e}function bn(e,t,l,i,n,s){var o=0;if(i=e,typeof e=="function")Js(e)&&(o=1);else if(typeof e=="string")o=yp(e,l,J.current)?26:e==="html"||e==="head"||e==="body"?27:5;else e:switch(e){case ne:return e=_t(31,l,t,n),e.elementType=ne,e.lanes=s,e;case ae:return il(l.children,n,s,t);case Z:o=8,n|=24;break;case G:return e=_t(12,l,t,n|2),e.elementType=G,e.lanes=s,e;case Re:return e=_t(13,l,t,n),e.elementType=Re,e.lanes=s,e;case oe:return e=_t(19,l,t,n),e.elementType=oe,e.lanes=s,e;default:if(typeof e=="object"&&e!==null)switch(e.$$typeof){case fe:o=10;break e;case q:o=9;break e;case ee:o=11;break e;case X:o=14;break e;case I:o=16,i=null;break e}o=29,l=Error(d(130,e===null?"null":typeof e,"")),i=null}return t=_t(o,l,t,n),t.elementType=e,t.type=i,t.lanes=s,t}function il(e,t,l,i){return e=_t(7,e,i,t),e.lanes=l,e}function Fs(e,t,l){return e=_t(6,e,null,t),e.lanes=l,e}function Kc(e){var t=_t(18,null,null,0);return t.stateNode=e,t}function Ps(e,t,l){return t=_t(4,e.children!==null?e.children:[],e.key,t),t.lanes=l,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}var qc=new WeakMap;function Ht(e,t){if(typeof e=="object"&&e!==null){var l=qc.get(e);return l!==void 0?l:(t={value:e,source:t,stack:yt(t)},qc.set(e,t),t)}return{value:e,source:t,stack:yt(t)}}var Cl=[],Dl=0,yn=null,yi=0,Yt=[],Gt=0,Sa=null,Pt=1,Wt="";function sa(e,t){Cl[Dl++]=yi,Cl[Dl++]=yn,yn=e,yi=t}function Vc(e,t,l){Yt[Gt++]=Pt,Yt[Gt++]=Wt,Yt[Gt++]=Sa,Sa=e;var i=Pt;e=Wt;var n=32-mt(i)-1;i&=~(1<<n),l+=1;var s=32-mt(t)+n;if(30<s){var o=n-n%5;s=(i&(1<<o)-1).toString(32),i>>=o,n-=o,Pt=1<<32-mt(t)+n|l<<n|i,Wt=s+e}else Pt=1<<s|l<<n|i,Wt=e}function Ws(e){e.return!==null&&(sa(e,1),Vc(e,1,0))}function $s(e){for(;e===yn;)yn=Cl[--Dl],Cl[Dl]=null,yi=Cl[--Dl],Cl[Dl]=null;for(;e===Sa;)Sa=Yt[--Gt],Yt[Gt]=null,Wt=Yt[--Gt],Yt[Gt]=null,Pt=Yt[--Gt],Yt[Gt]=null}function Xc(e,t){Yt[Gt++]=Pt,Yt[Gt++]=Wt,Yt[Gt++]=Sa,Pt=t.id,Wt=t.overflow,Sa=e}var ot=null,Ie=null,Ee=!1,Ea=null,It=!1,er=Error(d(519));function Ta(e){var t=Error(d(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw vi(Ht(t,e)),er}function Qc(e){var t=e.stateNode,l=e.type,i=e.memoizedProps;switch(t[rt]=e,t[vt]=i,l){case"dialog":Ne("cancel",t),Ne("close",t);break;case"iframe":case"object":case"embed":Ne("load",t);break;case"video":case"audio":for(l=0;l<Ii.length;l++)Ne(Ii[l],t);break;case"source":Ne("error",t);break;case"img":case"image":case"link":Ne("error",t),Ne("load",t);break;case"details":Ne("toggle",t);break;case"input":Ne("invalid",t),sc(t,i.value,i.defaultValue,i.checked,i.defaultChecked,i.type,i.name,!0);break;case"select":Ne("invalid",t);break;case"textarea":Ne("invalid",t),oc(t,i.value,i.defaultValue,i.children)}l=i.children,typeof l!="string"&&typeof l!="number"&&typeof l!="bigint"||t.textContent===""+l||i.suppressHydrationWarning===!0||uf(t.textContent,l)?(i.popover!=null&&(Ne("beforetoggle",t),Ne("toggle",t)),i.onScroll!=null&&Ne("scroll",t),i.onScrollEnd!=null&&Ne("scrollend",t),i.onClick!=null&&(t.onclick=la),t=!0):t=!1,t||Ta(e,!0)}function Zc(e){for(ot=e.return;ot;)switch(ot.tag){case 5:case 31:case 13:It=!1;return;case 27:case 3:It=!0;return;default:ot=ot.return}}function Ml(e){if(e!==ot)return!1;if(!Ee)return Zc(e),Ee=!0,!1;var t=e.tag,l;if((l=t!==3&&t!==27)&&((l=t===5)&&(l=e.type,l=!(l!=="form"&&l!=="button")||yo(e.type,e.memoizedProps)),l=!l),l&&Ie&&Ta(e),Zc(e),t===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(d(317));Ie=vf(e)}else if(t===31){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(d(317));Ie=vf(e)}else t===27?(t=Ie,Ia(e.type)?(e=zo,zo=null,Ie=e):Ie=t):Ie=ot?qt(e.stateNode.nextSibling):null;return!0}function nl(){Ie=ot=null,Ee=!1}function tr(){var e=Ea;return e!==null&&(wt===null?wt=e:wt.push.apply(wt,e),Ea=null),e}function vi(e){Ea===null?Ea=[e]:Ea.push(e)}var ar=m(null),sl=null,ra=null;function _a(e,t,l){K(ar,t._currentValue),t._currentValue=l}function oa(e){e._currentValue=ar.current,D(ar)}function lr(e,t,l){for(;e!==null;){var i=e.alternate;if((e.childLanes&t)!==t?(e.childLanes|=t,i!==null&&(i.childLanes|=t)):i!==null&&(i.childLanes&t)!==t&&(i.childLanes|=t),e===l)break;e=e.return}}function ir(e,t,l,i){var n=e.child;for(n!==null&&(n.return=e);n!==null;){var s=n.dependencies;if(s!==null){var o=n.child;s=s.firstContext;e:for(;s!==null;){var c=s;s=n;for(var u=0;u<t.length;u++)if(c.context===t[u]){s.lanes|=l,c=s.alternate,c!==null&&(c.lanes|=l),lr(s.return,l,e),i||(o=null);break e}s=c.next}}else if(n.tag===18){if(o=n.return,o===null)throw Error(d(341));o.lanes|=l,s=o.alternate,s!==null&&(s.lanes|=l),lr(o,l,e),o=null}else o=n.child;if(o!==null)o.return=n;else for(o=n;o!==null;){if(o===e){o=null;break}if(n=o.sibling,n!==null){n.return=o.return,o=n;break}o=o.return}n=o}}function Rl(e,t,l,i){e=null;for(var n=t,s=!1;n!==null;){if(!s){if((n.flags&524288)!==0)s=!0;else if((n.flags&262144)!==0)break}if(n.tag===10){var o=n.alternate;if(o===null)throw Error(d(387));if(o=o.memoizedProps,o!==null){var c=n.type;Tt(n.pendingProps.value,o.value)||(e!==null?e.push(c):e=[c])}}else if(n===O.current){if(o=n.alternate,o===null)throw Error(d(387));o.memoizedState.memoizedState!==n.memoizedState.memoizedState&&(e!==null?e.push(Qi):e=[Qi])}n=n.return}e!==null&&ir(t,e,l,i),t.flags|=262144}function vn(e){for(e=e.firstContext;e!==null;){if(!Tt(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function rl(e){sl=e,ra=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function ct(e){return Jc(sl,e)}function kn(e,t){return sl===null&&rl(e),Jc(e,t)}function Jc(e,t){var l=t._currentValue;if(t={context:t,memoizedValue:l,next:null},ra===null){if(e===null)throw Error(d(308));ra=t,e.dependencies={lanes:0,firstContext:t},e.flags|=524288}else ra=ra.next=t;return l}var p0=typeof AbortController<"u"?AbortController:function(){var e=[],t=this.signal={aborted:!1,addEventListener:function(l,i){e.push(i)}};this.abort=function(){t.aborted=!0,e.forEach(function(l){return l()})}},h0=r.unstable_scheduleCallback,g0=r.unstable_NormalPriority,$e={$$typeof:fe,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function nr(){return{controller:new p0,data:new Map,refCount:0}}function ki(e){e.refCount--,e.refCount===0&&h0(g0,function(){e.controller.abort()})}var ji=null,sr=0,Ul=0,Ll=null;function b0(e,t){if(ji===null){var l=ji=[];sr=0,Ul=co(),Ll={status:"pending",value:void 0,then:function(i){l.push(i)}}}return sr++,t.then(Fc,Fc),t}function Fc(){if(--sr===0&&ji!==null){Ll!==null&&(Ll.status="fulfilled");var e=ji;ji=null,Ul=0,Ll=null;for(var t=0;t<e.length;t++)(0,e[t])()}}function y0(e,t){var l=[],i={status:"pending",value:null,reason:null,then:function(n){l.push(n)}};return e.then(function(){i.status="fulfilled",i.value=t;for(var n=0;n<l.length;n++)(0,l[n])(t)},function(n){for(i.status="rejected",i.reason=n,n=0;n<l.length;n++)(0,l[n])(void 0)}),i}var Pc=T.S;T.S=function(e,t){Mu=he(),typeof t=="object"&&t!==null&&typeof t.then=="function"&&b0(e,t),Pc!==null&&Pc(e,t)};var ol=m(null);function rr(){var e=ol.current;return e!==null?e:Ge.pooledCache}function jn(e,t){t===null?K(ol,ol.current):K(ol,t.pool)}function Wc(){var e=rr();return e===null?null:{parent:$e._currentValue,pool:e}}var Bl=Error(d(460)),or=Error(d(474)),Nn=Error(d(542)),zn={then:function(){}};function $c(e){return e=e.status,e==="fulfilled"||e==="rejected"}function ed(e,t,l){switch(l=e[l],l===void 0?e.push(t):l!==t&&(t.then(la,la),t=l),t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,ad(e),e;default:if(typeof t.status=="string")t.then(la,la);else{if(e=Ge,e!==null&&100<e.shellSuspendCounter)throw Error(d(482));e=t,e.status="pending",e.then(function(i){if(t.status==="pending"){var n=t;n.status="fulfilled",n.value=i}},function(i){if(t.status==="pending"){var n=t;n.status="rejected",n.reason=i}})}switch(t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,ad(e),e}throw dl=t,Bl}}function cl(e){try{var t=e._init;return t(e._payload)}catch(l){throw l!==null&&typeof l=="object"&&typeof l.then=="function"?(dl=l,Bl):l}}var dl=null;function td(){if(dl===null)throw Error(d(459));var e=dl;return dl=null,e}function ad(e){if(e===Bl||e===Nn)throw Error(d(483))}var Hl=null,Ni=0;function wn(e){var t=Ni;return Ni+=1,Hl===null&&(Hl=[]),ed(Hl,e,t)}function zi(e,t){t=t.props.ref,e.ref=t!==void 0?t:null}function Sn(e,t){throw t.$$typeof===Y?Error(d(525)):(e=Object.prototype.toString.call(t),Error(d(31,e==="[object Object]"?"object with keys {"+Object.keys(t).join(", ")+"}":e)))}function ld(e){function t(y,x){if(e){var j=y.deletions;j===null?(y.deletions=[x],y.flags|=16):j.push(x)}}function l(y,x){if(!e)return null;for(;x!==null;)t(y,x),x=x.sibling;return null}function i(y){for(var x=new Map;y!==null;)y.key!==null?x.set(y.key,y):x.set(y.index,y),y=y.sibling;return x}function n(y,x){return y=na(y,x),y.index=0,y.sibling=null,y}function s(y,x,j){return y.index=j,e?(j=y.alternate,j!==null?(j=j.index,j<x?(y.flags|=67108866,x):j):(y.flags|=67108866,x)):(y.flags|=1048576,x)}function o(y){return e&&y.alternate===null&&(y.flags|=67108866),y}function c(y,x,j,M){return x===null||x.tag!==6?(x=Fs(j,y.mode,M),x.return=y,x):(x=n(x,j),x.return=y,x)}function u(y,x,j,M){var ie=j.type;return ie===ae?C(y,x,j.props.children,M,j.key):x!==null&&(x.elementType===ie||typeof ie=="object"&&ie!==null&&ie.$$typeof===I&&cl(ie)===x.type)?(x=n(x,j.props),zi(x,j),x.return=y,x):(x=bn(j.type,j.key,j.props,null,y.mode,M),zi(x,j),x.return=y,x)}function z(y,x,j,M){return x===null||x.tag!==4||x.stateNode.containerInfo!==j.containerInfo||x.stateNode.implementation!==j.implementation?(x=Ps(j,y.mode,M),x.return=y,x):(x=n(x,j.children||[]),x.return=y,x)}function C(y,x,j,M,ie){return x===null||x.tag!==7?(x=il(j,y.mode,M,ie),x.return=y,x):(x=n(x,j),x.return=y,x)}function R(y,x,j){if(typeof x=="string"&&x!==""||typeof x=="number"||typeof x=="bigint")return x=Fs(""+x,y.mode,j),x.return=y,x;if(typeof x=="object"&&x!==null){switch(x.$$typeof){case H:return j=bn(x.type,x.key,x.props,null,y.mode,j),zi(j,x),j.return=y,j;case B:return x=Ps(x,y.mode,j),x.return=y,x;case I:return x=cl(x),R(y,x,j)}if(_e(x)||re(x))return x=il(x,y.mode,j,null),x.return=y,x;if(typeof x.then=="function")return R(y,wn(x),j);if(x.$$typeof===fe)return R(y,kn(y,x),j);Sn(y,x)}return null}function w(y,x,j,M){var ie=x!==null?x.key:null;if(typeof j=="string"&&j!==""||typeof j=="number"||typeof j=="bigint")return ie!==null?null:c(y,x,""+j,M);if(typeof j=="object"&&j!==null){switch(j.$$typeof){case H:return j.key===ie?u(y,x,j,M):null;case B:return j.key===ie?z(y,x,j,M):null;case I:return j=cl(j),w(y,x,j,M)}if(_e(j)||re(j))return ie!==null?null:C(y,x,j,M,null);if(typeof j.then=="function")return w(y,x,wn(j),M);if(j.$$typeof===fe)return w(y,x,kn(y,j),M);Sn(y,j)}return null}function A(y,x,j,M,ie){if(typeof M=="string"&&M!==""||typeof M=="number"||typeof M=="bigint")return y=y.get(j)||null,c(x,y,""+M,ie);if(typeof M=="object"&&M!==null){switch(M.$$typeof){case H:return y=y.get(M.key===null?j:M.key)||null,u(x,y,M,ie);case B:return y=y.get(M.key===null?j:M.key)||null,z(x,y,M,ie);case I:return M=cl(M),A(y,x,j,M,ie)}if(_e(M)||re(M))return y=y.get(j)||null,C(x,y,M,ie,null);if(typeof M.then=="function")return A(y,x,j,wn(M),ie);if(M.$$typeof===fe)return A(y,x,j,kn(x,M),ie);Sn(x,M)}return null}function P(y,x,j,M){for(var ie=null,Oe=null,$=x,ve=x=0,we=null;$!==null&&ve<j.length;ve++){$.index>ve?(we=$,$=null):we=$.sibling;var Ce=w(y,$,j[ve],M);if(Ce===null){$===null&&($=we);break}e&&$&&Ce.alternate===null&&t(y,$),x=s(Ce,x,ve),Oe===null?ie=Ce:Oe.sibling=Ce,Oe=Ce,$=we}if(ve===j.length)return l(y,$),Ee&&sa(y,ve),ie;if($===null){for(;ve<j.length;ve++)$=R(y,j[ve],M),$!==null&&(x=s($,x,ve),Oe===null?ie=$:Oe.sibling=$,Oe=$);return Ee&&sa(y,ve),ie}for($=i($);ve<j.length;ve++)we=A($,y,ve,j[ve],M),we!==null&&(e&&we.alternate!==null&&$.delete(we.key===null?ve:we.key),x=s(we,x,ve),Oe===null?ie=we:Oe.sibling=we,Oe=we);return e&&$.forEach(function(Qa){return t(y,Qa)}),Ee&&sa(y,ve),ie}function de(y,x,j,M){if(j==null)throw Error(d(151));for(var ie=null,Oe=null,$=x,ve=x=0,we=null,Ce=j.next();$!==null&&!Ce.done;ve++,Ce=j.next()){$.index>ve?(we=$,$=null):we=$.sibling;var Qa=w(y,$,Ce.value,M);if(Qa===null){$===null&&($=we);break}e&&$&&Qa.alternate===null&&t(y,$),x=s(Qa,x,ve),Oe===null?ie=Qa:Oe.sibling=Qa,Oe=Qa,$=we}if(Ce.done)return l(y,$),Ee&&sa(y,ve),ie;if($===null){for(;!Ce.done;ve++,Ce=j.next())Ce=R(y,Ce.value,M),Ce!==null&&(x=s(Ce,x,ve),Oe===null?ie=Ce:Oe.sibling=Ce,Oe=Ce);return Ee&&sa(y,ve),ie}for($=i($);!Ce.done;ve++,Ce=j.next())Ce=A($,y,ve,Ce.value,M),Ce!==null&&(e&&Ce.alternate!==null&&$.delete(Ce.key===null?ve:Ce.key),x=s(Ce,x,ve),Oe===null?ie=Ce:Oe.sibling=Ce,Oe=Ce);return e&&$.forEach(function(Ap){return t(y,Ap)}),Ee&&sa(y,ve),ie}function Ye(y,x,j,M){if(typeof j=="object"&&j!==null&&j.type===ae&&j.key===null&&(j=j.props.children),typeof j=="object"&&j!==null){switch(j.$$typeof){case H:e:{for(var ie=j.key;x!==null;){if(x.key===ie){if(ie=j.type,ie===ae){if(x.tag===7){l(y,x.sibling),M=n(x,j.props.children),M.return=y,y=M;break e}}else if(x.elementType===ie||typeof ie=="object"&&ie!==null&&ie.$$typeof===I&&cl(ie)===x.type){l(y,x.sibling),M=n(x,j.props),zi(M,j),M.return=y,y=M;break e}l(y,x);break}else t(y,x);x=x.sibling}j.type===ae?(M=il(j.props.children,y.mode,M,j.key),M.return=y,y=M):(M=bn(j.type,j.key,j.props,null,y.mode,M),zi(M,j),M.return=y,y=M)}return o(y);case B:e:{for(ie=j.key;x!==null;){if(x.key===ie)if(x.tag===4&&x.stateNode.containerInfo===j.containerInfo&&x.stateNode.implementation===j.implementation){l(y,x.sibling),M=n(x,j.children||[]),M.return=y,y=M;break e}else{l(y,x);break}else t(y,x);x=x.sibling}M=Ps(j,y.mode,M),M.return=y,y=M}return o(y);case I:return j=cl(j),Ye(y,x,j,M)}if(_e(j))return P(y,x,j,M);if(re(j)){if(ie=re(j),typeof ie!="function")throw Error(d(150));return j=ie.call(j),de(y,x,j,M)}if(typeof j.then=="function")return Ye(y,x,wn(j),M);if(j.$$typeof===fe)return Ye(y,x,kn(y,j),M);Sn(y,j)}return typeof j=="string"&&j!==""||typeof j=="number"||typeof j=="bigint"?(j=""+j,x!==null&&x.tag===6?(l(y,x.sibling),M=n(x,j),M.return=y,y=M):(l(y,x),M=Fs(j,y.mode,M),M.return=y,y=M),o(y)):l(y,x)}return function(y,x,j,M){try{Ni=0;var ie=Ye(y,x,j,M);return Hl=null,ie}catch($){if($===Bl||$===Nn)throw $;var Oe=_t(29,$,null,y.mode);return Oe.lanes=M,Oe.return=y,Oe}finally{}}}var ul=ld(!0),id=ld(!1),Aa=!1;function cr(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function dr(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function Oa(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function Ca(e,t,l){var i=e.updateQueue;if(i===null)return null;if(i=i.shared,(Me&2)!==0){var n=i.pending;return n===null?t.next=t:(t.next=n.next,n.next=t),i.pending=t,t=gn(e),Gc(e,null,l),t}return hn(e,i,t,l),gn(e)}function wi(e,t,l){if(t=t.updateQueue,t!==null&&(t=t.shared,(l&4194048)!==0)){var i=t.lanes;i&=e.pendingLanes,l|=i,t.lanes=l,Jo(e,l)}}function ur(e,t){var l=e.updateQueue,i=e.alternate;if(i!==null&&(i=i.updateQueue,l===i)){var n=null,s=null;if(l=l.firstBaseUpdate,l!==null){do{var o={lane:l.lane,tag:l.tag,payload:l.payload,callback:null,next:null};s===null?n=s=o:s=s.next=o,l=l.next}while(l!==null);s===null?n=s=t:s=s.next=t}else n=s=t;l={baseState:i.baseState,firstBaseUpdate:n,lastBaseUpdate:s,shared:i.shared,callbacks:i.callbacks},e.updateQueue=l;return}e=l.lastBaseUpdate,e===null?l.firstBaseUpdate=t:e.next=t,l.lastBaseUpdate=t}var fr=!1;function Si(){if(fr){var e=Ll;if(e!==null)throw e}}function Ei(e,t,l,i){fr=!1;var n=e.updateQueue;Aa=!1;var s=n.firstBaseUpdate,o=n.lastBaseUpdate,c=n.shared.pending;if(c!==null){n.shared.pending=null;var u=c,z=u.next;u.next=null,o===null?s=z:o.next=z,o=u;var C=e.alternate;C!==null&&(C=C.updateQueue,c=C.lastBaseUpdate,c!==o&&(c===null?C.firstBaseUpdate=z:c.next=z,C.lastBaseUpdate=u))}if(s!==null){var R=n.baseState;o=0,C=z=u=null,c=s;do{var w=c.lane&-536870913,A=w!==c.lane;if(A?(ze&w)===w:(i&w)===w){w!==0&&w===Ul&&(fr=!0),C!==null&&(C=C.next={lane:0,tag:c.tag,payload:c.payload,callback:null,next:null});e:{var P=e,de=c;w=t;var Ye=l;switch(de.tag){case 1:if(P=de.payload,typeof P=="function"){R=P.call(Ye,R,w);break e}R=P;break e;case 3:P.flags=P.flags&-65537|128;case 0:if(P=de.payload,w=typeof P=="function"?P.call(Ye,R,w):P,w==null)break e;R=N({},R,w);break e;case 2:Aa=!0}}w=c.callback,w!==null&&(e.flags|=64,A&&(e.flags|=8192),A=n.callbacks,A===null?n.callbacks=[w]:A.push(w))}else A={lane:w,tag:c.tag,payload:c.payload,callback:c.callback,next:null},C===null?(z=C=A,u=R):C=C.next=A,o|=w;if(c=c.next,c===null){if(c=n.shared.pending,c===null)break;A=c,c=A.next,A.next=null,n.lastBaseUpdate=A,n.shared.pending=null}}while(!0);C===null&&(u=R),n.baseState=u,n.firstBaseUpdate=z,n.lastBaseUpdate=C,s===null&&(n.shared.lanes=0),La|=o,e.lanes=o,e.memoizedState=R}}function nd(e,t){if(typeof e!="function")throw Error(d(191,e));e.call(t)}function sd(e,t){var l=e.callbacks;if(l!==null)for(e.callbacks=null,e=0;e<l.length;e++)nd(l[e],t)}var Yl=m(null),En=m(0);function rd(e,t){e=ga,K(En,e),K(Yl,t),ga=e|t.baseLanes}function mr(){K(En,ga),K(Yl,Yl.current)}function xr(){ga=En.current,D(Yl),D(En)}var At=m(null),Kt=null;function Da(e){var t=e.alternate;K(Je,Je.current&1),K(At,e),Kt===null&&(t===null||Yl.current!==null||t.memoizedState!==null)&&(Kt=e)}function pr(e){K(Je,Je.current),K(At,e),Kt===null&&(Kt=e)}function od(e){e.tag===22?(K(Je,Je.current),K(At,e),Kt===null&&(Kt=e)):Ma()}function Ma(){K(Je,Je.current),K(At,At.current)}function Ot(e){D(At),Kt===e&&(Kt=null),D(Je)}var Je=m(0);function Tn(e){for(var t=e;t!==null;){if(t.tag===13){var l=t.memoizedState;if(l!==null&&(l=l.dehydrated,l===null||jo(l)||No(l)))return t}else if(t.tag===19&&(t.memoizedProps.revealOrder==="forwards"||t.memoizedProps.revealOrder==="backwards"||t.memoizedProps.revealOrder==="unstable_legacy-backwards"||t.memoizedProps.revealOrder==="together")){if((t.flags&128)!==0)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var ca=0,ye=null,Be=null,et=null,_n=!1,Gl=!1,fl=!1,An=0,Ti=0,Il=null,v0=0;function Xe(){throw Error(d(321))}function hr(e,t){if(t===null)return!1;for(var l=0;l<t.length&&l<e.length;l++)if(!Tt(e[l],t[l]))return!1;return!0}function gr(e,t,l,i,n,s){return ca=s,ye=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,T.H=e===null||e.memoizedState===null?Vd:Cr,fl=!1,s=l(i,n),fl=!1,Gl&&(s=dd(t,l,i,n)),cd(e),s}function cd(e){T.H=Oi;var t=Be!==null&&Be.next!==null;if(ca=0,et=Be=ye=null,_n=!1,Ti=0,Il=null,t)throw Error(d(300));e===null||tt||(e=e.dependencies,e!==null&&vn(e)&&(tt=!0))}function dd(e,t,l,i){ye=e;var n=0;do{if(Gl&&(Il=null),Ti=0,Gl=!1,25<=n)throw Error(d(301));if(n+=1,et=Be=null,e.updateQueue!=null){var s=e.updateQueue;s.lastEffect=null,s.events=null,s.stores=null,s.memoCache!=null&&(s.memoCache.index=0)}T.H=Xd,s=t(l,i)}while(Gl);return s}function k0(){var e=T.H,t=e.useState()[0];return t=typeof t.then=="function"?_i(t):t,e=e.useState()[0],(Be!==null?Be.memoizedState:null)!==e&&(ye.flags|=1024),t}function br(){var e=An!==0;return An=0,e}function yr(e,t,l){t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~l}function vr(e){if(_n){for(e=e.memoizedState;e!==null;){var t=e.queue;t!==null&&(t.pending=null),e=e.next}_n=!1}ca=0,et=Be=ye=null,Gl=!1,Ti=An=0,Il=null}function gt(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return et===null?ye.memoizedState=et=e:et=et.next=e,et}function Fe(){if(Be===null){var e=ye.alternate;e=e!==null?e.memoizedState:null}else e=Be.next;var t=et===null?ye.memoizedState:et.next;if(t!==null)et=t,Be=e;else{if(e===null)throw ye.alternate===null?Error(d(467)):Error(d(310));Be=e,e={memoizedState:Be.memoizedState,baseState:Be.baseState,baseQueue:Be.baseQueue,queue:Be.queue,next:null},et===null?ye.memoizedState=et=e:et=et.next=e}return et}function On(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function _i(e){var t=Ti;return Ti+=1,Il===null&&(Il=[]),e=ed(Il,e,t),t=ye,(et===null?t.memoizedState:et.next)===null&&(t=t.alternate,T.H=t===null||t.memoizedState===null?Vd:Cr),e}function Cn(e){if(e!==null&&typeof e=="object"){if(typeof e.then=="function")return _i(e);if(e.$$typeof===fe)return ct(e)}throw Error(d(438,String(e)))}function kr(e){var t=null,l=ye.updateQueue;if(l!==null&&(t=l.memoCache),t==null){var i=ye.alternate;i!==null&&(i=i.updateQueue,i!==null&&(i=i.memoCache,i!=null&&(t={data:i.data.map(function(n){return n.slice()}),index:0})))}if(t==null&&(t={data:[],index:0}),l===null&&(l=On(),ye.updateQueue=l),l.memoCache=t,l=t.data[t.index],l===void 0)for(l=t.data[t.index]=Array(e),i=0;i<e;i++)l[i]=se;return t.index++,l}function da(e,t){return typeof t=="function"?t(e):t}function Dn(e){var t=Fe();return jr(t,Be,e)}function jr(e,t,l){var i=e.queue;if(i===null)throw Error(d(311));i.lastRenderedReducer=l;var n=e.baseQueue,s=i.pending;if(s!==null){if(n!==null){var o=n.next;n.next=s.next,s.next=o}t.baseQueue=n=s,i.pending=null}if(s=e.baseState,n===null)e.memoizedState=s;else{t=n.next;var c=o=null,u=null,z=t,C=!1;do{var R=z.lane&-536870913;if(R!==z.lane?(ze&R)===R:(ca&R)===R){var w=z.revertLane;if(w===0)u!==null&&(u=u.next={lane:0,revertLane:0,gesture:null,action:z.action,hasEagerState:z.hasEagerState,eagerState:z.eagerState,next:null}),R===Ul&&(C=!0);else if((ca&w)===w){z=z.next,w===Ul&&(C=!0);continue}else R={lane:0,revertLane:z.revertLane,gesture:null,action:z.action,hasEagerState:z.hasEagerState,eagerState:z.eagerState,next:null},u===null?(c=u=R,o=s):u=u.next=R,ye.lanes|=w,La|=w;R=z.action,fl&&l(s,R),s=z.hasEagerState?z.eagerState:l(s,R)}else w={lane:R,revertLane:z.revertLane,gesture:z.gesture,action:z.action,hasEagerState:z.hasEagerState,eagerState:z.eagerState,next:null},u===null?(c=u=w,o=s):u=u.next=w,ye.lanes|=R,La|=R;z=z.next}while(z!==null&&z!==t);if(u===null?o=s:u.next=c,!Tt(s,e.memoizedState)&&(tt=!0,C&&(l=Ll,l!==null)))throw l;e.memoizedState=s,e.baseState=o,e.baseQueue=u,i.lastRenderedState=s}return n===null&&(i.lanes=0),[e.memoizedState,i.dispatch]}function Nr(e){var t=Fe(),l=t.queue;if(l===null)throw Error(d(311));l.lastRenderedReducer=e;var i=l.dispatch,n=l.pending,s=t.memoizedState;if(n!==null){l.pending=null;var o=n=n.next;do s=e(s,o.action),o=o.next;while(o!==n);Tt(s,t.memoizedState)||(tt=!0),t.memoizedState=s,t.baseQueue===null&&(t.baseState=s),l.lastRenderedState=s}return[s,i]}function ud(e,t,l){var i=ye,n=Fe(),s=Ee;if(s){if(l===void 0)throw Error(d(407));l=l()}else l=t();var o=!Tt((Be||n).memoizedState,l);if(o&&(n.memoizedState=l,tt=!0),n=n.queue,Sr(xd.bind(null,i,n,e),[e]),n.getSnapshot!==t||o||et!==null&&et.memoizedState.tag&1){if(i.flags|=2048,Kl(9,{destroy:void 0},md.bind(null,i,n,l,t),null),Ge===null)throw Error(d(349));s||(ca&127)!==0||fd(i,t,l)}return l}function fd(e,t,l){e.flags|=16384,e={getSnapshot:t,value:l},t=ye.updateQueue,t===null?(t=On(),ye.updateQueue=t,t.stores=[e]):(l=t.stores,l===null?t.stores=[e]:l.push(e))}function md(e,t,l,i){t.value=l,t.getSnapshot=i,pd(t)&&hd(e)}function xd(e,t,l){return l(function(){pd(t)&&hd(e)})}function pd(e){var t=e.getSnapshot;e=e.value;try{var l=t();return!Tt(e,l)}catch{return!0}}function hd(e){var t=ll(e,2);t!==null&&St(t,e,2)}function zr(e){var t=gt();if(typeof e=="function"){var l=e;if(e=l(),fl){Rt(!0);try{l()}finally{Rt(!1)}}}return t.memoizedState=t.baseState=e,t.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:da,lastRenderedState:e},t}function gd(e,t,l,i){return e.baseState=l,jr(e,Be,typeof i=="function"?i:da)}function j0(e,t,l,i,n){if(Un(e))throw Error(d(485));if(e=t.action,e!==null){var s={payload:n,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(o){s.listeners.push(o)}};T.T!==null?l(!0):s.isTransition=!1,i(s),l=t.pending,l===null?(s.next=t.pending=s,bd(t,s)):(s.next=l.next,t.pending=l.next=s)}}function bd(e,t){var l=t.action,i=t.payload,n=e.state;if(t.isTransition){var s=T.T,o={};T.T=o;try{var c=l(n,i),u=T.S;u!==null&&u(o,c),yd(e,t,c)}catch(z){wr(e,t,z)}finally{s!==null&&o.types!==null&&(s.types=o.types),T.T=s}}else try{s=l(n,i),yd(e,t,s)}catch(z){wr(e,t,z)}}function yd(e,t,l){l!==null&&typeof l=="object"&&typeof l.then=="function"?l.then(function(i){vd(e,t,i)},function(i){return wr(e,t,i)}):vd(e,t,l)}function vd(e,t,l){t.status="fulfilled",t.value=l,kd(t),e.state=l,t=e.pending,t!==null&&(l=t.next,l===t?e.pending=null:(l=l.next,t.next=l,bd(e,l)))}function wr(e,t,l){var i=e.pending;if(e.pending=null,i!==null){i=i.next;do t.status="rejected",t.reason=l,kd(t),t=t.next;while(t!==i)}e.action=null}function kd(e){e=e.listeners;for(var t=0;t<e.length;t++)(0,e[t])()}function jd(e,t){return t}function Nd(e,t){if(Ee){var l=Ge.formState;if(l!==null){e:{var i=ye;if(Ee){if(Ie){t:{for(var n=Ie,s=It;n.nodeType!==8;){if(!s){n=null;break t}if(n=qt(n.nextSibling),n===null){n=null;break t}}s=n.data,n=s==="F!"||s==="F"?n:null}if(n){Ie=qt(n.nextSibling),i=n.data==="F!";break e}}Ta(i)}i=!1}i&&(t=l[0])}}return l=gt(),l.memoizedState=l.baseState=t,i={pending:null,lanes:0,dispatch:null,lastRenderedReducer:jd,lastRenderedState:t},l.queue=i,l=Id.bind(null,ye,i),i.dispatch=l,i=zr(!1),s=Or.bind(null,ye,!1,i.queue),i=gt(),n={state:t,dispatch:null,action:e,pending:null},i.queue=n,l=j0.bind(null,ye,n,s,l),n.dispatch=l,i.memoizedState=e,[t,l,!1]}function zd(e){var t=Fe();return wd(t,Be,e)}function wd(e,t,l){if(t=jr(e,t,jd)[0],e=Dn(da)[0],typeof t=="object"&&t!==null&&typeof t.then=="function")try{var i=_i(t)}catch(o){throw o===Bl?Nn:o}else i=t;t=Fe();var n=t.queue,s=n.dispatch;return l!==t.memoizedState&&(ye.flags|=2048,Kl(9,{destroy:void 0},N0.bind(null,n,l),null)),[i,s,e]}function N0(e,t){e.action=t}function Sd(e){var t=Fe(),l=Be;if(l!==null)return wd(t,l,e);Fe(),t=t.memoizedState,l=Fe();var i=l.queue.dispatch;return l.memoizedState=e,[t,i,!1]}function Kl(e,t,l,i){return e={tag:e,create:l,deps:i,inst:t,next:null},t=ye.updateQueue,t===null&&(t=On(),ye.updateQueue=t),l=t.lastEffect,l===null?t.lastEffect=e.next=e:(i=l.next,l.next=e,e.next=i,t.lastEffect=e),e}function Ed(){return Fe().memoizedState}function Mn(e,t,l,i){var n=gt();ye.flags|=e,n.memoizedState=Kl(1|t,{destroy:void 0},l,i===void 0?null:i)}function Rn(e,t,l,i){var n=Fe();i=i===void 0?null:i;var s=n.memoizedState.inst;Be!==null&&i!==null&&hr(i,Be.memoizedState.deps)?n.memoizedState=Kl(t,s,l,i):(ye.flags|=e,n.memoizedState=Kl(1|t,s,l,i))}function Td(e,t){Mn(8390656,8,e,t)}function Sr(e,t){Rn(2048,8,e,t)}function z0(e){ye.flags|=4;var t=ye.updateQueue;if(t===null)t=On(),ye.updateQueue=t,t.events=[e];else{var l=t.events;l===null?t.events=[e]:l.push(e)}}function _d(e){var t=Fe().memoizedState;return z0({ref:t,nextImpl:e}),function(){if((Me&2)!==0)throw Error(d(440));return t.impl.apply(void 0,arguments)}}function Ad(e,t){return Rn(4,2,e,t)}function Od(e,t){return Rn(4,4,e,t)}function Cd(e,t){if(typeof t=="function"){e=e();var l=t(e);return function(){typeof l=="function"?l():t(null)}}if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function Dd(e,t,l){l=l!=null?l.concat([e]):null,Rn(4,4,Cd.bind(null,t,e),l)}function Er(){}function Md(e,t){var l=Fe();t=t===void 0?null:t;var i=l.memoizedState;return t!==null&&hr(t,i[1])?i[0]:(l.memoizedState=[e,t],e)}function Rd(e,t){var l=Fe();t=t===void 0?null:t;var i=l.memoizedState;if(t!==null&&hr(t,i[1]))return i[0];if(i=e(),fl){Rt(!0);try{e()}finally{Rt(!1)}}return l.memoizedState=[i,t],i}function Tr(e,t,l){return l===void 0||(ca&1073741824)!==0&&(ze&261930)===0?e.memoizedState=t:(e.memoizedState=l,e=Uu(),ye.lanes|=e,La|=e,l)}function Ud(e,t,l,i){return Tt(l,t)?l:Yl.current!==null?(e=Tr(e,l,i),Tt(e,t)||(tt=!0),e):(ca&42)===0||(ca&1073741824)!==0&&(ze&261930)===0?(tt=!0,e.memoizedState=l):(e=Uu(),ye.lanes|=e,La|=e,t)}function Ld(e,t,l,i,n){var s=f.p;f.p=s!==0&&8>s?s:8;var o=T.T,c={};T.T=c,Or(e,!1,t,l);try{var u=n(),z=T.S;if(z!==null&&z(c,u),u!==null&&typeof u=="object"&&typeof u.then=="function"){var C=y0(u,i);Ai(e,t,C,Mt(e))}else Ai(e,t,i,Mt(e))}catch(R){Ai(e,t,{then:function(){},status:"rejected",reason:R},Mt())}finally{f.p=s,o!==null&&c.types!==null&&(o.types=c.types),T.T=o}}function w0(){}function _r(e,t,l,i){if(e.tag!==5)throw Error(d(476));var n=Bd(e).queue;Ld(e,n,t,Q,l===null?w0:function(){return Hd(e),l(i)})}function Bd(e){var t=e.memoizedState;if(t!==null)return t;t={memoizedState:Q,baseState:Q,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:da,lastRenderedState:Q},next:null};var l={};return t.next={memoizedState:l,baseState:l,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:da,lastRenderedState:l},next:null},e.memoizedState=t,e=e.alternate,e!==null&&(e.memoizedState=t),t}function Hd(e){var t=Bd(e);t.next===null&&(t=e.alternate.memoizedState),Ai(e,t.next.queue,{},Mt())}function Ar(){return ct(Qi)}function Yd(){return Fe().memoizedState}function Gd(){return Fe().memoizedState}function S0(e){for(var t=e.return;t!==null;){switch(t.tag){case 24:case 3:var l=Mt();e=Oa(l);var i=Ca(t,e,l);i!==null&&(St(i,t,l),wi(i,t,l)),t={cache:nr()},e.payload=t;return}t=t.return}}function E0(e,t,l){var i=Mt();l={lane:i,revertLane:0,gesture:null,action:l,hasEagerState:!1,eagerState:null,next:null},Un(e)?Kd(t,l):(l=Zs(e,t,l,i),l!==null&&(St(l,e,i),qd(l,t,i)))}function Id(e,t,l){var i=Mt();Ai(e,t,l,i)}function Ai(e,t,l,i){var n={lane:i,revertLane:0,gesture:null,action:l,hasEagerState:!1,eagerState:null,next:null};if(Un(e))Kd(t,n);else{var s=e.alternate;if(e.lanes===0&&(s===null||s.lanes===0)&&(s=t.lastRenderedReducer,s!==null))try{var o=t.lastRenderedState,c=s(o,l);if(n.hasEagerState=!0,n.eagerState=c,Tt(c,o))return hn(e,t,n,0),Ge===null&&pn(),!1}catch{}finally{}if(l=Zs(e,t,n,i),l!==null)return St(l,e,i),qd(l,t,i),!0}return!1}function Or(e,t,l,i){if(i={lane:2,revertLane:co(),gesture:null,action:i,hasEagerState:!1,eagerState:null,next:null},Un(e)){if(t)throw Error(d(479))}else t=Zs(e,l,i,2),t!==null&&St(t,e,2)}function Un(e){var t=e.alternate;return e===ye||t!==null&&t===ye}function Kd(e,t){Gl=_n=!0;var l=e.pending;l===null?t.next=t:(t.next=l.next,l.next=t),e.pending=t}function qd(e,t,l){if((l&4194048)!==0){var i=t.lanes;i&=e.pendingLanes,l|=i,t.lanes=l,Jo(e,l)}}var Oi={readContext:ct,use:Cn,useCallback:Xe,useContext:Xe,useEffect:Xe,useImperativeHandle:Xe,useLayoutEffect:Xe,useInsertionEffect:Xe,useMemo:Xe,useReducer:Xe,useRef:Xe,useState:Xe,useDebugValue:Xe,useDeferredValue:Xe,useTransition:Xe,useSyncExternalStore:Xe,useId:Xe,useHostTransitionStatus:Xe,useFormState:Xe,useActionState:Xe,useOptimistic:Xe,useMemoCache:Xe,useCacheRefresh:Xe};Oi.useEffectEvent=Xe;var Vd={readContext:ct,use:Cn,useCallback:function(e,t){return gt().memoizedState=[e,t===void 0?null:t],e},useContext:ct,useEffect:Td,useImperativeHandle:function(e,t,l){l=l!=null?l.concat([e]):null,Mn(4194308,4,Cd.bind(null,t,e),l)},useLayoutEffect:function(e,t){return Mn(4194308,4,e,t)},useInsertionEffect:function(e,t){Mn(4,2,e,t)},useMemo:function(e,t){var l=gt();t=t===void 0?null:t;var i=e();if(fl){Rt(!0);try{e()}finally{Rt(!1)}}return l.memoizedState=[i,t],i},useReducer:function(e,t,l){var i=gt();if(l!==void 0){var n=l(t);if(fl){Rt(!0);try{l(t)}finally{Rt(!1)}}}else n=t;return i.memoizedState=i.baseState=n,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:n},i.queue=e,e=e.dispatch=E0.bind(null,ye,e),[i.memoizedState,e]},useRef:function(e){var t=gt();return e={current:e},t.memoizedState=e},useState:function(e){e=zr(e);var t=e.queue,l=Id.bind(null,ye,t);return t.dispatch=l,[e.memoizedState,l]},useDebugValue:Er,useDeferredValue:function(e,t){var l=gt();return Tr(l,e,t)},useTransition:function(){var e=zr(!1);return e=Ld.bind(null,ye,e.queue,!0,!1),gt().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,t,l){var i=ye,n=gt();if(Ee){if(l===void 0)throw Error(d(407));l=l()}else{if(l=t(),Ge===null)throw Error(d(349));(ze&127)!==0||fd(i,t,l)}n.memoizedState=l;var s={value:l,getSnapshot:t};return n.queue=s,Td(xd.bind(null,i,s,e),[e]),i.flags|=2048,Kl(9,{destroy:void 0},md.bind(null,i,s,l,t),null),l},useId:function(){var e=gt(),t=Ge.identifierPrefix;if(Ee){var l=Wt,i=Pt;l=(i&~(1<<32-mt(i)-1)).toString(32)+l,t="_"+t+"R_"+l,l=An++,0<l&&(t+="H"+l.toString(32)),t+="_"}else l=v0++,t="_"+t+"r_"+l.toString(32)+"_";return e.memoizedState=t},useHostTransitionStatus:Ar,useFormState:Nd,useActionState:Nd,useOptimistic:function(e){var t=gt();t.memoizedState=t.baseState=e;var l={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return t.queue=l,t=Or.bind(null,ye,!0,l),l.dispatch=t,[e,t]},useMemoCache:kr,useCacheRefresh:function(){return gt().memoizedState=S0.bind(null,ye)},useEffectEvent:function(e){var t=gt(),l={impl:e};return t.memoizedState=l,function(){if((Me&2)!==0)throw Error(d(440));return l.impl.apply(void 0,arguments)}}},Cr={readContext:ct,use:Cn,useCallback:Md,useContext:ct,useEffect:Sr,useImperativeHandle:Dd,useInsertionEffect:Ad,useLayoutEffect:Od,useMemo:Rd,useReducer:Dn,useRef:Ed,useState:function(){return Dn(da)},useDebugValue:Er,useDeferredValue:function(e,t){var l=Fe();return Ud(l,Be.memoizedState,e,t)},useTransition:function(){var e=Dn(da)[0],t=Fe().memoizedState;return[typeof e=="boolean"?e:_i(e),t]},useSyncExternalStore:ud,useId:Yd,useHostTransitionStatus:Ar,useFormState:zd,useActionState:zd,useOptimistic:function(e,t){var l=Fe();return gd(l,Be,e,t)},useMemoCache:kr,useCacheRefresh:Gd};Cr.useEffectEvent=_d;var Xd={readContext:ct,use:Cn,useCallback:Md,useContext:ct,useEffect:Sr,useImperativeHandle:Dd,useInsertionEffect:Ad,useLayoutEffect:Od,useMemo:Rd,useReducer:Nr,useRef:Ed,useState:function(){return Nr(da)},useDebugValue:Er,useDeferredValue:function(e,t){var l=Fe();return Be===null?Tr(l,e,t):Ud(l,Be.memoizedState,e,t)},useTransition:function(){var e=Nr(da)[0],t=Fe().memoizedState;return[typeof e=="boolean"?e:_i(e),t]},useSyncExternalStore:ud,useId:Yd,useHostTransitionStatus:Ar,useFormState:Sd,useActionState:Sd,useOptimistic:function(e,t){var l=Fe();return Be!==null?gd(l,Be,e,t):(l.baseState=e,[e,l.queue.dispatch])},useMemoCache:kr,useCacheRefresh:Gd};Xd.useEffectEvent=_d;function Dr(e,t,l,i){t=e.memoizedState,l=l(i,t),l=l==null?t:N({},t,l),e.memoizedState=l,e.lanes===0&&(e.updateQueue.baseState=l)}var Mr={enqueueSetState:function(e,t,l){e=e._reactInternals;var i=Mt(),n=Oa(i);n.payload=t,l!=null&&(n.callback=l),t=Ca(e,n,i),t!==null&&(St(t,e,i),wi(t,e,i))},enqueueReplaceState:function(e,t,l){e=e._reactInternals;var i=Mt(),n=Oa(i);n.tag=1,n.payload=t,l!=null&&(n.callback=l),t=Ca(e,n,i),t!==null&&(St(t,e,i),wi(t,e,i))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var l=Mt(),i=Oa(l);i.tag=2,t!=null&&(i.callback=t),t=Ca(e,i,l),t!==null&&(St(t,e,l),wi(t,e,l))}};function Qd(e,t,l,i,n,s,o){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(i,s,o):t.prototype&&t.prototype.isPureReactComponent?!gi(l,i)||!gi(n,s):!0}function Zd(e,t,l,i){e=t.state,typeof t.componentWillReceiveProps=="function"&&t.componentWillReceiveProps(l,i),typeof t.UNSAFE_componentWillReceiveProps=="function"&&t.UNSAFE_componentWillReceiveProps(l,i),t.state!==e&&Mr.enqueueReplaceState(t,t.state,null)}function ml(e,t){var l=t;if("ref"in t){l={};for(var i in t)i!=="ref"&&(l[i]=t[i])}if(e=e.defaultProps){l===t&&(l=N({},l));for(var n in e)l[n]===void 0&&(l[n]=e[n])}return l}function Jd(e){xn(e)}function Fd(e){console.error(e)}function Pd(e){xn(e)}function Ln(e,t){try{var l=e.onUncaughtError;l(t.value,{componentStack:t.stack})}catch(i){setTimeout(function(){throw i})}}function Wd(e,t,l){try{var i=e.onCaughtError;i(l.value,{componentStack:l.stack,errorBoundary:t.tag===1?t.stateNode:null})}catch(n){setTimeout(function(){throw n})}}function Rr(e,t,l){return l=Oa(l),l.tag=3,l.payload={element:null},l.callback=function(){Ln(e,t)},l}function $d(e){return e=Oa(e),e.tag=3,e}function eu(e,t,l,i){var n=l.type.getDerivedStateFromError;if(typeof n=="function"){var s=i.value;e.payload=function(){return n(s)},e.callback=function(){Wd(t,l,i)}}var o=l.stateNode;o!==null&&typeof o.componentDidCatch=="function"&&(e.callback=function(){Wd(t,l,i),typeof n!="function"&&(Ba===null?Ba=new Set([this]):Ba.add(this));var c=i.stack;this.componentDidCatch(i.value,{componentStack:c!==null?c:""})})}function T0(e,t,l,i,n){if(l.flags|=32768,i!==null&&typeof i=="object"&&typeof i.then=="function"){if(t=l.alternate,t!==null&&Rl(t,l,n,!0),l=At.current,l!==null){switch(l.tag){case 31:case 13:return Kt===null?Jn():l.alternate===null&&Qe===0&&(Qe=3),l.flags&=-257,l.flags|=65536,l.lanes=n,i===zn?l.flags|=16384:(t=l.updateQueue,t===null?l.updateQueue=new Set([i]):t.add(i),so(e,i,n)),!1;case 22:return l.flags|=65536,i===zn?l.flags|=16384:(t=l.updateQueue,t===null?(t={transitions:null,markerInstances:null,retryQueue:new Set([i])},l.updateQueue=t):(l=t.retryQueue,l===null?t.retryQueue=new Set([i]):l.add(i)),so(e,i,n)),!1}throw Error(d(435,l.tag))}return so(e,i,n),Jn(),!1}if(Ee)return t=At.current,t!==null?((t.flags&65536)===0&&(t.flags|=256),t.flags|=65536,t.lanes=n,i!==er&&(e=Error(d(422),{cause:i}),vi(Ht(e,l)))):(i!==er&&(t=Error(d(423),{cause:i}),vi(Ht(t,l))),e=e.current.alternate,e.flags|=65536,n&=-n,e.lanes|=n,i=Ht(i,l),n=Rr(e.stateNode,i,n),ur(e,n),Qe!==4&&(Qe=2)),!1;var s=Error(d(520),{cause:i});if(s=Ht(s,l),Hi===null?Hi=[s]:Hi.push(s),Qe!==4&&(Qe=2),t===null)return!0;i=Ht(i,l),l=t;do{switch(l.tag){case 3:return l.flags|=65536,e=n&-n,l.lanes|=e,e=Rr(l.stateNode,i,e),ur(l,e),!1;case 1:if(t=l.type,s=l.stateNode,(l.flags&128)===0&&(typeof t.getDerivedStateFromError=="function"||s!==null&&typeof s.componentDidCatch=="function"&&(Ba===null||!Ba.has(s))))return l.flags|=65536,n&=-n,l.lanes|=n,n=$d(n),eu(n,e,l,i),ur(l,n),!1}l=l.return}while(l!==null);return!1}var Ur=Error(d(461)),tt=!1;function dt(e,t,l,i){t.child=e===null?id(t,null,l,i):ul(t,e.child,l,i)}function tu(e,t,l,i,n){l=l.render;var s=t.ref;if("ref"in i){var o={};for(var c in i)c!=="ref"&&(o[c]=i[c])}else o=i;return rl(t),i=gr(e,t,l,o,s,n),c=br(),e!==null&&!tt?(yr(e,t,n),ua(e,t,n)):(Ee&&c&&Ws(t),t.flags|=1,dt(e,t,i,n),t.child)}function au(e,t,l,i,n){if(e===null){var s=l.type;return typeof s=="function"&&!Js(s)&&s.defaultProps===void 0&&l.compare===null?(t.tag=15,t.type=s,lu(e,t,s,i,n)):(e=bn(l.type,null,i,t,t.mode,n),e.ref=t.ref,e.return=t,t.child=e)}if(s=e.child,!qr(e,n)){var o=s.memoizedProps;if(l=l.compare,l=l!==null?l:gi,l(o,i)&&e.ref===t.ref)return ua(e,t,n)}return t.flags|=1,e=na(s,i),e.ref=t.ref,e.return=t,t.child=e}function lu(e,t,l,i,n){if(e!==null){var s=e.memoizedProps;if(gi(s,i)&&e.ref===t.ref)if(tt=!1,t.pendingProps=i=s,qr(e,n))(e.flags&131072)!==0&&(tt=!0);else return t.lanes=e.lanes,ua(e,t,n)}return Lr(e,t,l,i,n)}function iu(e,t,l,i){var n=i.children,s=e!==null?e.memoizedState:null;if(e===null&&t.stateNode===null&&(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),i.mode==="hidden"){if((t.flags&128)!==0){if(s=s!==null?s.baseLanes|l:l,e!==null){for(i=t.child=e.child,n=0;i!==null;)n=n|i.lanes|i.childLanes,i=i.sibling;i=n&~s}else i=0,t.child=null;return nu(e,t,s,l,i)}if((l&536870912)!==0)t.memoizedState={baseLanes:0,cachePool:null},e!==null&&jn(t,s!==null?s.cachePool:null),s!==null?rd(t,s):mr(),od(t);else return i=t.lanes=536870912,nu(e,t,s!==null?s.baseLanes|l:l,l,i)}else s!==null?(jn(t,s.cachePool),rd(t,s),Ma(),t.memoizedState=null):(e!==null&&jn(t,null),mr(),Ma());return dt(e,t,n,l),t.child}function Ci(e,t){return e!==null&&e.tag===22||t.stateNode!==null||(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),t.sibling}function nu(e,t,l,i,n){var s=rr();return s=s===null?null:{parent:$e._currentValue,pool:s},t.memoizedState={baseLanes:l,cachePool:s},e!==null&&jn(t,null),mr(),od(t),e!==null&&Rl(e,t,i,!0),t.childLanes=n,null}function Bn(e,t){return t=Yn({mode:t.mode,children:t.children},e.mode),t.ref=e.ref,e.child=t,t.return=e,t}function su(e,t,l){return ul(t,e.child,null,l),e=Bn(t,t.pendingProps),e.flags|=2,Ot(t),t.memoizedState=null,e}function _0(e,t,l){var i=t.pendingProps,n=(t.flags&128)!==0;if(t.flags&=-129,e===null){if(Ee){if(i.mode==="hidden")return e=Bn(t,i),t.lanes=536870912,Ci(null,e);if(pr(t),(e=Ie)?(e=yf(e,It),e=e!==null&&e.data==="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:Sa!==null?{id:Pt,overflow:Wt}:null,retryLane:536870912,hydrationErrors:null},l=Kc(e),l.return=t,t.child=l,ot=t,Ie=null)):e=null,e===null)throw Ta(t);return t.lanes=536870912,null}return Bn(t,i)}var s=e.memoizedState;if(s!==null){var o=s.dehydrated;if(pr(t),n)if(t.flags&256)t.flags&=-257,t=su(e,t,l);else if(t.memoizedState!==null)t.child=e.child,t.flags|=128,t=null;else throw Error(d(558));else if(tt||Rl(e,t,l,!1),n=(l&e.childLanes)!==0,tt||n){if(i=Ge,i!==null&&(o=Fo(i,l),o!==0&&o!==s.retryLane))throw s.retryLane=o,ll(e,o),St(i,e,o),Ur;Jn(),t=su(e,t,l)}else e=s.treeContext,Ie=qt(o.nextSibling),ot=t,Ee=!0,Ea=null,It=!1,e!==null&&Xc(t,e),t=Bn(t,i),t.flags|=4096;return t}return e=na(e.child,{mode:i.mode,children:i.children}),e.ref=t.ref,t.child=e,e.return=t,e}function Hn(e,t){var l=t.ref;if(l===null)e!==null&&e.ref!==null&&(t.flags|=4194816);else{if(typeof l!="function"&&typeof l!="object")throw Error(d(284));(e===null||e.ref!==l)&&(t.flags|=4194816)}}function Lr(e,t,l,i,n){return rl(t),l=gr(e,t,l,i,void 0,n),i=br(),e!==null&&!tt?(yr(e,t,n),ua(e,t,n)):(Ee&&i&&Ws(t),t.flags|=1,dt(e,t,l,n),t.child)}function ru(e,t,l,i,n,s){return rl(t),t.updateQueue=null,l=dd(t,i,l,n),cd(e),i=br(),e!==null&&!tt?(yr(e,t,s),ua(e,t,s)):(Ee&&i&&Ws(t),t.flags|=1,dt(e,t,l,s),t.child)}function ou(e,t,l,i,n){if(rl(t),t.stateNode===null){var s=Ol,o=l.contextType;typeof o=="object"&&o!==null&&(s=ct(o)),s=new l(i,s),t.memoizedState=s.state!==null&&s.state!==void 0?s.state:null,s.updater=Mr,t.stateNode=s,s._reactInternals=t,s=t.stateNode,s.props=i,s.state=t.memoizedState,s.refs={},cr(t),o=l.contextType,s.context=typeof o=="object"&&o!==null?ct(o):Ol,s.state=t.memoizedState,o=l.getDerivedStateFromProps,typeof o=="function"&&(Dr(t,l,o,i),s.state=t.memoizedState),typeof l.getDerivedStateFromProps=="function"||typeof s.getSnapshotBeforeUpdate=="function"||typeof s.UNSAFE_componentWillMount!="function"&&typeof s.componentWillMount!="function"||(o=s.state,typeof s.componentWillMount=="function"&&s.componentWillMount(),typeof s.UNSAFE_componentWillMount=="function"&&s.UNSAFE_componentWillMount(),o!==s.state&&Mr.enqueueReplaceState(s,s.state,null),Ei(t,i,s,n),Si(),s.state=t.memoizedState),typeof s.componentDidMount=="function"&&(t.flags|=4194308),i=!0}else if(e===null){s=t.stateNode;var c=t.memoizedProps,u=ml(l,c);s.props=u;var z=s.context,C=l.contextType;o=Ol,typeof C=="object"&&C!==null&&(o=ct(C));var R=l.getDerivedStateFromProps;C=typeof R=="function"||typeof s.getSnapshotBeforeUpdate=="function",c=t.pendingProps!==c,C||typeof s.UNSAFE_componentWillReceiveProps!="function"&&typeof s.componentWillReceiveProps!="function"||(c||z!==o)&&Zd(t,s,i,o),Aa=!1;var w=t.memoizedState;s.state=w,Ei(t,i,s,n),Si(),z=t.memoizedState,c||w!==z||Aa?(typeof R=="function"&&(Dr(t,l,R,i),z=t.memoizedState),(u=Aa||Qd(t,l,u,i,w,z,o))?(C||typeof s.UNSAFE_componentWillMount!="function"&&typeof s.componentWillMount!="function"||(typeof s.componentWillMount=="function"&&s.componentWillMount(),typeof s.UNSAFE_componentWillMount=="function"&&s.UNSAFE_componentWillMount()),typeof s.componentDidMount=="function"&&(t.flags|=4194308)):(typeof s.componentDidMount=="function"&&(t.flags|=4194308),t.memoizedProps=i,t.memoizedState=z),s.props=i,s.state=z,s.context=o,i=u):(typeof s.componentDidMount=="function"&&(t.flags|=4194308),i=!1)}else{s=t.stateNode,dr(e,t),o=t.memoizedProps,C=ml(l,o),s.props=C,R=t.pendingProps,w=s.context,z=l.contextType,u=Ol,typeof z=="object"&&z!==null&&(u=ct(z)),c=l.getDerivedStateFromProps,(z=typeof c=="function"||typeof s.getSnapshotBeforeUpdate=="function")||typeof s.UNSAFE_componentWillReceiveProps!="function"&&typeof s.componentWillReceiveProps!="function"||(o!==R||w!==u)&&Zd(t,s,i,u),Aa=!1,w=t.memoizedState,s.state=w,Ei(t,i,s,n),Si();var A=t.memoizedState;o!==R||w!==A||Aa||e!==null&&e.dependencies!==null&&vn(e.dependencies)?(typeof c=="function"&&(Dr(t,l,c,i),A=t.memoizedState),(C=Aa||Qd(t,l,C,i,w,A,u)||e!==null&&e.dependencies!==null&&vn(e.dependencies))?(z||typeof s.UNSAFE_componentWillUpdate!="function"&&typeof s.componentWillUpdate!="function"||(typeof s.componentWillUpdate=="function"&&s.componentWillUpdate(i,A,u),typeof s.UNSAFE_componentWillUpdate=="function"&&s.UNSAFE_componentWillUpdate(i,A,u)),typeof s.componentDidUpdate=="function"&&(t.flags|=4),typeof s.getSnapshotBeforeUpdate=="function"&&(t.flags|=1024)):(typeof s.componentDidUpdate!="function"||o===e.memoizedProps&&w===e.memoizedState||(t.flags|=4),typeof s.getSnapshotBeforeUpdate!="function"||o===e.memoizedProps&&w===e.memoizedState||(t.flags|=1024),t.memoizedProps=i,t.memoizedState=A),s.props=i,s.state=A,s.context=u,i=C):(typeof s.componentDidUpdate!="function"||o===e.memoizedProps&&w===e.memoizedState||(t.flags|=4),typeof s.getSnapshotBeforeUpdate!="function"||o===e.memoizedProps&&w===e.memoizedState||(t.flags|=1024),i=!1)}return s=i,Hn(e,t),i=(t.flags&128)!==0,s||i?(s=t.stateNode,l=i&&typeof l.getDerivedStateFromError!="function"?null:s.render(),t.flags|=1,e!==null&&i?(t.child=ul(t,e.child,null,n),t.child=ul(t,null,l,n)):dt(e,t,l,n),t.memoizedState=s.state,e=t.child):e=ua(e,t,n),e}function cu(e,t,l,i){return nl(),t.flags|=256,dt(e,t,l,i),t.child}var Br={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function Hr(e){return{baseLanes:e,cachePool:Wc()}}function Yr(e,t,l){return e=e!==null?e.childLanes&~l:0,t&&(e|=Dt),e}function du(e,t,l){var i=t.pendingProps,n=!1,s=(t.flags&128)!==0,o;if((o=s)||(o=e!==null&&e.memoizedState===null?!1:(Je.current&2)!==0),o&&(n=!0,t.flags&=-129),o=(t.flags&32)!==0,t.flags&=-33,e===null){if(Ee){if(n?Da(t):Ma(),(e=Ie)?(e=yf(e,It),e=e!==null&&e.data!=="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:Sa!==null?{id:Pt,overflow:Wt}:null,retryLane:536870912,hydrationErrors:null},l=Kc(e),l.return=t,t.child=l,ot=t,Ie=null)):e=null,e===null)throw Ta(t);return No(e)?t.lanes=32:t.lanes=536870912,null}var c=i.children;return i=i.fallback,n?(Ma(),n=t.mode,c=Yn({mode:"hidden",children:c},n),i=il(i,n,l,null),c.return=t,i.return=t,c.sibling=i,t.child=c,i=t.child,i.memoizedState=Hr(l),i.childLanes=Yr(e,o,l),t.memoizedState=Br,Ci(null,i)):(Da(t),Gr(t,c))}var u=e.memoizedState;if(u!==null&&(c=u.dehydrated,c!==null)){if(s)t.flags&256?(Da(t),t.flags&=-257,t=Ir(e,t,l)):t.memoizedState!==null?(Ma(),t.child=e.child,t.flags|=128,t=null):(Ma(),c=i.fallback,n=t.mode,i=Yn({mode:"visible",children:i.children},n),c=il(c,n,l,null),c.flags|=2,i.return=t,c.return=t,i.sibling=c,t.child=i,ul(t,e.child,null,l),i=t.child,i.memoizedState=Hr(l),i.childLanes=Yr(e,o,l),t.memoizedState=Br,t=Ci(null,i));else if(Da(t),No(c)){if(o=c.nextSibling&&c.nextSibling.dataset,o)var z=o.dgst;o=z,i=Error(d(419)),i.stack="",i.digest=o,vi({value:i,source:null,stack:null}),t=Ir(e,t,l)}else if(tt||Rl(e,t,l,!1),o=(l&e.childLanes)!==0,tt||o){if(o=Ge,o!==null&&(i=Fo(o,l),i!==0&&i!==u.retryLane))throw u.retryLane=i,ll(e,i),St(o,e,i),Ur;jo(c)||Jn(),t=Ir(e,t,l)}else jo(c)?(t.flags|=192,t.child=e.child,t=null):(e=u.treeContext,Ie=qt(c.nextSibling),ot=t,Ee=!0,Ea=null,It=!1,e!==null&&Xc(t,e),t=Gr(t,i.children),t.flags|=4096);return t}return n?(Ma(),c=i.fallback,n=t.mode,u=e.child,z=u.sibling,i=na(u,{mode:"hidden",children:i.children}),i.subtreeFlags=u.subtreeFlags&65011712,z!==null?c=na(z,c):(c=il(c,n,l,null),c.flags|=2),c.return=t,i.return=t,i.sibling=c,t.child=i,Ci(null,i),i=t.child,c=e.child.memoizedState,c===null?c=Hr(l):(n=c.cachePool,n!==null?(u=$e._currentValue,n=n.parent!==u?{parent:u,pool:u}:n):n=Wc(),c={baseLanes:c.baseLanes|l,cachePool:n}),i.memoizedState=c,i.childLanes=Yr(e,o,l),t.memoizedState=Br,Ci(e.child,i)):(Da(t),l=e.child,e=l.sibling,l=na(l,{mode:"visible",children:i.children}),l.return=t,l.sibling=null,e!==null&&(o=t.deletions,o===null?(t.deletions=[e],t.flags|=16):o.push(e)),t.child=l,t.memoizedState=null,l)}function Gr(e,t){return t=Yn({mode:"visible",children:t},e.mode),t.return=e,e.child=t}function Yn(e,t){return e=_t(22,e,null,t),e.lanes=0,e}function Ir(e,t,l){return ul(t,e.child,null,l),e=Gr(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function uu(e,t,l){e.lanes|=t;var i=e.alternate;i!==null&&(i.lanes|=t),lr(e.return,t,l)}function Kr(e,t,l,i,n,s){var o=e.memoizedState;o===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:i,tail:l,tailMode:n,treeForkCount:s}:(o.isBackwards=t,o.rendering=null,o.renderingStartTime=0,o.last=i,o.tail=l,o.tailMode=n,o.treeForkCount=s)}function fu(e,t,l){var i=t.pendingProps,n=i.revealOrder,s=i.tail;i=i.children;var o=Je.current,c=(o&2)!==0;if(c?(o=o&1|2,t.flags|=128):o&=1,K(Je,o),dt(e,t,i,l),i=Ee?yi:0,!c&&e!==null&&(e.flags&128)!==0)e:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&uu(e,l,t);else if(e.tag===19)uu(e,l,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;e.sibling===null;){if(e.return===null||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(n){case"forwards":for(l=t.child,n=null;l!==null;)e=l.alternate,e!==null&&Tn(e)===null&&(n=l),l=l.sibling;l=n,l===null?(n=t.child,t.child=null):(n=l.sibling,l.sibling=null),Kr(t,!1,n,l,s,i);break;case"backwards":case"unstable_legacy-backwards":for(l=null,n=t.child,t.child=null;n!==null;){if(e=n.alternate,e!==null&&Tn(e)===null){t.child=n;break}e=n.sibling,n.sibling=l,l=n,n=e}Kr(t,!0,l,null,s,i);break;case"together":Kr(t,!1,null,null,void 0,i);break;default:t.memoizedState=null}return t.child}function ua(e,t,l){if(e!==null&&(t.dependencies=e.dependencies),La|=t.lanes,(l&t.childLanes)===0)if(e!==null){if(Rl(e,t,l,!1),(l&t.childLanes)===0)return null}else return null;if(e!==null&&t.child!==e.child)throw Error(d(153));if(t.child!==null){for(e=t.child,l=na(e,e.pendingProps),t.child=l,l.return=t;e.sibling!==null;)e=e.sibling,l=l.sibling=na(e,e.pendingProps),l.return=t;l.sibling=null}return t.child}function qr(e,t){return(e.lanes&t)!==0?!0:(e=e.dependencies,!!(e!==null&&vn(e)))}function A0(e,t,l){switch(t.tag){case 3:te(t,t.stateNode.containerInfo),_a(t,$e,e.memoizedState.cache),nl();break;case 27:case 5:ke(t);break;case 4:te(t,t.stateNode.containerInfo);break;case 10:_a(t,t.type,t.memoizedProps.value);break;case 31:if(t.memoizedState!==null)return t.flags|=128,pr(t),null;break;case 13:var i=t.memoizedState;if(i!==null)return i.dehydrated!==null?(Da(t),t.flags|=128,null):(l&t.child.childLanes)!==0?du(e,t,l):(Da(t),e=ua(e,t,l),e!==null?e.sibling:null);Da(t);break;case 19:var n=(e.flags&128)!==0;if(i=(l&t.childLanes)!==0,i||(Rl(e,t,l,!1),i=(l&t.childLanes)!==0),n){if(i)return fu(e,t,l);t.flags|=128}if(n=t.memoizedState,n!==null&&(n.rendering=null,n.tail=null,n.lastEffect=null),K(Je,Je.current),i)break;return null;case 22:return t.lanes=0,iu(e,t,l,t.pendingProps);case 24:_a(t,$e,e.memoizedState.cache)}return ua(e,t,l)}function mu(e,t,l){if(e!==null)if(e.memoizedProps!==t.pendingProps)tt=!0;else{if(!qr(e,l)&&(t.flags&128)===0)return tt=!1,A0(e,t,l);tt=(e.flags&131072)!==0}else tt=!1,Ee&&(t.flags&1048576)!==0&&Vc(t,yi,t.index);switch(t.lanes=0,t.tag){case 16:e:{var i=t.pendingProps;if(e=cl(t.elementType),t.type=e,typeof e=="function")Js(e)?(i=ml(e,i),t.tag=1,t=ou(null,t,e,i,l)):(t.tag=0,t=Lr(null,t,e,i,l));else{if(e!=null){var n=e.$$typeof;if(n===ee){t.tag=11,t=tu(null,t,e,i,l);break e}else if(n===X){t.tag=14,t=au(null,t,e,i,l);break e}}throw t=xe(e)||e,Error(d(306,t,""))}}return t;case 0:return Lr(e,t,t.type,t.pendingProps,l);case 1:return i=t.type,n=ml(i,t.pendingProps),ou(e,t,i,n,l);case 3:e:{if(te(t,t.stateNode.containerInfo),e===null)throw Error(d(387));i=t.pendingProps;var s=t.memoizedState;n=s.element,dr(e,t),Ei(t,i,null,l);var o=t.memoizedState;if(i=o.cache,_a(t,$e,i),i!==s.cache&&ir(t,[$e],l,!0),Si(),i=o.element,s.isDehydrated)if(s={element:i,isDehydrated:!1,cache:o.cache},t.updateQueue.baseState=s,t.memoizedState=s,t.flags&256){t=cu(e,t,i,l);break e}else if(i!==n){n=Ht(Error(d(424)),t),vi(n),t=cu(e,t,i,l);break e}else{switch(e=t.stateNode.containerInfo,e.nodeType){case 9:e=e.body;break;default:e=e.nodeName==="HTML"?e.ownerDocument.body:e}for(Ie=qt(e.firstChild),ot=t,Ee=!0,Ea=null,It=!0,l=id(t,null,i,l),t.child=l;l;)l.flags=l.flags&-3|4096,l=l.sibling}else{if(nl(),i===n){t=ua(e,t,l);break e}dt(e,t,i,l)}t=t.child}return t;case 26:return Hn(e,t),e===null?(l=wf(t.type,null,t.pendingProps,null))?t.memoizedState=l:Ee||(l=t.type,e=t.pendingProps,i=as(pe.current).createElement(l),i[rt]=t,i[vt]=e,ut(i,l,e),it(i),t.stateNode=i):t.memoizedState=wf(t.type,e.memoizedProps,t.pendingProps,e.memoizedState),null;case 27:return ke(t),e===null&&Ee&&(i=t.stateNode=jf(t.type,t.pendingProps,pe.current),ot=t,It=!0,n=Ie,Ia(t.type)?(zo=n,Ie=qt(i.firstChild)):Ie=n),dt(e,t,t.pendingProps.children,l),Hn(e,t),e===null&&(t.flags|=4194304),t.child;case 5:return e===null&&Ee&&((n=i=Ie)&&(i=sp(i,t.type,t.pendingProps,It),i!==null?(t.stateNode=i,ot=t,Ie=qt(i.firstChild),It=!1,n=!0):n=!1),n||Ta(t)),ke(t),n=t.type,s=t.pendingProps,o=e!==null?e.memoizedProps:null,i=s.children,yo(n,s)?i=null:o!==null&&yo(n,o)&&(t.flags|=32),t.memoizedState!==null&&(n=gr(e,t,k0,null,null,l),Qi._currentValue=n),Hn(e,t),dt(e,t,i,l),t.child;case 6:return e===null&&Ee&&((e=l=Ie)&&(l=rp(l,t.pendingProps,It),l!==null?(t.stateNode=l,ot=t,Ie=null,e=!0):e=!1),e||Ta(t)),null;case 13:return du(e,t,l);case 4:return te(t,t.stateNode.containerInfo),i=t.pendingProps,e===null?t.child=ul(t,null,i,l):dt(e,t,i,l),t.child;case 11:return tu(e,t,t.type,t.pendingProps,l);case 7:return dt(e,t,t.pendingProps,l),t.child;case 8:return dt(e,t,t.pendingProps.children,l),t.child;case 12:return dt(e,t,t.pendingProps.children,l),t.child;case 10:return i=t.pendingProps,_a(t,t.type,i.value),dt(e,t,i.children,l),t.child;case 9:return n=t.type._context,i=t.pendingProps.children,rl(t),n=ct(n),i=i(n),t.flags|=1,dt(e,t,i,l),t.child;case 14:return au(e,t,t.type,t.pendingProps,l);case 15:return lu(e,t,t.type,t.pendingProps,l);case 19:return fu(e,t,l);case 31:return _0(e,t,l);case 22:return iu(e,t,l,t.pendingProps);case 24:return rl(t),i=ct($e),e===null?(n=rr(),n===null&&(n=Ge,s=nr(),n.pooledCache=s,s.refCount++,s!==null&&(n.pooledCacheLanes|=l),n=s),t.memoizedState={parent:i,cache:n},cr(t),_a(t,$e,n)):((e.lanes&l)!==0&&(dr(e,t),Ei(t,null,null,l),Si()),n=e.memoizedState,s=t.memoizedState,n.parent!==i?(n={parent:i,cache:i},t.memoizedState=n,t.lanes===0&&(t.memoizedState=t.updateQueue.baseState=n),_a(t,$e,i)):(i=s.cache,_a(t,$e,i),i!==n.cache&&ir(t,[$e],l,!0))),dt(e,t,t.pendingProps.children,l),t.child;case 29:throw t.pendingProps}throw Error(d(156,t.tag))}function fa(e){e.flags|=4}function Vr(e,t,l,i,n){if((t=(e.mode&32)!==0)&&(t=!1),t){if(e.flags|=16777216,(n&335544128)===n)if(e.stateNode.complete)e.flags|=8192;else if(Yu())e.flags|=8192;else throw dl=zn,or}else e.flags&=-16777217}function xu(e,t){if(t.type!=="stylesheet"||(t.state.loading&4)!==0)e.flags&=-16777217;else if(e.flags|=16777216,!Af(t))if(Yu())e.flags|=8192;else throw dl=zn,or}function Gn(e,t){t!==null&&(e.flags|=4),e.flags&16384&&(t=e.tag!==22?ks():536870912,e.lanes|=t,Ql|=t)}function Di(e,t){if(!Ee)switch(e.tailMode){case"hidden":t=e.tail;for(var l=null;t!==null;)t.alternate!==null&&(l=t),t=t.sibling;l===null?e.tail=null:l.sibling=null;break;case"collapsed":l=e.tail;for(var i=null;l!==null;)l.alternate!==null&&(i=l),l=l.sibling;i===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:i.sibling=null}}function Ke(e){var t=e.alternate!==null&&e.alternate.child===e.child,l=0,i=0;if(t)for(var n=e.child;n!==null;)l|=n.lanes|n.childLanes,i|=n.subtreeFlags&65011712,i|=n.flags&65011712,n.return=e,n=n.sibling;else for(n=e.child;n!==null;)l|=n.lanes|n.childLanes,i|=n.subtreeFlags,i|=n.flags,n.return=e,n=n.sibling;return e.subtreeFlags|=i,e.childLanes=l,t}function O0(e,t,l){var i=t.pendingProps;switch($s(t),t.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return Ke(t),null;case 1:return Ke(t),null;case 3:return l=t.stateNode,i=null,e!==null&&(i=e.memoizedState.cache),t.memoizedState.cache!==i&&(t.flags|=2048),oa($e),W(),l.pendingContext&&(l.context=l.pendingContext,l.pendingContext=null),(e===null||e.child===null)&&(Ml(t)?fa(t):e===null||e.memoizedState.isDehydrated&&(t.flags&256)===0||(t.flags|=1024,tr())),Ke(t),null;case 26:var n=t.type,s=t.memoizedState;return e===null?(fa(t),s!==null?(Ke(t),xu(t,s)):(Ke(t),Vr(t,n,null,i,l))):s?s!==e.memoizedState?(fa(t),Ke(t),xu(t,s)):(Ke(t),t.flags&=-16777217):(e=e.memoizedProps,e!==i&&fa(t),Ke(t),Vr(t,n,e,i,l)),null;case 27:if(Ze(t),l=pe.current,n=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==i&&fa(t);else{if(!i){if(t.stateNode===null)throw Error(d(166));return Ke(t),null}e=J.current,Ml(t)?Qc(t):(e=jf(n,i,l),t.stateNode=e,fa(t))}return Ke(t),null;case 5:if(Ze(t),n=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==i&&fa(t);else{if(!i){if(t.stateNode===null)throw Error(d(166));return Ke(t),null}if(s=J.current,Ml(t))Qc(t);else{var o=as(pe.current);switch(s){case 1:s=o.createElementNS("http://www.w3.org/2000/svg",n);break;case 2:s=o.createElementNS("http://www.w3.org/1998/Math/MathML",n);break;default:switch(n){case"svg":s=o.createElementNS("http://www.w3.org/2000/svg",n);break;case"math":s=o.createElementNS("http://www.w3.org/1998/Math/MathML",n);break;case"script":s=o.createElement("div"),s.innerHTML="<script><\/script>",s=s.removeChild(s.firstChild);break;case"select":s=typeof i.is=="string"?o.createElement("select",{is:i.is}):o.createElement("select"),i.multiple?s.multiple=!0:i.size&&(s.size=i.size);break;default:s=typeof i.is=="string"?o.createElement(n,{is:i.is}):o.createElement(n)}}s[rt]=t,s[vt]=i;e:for(o=t.child;o!==null;){if(o.tag===5||o.tag===6)s.appendChild(o.stateNode);else if(o.tag!==4&&o.tag!==27&&o.child!==null){o.child.return=o,o=o.child;continue}if(o===t)break e;for(;o.sibling===null;){if(o.return===null||o.return===t)break e;o=o.return}o.sibling.return=o.return,o=o.sibling}t.stateNode=s;e:switch(ut(s,n,i),n){case"button":case"input":case"select":case"textarea":i=!!i.autoFocus;break e;case"img":i=!0;break e;default:i=!1}i&&fa(t)}}return Ke(t),Vr(t,t.type,e===null?null:e.memoizedProps,t.pendingProps,l),null;case 6:if(e&&t.stateNode!=null)e.memoizedProps!==i&&fa(t);else{if(typeof i!="string"&&t.stateNode===null)throw Error(d(166));if(e=pe.current,Ml(t)){if(e=t.stateNode,l=t.memoizedProps,i=null,n=ot,n!==null)switch(n.tag){case 27:case 5:i=n.memoizedProps}e[rt]=t,e=!!(e.nodeValue===l||i!==null&&i.suppressHydrationWarning===!0||uf(e.nodeValue,l)),e||Ta(t,!0)}else e=as(e).createTextNode(i),e[rt]=t,t.stateNode=e}return Ke(t),null;case 31:if(l=t.memoizedState,e===null||e.memoizedState!==null){if(i=Ml(t),l!==null){if(e===null){if(!i)throw Error(d(318));if(e=t.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(d(557));e[rt]=t}else nl(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;Ke(t),e=!1}else l=tr(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=l),e=!0;if(!e)return t.flags&256?(Ot(t),t):(Ot(t),null);if((t.flags&128)!==0)throw Error(d(558))}return Ke(t),null;case 13:if(i=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(n=Ml(t),i!==null&&i.dehydrated!==null){if(e===null){if(!n)throw Error(d(318));if(n=t.memoizedState,n=n!==null?n.dehydrated:null,!n)throw Error(d(317));n[rt]=t}else nl(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;Ke(t),n=!1}else n=tr(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=n),n=!0;if(!n)return t.flags&256?(Ot(t),t):(Ot(t),null)}return Ot(t),(t.flags&128)!==0?(t.lanes=l,t):(l=i!==null,e=e!==null&&e.memoizedState!==null,l&&(i=t.child,n=null,i.alternate!==null&&i.alternate.memoizedState!==null&&i.alternate.memoizedState.cachePool!==null&&(n=i.alternate.memoizedState.cachePool.pool),s=null,i.memoizedState!==null&&i.memoizedState.cachePool!==null&&(s=i.memoizedState.cachePool.pool),s!==n&&(i.flags|=2048)),l!==e&&l&&(t.child.flags|=8192),Gn(t,t.updateQueue),Ke(t),null);case 4:return W(),e===null&&xo(t.stateNode.containerInfo),Ke(t),null;case 10:return oa(t.type),Ke(t),null;case 19:if(D(Je),i=t.memoizedState,i===null)return Ke(t),null;if(n=(t.flags&128)!==0,s=i.rendering,s===null)if(n)Di(i,!1);else{if(Qe!==0||e!==null&&(e.flags&128)!==0)for(e=t.child;e!==null;){if(s=Tn(e),s!==null){for(t.flags|=128,Di(i,!1),e=s.updateQueue,t.updateQueue=e,Gn(t,e),t.subtreeFlags=0,e=l,l=t.child;l!==null;)Ic(l,e),l=l.sibling;return K(Je,Je.current&1|2),Ee&&sa(t,i.treeForkCount),t.child}e=e.sibling}i.tail!==null&&he()>Xn&&(t.flags|=128,n=!0,Di(i,!1),t.lanes=4194304)}else{if(!n)if(e=Tn(s),e!==null){if(t.flags|=128,n=!0,e=e.updateQueue,t.updateQueue=e,Gn(t,e),Di(i,!0),i.tail===null&&i.tailMode==="hidden"&&!s.alternate&&!Ee)return Ke(t),null}else 2*he()-i.renderingStartTime>Xn&&l!==536870912&&(t.flags|=128,n=!0,Di(i,!1),t.lanes=4194304);i.isBackwards?(s.sibling=t.child,t.child=s):(e=i.last,e!==null?e.sibling=s:t.child=s,i.last=s)}return i.tail!==null?(e=i.tail,i.rendering=e,i.tail=e.sibling,i.renderingStartTime=he(),e.sibling=null,l=Je.current,K(Je,n?l&1|2:l&1),Ee&&sa(t,i.treeForkCount),e):(Ke(t),null);case 22:case 23:return Ot(t),xr(),i=t.memoizedState!==null,e!==null?e.memoizedState!==null!==i&&(t.flags|=8192):i&&(t.flags|=8192),i?(l&536870912)!==0&&(t.flags&128)===0&&(Ke(t),t.subtreeFlags&6&&(t.flags|=8192)):Ke(t),l=t.updateQueue,l!==null&&Gn(t,l.retryQueue),l=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(l=e.memoizedState.cachePool.pool),i=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(i=t.memoizedState.cachePool.pool),i!==l&&(t.flags|=2048),e!==null&&D(ol),null;case 24:return l=null,e!==null&&(l=e.memoizedState.cache),t.memoizedState.cache!==l&&(t.flags|=2048),oa($e),Ke(t),null;case 25:return null;case 30:return null}throw Error(d(156,t.tag))}function C0(e,t){switch($s(t),t.tag){case 1:return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return oa($e),W(),e=t.flags,(e&65536)!==0&&(e&128)===0?(t.flags=e&-65537|128,t):null;case 26:case 27:case 5:return Ze(t),null;case 31:if(t.memoizedState!==null){if(Ot(t),t.alternate===null)throw Error(d(340));nl()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 13:if(Ot(t),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(d(340));nl()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return D(Je),null;case 4:return W(),null;case 10:return oa(t.type),null;case 22:case 23:return Ot(t),xr(),e!==null&&D(ol),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 24:return oa($e),null;case 25:return null;default:return null}}function pu(e,t){switch($s(t),t.tag){case 3:oa($e),W();break;case 26:case 27:case 5:Ze(t);break;case 4:W();break;case 31:t.memoizedState!==null&&Ot(t);break;case 13:Ot(t);break;case 19:D(Je);break;case 10:oa(t.type);break;case 22:case 23:Ot(t),xr(),e!==null&&D(ol);break;case 24:oa($e)}}function Mi(e,t){try{var l=t.updateQueue,i=l!==null?l.lastEffect:null;if(i!==null){var n=i.next;l=n;do{if((l.tag&e)===e){i=void 0;var s=l.create,o=l.inst;i=s(),o.destroy=i}l=l.next}while(l!==n)}}catch(c){Le(t,t.return,c)}}function Ra(e,t,l){try{var i=t.updateQueue,n=i!==null?i.lastEffect:null;if(n!==null){var s=n.next;i=s;do{if((i.tag&e)===e){var o=i.inst,c=o.destroy;if(c!==void 0){o.destroy=void 0,n=t;var u=l,z=c;try{z()}catch(C){Le(n,u,C)}}}i=i.next}while(i!==s)}}catch(C){Le(t,t.return,C)}}function hu(e){var t=e.updateQueue;if(t!==null){var l=e.stateNode;try{sd(t,l)}catch(i){Le(e,e.return,i)}}}function gu(e,t,l){l.props=ml(e.type,e.memoizedProps),l.state=e.memoizedState;try{l.componentWillUnmount()}catch(i){Le(e,t,i)}}function Ri(e,t){try{var l=e.ref;if(l!==null){switch(e.tag){case 26:case 27:case 5:var i=e.stateNode;break;case 30:i=e.stateNode;break;default:i=e.stateNode}typeof l=="function"?e.refCleanup=l(i):l.current=i}}catch(n){Le(e,t,n)}}function $t(e,t){var l=e.ref,i=e.refCleanup;if(l!==null)if(typeof i=="function")try{i()}catch(n){Le(e,t,n)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof l=="function")try{l(null)}catch(n){Le(e,t,n)}else l.current=null}function bu(e){var t=e.type,l=e.memoizedProps,i=e.stateNode;try{e:switch(t){case"button":case"input":case"select":case"textarea":l.autoFocus&&i.focus();break e;case"img":l.src?i.src=l.src:l.srcSet&&(i.srcset=l.srcSet)}}catch(n){Le(e,e.return,n)}}function Xr(e,t,l){try{var i=e.stateNode;ep(i,e.type,l,t),i[vt]=t}catch(n){Le(e,e.return,n)}}function yu(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&Ia(e.type)||e.tag===4}function Qr(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||yu(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&Ia(e.type)||e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function Zr(e,t,l){var i=e.tag;if(i===5||i===6)e=e.stateNode,t?(l.nodeType===9?l.body:l.nodeName==="HTML"?l.ownerDocument.body:l).insertBefore(e,t):(t=l.nodeType===9?l.body:l.nodeName==="HTML"?l.ownerDocument.body:l,t.appendChild(e),l=l._reactRootContainer,l!=null||t.onclick!==null||(t.onclick=la));else if(i!==4&&(i===27&&Ia(e.type)&&(l=e.stateNode,t=null),e=e.child,e!==null))for(Zr(e,t,l),e=e.sibling;e!==null;)Zr(e,t,l),e=e.sibling}function In(e,t,l){var i=e.tag;if(i===5||i===6)e=e.stateNode,t?l.insertBefore(e,t):l.appendChild(e);else if(i!==4&&(i===27&&Ia(e.type)&&(l=e.stateNode),e=e.child,e!==null))for(In(e,t,l),e=e.sibling;e!==null;)In(e,t,l),e=e.sibling}function vu(e){var t=e.stateNode,l=e.memoizedProps;try{for(var i=e.type,n=t.attributes;n.length;)t.removeAttributeNode(n[0]);ut(t,i,l),t[rt]=e,t[vt]=l}catch(s){Le(e,e.return,s)}}var ma=!1,at=!1,Jr=!1,ku=typeof WeakSet=="function"?WeakSet:Set,nt=null;function D0(e,t){if(e=e.containerInfo,go=cs,e=Dc(e),Is(e)){if("selectionStart"in e)var l={start:e.selectionStart,end:e.selectionEnd};else e:{l=(l=e.ownerDocument)&&l.defaultView||window;var i=l.getSelection&&l.getSelection();if(i&&i.rangeCount!==0){l=i.anchorNode;var n=i.anchorOffset,s=i.focusNode;i=i.focusOffset;try{l.nodeType,s.nodeType}catch{l=null;break e}var o=0,c=-1,u=-1,z=0,C=0,R=e,w=null;t:for(;;){for(var A;R!==l||n!==0&&R.nodeType!==3||(c=o+n),R!==s||i!==0&&R.nodeType!==3||(u=o+i),R.nodeType===3&&(o+=R.nodeValue.length),(A=R.firstChild)!==null;)w=R,R=A;for(;;){if(R===e)break t;if(w===l&&++z===n&&(c=o),w===s&&++C===i&&(u=o),(A=R.nextSibling)!==null)break;R=w,w=R.parentNode}R=A}l=c===-1||u===-1?null:{start:c,end:u}}else l=null}l=l||{start:0,end:0}}else l=null;for(bo={focusedElem:e,selectionRange:l},cs=!1,nt=t;nt!==null;)if(t=nt,e=t.child,(t.subtreeFlags&1028)!==0&&e!==null)e.return=t,nt=e;else for(;nt!==null;){switch(t=nt,s=t.alternate,e=t.flags,t.tag){case 0:if((e&4)!==0&&(e=t.updateQueue,e=e!==null?e.events:null,e!==null))for(l=0;l<e.length;l++)n=e[l],n.ref.impl=n.nextImpl;break;case 11:case 15:break;case 1:if((e&1024)!==0&&s!==null){e=void 0,l=t,n=s.memoizedProps,s=s.memoizedState,i=l.stateNode;try{var P=ml(l.type,n);e=i.getSnapshotBeforeUpdate(P,s),i.__reactInternalSnapshotBeforeUpdate=e}catch(de){Le(l,l.return,de)}}break;case 3:if((e&1024)!==0){if(e=t.stateNode.containerInfo,l=e.nodeType,l===9)ko(e);else if(l===1)switch(e.nodeName){case"HEAD":case"HTML":case"BODY":ko(e);break;default:e.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((e&1024)!==0)throw Error(d(163))}if(e=t.sibling,e!==null){e.return=t.return,nt=e;break}nt=t.return}}function ju(e,t,l){var i=l.flags;switch(l.tag){case 0:case 11:case 15:pa(e,l),i&4&&Mi(5,l);break;case 1:if(pa(e,l),i&4)if(e=l.stateNode,t===null)try{e.componentDidMount()}catch(o){Le(l,l.return,o)}else{var n=ml(l.type,t.memoizedProps);t=t.memoizedState;try{e.componentDidUpdate(n,t,e.__reactInternalSnapshotBeforeUpdate)}catch(o){Le(l,l.return,o)}}i&64&&hu(l),i&512&&Ri(l,l.return);break;case 3:if(pa(e,l),i&64&&(e=l.updateQueue,e!==null)){if(t=null,l.child!==null)switch(l.child.tag){case 27:case 5:t=l.child.stateNode;break;case 1:t=l.child.stateNode}try{sd(e,t)}catch(o){Le(l,l.return,o)}}break;case 27:t===null&&i&4&&vu(l);case 26:case 5:pa(e,l),t===null&&i&4&&bu(l),i&512&&Ri(l,l.return);break;case 12:pa(e,l);break;case 31:pa(e,l),i&4&&wu(e,l);break;case 13:pa(e,l),i&4&&Su(e,l),i&64&&(e=l.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(l=I0.bind(null,l),op(e,l))));break;case 22:if(i=l.memoizedState!==null||ma,!i){t=t!==null&&t.memoizedState!==null||at,n=ma;var s=at;ma=i,(at=t)&&!s?ha(e,l,(l.subtreeFlags&8772)!==0):pa(e,l),ma=n,at=s}break;case 30:break;default:pa(e,l)}}function Nu(e){var t=e.alternate;t!==null&&(e.alternate=null,Nu(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&ws(t)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var qe=null,jt=!1;function xa(e,t,l){for(l=l.child;l!==null;)zu(e,t,l),l=l.sibling}function zu(e,t,l){if(ht&&typeof ht.onCommitFiberUnmount=="function")try{ht.onCommitFiberUnmount(Ja,l)}catch{}switch(l.tag){case 26:at||$t(l,t),xa(e,t,l),l.memoizedState?l.memoizedState.count--:l.stateNode&&(l=l.stateNode,l.parentNode.removeChild(l));break;case 27:at||$t(l,t);var i=qe,n=jt;Ia(l.type)&&(qe=l.stateNode,jt=!1),xa(e,t,l),qi(l.stateNode),qe=i,jt=n;break;case 5:at||$t(l,t);case 6:if(i=qe,n=jt,qe=null,xa(e,t,l),qe=i,jt=n,qe!==null)if(jt)try{(qe.nodeType===9?qe.body:qe.nodeName==="HTML"?qe.ownerDocument.body:qe).removeChild(l.stateNode)}catch(s){Le(l,t,s)}else try{qe.removeChild(l.stateNode)}catch(s){Le(l,t,s)}break;case 18:qe!==null&&(jt?(e=qe,gf(e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,l.stateNode),ti(e)):gf(qe,l.stateNode));break;case 4:i=qe,n=jt,qe=l.stateNode.containerInfo,jt=!0,xa(e,t,l),qe=i,jt=n;break;case 0:case 11:case 14:case 15:Ra(2,l,t),at||Ra(4,l,t),xa(e,t,l);break;case 1:at||($t(l,t),i=l.stateNode,typeof i.componentWillUnmount=="function"&&gu(l,t,i)),xa(e,t,l);break;case 21:xa(e,t,l);break;case 22:at=(i=at)||l.memoizedState!==null,xa(e,t,l),at=i;break;default:xa(e,t,l)}}function wu(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{ti(e)}catch(l){Le(t,t.return,l)}}}function Su(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{ti(e)}catch(l){Le(t,t.return,l)}}function M0(e){switch(e.tag){case 31:case 13:case 19:var t=e.stateNode;return t===null&&(t=e.stateNode=new ku),t;case 22:return e=e.stateNode,t=e._retryCache,t===null&&(t=e._retryCache=new ku),t;default:throw Error(d(435,e.tag))}}function Kn(e,t){var l=M0(e);t.forEach(function(i){if(!l.has(i)){l.add(i);var n=K0.bind(null,e,i);i.then(n,n)}})}function Nt(e,t){var l=t.deletions;if(l!==null)for(var i=0;i<l.length;i++){var n=l[i],s=e,o=t,c=o;e:for(;c!==null;){switch(c.tag){case 27:if(Ia(c.type)){qe=c.stateNode,jt=!1;break e}break;case 5:qe=c.stateNode,jt=!1;break e;case 3:case 4:qe=c.stateNode.containerInfo,jt=!0;break e}c=c.return}if(qe===null)throw Error(d(160));zu(s,o,n),qe=null,jt=!1,s=n.alternate,s!==null&&(s.return=null),n.return=null}if(t.subtreeFlags&13886)for(t=t.child;t!==null;)Eu(t,e),t=t.sibling}var Zt=null;function Eu(e,t){var l=e.alternate,i=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:Nt(t,e),zt(e),i&4&&(Ra(3,e,e.return),Mi(3,e),Ra(5,e,e.return));break;case 1:Nt(t,e),zt(e),i&512&&(at||l===null||$t(l,l.return)),i&64&&ma&&(e=e.updateQueue,e!==null&&(i=e.callbacks,i!==null&&(l=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=l===null?i:l.concat(i))));break;case 26:var n=Zt;if(Nt(t,e),zt(e),i&512&&(at||l===null||$t(l,l.return)),i&4){var s=l!==null?l.memoizedState:null;if(i=e.memoizedState,l===null)if(i===null)if(e.stateNode===null){e:{i=e.type,l=e.memoizedProps,n=n.ownerDocument||n;t:switch(i){case"title":s=n.getElementsByTagName("title")[0],(!s||s[oi]||s[rt]||s.namespaceURI==="http://www.w3.org/2000/svg"||s.hasAttribute("itemprop"))&&(s=n.createElement(i),n.head.insertBefore(s,n.querySelector("head > title"))),ut(s,i,l),s[rt]=e,it(s),i=s;break e;case"link":var o=Tf("link","href",n).get(i+(l.href||""));if(o){for(var c=0;c<o.length;c++)if(s=o[c],s.getAttribute("href")===(l.href==null||l.href===""?null:l.href)&&s.getAttribute("rel")===(l.rel==null?null:l.rel)&&s.getAttribute("title")===(l.title==null?null:l.title)&&s.getAttribute("crossorigin")===(l.crossOrigin==null?null:l.crossOrigin)){o.splice(c,1);break t}}s=n.createElement(i),ut(s,i,l),n.head.appendChild(s);break;case"meta":if(o=Tf("meta","content",n).get(i+(l.content||""))){for(c=0;c<o.length;c++)if(s=o[c],s.getAttribute("content")===(l.content==null?null:""+l.content)&&s.getAttribute("name")===(l.name==null?null:l.name)&&s.getAttribute("property")===(l.property==null?null:l.property)&&s.getAttribute("http-equiv")===(l.httpEquiv==null?null:l.httpEquiv)&&s.getAttribute("charset")===(l.charSet==null?null:l.charSet)){o.splice(c,1);break t}}s=n.createElement(i),ut(s,i,l),n.head.appendChild(s);break;default:throw Error(d(468,i))}s[rt]=e,it(s),i=s}e.stateNode=i}else _f(n,e.type,e.stateNode);else e.stateNode=Ef(n,i,e.memoizedProps);else s!==i?(s===null?l.stateNode!==null&&(l=l.stateNode,l.parentNode.removeChild(l)):s.count--,i===null?_f(n,e.type,e.stateNode):Ef(n,i,e.memoizedProps)):i===null&&e.stateNode!==null&&Xr(e,e.memoizedProps,l.memoizedProps)}break;case 27:Nt(t,e),zt(e),i&512&&(at||l===null||$t(l,l.return)),l!==null&&i&4&&Xr(e,e.memoizedProps,l.memoizedProps);break;case 5:if(Nt(t,e),zt(e),i&512&&(at||l===null||$t(l,l.return)),e.flags&32){n=e.stateNode;try{zl(n,"")}catch(P){Le(e,e.return,P)}}i&4&&e.stateNode!=null&&(n=e.memoizedProps,Xr(e,n,l!==null?l.memoizedProps:n)),i&1024&&(Jr=!0);break;case 6:if(Nt(t,e),zt(e),i&4){if(e.stateNode===null)throw Error(d(162));i=e.memoizedProps,l=e.stateNode;try{l.nodeValue=i}catch(P){Le(e,e.return,P)}}break;case 3:if(ns=null,n=Zt,Zt=ls(t.containerInfo),Nt(t,e),Zt=n,zt(e),i&4&&l!==null&&l.memoizedState.isDehydrated)try{ti(t.containerInfo)}catch(P){Le(e,e.return,P)}Jr&&(Jr=!1,Tu(e));break;case 4:i=Zt,Zt=ls(e.stateNode.containerInfo),Nt(t,e),zt(e),Zt=i;break;case 12:Nt(t,e),zt(e);break;case 31:Nt(t,e),zt(e),i&4&&(i=e.updateQueue,i!==null&&(e.updateQueue=null,Kn(e,i)));break;case 13:Nt(t,e),zt(e),e.child.flags&8192&&e.memoizedState!==null!=(l!==null&&l.memoizedState!==null)&&(Vn=he()),i&4&&(i=e.updateQueue,i!==null&&(e.updateQueue=null,Kn(e,i)));break;case 22:n=e.memoizedState!==null;var u=l!==null&&l.memoizedState!==null,z=ma,C=at;if(ma=z||n,at=C||u,Nt(t,e),at=C,ma=z,zt(e),i&8192)e:for(t=e.stateNode,t._visibility=n?t._visibility&-2:t._visibility|1,n&&(l===null||u||ma||at||xl(e)),l=null,t=e;;){if(t.tag===5||t.tag===26){if(l===null){u=l=t;try{if(s=u.stateNode,n)o=s.style,typeof o.setProperty=="function"?o.setProperty("display","none","important"):o.display="none";else{c=u.stateNode;var R=u.memoizedProps.style,w=R!=null&&R.hasOwnProperty("display")?R.display:null;c.style.display=w==null||typeof w=="boolean"?"":(""+w).trim()}}catch(P){Le(u,u.return,P)}}}else if(t.tag===6){if(l===null){u=t;try{u.stateNode.nodeValue=n?"":u.memoizedProps}catch(P){Le(u,u.return,P)}}}else if(t.tag===18){if(l===null){u=t;try{var A=u.stateNode;n?bf(A,!0):bf(u.stateNode,!1)}catch(P){Le(u,u.return,P)}}}else if((t.tag!==22&&t.tag!==23||t.memoizedState===null||t===e)&&t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break e;for(;t.sibling===null;){if(t.return===null||t.return===e)break e;l===t&&(l=null),t=t.return}l===t&&(l=null),t.sibling.return=t.return,t=t.sibling}i&4&&(i=e.updateQueue,i!==null&&(l=i.retryQueue,l!==null&&(i.retryQueue=null,Kn(e,l))));break;case 19:Nt(t,e),zt(e),i&4&&(i=e.updateQueue,i!==null&&(e.updateQueue=null,Kn(e,i)));break;case 30:break;case 21:break;default:Nt(t,e),zt(e)}}function zt(e){var t=e.flags;if(t&2){try{for(var l,i=e.return;i!==null;){if(yu(i)){l=i;break}i=i.return}if(l==null)throw Error(d(160));switch(l.tag){case 27:var n=l.stateNode,s=Qr(e);In(e,s,n);break;case 5:var o=l.stateNode;l.flags&32&&(zl(o,""),l.flags&=-33);var c=Qr(e);In(e,c,o);break;case 3:case 4:var u=l.stateNode.containerInfo,z=Qr(e);Zr(e,z,u);break;default:throw Error(d(161))}}catch(C){Le(e,e.return,C)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function Tu(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var t=e;Tu(t),t.tag===5&&t.flags&1024&&t.stateNode.reset(),e=e.sibling}}function pa(e,t){if(t.subtreeFlags&8772)for(t=t.child;t!==null;)ju(e,t.alternate,t),t=t.sibling}function xl(e){for(e=e.child;e!==null;){var t=e;switch(t.tag){case 0:case 11:case 14:case 15:Ra(4,t,t.return),xl(t);break;case 1:$t(t,t.return);var l=t.stateNode;typeof l.componentWillUnmount=="function"&&gu(t,t.return,l),xl(t);break;case 27:qi(t.stateNode);case 26:case 5:$t(t,t.return),xl(t);break;case 22:t.memoizedState===null&&xl(t);break;case 30:xl(t);break;default:xl(t)}e=e.sibling}}function ha(e,t,l){for(l=l&&(t.subtreeFlags&8772)!==0,t=t.child;t!==null;){var i=t.alternate,n=e,s=t,o=s.flags;switch(s.tag){case 0:case 11:case 15:ha(n,s,l),Mi(4,s);break;case 1:if(ha(n,s,l),i=s,n=i.stateNode,typeof n.componentDidMount=="function")try{n.componentDidMount()}catch(z){Le(i,i.return,z)}if(i=s,n=i.updateQueue,n!==null){var c=i.stateNode;try{var u=n.shared.hiddenCallbacks;if(u!==null)for(n.shared.hiddenCallbacks=null,n=0;n<u.length;n++)nd(u[n],c)}catch(z){Le(i,i.return,z)}}l&&o&64&&hu(s),Ri(s,s.return);break;case 27:vu(s);case 26:case 5:ha(n,s,l),l&&i===null&&o&4&&bu(s),Ri(s,s.return);break;case 12:ha(n,s,l);break;case 31:ha(n,s,l),l&&o&4&&wu(n,s);break;case 13:ha(n,s,l),l&&o&4&&Su(n,s);break;case 22:s.memoizedState===null&&ha(n,s,l),Ri(s,s.return);break;case 30:break;default:ha(n,s,l)}t=t.sibling}}function Fr(e,t){var l=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(l=e.memoizedState.cachePool.pool),e=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(e=t.memoizedState.cachePool.pool),e!==l&&(e!=null&&e.refCount++,l!=null&&ki(l))}function Pr(e,t){e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&ki(e))}function Jt(e,t,l,i){if(t.subtreeFlags&10256)for(t=t.child;t!==null;)_u(e,t,l,i),t=t.sibling}function _u(e,t,l,i){var n=t.flags;switch(t.tag){case 0:case 11:case 15:Jt(e,t,l,i),n&2048&&Mi(9,t);break;case 1:Jt(e,t,l,i);break;case 3:Jt(e,t,l,i),n&2048&&(e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&ki(e)));break;case 12:if(n&2048){Jt(e,t,l,i),e=t.stateNode;try{var s=t.memoizedProps,o=s.id,c=s.onPostCommit;typeof c=="function"&&c(o,t.alternate===null?"mount":"update",e.passiveEffectDuration,-0)}catch(u){Le(t,t.return,u)}}else Jt(e,t,l,i);break;case 31:Jt(e,t,l,i);break;case 13:Jt(e,t,l,i);break;case 23:break;case 22:s=t.stateNode,o=t.alternate,t.memoizedState!==null?s._visibility&2?Jt(e,t,l,i):Ui(e,t):s._visibility&2?Jt(e,t,l,i):(s._visibility|=2,ql(e,t,l,i,(t.subtreeFlags&10256)!==0||!1)),n&2048&&Fr(o,t);break;case 24:Jt(e,t,l,i),n&2048&&Pr(t.alternate,t);break;default:Jt(e,t,l,i)}}function ql(e,t,l,i,n){for(n=n&&((t.subtreeFlags&10256)!==0||!1),t=t.child;t!==null;){var s=e,o=t,c=l,u=i,z=o.flags;switch(o.tag){case 0:case 11:case 15:ql(s,o,c,u,n),Mi(8,o);break;case 23:break;case 22:var C=o.stateNode;o.memoizedState!==null?C._visibility&2?ql(s,o,c,u,n):Ui(s,o):(C._visibility|=2,ql(s,o,c,u,n)),n&&z&2048&&Fr(o.alternate,o);break;case 24:ql(s,o,c,u,n),n&&z&2048&&Pr(o.alternate,o);break;default:ql(s,o,c,u,n)}t=t.sibling}}function Ui(e,t){if(t.subtreeFlags&10256)for(t=t.child;t!==null;){var l=e,i=t,n=i.flags;switch(i.tag){case 22:Ui(l,i),n&2048&&Fr(i.alternate,i);break;case 24:Ui(l,i),n&2048&&Pr(i.alternate,i);break;default:Ui(l,i)}t=t.sibling}}var Li=8192;function Vl(e,t,l){if(e.subtreeFlags&Li)for(e=e.child;e!==null;)Au(e,t,l),e=e.sibling}function Au(e,t,l){switch(e.tag){case 26:Vl(e,t,l),e.flags&Li&&e.memoizedState!==null&&vp(l,Zt,e.memoizedState,e.memoizedProps);break;case 5:Vl(e,t,l);break;case 3:case 4:var i=Zt;Zt=ls(e.stateNode.containerInfo),Vl(e,t,l),Zt=i;break;case 22:e.memoizedState===null&&(i=e.alternate,i!==null&&i.memoizedState!==null?(i=Li,Li=16777216,Vl(e,t,l),Li=i):Vl(e,t,l));break;default:Vl(e,t,l)}}function Ou(e){var t=e.alternate;if(t!==null&&(e=t.child,e!==null)){t.child=null;do t=e.sibling,e.sibling=null,e=t;while(e!==null)}}function Bi(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var l=0;l<t.length;l++){var i=t[l];nt=i,Du(i,e)}Ou(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)Cu(e),e=e.sibling}function Cu(e){switch(e.tag){case 0:case 11:case 15:Bi(e),e.flags&2048&&Ra(9,e,e.return);break;case 3:Bi(e);break;case 12:Bi(e);break;case 22:var t=e.stateNode;e.memoizedState!==null&&t._visibility&2&&(e.return===null||e.return.tag!==13)?(t._visibility&=-3,qn(e)):Bi(e);break;default:Bi(e)}}function qn(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var l=0;l<t.length;l++){var i=t[l];nt=i,Du(i,e)}Ou(e)}for(e=e.child;e!==null;){switch(t=e,t.tag){case 0:case 11:case 15:Ra(8,t,t.return),qn(t);break;case 22:l=t.stateNode,l._visibility&2&&(l._visibility&=-3,qn(t));break;default:qn(t)}e=e.sibling}}function Du(e,t){for(;nt!==null;){var l=nt;switch(l.tag){case 0:case 11:case 15:Ra(8,l,t);break;case 23:case 22:if(l.memoizedState!==null&&l.memoizedState.cachePool!==null){var i=l.memoizedState.cachePool.pool;i!=null&&i.refCount++}break;case 24:ki(l.memoizedState.cache)}if(i=l.child,i!==null)i.return=l,nt=i;else e:for(l=e;nt!==null;){i=nt;var n=i.sibling,s=i.return;if(Nu(i),i===l){nt=null;break e}if(n!==null){n.return=s,nt=n;break e}nt=s}}}var R0={getCacheForType:function(e){var t=ct($e),l=t.data.get(e);return l===void 0&&(l=e(),t.data.set(e,l)),l},cacheSignal:function(){return ct($e).controller.signal}},U0=typeof WeakMap=="function"?WeakMap:Map,Me=0,Ge=null,je=null,ze=0,Ue=0,Ct=null,Ua=!1,Xl=!1,Wr=!1,ga=0,Qe=0,La=0,pl=0,$r=0,Dt=0,Ql=0,Hi=null,wt=null,eo=!1,Vn=0,Mu=0,Xn=1/0,Qn=null,Ba=null,lt=0,Ha=null,Zl=null,ba=0,to=0,ao=null,Ru=null,Yi=0,lo=null;function Mt(){return(Me&2)!==0&&ze!==0?ze&-ze:T.T!==null?co():Po()}function Uu(){if(Dt===0)if((ze&536870912)===0||Ee){var e=Pa;Pa<<=1,(Pa&3932160)===0&&(Pa=262144),Dt=e}else Dt=536870912;return e=At.current,e!==null&&(e.flags|=32),Dt}function St(e,t,l){(e===Ge&&(Ue===2||Ue===9)||e.cancelPendingCommit!==null)&&(Jl(e,0),Ya(e,ze,Dt,!1)),Wa(e,l),((Me&2)===0||e!==Ge)&&(e===Ge&&((Me&2)===0&&(pl|=l),Qe===4&&Ya(e,ze,Dt,!1)),ea(e))}function Lu(e,t,l){if((Me&6)!==0)throw Error(d(327));var i=!l&&(t&127)===0&&(t&e.expiredLanes)===0||Ae(e,t),n=i?H0(e,t):no(e,t,!0),s=i;do{if(n===0){Xl&&!i&&Ya(e,t,0,!1);break}else{if(l=e.current.alternate,s&&!L0(l)){n=no(e,t,!1),s=!1;continue}if(n===2){if(s=t,e.errorRecoveryDisabledLanes&s)var o=0;else o=e.pendingLanes&-536870913,o=o!==0?o:o&536870912?536870912:0;if(o!==0){t=o;e:{var c=e;n=Hi;var u=c.current.memoizedState.isDehydrated;if(u&&(Jl(c,o).flags|=256),o=no(c,o,!1),o!==2){if(Wr&&!u){c.errorRecoveryDisabledLanes|=s,pl|=s,n=4;break e}s=wt,wt=n,s!==null&&(wt===null?wt=s:wt.push.apply(wt,s))}n=o}if(s=!1,n!==2)continue}}if(n===1){Jl(e,0),Ya(e,t,0,!0);break}e:{switch(i=e,s=n,s){case 0:case 1:throw Error(d(345));case 4:if((t&4194048)!==t)break;case 6:Ya(i,t,Dt,!Ua);break e;case 2:wt=null;break;case 3:case 5:break;default:throw Error(d(329))}if((t&62914560)===t&&(n=Vn+300-he(),10<n)){if(Ya(i,t,Dt,!Ua),ge(i,0,!0)!==0)break e;ba=t,i.timeoutHandle=pf(Bu.bind(null,i,l,wt,Qn,eo,t,Dt,pl,Ql,Ua,s,"Throttled",-0,0),n);break e}Bu(i,l,wt,Qn,eo,t,Dt,pl,Ql,Ua,s,null,-0,0)}}break}while(!0);ea(e)}function Bu(e,t,l,i,n,s,o,c,u,z,C,R,w,A){if(e.timeoutHandle=-1,R=t.subtreeFlags,R&8192||(R&16785408)===16785408){R={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:la},Au(t,s,R);var P=(s&62914560)===s?Vn-he():(s&4194048)===s?Mu-he():0;if(P=kp(R,P),P!==null){ba=s,e.cancelPendingCommit=P(Xu.bind(null,e,t,s,l,i,n,o,c,u,C,R,null,w,A)),Ya(e,s,o,!z);return}}Xu(e,t,s,l,i,n,o,c,u)}function L0(e){for(var t=e;;){var l=t.tag;if((l===0||l===11||l===15)&&t.flags&16384&&(l=t.updateQueue,l!==null&&(l=l.stores,l!==null)))for(var i=0;i<l.length;i++){var n=l[i],s=n.getSnapshot;n=n.value;try{if(!Tt(s(),n))return!1}catch{return!1}}if(l=t.child,t.subtreeFlags&16384&&l!==null)l.return=t,t=l;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function Ya(e,t,l,i){t&=~$r,t&=~pl,e.suspendedLanes|=t,e.pingedLanes&=~t,i&&(e.warmLanes|=t),i=e.expirationTimes;for(var n=t;0<n;){var s=31-mt(n),o=1<<s;i[s]=-1,n&=~o}l!==0&&Zo(e,l,t)}function Zn(){return(Me&6)===0?(Gi(0),!1):!0}function io(){if(je!==null){if(Ue===0)var e=je.return;else e=je,ra=sl=null,vr(e),Hl=null,Ni=0,e=je;for(;e!==null;)pu(e.alternate,e),e=e.return;je=null}}function Jl(e,t){var l=e.timeoutHandle;l!==-1&&(e.timeoutHandle=-1,lp(l)),l=e.cancelPendingCommit,l!==null&&(e.cancelPendingCommit=null,l()),ba=0,io(),Ge=e,je=l=na(e.current,null),ze=t,Ue=0,Ct=null,Ua=!1,Xl=Ae(e,t),Wr=!1,Ql=Dt=$r=pl=La=Qe=0,wt=Hi=null,eo=!1,(t&8)!==0&&(t|=t&32);var i=e.entangledLanes;if(i!==0)for(e=e.entanglements,i&=t;0<i;){var n=31-mt(i),s=1<<n;t|=e[n],i&=~s}return ga=t,pn(),l}function Hu(e,t){ye=null,T.H=Oi,t===Bl||t===Nn?(t=td(),Ue=3):t===or?(t=td(),Ue=4):Ue=t===Ur?8:t!==null&&typeof t=="object"&&typeof t.then=="function"?6:1,Ct=t,je===null&&(Qe=1,Ln(e,Ht(t,e.current)))}function Yu(){var e=At.current;return e===null?!0:(ze&4194048)===ze?Kt===null:(ze&62914560)===ze||(ze&536870912)!==0?e===Kt:!1}function Gu(){var e=T.H;return T.H=Oi,e===null?Oi:e}function Iu(){var e=T.A;return T.A=R0,e}function Jn(){Qe=4,Ua||(ze&4194048)!==ze&&At.current!==null||(Xl=!0),(La&134217727)===0&&(pl&134217727)===0||Ge===null||Ya(Ge,ze,Dt,!1)}function no(e,t,l){var i=Me;Me|=2;var n=Gu(),s=Iu();(Ge!==e||ze!==t)&&(Qn=null,Jl(e,t)),t=!1;var o=Qe;e:do try{if(Ue!==0&&je!==null){var c=je,u=Ct;switch(Ue){case 8:io(),o=6;break e;case 3:case 2:case 9:case 6:At.current===null&&(t=!0);var z=Ue;if(Ue=0,Ct=null,Fl(e,c,u,z),l&&Xl){o=0;break e}break;default:z=Ue,Ue=0,Ct=null,Fl(e,c,u,z)}}B0(),o=Qe;break}catch(C){Hu(e,C)}while(!0);return t&&e.shellSuspendCounter++,ra=sl=null,Me=i,T.H=n,T.A=s,je===null&&(Ge=null,ze=0,pn()),o}function B0(){for(;je!==null;)Ku(je)}function H0(e,t){var l=Me;Me|=2;var i=Gu(),n=Iu();Ge!==e||ze!==t?(Qn=null,Xn=he()+500,Jl(e,t)):Xl=Ae(e,t);e:do try{if(Ue!==0&&je!==null){t=je;var s=Ct;t:switch(Ue){case 1:Ue=0,Ct=null,Fl(e,t,s,1);break;case 2:case 9:if($c(s)){Ue=0,Ct=null,qu(t);break}t=function(){Ue!==2&&Ue!==9||Ge!==e||(Ue=7),ea(e)},s.then(t,t);break e;case 3:Ue=7;break e;case 4:Ue=5;break e;case 7:$c(s)?(Ue=0,Ct=null,qu(t)):(Ue=0,Ct=null,Fl(e,t,s,7));break;case 5:var o=null;switch(je.tag){case 26:o=je.memoizedState;case 5:case 27:var c=je;if(o?Af(o):c.stateNode.complete){Ue=0,Ct=null;var u=c.sibling;if(u!==null)je=u;else{var z=c.return;z!==null?(je=z,Fn(z)):je=null}break t}}Ue=0,Ct=null,Fl(e,t,s,5);break;case 6:Ue=0,Ct=null,Fl(e,t,s,6);break;case 8:io(),Qe=6;break e;default:throw Error(d(462))}}Y0();break}catch(C){Hu(e,C)}while(!0);return ra=sl=null,T.H=i,T.A=n,Me=l,je!==null?0:(Ge=null,ze=0,pn(),Qe)}function Y0(){for(;je!==null&&!F();)Ku(je)}function Ku(e){var t=mu(e.alternate,e,ga);e.memoizedProps=e.pendingProps,t===null?Fn(e):je=t}function qu(e){var t=e,l=t.alternate;switch(t.tag){case 15:case 0:t=ru(l,t,t.pendingProps,t.type,void 0,ze);break;case 11:t=ru(l,t,t.pendingProps,t.type.render,t.ref,ze);break;case 5:vr(t);default:pu(l,t),t=je=Ic(t,ga),t=mu(l,t,ga)}e.memoizedProps=e.pendingProps,t===null?Fn(e):je=t}function Fl(e,t,l,i){ra=sl=null,vr(t),Hl=null,Ni=0;var n=t.return;try{if(T0(e,n,t,l,ze)){Qe=1,Ln(e,Ht(l,e.current)),je=null;return}}catch(s){if(n!==null)throw je=n,s;Qe=1,Ln(e,Ht(l,e.current)),je=null;return}t.flags&32768?(Ee||i===1?e=!0:Xl||(ze&536870912)!==0?e=!1:(Ua=e=!0,(i===2||i===9||i===3||i===6)&&(i=At.current,i!==null&&i.tag===13&&(i.flags|=16384))),Vu(t,e)):Fn(t)}function Fn(e){var t=e;do{if((t.flags&32768)!==0){Vu(t,Ua);return}e=t.return;var l=O0(t.alternate,t,ga);if(l!==null){je=l;return}if(t=t.sibling,t!==null){je=t;return}je=t=e}while(t!==null);Qe===0&&(Qe=5)}function Vu(e,t){do{var l=C0(e.alternate,e);if(l!==null){l.flags&=32767,je=l;return}if(l=e.return,l!==null&&(l.flags|=32768,l.subtreeFlags=0,l.deletions=null),!t&&(e=e.sibling,e!==null)){je=e;return}je=e=l}while(e!==null);Qe=6,je=null}function Xu(e,t,l,i,n,s,o,c,u){e.cancelPendingCommit=null;do Pn();while(lt!==0);if((Me&6)!==0)throw Error(d(327));if(t!==null){if(t===e.current)throw Error(d(177));if(s=t.lanes|t.childLanes,s|=Qs,yx(e,l,s,o,c,u),e===Ge&&(je=Ge=null,ze=0),Zl=t,Ha=e,ba=l,to=s,ao=n,Ru=i,(t.subtreeFlags&10256)!==0||(t.flags&10256)!==0?(e.callbackNode=null,e.callbackPriority=0,q0(Et,function(){return Pu(),null})):(e.callbackNode=null,e.callbackPriority=0),i=(t.flags&13878)!==0,(t.subtreeFlags&13878)!==0||i){i=T.T,T.T=null,n=f.p,f.p=2,o=Me,Me|=4;try{D0(e,t,l)}finally{Me=o,f.p=n,T.T=i}}lt=1,Qu(),Zu(),Ju()}}function Qu(){if(lt===1){lt=0;var e=Ha,t=Zl,l=(t.flags&13878)!==0;if((t.subtreeFlags&13878)!==0||l){l=T.T,T.T=null;var i=f.p;f.p=2;var n=Me;Me|=4;try{Eu(t,e);var s=bo,o=Dc(e.containerInfo),c=s.focusedElem,u=s.selectionRange;if(o!==c&&c&&c.ownerDocument&&Cc(c.ownerDocument.documentElement,c)){if(u!==null&&Is(c)){var z=u.start,C=u.end;if(C===void 0&&(C=z),"selectionStart"in c)c.selectionStart=z,c.selectionEnd=Math.min(C,c.value.length);else{var R=c.ownerDocument||document,w=R&&R.defaultView||window;if(w.getSelection){var A=w.getSelection(),P=c.textContent.length,de=Math.min(u.start,P),Ye=u.end===void 0?de:Math.min(u.end,P);!A.extend&&de>Ye&&(o=Ye,Ye=de,de=o);var y=Oc(c,de),x=Oc(c,Ye);if(y&&x&&(A.rangeCount!==1||A.anchorNode!==y.node||A.anchorOffset!==y.offset||A.focusNode!==x.node||A.focusOffset!==x.offset)){var j=R.createRange();j.setStart(y.node,y.offset),A.removeAllRanges(),de>Ye?(A.addRange(j),A.extend(x.node,x.offset)):(j.setEnd(x.node,x.offset),A.addRange(j))}}}}for(R=[],A=c;A=A.parentNode;)A.nodeType===1&&R.push({element:A,left:A.scrollLeft,top:A.scrollTop});for(typeof c.focus=="function"&&c.focus(),c=0;c<R.length;c++){var M=R[c];M.element.scrollLeft=M.left,M.element.scrollTop=M.top}}cs=!!go,bo=go=null}finally{Me=n,f.p=i,T.T=l}}e.current=t,lt=2}}function Zu(){if(lt===2){lt=0;var e=Ha,t=Zl,l=(t.flags&8772)!==0;if((t.subtreeFlags&8772)!==0||l){l=T.T,T.T=null;var i=f.p;f.p=2;var n=Me;Me|=4;try{ju(e,t.alternate,t)}finally{Me=n,f.p=i,T.T=l}}lt=3}}function Ju(){if(lt===4||lt===3){lt=0,le();var e=Ha,t=Zl,l=ba,i=Ru;(t.subtreeFlags&10256)!==0||(t.flags&10256)!==0?lt=5:(lt=0,Zl=Ha=null,Fu(e,e.pendingLanes));var n=e.pendingLanes;if(n===0&&(Ba=null),Ns(l),t=t.stateNode,ht&&typeof ht.onCommitFiberRoot=="function")try{ht.onCommitFiberRoot(Ja,t,void 0,(t.current.flags&128)===128)}catch{}if(i!==null){t=T.T,n=f.p,f.p=2,T.T=null;try{for(var s=e.onRecoverableError,o=0;o<i.length;o++){var c=i[o];s(c.value,{componentStack:c.stack})}}finally{T.T=t,f.p=n}}(ba&3)!==0&&Pn(),ea(e),n=e.pendingLanes,(l&261930)!==0&&(n&42)!==0?e===lo?Yi++:(Yi=0,lo=e):Yi=0,Gi(0)}}function Fu(e,t){(e.pooledCacheLanes&=t)===0&&(t=e.pooledCache,t!=null&&(e.pooledCache=null,ki(t)))}function Pn(){return Qu(),Zu(),Ju(),Pu()}function Pu(){if(lt!==5)return!1;var e=Ha,t=to;to=0;var l=Ns(ba),i=T.T,n=f.p;try{f.p=32>l?32:l,T.T=null,l=ao,ao=null;var s=Ha,o=ba;if(lt=0,Zl=Ha=null,ba=0,(Me&6)!==0)throw Error(d(331));var c=Me;if(Me|=4,Cu(s.current),_u(s,s.current,o,l),Me=c,Gi(0,!1),ht&&typeof ht.onPostCommitFiberRoot=="function")try{ht.onPostCommitFiberRoot(Ja,s)}catch{}return!0}finally{f.p=n,T.T=i,Fu(e,t)}}function Wu(e,t,l){t=Ht(l,t),t=Rr(e.stateNode,t,2),e=Ca(e,t,2),e!==null&&(Wa(e,2),ea(e))}function Le(e,t,l){if(e.tag===3)Wu(e,e,l);else for(;t!==null;){if(t.tag===3){Wu(t,e,l);break}else if(t.tag===1){var i=t.stateNode;if(typeof t.type.getDerivedStateFromError=="function"||typeof i.componentDidCatch=="function"&&(Ba===null||!Ba.has(i))){e=Ht(l,e),l=$d(2),i=Ca(t,l,2),i!==null&&(eu(l,i,t,e),Wa(i,2),ea(i));break}}t=t.return}}function so(e,t,l){var i=e.pingCache;if(i===null){i=e.pingCache=new U0;var n=new Set;i.set(t,n)}else n=i.get(t),n===void 0&&(n=new Set,i.set(t,n));n.has(l)||(Wr=!0,n.add(l),e=G0.bind(null,e,t,l),t.then(e,e))}function G0(e,t,l){var i=e.pingCache;i!==null&&i.delete(t),e.pingedLanes|=e.suspendedLanes&l,e.warmLanes&=~l,Ge===e&&(ze&l)===l&&(Qe===4||Qe===3&&(ze&62914560)===ze&&300>he()-Vn?(Me&2)===0&&Jl(e,0):$r|=l,Ql===ze&&(Ql=0)),ea(e)}function $u(e,t){t===0&&(t=ks()),e=ll(e,t),e!==null&&(Wa(e,t),ea(e))}function I0(e){var t=e.memoizedState,l=0;t!==null&&(l=t.retryLane),$u(e,l)}function K0(e,t){var l=0;switch(e.tag){case 31:case 13:var i=e.stateNode,n=e.memoizedState;n!==null&&(l=n.retryLane);break;case 19:i=e.stateNode;break;case 22:i=e.stateNode._retryCache;break;default:throw Error(d(314))}i!==null&&i.delete(t),$u(e,l)}function q0(e,t){return Xt(e,t)}var Wn=null,Pl=null,ro=!1,$n=!1,oo=!1,Ga=0;function ea(e){e!==Pl&&e.next===null&&(Pl===null?Wn=Pl=e:Pl=Pl.next=e),$n=!0,ro||(ro=!0,X0())}function Gi(e,t){if(!oo&&$n){oo=!0;do for(var l=!1,i=Wn;i!==null;){if(e!==0){var n=i.pendingLanes;if(n===0)var s=0;else{var o=i.suspendedLanes,c=i.pingedLanes;s=(1<<31-mt(42|e)+1)-1,s&=n&~(o&~c),s=s&201326741?s&201326741|1:s?s|2:0}s!==0&&(l=!0,lf(i,s))}else s=ze,s=ge(i,i===Ge?s:0,i.cancelPendingCommit!==null||i.timeoutHandle!==-1),(s&3)===0||Ae(i,s)||(l=!0,lf(i,s));i=i.next}while(l);oo=!1}}function V0(){ef()}function ef(){$n=ro=!1;var e=0;Ga!==0&&ap()&&(e=Ga);for(var t=he(),l=null,i=Wn;i!==null;){var n=i.next,s=tf(i,t);s===0?(i.next=null,l===null?Wn=n:l.next=n,n===null&&(Pl=l)):(l=i,(e!==0||(s&3)!==0)&&($n=!0)),i=n}lt!==0&&lt!==5||Gi(e),Ga!==0&&(Ga=0)}function tf(e,t){for(var l=e.suspendedLanes,i=e.pingedLanes,n=e.expirationTimes,s=e.pendingLanes&-62914561;0<s;){var o=31-mt(s),c=1<<o,u=n[o];u===-1?((c&l)===0||(c&i)!==0)&&(n[o]=Te(c,t)):u<=t&&(e.expiredLanes|=c),s&=~c}if(t=Ge,l=ze,l=ge(e,e===t?l:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),i=e.callbackNode,l===0||e===t&&(Ue===2||Ue===9)||e.cancelPendingCommit!==null)return i!==null&&i!==null&&st(i),e.callbackNode=null,e.callbackPriority=0;if((l&3)===0||Ae(e,l)){if(t=l&-l,t===e.callbackPriority)return t;switch(i!==null&&st(i),Ns(l)){case 2:case 8:l=Ft;break;case 32:l=Et;break;case 268435456:l=si;break;default:l=Et}return i=af.bind(null,e),l=Xt(l,i),e.callbackPriority=t,e.callbackNode=l,t}return i!==null&&i!==null&&st(i),e.callbackPriority=2,e.callbackNode=null,2}function af(e,t){if(lt!==0&&lt!==5)return e.callbackNode=null,e.callbackPriority=0,null;var l=e.callbackNode;if(Pn()&&e.callbackNode!==l)return null;var i=ze;return i=ge(e,e===Ge?i:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),i===0?null:(Lu(e,i,t),tf(e,he()),e.callbackNode!=null&&e.callbackNode===l?af.bind(null,e):null)}function lf(e,t){if(Pn())return null;Lu(e,t,!0)}function X0(){ip(function(){(Me&6)!==0?Xt(We,V0):ef()})}function co(){if(Ga===0){var e=Ul;e===0&&(e=Fa,Fa<<=1,(Fa&261888)===0&&(Fa=256)),Ga=e}return Ga}function nf(e){return e==null||typeof e=="symbol"||typeof e=="boolean"?null:typeof e=="function"?e:rn(""+e)}function sf(e,t){var l=t.ownerDocument.createElement("input");return l.name=t.name,l.value=t.value,e.id&&l.setAttribute("form",e.id),t.parentNode.insertBefore(l,t),e=new FormData(e),l.parentNode.removeChild(l),e}function Q0(e,t,l,i,n){if(t==="submit"&&l&&l.stateNode===n){var s=nf((n[vt]||null).action),o=i.submitter;o&&(t=(t=o[vt]||null)?nf(t.formAction):o.getAttribute("formAction"),t!==null&&(s=t,o=null));var c=new un("action","action",null,i,n);e.push({event:c,listeners:[{instance:null,listener:function(){if(i.defaultPrevented){if(Ga!==0){var u=o?sf(n,o):new FormData(n);_r(l,{pending:!0,data:u,method:n.method,action:s},null,u)}}else typeof s=="function"&&(c.preventDefault(),u=o?sf(n,o):new FormData(n),_r(l,{pending:!0,data:u,method:n.method,action:s},s,u))},currentTarget:n}]})}}for(var uo=0;uo<Xs.length;uo++){var fo=Xs[uo],Z0=fo.toLowerCase(),J0=fo[0].toUpperCase()+fo.slice(1);Qt(Z0,"on"+J0)}Qt(Uc,"onAnimationEnd"),Qt(Lc,"onAnimationIteration"),Qt(Bc,"onAnimationStart"),Qt("dblclick","onDoubleClick"),Qt("focusin","onFocus"),Qt("focusout","onBlur"),Qt(u0,"onTransitionRun"),Qt(f0,"onTransitionStart"),Qt(m0,"onTransitionCancel"),Qt(Hc,"onTransitionEnd"),jl("onMouseEnter",["mouseout","mouseover"]),jl("onMouseLeave",["mouseout","mouseover"]),jl("onPointerEnter",["pointerout","pointerover"]),jl("onPointerLeave",["pointerout","pointerover"]),$a("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),$a("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),$a("onBeforeInput",["compositionend","keypress","textInput","paste"]),$a("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),$a("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),$a("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Ii="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),F0=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Ii));function rf(e,t){t=(t&4)!==0;for(var l=0;l<e.length;l++){var i=e[l],n=i.event;i=i.listeners;e:{var s=void 0;if(t)for(var o=i.length-1;0<=o;o--){var c=i[o],u=c.instance,z=c.currentTarget;if(c=c.listener,u!==s&&n.isPropagationStopped())break e;s=c,n.currentTarget=z;try{s(n)}catch(C){xn(C)}n.currentTarget=null,s=u}else for(o=0;o<i.length;o++){if(c=i[o],u=c.instance,z=c.currentTarget,c=c.listener,u!==s&&n.isPropagationStopped())break e;s=c,n.currentTarget=z;try{s(n)}catch(C){xn(C)}n.currentTarget=null,s=u}}}}function Ne(e,t){var l=t[zs];l===void 0&&(l=t[zs]=new Set);var i=e+"__bubble";l.has(i)||(of(t,e,2,!1),l.add(i))}function mo(e,t,l){var i=0;t&&(i|=4),of(l,e,i,t)}var es="_reactListening"+Math.random().toString(36).slice(2);function xo(e){if(!e[es]){e[es]=!0,ec.forEach(function(l){l!=="selectionchange"&&(F0.has(l)||mo(l,!1,e),mo(l,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[es]||(t[es]=!0,mo("selectionchange",!1,t))}}function of(e,t,l,i){switch(Lf(t)){case 2:var n=zp;break;case 8:n=wp;break;default:n=_o}l=n.bind(null,t,l,e),n=void 0,!Ds||t!=="touchstart"&&t!=="touchmove"&&t!=="wheel"||(n=!0),i?n!==void 0?e.addEventListener(t,l,{capture:!0,passive:n}):e.addEventListener(t,l,!0):n!==void 0?e.addEventListener(t,l,{passive:n}):e.addEventListener(t,l,!1)}function po(e,t,l,i,n){var s=i;if((t&1)===0&&(t&2)===0&&i!==null)e:for(;;){if(i===null)return;var o=i.tag;if(o===3||o===4){var c=i.stateNode.containerInfo;if(c===n)break;if(o===4)for(o=i.return;o!==null;){var u=o.tag;if((u===3||u===4)&&o.stateNode.containerInfo===n)return;o=o.return}for(;c!==null;){if(o=yl(c),o===null)return;if(u=o.tag,u===5||u===6||u===26||u===27){i=s=o;continue e}c=c.parentNode}}i=i.return}fc(function(){var z=s,C=Os(l),R=[];e:{var w=Yc.get(e);if(w!==void 0){var A=un,P=e;switch(e){case"keypress":if(cn(l)===0)break e;case"keydown":case"keyup":A=Kx;break;case"focusin":P="focus",A=Ls;break;case"focusout":P="blur",A=Ls;break;case"beforeblur":case"afterblur":A=Ls;break;case"click":if(l.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":A=pc;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":A=Ox;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":A=Xx;break;case Uc:case Lc:case Bc:A=Mx;break;case Hc:A=Zx;break;case"scroll":case"scrollend":A=_x;break;case"wheel":A=Fx;break;case"copy":case"cut":case"paste":A=Ux;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":A=gc;break;case"toggle":case"beforetoggle":A=Wx}var de=(t&4)!==0,Ye=!de&&(e==="scroll"||e==="scrollend"),y=de?w!==null?w+"Capture":null:w;de=[];for(var x=z,j;x!==null;){var M=x;if(j=M.stateNode,M=M.tag,M!==5&&M!==26&&M!==27||j===null||y===null||(M=di(x,y),M!=null&&de.push(Ki(x,M,j))),Ye)break;x=x.return}0<de.length&&(w=new A(w,P,null,l,C),R.push({event:w,listeners:de}))}}if((t&7)===0){e:{if(w=e==="mouseover"||e==="pointerover",A=e==="mouseout"||e==="pointerout",w&&l!==As&&(P=l.relatedTarget||l.fromElement)&&(yl(P)||P[bl]))break e;if((A||w)&&(w=C.window===C?C:(w=C.ownerDocument)?w.defaultView||w.parentWindow:window,A?(P=l.relatedTarget||l.toElement,A=z,P=P?yl(P):null,P!==null&&(Ye=E(P),de=P.tag,P!==Ye||de!==5&&de!==27&&de!==6)&&(P=null)):(A=null,P=z),A!==P)){if(de=pc,M="onMouseLeave",y="onMouseEnter",x="mouse",(e==="pointerout"||e==="pointerover")&&(de=gc,M="onPointerLeave",y="onPointerEnter",x="pointer"),Ye=A==null?w:ci(A),j=P==null?w:ci(P),w=new de(M,x+"leave",A,l,C),w.target=Ye,w.relatedTarget=j,M=null,yl(C)===z&&(de=new de(y,x+"enter",P,l,C),de.target=j,de.relatedTarget=Ye,M=de),Ye=M,A&&P)t:{for(de=P0,y=A,x=P,j=0,M=y;M;M=de(M))j++;M=0;for(var ie=x;ie;ie=de(ie))M++;for(;0<j-M;)y=de(y),j--;for(;0<M-j;)x=de(x),M--;for(;j--;){if(y===x||x!==null&&y===x.alternate){de=y;break t}y=de(y),x=de(x)}de=null}else de=null;A!==null&&cf(R,w,A,de,!1),P!==null&&Ye!==null&&cf(R,Ye,P,de,!0)}}e:{if(w=z?ci(z):window,A=w.nodeName&&w.nodeName.toLowerCase(),A==="select"||A==="input"&&w.type==="file")var Oe=wc;else if(Nc(w))if(Sc)Oe=o0;else{Oe=s0;var $=n0}else A=w.nodeName,!A||A.toLowerCase()!=="input"||w.type!=="checkbox"&&w.type!=="radio"?z&&_s(z.elementType)&&(Oe=wc):Oe=r0;if(Oe&&(Oe=Oe(e,z))){zc(R,Oe,l,C);break e}$&&$(e,w,z),e==="focusout"&&z&&w.type==="number"&&z.memoizedProps.value!=null&&Ts(w,"number",w.value)}switch($=z?ci(z):window,e){case"focusin":(Nc($)||$.contentEditable==="true")&&(Tl=$,Ks=z,bi=null);break;case"focusout":bi=Ks=Tl=null;break;case"mousedown":qs=!0;break;case"contextmenu":case"mouseup":case"dragend":qs=!1,Mc(R,l,C);break;case"selectionchange":if(d0)break;case"keydown":case"keyup":Mc(R,l,C)}var ve;if(Hs)e:{switch(e){case"compositionstart":var we="onCompositionStart";break e;case"compositionend":we="onCompositionEnd";break e;case"compositionupdate":we="onCompositionUpdate";break e}we=void 0}else El?kc(e,l)&&(we="onCompositionEnd"):e==="keydown"&&l.keyCode===229&&(we="onCompositionStart");we&&(bc&&l.locale!=="ko"&&(El||we!=="onCompositionStart"?we==="onCompositionEnd"&&El&&(ve=mc()):(wa=C,Ms="value"in wa?wa.value:wa.textContent,El=!0)),$=ts(z,we),0<$.length&&(we=new hc(we,e,null,l,C),R.push({event:we,listeners:$}),ve?we.data=ve:(ve=jc(l),ve!==null&&(we.data=ve)))),(ve=e0?t0(e,l):a0(e,l))&&(we=ts(z,"onBeforeInput"),0<we.length&&($=new hc("onBeforeInput","beforeinput",null,l,C),R.push({event:$,listeners:we}),$.data=ve)),Q0(R,e,z,l,C)}rf(R,t)})}function Ki(e,t,l){return{instance:e,listener:t,currentTarget:l}}function ts(e,t){for(var l=t+"Capture",i=[];e!==null;){var n=e,s=n.stateNode;if(n=n.tag,n!==5&&n!==26&&n!==27||s===null||(n=di(e,l),n!=null&&i.unshift(Ki(e,n,s)),n=di(e,t),n!=null&&i.push(Ki(e,n,s))),e.tag===3)return i;e=e.return}return[]}function P0(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function cf(e,t,l,i,n){for(var s=t._reactName,o=[];l!==null&&l!==i;){var c=l,u=c.alternate,z=c.stateNode;if(c=c.tag,u!==null&&u===i)break;c!==5&&c!==26&&c!==27||z===null||(u=z,n?(z=di(l,s),z!=null&&o.unshift(Ki(l,z,u))):n||(z=di(l,s),z!=null&&o.push(Ki(l,z,u)))),l=l.return}o.length!==0&&e.push({event:t,listeners:o})}var W0=/\r\n?/g,$0=/\u0000|\uFFFD/g;function df(e){return(typeof e=="string"?e:""+e).replace(W0,`
`).replace($0,"")}function uf(e,t){return t=df(t),df(e)===t}function He(e,t,l,i,n,s){switch(l){case"children":typeof i=="string"?t==="body"||t==="textarea"&&i===""||zl(e,i):(typeof i=="number"||typeof i=="bigint")&&t!=="body"&&zl(e,""+i);break;case"className":nn(e,"class",i);break;case"tabIndex":nn(e,"tabindex",i);break;case"dir":case"role":case"viewBox":case"width":case"height":nn(e,l,i);break;case"style":dc(e,i,s);break;case"data":if(t!=="object"){nn(e,"data",i);break}case"src":case"href":if(i===""&&(t!=="a"||l!=="href")){e.removeAttribute(l);break}if(i==null||typeof i=="function"||typeof i=="symbol"||typeof i=="boolean"){e.removeAttribute(l);break}i=rn(""+i),e.setAttribute(l,i);break;case"action":case"formAction":if(typeof i=="function"){e.setAttribute(l,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof s=="function"&&(l==="formAction"?(t!=="input"&&He(e,t,"name",n.name,n,null),He(e,t,"formEncType",n.formEncType,n,null),He(e,t,"formMethod",n.formMethod,n,null),He(e,t,"formTarget",n.formTarget,n,null)):(He(e,t,"encType",n.encType,n,null),He(e,t,"method",n.method,n,null),He(e,t,"target",n.target,n,null)));if(i==null||typeof i=="symbol"||typeof i=="boolean"){e.removeAttribute(l);break}i=rn(""+i),e.setAttribute(l,i);break;case"onClick":i!=null&&(e.onclick=la);break;case"onScroll":i!=null&&Ne("scroll",e);break;case"onScrollEnd":i!=null&&Ne("scrollend",e);break;case"dangerouslySetInnerHTML":if(i!=null){if(typeof i!="object"||!("__html"in i))throw Error(d(61));if(l=i.__html,l!=null){if(n.children!=null)throw Error(d(60));e.innerHTML=l}}break;case"multiple":e.multiple=i&&typeof i!="function"&&typeof i!="symbol";break;case"muted":e.muted=i&&typeof i!="function"&&typeof i!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(i==null||typeof i=="function"||typeof i=="boolean"||typeof i=="symbol"){e.removeAttribute("xlink:href");break}l=rn(""+i),e.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",l);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":i!=null&&typeof i!="function"&&typeof i!="symbol"?e.setAttribute(l,""+i):e.removeAttribute(l);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":i&&typeof i!="function"&&typeof i!="symbol"?e.setAttribute(l,""):e.removeAttribute(l);break;case"capture":case"download":i===!0?e.setAttribute(l,""):i!==!1&&i!=null&&typeof i!="function"&&typeof i!="symbol"?e.setAttribute(l,i):e.removeAttribute(l);break;case"cols":case"rows":case"size":case"span":i!=null&&typeof i!="function"&&typeof i!="symbol"&&!isNaN(i)&&1<=i?e.setAttribute(l,i):e.removeAttribute(l);break;case"rowSpan":case"start":i==null||typeof i=="function"||typeof i=="symbol"||isNaN(i)?e.removeAttribute(l):e.setAttribute(l,i);break;case"popover":Ne("beforetoggle",e),Ne("toggle",e),ln(e,"popover",i);break;case"xlinkActuate":aa(e,"http://www.w3.org/1999/xlink","xlink:actuate",i);break;case"xlinkArcrole":aa(e,"http://www.w3.org/1999/xlink","xlink:arcrole",i);break;case"xlinkRole":aa(e,"http://www.w3.org/1999/xlink","xlink:role",i);break;case"xlinkShow":aa(e,"http://www.w3.org/1999/xlink","xlink:show",i);break;case"xlinkTitle":aa(e,"http://www.w3.org/1999/xlink","xlink:title",i);break;case"xlinkType":aa(e,"http://www.w3.org/1999/xlink","xlink:type",i);break;case"xmlBase":aa(e,"http://www.w3.org/XML/1998/namespace","xml:base",i);break;case"xmlLang":aa(e,"http://www.w3.org/XML/1998/namespace","xml:lang",i);break;case"xmlSpace":aa(e,"http://www.w3.org/XML/1998/namespace","xml:space",i);break;case"is":ln(e,"is",i);break;case"innerText":case"textContent":break;default:(!(2<l.length)||l[0]!=="o"&&l[0]!=="O"||l[1]!=="n"&&l[1]!=="N")&&(l=Ex.get(l)||l,ln(e,l,i))}}function ho(e,t,l,i,n,s){switch(l){case"style":dc(e,i,s);break;case"dangerouslySetInnerHTML":if(i!=null){if(typeof i!="object"||!("__html"in i))throw Error(d(61));if(l=i.__html,l!=null){if(n.children!=null)throw Error(d(60));e.innerHTML=l}}break;case"children":typeof i=="string"?zl(e,i):(typeof i=="number"||typeof i=="bigint")&&zl(e,""+i);break;case"onScroll":i!=null&&Ne("scroll",e);break;case"onScrollEnd":i!=null&&Ne("scrollend",e);break;case"onClick":i!=null&&(e.onclick=la);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!tc.hasOwnProperty(l))e:{if(l[0]==="o"&&l[1]==="n"&&(n=l.endsWith("Capture"),t=l.slice(2,n?l.length-7:void 0),s=e[vt]||null,s=s!=null?s[l]:null,typeof s=="function"&&e.removeEventListener(t,s,n),typeof i=="function")){typeof s!="function"&&s!==null&&(l in e?e[l]=null:e.hasAttribute(l)&&e.removeAttribute(l)),e.addEventListener(t,i,n);break e}l in e?e[l]=i:i===!0?e.setAttribute(l,""):ln(e,l,i)}}}function ut(e,t,l){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":Ne("error",e),Ne("load",e);var i=!1,n=!1,s;for(s in l)if(l.hasOwnProperty(s)){var o=l[s];if(o!=null)switch(s){case"src":i=!0;break;case"srcSet":n=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(d(137,t));default:He(e,t,s,o,l,null)}}n&&He(e,t,"srcSet",l.srcSet,l,null),i&&He(e,t,"src",l.src,l,null);return;case"input":Ne("invalid",e);var c=s=o=n=null,u=null,z=null;for(i in l)if(l.hasOwnProperty(i)){var C=l[i];if(C!=null)switch(i){case"name":n=C;break;case"type":o=C;break;case"checked":u=C;break;case"defaultChecked":z=C;break;case"value":s=C;break;case"defaultValue":c=C;break;case"children":case"dangerouslySetInnerHTML":if(C!=null)throw Error(d(137,t));break;default:He(e,t,i,C,l,null)}}sc(e,s,c,u,z,o,n,!1);return;case"select":Ne("invalid",e),i=o=s=null;for(n in l)if(l.hasOwnProperty(n)&&(c=l[n],c!=null))switch(n){case"value":s=c;break;case"defaultValue":o=c;break;case"multiple":i=c;default:He(e,t,n,c,l,null)}t=s,l=o,e.multiple=!!i,t!=null?Nl(e,!!i,t,!1):l!=null&&Nl(e,!!i,l,!0);return;case"textarea":Ne("invalid",e),s=n=i=null;for(o in l)if(l.hasOwnProperty(o)&&(c=l[o],c!=null))switch(o){case"value":i=c;break;case"defaultValue":n=c;break;case"children":s=c;break;case"dangerouslySetInnerHTML":if(c!=null)throw Error(d(91));break;default:He(e,t,o,c,l,null)}oc(e,i,n,s);return;case"option":for(u in l)if(l.hasOwnProperty(u)&&(i=l[u],i!=null))switch(u){case"selected":e.selected=i&&typeof i!="function"&&typeof i!="symbol";break;default:He(e,t,u,i,l,null)}return;case"dialog":Ne("beforetoggle",e),Ne("toggle",e),Ne("cancel",e),Ne("close",e);break;case"iframe":case"object":Ne("load",e);break;case"video":case"audio":for(i=0;i<Ii.length;i++)Ne(Ii[i],e);break;case"image":Ne("error",e),Ne("load",e);break;case"details":Ne("toggle",e);break;case"embed":case"source":case"link":Ne("error",e),Ne("load",e);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(z in l)if(l.hasOwnProperty(z)&&(i=l[z],i!=null))switch(z){case"children":case"dangerouslySetInnerHTML":throw Error(d(137,t));default:He(e,t,z,i,l,null)}return;default:if(_s(t)){for(C in l)l.hasOwnProperty(C)&&(i=l[C],i!==void 0&&ho(e,t,C,i,l,void 0));return}}for(c in l)l.hasOwnProperty(c)&&(i=l[c],i!=null&&He(e,t,c,i,l,null))}function ep(e,t,l,i){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var n=null,s=null,o=null,c=null,u=null,z=null,C=null;for(A in l){var R=l[A];if(l.hasOwnProperty(A)&&R!=null)switch(A){case"checked":break;case"value":break;case"defaultValue":u=R;default:i.hasOwnProperty(A)||He(e,t,A,null,i,R)}}for(var w in i){var A=i[w];if(R=l[w],i.hasOwnProperty(w)&&(A!=null||R!=null))switch(w){case"type":s=A;break;case"name":n=A;break;case"checked":z=A;break;case"defaultChecked":C=A;break;case"value":o=A;break;case"defaultValue":c=A;break;case"children":case"dangerouslySetInnerHTML":if(A!=null)throw Error(d(137,t));break;default:A!==R&&He(e,t,w,A,i,R)}}Es(e,o,c,u,z,C,s,n);return;case"select":A=o=c=w=null;for(s in l)if(u=l[s],l.hasOwnProperty(s)&&u!=null)switch(s){case"value":break;case"multiple":A=u;default:i.hasOwnProperty(s)||He(e,t,s,null,i,u)}for(n in i)if(s=i[n],u=l[n],i.hasOwnProperty(n)&&(s!=null||u!=null))switch(n){case"value":w=s;break;case"defaultValue":c=s;break;case"multiple":o=s;default:s!==u&&He(e,t,n,s,i,u)}t=c,l=o,i=A,w!=null?Nl(e,!!l,w,!1):!!i!=!!l&&(t!=null?Nl(e,!!l,t,!0):Nl(e,!!l,l?[]:"",!1));return;case"textarea":A=w=null;for(c in l)if(n=l[c],l.hasOwnProperty(c)&&n!=null&&!i.hasOwnProperty(c))switch(c){case"value":break;case"children":break;default:He(e,t,c,null,i,n)}for(o in i)if(n=i[o],s=l[o],i.hasOwnProperty(o)&&(n!=null||s!=null))switch(o){case"value":w=n;break;case"defaultValue":A=n;break;case"children":break;case"dangerouslySetInnerHTML":if(n!=null)throw Error(d(91));break;default:n!==s&&He(e,t,o,n,i,s)}rc(e,w,A);return;case"option":for(var P in l)if(w=l[P],l.hasOwnProperty(P)&&w!=null&&!i.hasOwnProperty(P))switch(P){case"selected":e.selected=!1;break;default:He(e,t,P,null,i,w)}for(u in i)if(w=i[u],A=l[u],i.hasOwnProperty(u)&&w!==A&&(w!=null||A!=null))switch(u){case"selected":e.selected=w&&typeof w!="function"&&typeof w!="symbol";break;default:He(e,t,u,w,i,A)}return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var de in l)w=l[de],l.hasOwnProperty(de)&&w!=null&&!i.hasOwnProperty(de)&&He(e,t,de,null,i,w);for(z in i)if(w=i[z],A=l[z],i.hasOwnProperty(z)&&w!==A&&(w!=null||A!=null))switch(z){case"children":case"dangerouslySetInnerHTML":if(w!=null)throw Error(d(137,t));break;default:He(e,t,z,w,i,A)}return;default:if(_s(t)){for(var Ye in l)w=l[Ye],l.hasOwnProperty(Ye)&&w!==void 0&&!i.hasOwnProperty(Ye)&&ho(e,t,Ye,void 0,i,w);for(C in i)w=i[C],A=l[C],!i.hasOwnProperty(C)||w===A||w===void 0&&A===void 0||ho(e,t,C,w,i,A);return}}for(var y in l)w=l[y],l.hasOwnProperty(y)&&w!=null&&!i.hasOwnProperty(y)&&He(e,t,y,null,i,w);for(R in i)w=i[R],A=l[R],!i.hasOwnProperty(R)||w===A||w==null&&A==null||He(e,t,R,w,i,A)}function ff(e){switch(e){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function tp(){if(typeof performance.getEntriesByType=="function"){for(var e=0,t=0,l=performance.getEntriesByType("resource"),i=0;i<l.length;i++){var n=l[i],s=n.transferSize,o=n.initiatorType,c=n.duration;if(s&&c&&ff(o)){for(o=0,c=n.responseEnd,i+=1;i<l.length;i++){var u=l[i],z=u.startTime;if(z>c)break;var C=u.transferSize,R=u.initiatorType;C&&ff(R)&&(u=u.responseEnd,o+=C*(u<c?1:(c-z)/(u-z)))}if(--i,t+=8*(s+o)/(n.duration/1e3),e++,10<e)break}}if(0<e)return t/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e=="number")?e:5}var go=null,bo=null;function as(e){return e.nodeType===9?e:e.ownerDocument}function mf(e){switch(e){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function xf(e,t){if(e===0)switch(t){case"svg":return 1;case"math":return 2;default:return 0}return e===1&&t==="foreignObject"?0:e}function yo(e,t){return e==="textarea"||e==="noscript"||typeof t.children=="string"||typeof t.children=="number"||typeof t.children=="bigint"||typeof t.dangerouslySetInnerHTML=="object"&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var vo=null;function ap(){var e=window.event;return e&&e.type==="popstate"?e===vo?!1:(vo=e,!0):(vo=null,!1)}var pf=typeof setTimeout=="function"?setTimeout:void 0,lp=typeof clearTimeout=="function"?clearTimeout:void 0,hf=typeof Promise=="function"?Promise:void 0,ip=typeof queueMicrotask=="function"?queueMicrotask:typeof hf<"u"?function(e){return hf.resolve(null).then(e).catch(np)}:pf;function np(e){setTimeout(function(){throw e})}function Ia(e){return e==="head"}function gf(e,t){var l=t,i=0;do{var n=l.nextSibling;if(e.removeChild(l),n&&n.nodeType===8)if(l=n.data,l==="/$"||l==="/&"){if(i===0){e.removeChild(n),ti(t);return}i--}else if(l==="$"||l==="$?"||l==="$~"||l==="$!"||l==="&")i++;else if(l==="html")qi(e.ownerDocument.documentElement);else if(l==="head"){l=e.ownerDocument.head,qi(l);for(var s=l.firstChild;s;){var o=s.nextSibling,c=s.nodeName;s[oi]||c==="SCRIPT"||c==="STYLE"||c==="LINK"&&s.rel.toLowerCase()==="stylesheet"||l.removeChild(s),s=o}}else l==="body"&&qi(e.ownerDocument.body);l=n}while(l);ti(t)}function bf(e,t){var l=e;e=0;do{var i=l.nextSibling;if(l.nodeType===1?t?(l._stashedDisplay=l.style.display,l.style.display="none"):(l.style.display=l._stashedDisplay||"",l.getAttribute("style")===""&&l.removeAttribute("style")):l.nodeType===3&&(t?(l._stashedText=l.nodeValue,l.nodeValue=""):l.nodeValue=l._stashedText||""),i&&i.nodeType===8)if(l=i.data,l==="/$"){if(e===0)break;e--}else l!=="$"&&l!=="$?"&&l!=="$~"&&l!=="$!"||e++;l=i}while(l)}function ko(e){var t=e.firstChild;for(t&&t.nodeType===10&&(t=t.nextSibling);t;){var l=t;switch(t=t.nextSibling,l.nodeName){case"HTML":case"HEAD":case"BODY":ko(l),ws(l);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(l.rel.toLowerCase()==="stylesheet")continue}e.removeChild(l)}}function sp(e,t,l,i){for(;e.nodeType===1;){var n=l;if(e.nodeName.toLowerCase()!==t.toLowerCase()){if(!i&&(e.nodeName!=="INPUT"||e.type!=="hidden"))break}else if(i){if(!e[oi])switch(t){case"meta":if(!e.hasAttribute("itemprop"))break;return e;case"link":if(s=e.getAttribute("rel"),s==="stylesheet"&&e.hasAttribute("data-precedence"))break;if(s!==n.rel||e.getAttribute("href")!==(n.href==null||n.href===""?null:n.href)||e.getAttribute("crossorigin")!==(n.crossOrigin==null?null:n.crossOrigin)||e.getAttribute("title")!==(n.title==null?null:n.title))break;return e;case"style":if(e.hasAttribute("data-precedence"))break;return e;case"script":if(s=e.getAttribute("src"),(s!==(n.src==null?null:n.src)||e.getAttribute("type")!==(n.type==null?null:n.type)||e.getAttribute("crossorigin")!==(n.crossOrigin==null?null:n.crossOrigin))&&s&&e.hasAttribute("async")&&!e.hasAttribute("itemprop"))break;return e;default:return e}}else if(t==="input"&&e.type==="hidden"){var s=n.name==null?null:""+n.name;if(n.type==="hidden"&&e.getAttribute("name")===s)return e}else return e;if(e=qt(e.nextSibling),e===null)break}return null}function rp(e,t,l){if(t==="")return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!l||(e=qt(e.nextSibling),e===null))return null;return e}function yf(e,t){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!t||(e=qt(e.nextSibling),e===null))return null;return e}function jo(e){return e.data==="$?"||e.data==="$~"}function No(e){return e.data==="$!"||e.data==="$?"&&e.ownerDocument.readyState!=="loading"}function op(e,t){var l=e.ownerDocument;if(e.data==="$~")e._reactRetry=t;else if(e.data!=="$?"||l.readyState!=="loading")t();else{var i=function(){t(),l.removeEventListener("DOMContentLoaded",i)};l.addEventListener("DOMContentLoaded",i),e._reactRetry=i}}function qt(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t==="$"||t==="$!"||t==="$?"||t==="$~"||t==="&"||t==="F!"||t==="F")break;if(t==="/$"||t==="/&")return null}}return e}var zo=null;function vf(e){e=e.nextSibling;for(var t=0;e;){if(e.nodeType===8){var l=e.data;if(l==="/$"||l==="/&"){if(t===0)return qt(e.nextSibling);t--}else l!=="$"&&l!=="$!"&&l!=="$?"&&l!=="$~"&&l!=="&"||t++}e=e.nextSibling}return null}function kf(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var l=e.data;if(l==="$"||l==="$!"||l==="$?"||l==="$~"||l==="&"){if(t===0)return e;t--}else l!=="/$"&&l!=="/&"||t++}e=e.previousSibling}return null}function jf(e,t,l){switch(t=as(l),e){case"html":if(e=t.documentElement,!e)throw Error(d(452));return e;case"head":if(e=t.head,!e)throw Error(d(453));return e;case"body":if(e=t.body,!e)throw Error(d(454));return e;default:throw Error(d(451))}}function qi(e){for(var t=e.attributes;t.length;)e.removeAttributeNode(t[0]);ws(e)}var Vt=new Map,Nf=new Set;function ls(e){return typeof e.getRootNode=="function"?e.getRootNode():e.nodeType===9?e:e.ownerDocument}var ya=f.d;f.d={f:cp,r:dp,D:up,C:fp,L:mp,m:xp,X:hp,S:pp,M:gp};function cp(){var e=ya.f(),t=Zn();return e||t}function dp(e){var t=vl(e);t!==null&&t.tag===5&&t.type==="form"?Hd(t):ya.r(e)}var Wl=typeof document>"u"?null:document;function zf(e,t,l){var i=Wl;if(i&&typeof t=="string"&&t){var n=Lt(t);n='link[rel="'+e+'"][href="'+n+'"]',typeof l=="string"&&(n+='[crossorigin="'+l+'"]'),Nf.has(n)||(Nf.add(n),e={rel:e,crossOrigin:l,href:t},i.querySelector(n)===null&&(t=i.createElement("link"),ut(t,"link",e),it(t),i.head.appendChild(t)))}}function up(e){ya.D(e),zf("dns-prefetch",e,null)}function fp(e,t){ya.C(e,t),zf("preconnect",e,t)}function mp(e,t,l){ya.L(e,t,l);var i=Wl;if(i&&e&&t){var n='link[rel="preload"][as="'+Lt(t)+'"]';t==="image"&&l&&l.imageSrcSet?(n+='[imagesrcset="'+Lt(l.imageSrcSet)+'"]',typeof l.imageSizes=="string"&&(n+='[imagesizes="'+Lt(l.imageSizes)+'"]')):n+='[href="'+Lt(e)+'"]';var s=n;switch(t){case"style":s=$l(e);break;case"script":s=ei(e)}Vt.has(s)||(e=N({rel:"preload",href:t==="image"&&l&&l.imageSrcSet?void 0:e,as:t},l),Vt.set(s,e),i.querySelector(n)!==null||t==="style"&&i.querySelector(Vi(s))||t==="script"&&i.querySelector(Xi(s))||(t=i.createElement("link"),ut(t,"link",e),it(t),i.head.appendChild(t)))}}function xp(e,t){ya.m(e,t);var l=Wl;if(l&&e){var i=t&&typeof t.as=="string"?t.as:"script",n='link[rel="modulepreload"][as="'+Lt(i)+'"][href="'+Lt(e)+'"]',s=n;switch(i){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":s=ei(e)}if(!Vt.has(s)&&(e=N({rel:"modulepreload",href:e},t),Vt.set(s,e),l.querySelector(n)===null)){switch(i){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(l.querySelector(Xi(s)))return}i=l.createElement("link"),ut(i,"link",e),it(i),l.head.appendChild(i)}}}function pp(e,t,l){ya.S(e,t,l);var i=Wl;if(i&&e){var n=kl(i).hoistableStyles,s=$l(e);t=t||"default";var o=n.get(s);if(!o){var c={loading:0,preload:null};if(o=i.querySelector(Vi(s)))c.loading=5;else{e=N({rel:"stylesheet",href:e,"data-precedence":t},l),(l=Vt.get(s))&&wo(e,l);var u=o=i.createElement("link");it(u),ut(u,"link",e),u._p=new Promise(function(z,C){u.onload=z,u.onerror=C}),u.addEventListener("load",function(){c.loading|=1}),u.addEventListener("error",function(){c.loading|=2}),c.loading|=4,is(o,t,i)}o={type:"stylesheet",instance:o,count:1,state:c},n.set(s,o)}}}function hp(e,t){ya.X(e,t);var l=Wl;if(l&&e){var i=kl(l).hoistableScripts,n=ei(e),s=i.get(n);s||(s=l.querySelector(Xi(n)),s||(e=N({src:e,async:!0},t),(t=Vt.get(n))&&So(e,t),s=l.createElement("script"),it(s),ut(s,"link",e),l.head.appendChild(s)),s={type:"script",instance:s,count:1,state:null},i.set(n,s))}}function gp(e,t){ya.M(e,t);var l=Wl;if(l&&e){var i=kl(l).hoistableScripts,n=ei(e),s=i.get(n);s||(s=l.querySelector(Xi(n)),s||(e=N({src:e,async:!0,type:"module"},t),(t=Vt.get(n))&&So(e,t),s=l.createElement("script"),it(s),ut(s,"link",e),l.head.appendChild(s)),s={type:"script",instance:s,count:1,state:null},i.set(n,s))}}function wf(e,t,l,i){var n=(n=pe.current)?ls(n):null;if(!n)throw Error(d(446));switch(e){case"meta":case"title":return null;case"style":return typeof l.precedence=="string"&&typeof l.href=="string"?(t=$l(l.href),l=kl(n).hoistableStyles,i=l.get(t),i||(i={type:"style",instance:null,count:0,state:null},l.set(t,i)),i):{type:"void",instance:null,count:0,state:null};case"link":if(l.rel==="stylesheet"&&typeof l.href=="string"&&typeof l.precedence=="string"){e=$l(l.href);var s=kl(n).hoistableStyles,o=s.get(e);if(o||(n=n.ownerDocument||n,o={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},s.set(e,o),(s=n.querySelector(Vi(e)))&&!s._p&&(o.instance=s,o.state.loading=5),Vt.has(e)||(l={rel:"preload",as:"style",href:l.href,crossOrigin:l.crossOrigin,integrity:l.integrity,media:l.media,hrefLang:l.hrefLang,referrerPolicy:l.referrerPolicy},Vt.set(e,l),s||bp(n,e,l,o.state))),t&&i===null)throw Error(d(528,""));return o}if(t&&i!==null)throw Error(d(529,""));return null;case"script":return t=l.async,l=l.src,typeof l=="string"&&t&&typeof t!="function"&&typeof t!="symbol"?(t=ei(l),l=kl(n).hoistableScripts,i=l.get(t),i||(i={type:"script",instance:null,count:0,state:null},l.set(t,i)),i):{type:"void",instance:null,count:0,state:null};default:throw Error(d(444,e))}}function $l(e){return'href="'+Lt(e)+'"'}function Vi(e){return'link[rel="stylesheet"]['+e+"]"}function Sf(e){return N({},e,{"data-precedence":e.precedence,precedence:null})}function bp(e,t,l,i){e.querySelector('link[rel="preload"][as="style"]['+t+"]")?i.loading=1:(t=e.createElement("link"),i.preload=t,t.addEventListener("load",function(){return i.loading|=1}),t.addEventListener("error",function(){return i.loading|=2}),ut(t,"link",l),it(t),e.head.appendChild(t))}function ei(e){return'[src="'+Lt(e)+'"]'}function Xi(e){return"script[async]"+e}function Ef(e,t,l){if(t.count++,t.instance===null)switch(t.type){case"style":var i=e.querySelector('style[data-href~="'+Lt(l.href)+'"]');if(i)return t.instance=i,it(i),i;var n=N({},l,{"data-href":l.href,"data-precedence":l.precedence,href:null,precedence:null});return i=(e.ownerDocument||e).createElement("style"),it(i),ut(i,"style",n),is(i,l.precedence,e),t.instance=i;case"stylesheet":n=$l(l.href);var s=e.querySelector(Vi(n));if(s)return t.state.loading|=4,t.instance=s,it(s),s;i=Sf(l),(n=Vt.get(n))&&wo(i,n),s=(e.ownerDocument||e).createElement("link"),it(s);var o=s;return o._p=new Promise(function(c,u){o.onload=c,o.onerror=u}),ut(s,"link",i),t.state.loading|=4,is(s,l.precedence,e),t.instance=s;case"script":return s=ei(l.src),(n=e.querySelector(Xi(s)))?(t.instance=n,it(n),n):(i=l,(n=Vt.get(s))&&(i=N({},l),So(i,n)),e=e.ownerDocument||e,n=e.createElement("script"),it(n),ut(n,"link",i),e.head.appendChild(n),t.instance=n);case"void":return null;default:throw Error(d(443,t.type))}else t.type==="stylesheet"&&(t.state.loading&4)===0&&(i=t.instance,t.state.loading|=4,is(i,l.precedence,e));return t.instance}function is(e,t,l){for(var i=l.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),n=i.length?i[i.length-1]:null,s=n,o=0;o<i.length;o++){var c=i[o];if(c.dataset.precedence===t)s=c;else if(s!==n)break}s?s.parentNode.insertBefore(e,s.nextSibling):(t=l.nodeType===9?l.head:l,t.insertBefore(e,t.firstChild))}function wo(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.title==null&&(e.title=t.title)}function So(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.integrity==null&&(e.integrity=t.integrity)}var ns=null;function Tf(e,t,l){if(ns===null){var i=new Map,n=ns=new Map;n.set(l,i)}else n=ns,i=n.get(l),i||(i=new Map,n.set(l,i));if(i.has(e))return i;for(i.set(e,null),l=l.getElementsByTagName(e),n=0;n<l.length;n++){var s=l[n];if(!(s[oi]||s[rt]||e==="link"&&s.getAttribute("rel")==="stylesheet")&&s.namespaceURI!=="http://www.w3.org/2000/svg"){var o=s.getAttribute(t)||"";o=e+o;var c=i.get(o);c?c.push(s):i.set(o,[s])}}return i}function _f(e,t,l){e=e.ownerDocument||e,e.head.insertBefore(l,t==="title"?e.querySelector("head > title"):null)}function yp(e,t,l){if(l===1||t.itemProp!=null)return!1;switch(e){case"meta":case"title":return!0;case"style":if(typeof t.precedence!="string"||typeof t.href!="string"||t.href==="")break;return!0;case"link":if(typeof t.rel!="string"||typeof t.href!="string"||t.href===""||t.onLoad||t.onError)break;switch(t.rel){case"stylesheet":return e=t.disabled,typeof t.precedence=="string"&&e==null;default:return!0}case"script":if(t.async&&typeof t.async!="function"&&typeof t.async!="symbol"&&!t.onLoad&&!t.onError&&t.src&&typeof t.src=="string")return!0}return!1}function Af(e){return!(e.type==="stylesheet"&&(e.state.loading&3)===0)}function vp(e,t,l,i){if(l.type==="stylesheet"&&(typeof i.media!="string"||matchMedia(i.media).matches!==!1)&&(l.state.loading&4)===0){if(l.instance===null){var n=$l(i.href),s=t.querySelector(Vi(n));if(s){t=s._p,t!==null&&typeof t=="object"&&typeof t.then=="function"&&(e.count++,e=ss.bind(e),t.then(e,e)),l.state.loading|=4,l.instance=s,it(s);return}s=t.ownerDocument||t,i=Sf(i),(n=Vt.get(n))&&wo(i,n),s=s.createElement("link"),it(s);var o=s;o._p=new Promise(function(c,u){o.onload=c,o.onerror=u}),ut(s,"link",i),l.instance=s}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(l,t),(t=l.state.preload)&&(l.state.loading&3)===0&&(e.count++,l=ss.bind(e),t.addEventListener("load",l),t.addEventListener("error",l))}}var Eo=0;function kp(e,t){return e.stylesheets&&e.count===0&&os(e,e.stylesheets),0<e.count||0<e.imgCount?function(l){var i=setTimeout(function(){if(e.stylesheets&&os(e,e.stylesheets),e.unsuspend){var s=e.unsuspend;e.unsuspend=null,s()}},6e4+t);0<e.imgBytes&&Eo===0&&(Eo=62500*tp());var n=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&os(e,e.stylesheets),e.unsuspend)){var s=e.unsuspend;e.unsuspend=null,s()}},(e.imgBytes>Eo?50:800)+t);return e.unsuspend=l,function(){e.unsuspend=null,clearTimeout(i),clearTimeout(n)}}:null}function ss(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)os(this,this.stylesheets);else if(this.unsuspend){var e=this.unsuspend;this.unsuspend=null,e()}}}var rs=null;function os(e,t){e.stylesheets=null,e.unsuspend!==null&&(e.count++,rs=new Map,t.forEach(jp,e),rs=null,ss.call(e))}function jp(e,t){if(!(t.state.loading&4)){var l=rs.get(e);if(l)var i=l.get(null);else{l=new Map,rs.set(e,l);for(var n=e.querySelectorAll("link[data-precedence],style[data-precedence]"),s=0;s<n.length;s++){var o=n[s];(o.nodeName==="LINK"||o.getAttribute("media")!=="not all")&&(l.set(o.dataset.precedence,o),i=o)}i&&l.set(null,i)}n=t.instance,o=n.getAttribute("data-precedence"),s=l.get(o)||i,s===i&&l.set(null,n),l.set(o,n),this.count++,i=ss.bind(this),n.addEventListener("load",i),n.addEventListener("error",i),s?s.parentNode.insertBefore(n,s.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(n,e.firstChild)),t.state.loading|=4}}var Qi={$$typeof:fe,Provider:null,Consumer:null,_currentValue:Q,_currentValue2:Q,_threadCount:0};function Np(e,t,l,i,n,s,o,c,u){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=ri(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=ri(0),this.hiddenUpdates=ri(null),this.identifierPrefix=i,this.onUncaughtError=n,this.onCaughtError=s,this.onRecoverableError=o,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=u,this.incompleteTransitions=new Map}function Of(e,t,l,i,n,s,o,c,u,z,C,R){return e=new Np(e,t,l,o,u,z,C,R,c),t=1,s===!0&&(t|=24),s=_t(3,null,null,t),e.current=s,s.stateNode=e,t=nr(),t.refCount++,e.pooledCache=t,t.refCount++,s.memoizedState={element:i,isDehydrated:l,cache:t},cr(s),e}function Cf(e){return e?(e=Ol,e):Ol}function Df(e,t,l,i,n,s){n=Cf(n),i.context===null?i.context=n:i.pendingContext=n,i=Oa(t),i.payload={element:l},s=s===void 0?null:s,s!==null&&(i.callback=s),l=Ca(e,i,t),l!==null&&(St(l,e,t),wi(l,e,t))}function Mf(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var l=e.retryLane;e.retryLane=l!==0&&l<t?l:t}}function To(e,t){Mf(e,t),(e=e.alternate)&&Mf(e,t)}function Rf(e){if(e.tag===13||e.tag===31){var t=ll(e,67108864);t!==null&&St(t,e,67108864),To(e,67108864)}}function Uf(e){if(e.tag===13||e.tag===31){var t=Mt();t=js(t);var l=ll(e,t);l!==null&&St(l,e,t),To(e,t)}}var cs=!0;function zp(e,t,l,i){var n=T.T;T.T=null;var s=f.p;try{f.p=2,_o(e,t,l,i)}finally{f.p=s,T.T=n}}function wp(e,t,l,i){var n=T.T;T.T=null;var s=f.p;try{f.p=8,_o(e,t,l,i)}finally{f.p=s,T.T=n}}function _o(e,t,l,i){if(cs){var n=Ao(i);if(n===null)po(e,t,i,ds,l),Bf(e,i);else if(Ep(n,e,t,l,i))i.stopPropagation();else if(Bf(e,i),t&4&&-1<Sp.indexOf(e)){for(;n!==null;){var s=vl(n);if(s!==null)switch(s.tag){case 3:if(s=s.stateNode,s.current.memoizedState.isDehydrated){var o=V(s.pendingLanes);if(o!==0){var c=s;for(c.pendingLanes|=2,c.entangledLanes|=2;o;){var u=1<<31-mt(o);c.entanglements[1]|=u,o&=~u}ea(s),(Me&6)===0&&(Xn=he()+500,Gi(0))}}break;case 31:case 13:c=ll(s,2),c!==null&&St(c,s,2),Zn(),To(s,2)}if(s=Ao(i),s===null&&po(e,t,i,ds,l),s===n)break;n=s}n!==null&&i.stopPropagation()}else po(e,t,i,null,l)}}function Ao(e){return e=Os(e),Oo(e)}var ds=null;function Oo(e){if(ds=null,e=yl(e),e!==null){var t=E(e);if(t===null)e=null;else{var l=t.tag;if(l===13){if(e=S(t),e!==null)return e;e=null}else if(l===31){if(e=U(t),e!==null)return e;e=null}else if(l===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}}return ds=e,null}function Lf(e){switch(e){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(De()){case We:return 2;case Ft:return 8;case Et:case Na:return 32;case si:return 268435456;default:return 32}default:return 32}}var Co=!1,Ka=null,qa=null,Va=null,Zi=new Map,Ji=new Map,Xa=[],Sp="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function Bf(e,t){switch(e){case"focusin":case"focusout":Ka=null;break;case"dragenter":case"dragleave":qa=null;break;case"mouseover":case"mouseout":Va=null;break;case"pointerover":case"pointerout":Zi.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":Ji.delete(t.pointerId)}}function Fi(e,t,l,i,n,s){return e===null||e.nativeEvent!==s?(e={blockedOn:t,domEventName:l,eventSystemFlags:i,nativeEvent:s,targetContainers:[n]},t!==null&&(t=vl(t),t!==null&&Rf(t)),e):(e.eventSystemFlags|=i,t=e.targetContainers,n!==null&&t.indexOf(n)===-1&&t.push(n),e)}function Ep(e,t,l,i,n){switch(t){case"focusin":return Ka=Fi(Ka,e,t,l,i,n),!0;case"dragenter":return qa=Fi(qa,e,t,l,i,n),!0;case"mouseover":return Va=Fi(Va,e,t,l,i,n),!0;case"pointerover":var s=n.pointerId;return Zi.set(s,Fi(Zi.get(s)||null,e,t,l,i,n)),!0;case"gotpointercapture":return s=n.pointerId,Ji.set(s,Fi(Ji.get(s)||null,e,t,l,i,n)),!0}return!1}function Hf(e){var t=yl(e.target);if(t!==null){var l=E(t);if(l!==null){if(t=l.tag,t===13){if(t=S(l),t!==null){e.blockedOn=t,Wo(e.priority,function(){Uf(l)});return}}else if(t===31){if(t=U(l),t!==null){e.blockedOn=t,Wo(e.priority,function(){Uf(l)});return}}else if(t===3&&l.stateNode.current.memoizedState.isDehydrated){e.blockedOn=l.tag===3?l.stateNode.containerInfo:null;return}}}e.blockedOn=null}function us(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var l=Ao(e.nativeEvent);if(l===null){l=e.nativeEvent;var i=new l.constructor(l.type,l);As=i,l.target.dispatchEvent(i),As=null}else return t=vl(l),t!==null&&Rf(t),e.blockedOn=l,!1;t.shift()}return!0}function Yf(e,t,l){us(e)&&l.delete(t)}function Tp(){Co=!1,Ka!==null&&us(Ka)&&(Ka=null),qa!==null&&us(qa)&&(qa=null),Va!==null&&us(Va)&&(Va=null),Zi.forEach(Yf),Ji.forEach(Yf)}function fs(e,t){e.blockedOn===t&&(e.blockedOn=null,Co||(Co=!0,r.unstable_scheduleCallback(r.unstable_NormalPriority,Tp)))}var ms=null;function Gf(e){ms!==e&&(ms=e,r.unstable_scheduleCallback(r.unstable_NormalPriority,function(){ms===e&&(ms=null);for(var t=0;t<e.length;t+=3){var l=e[t],i=e[t+1],n=e[t+2];if(typeof i!="function"){if(Oo(i||l)===null)continue;break}var s=vl(l);s!==null&&(e.splice(t,3),t-=3,_r(s,{pending:!0,data:n,method:l.method,action:i},i,n))}}))}function ti(e){function t(u){return fs(u,e)}Ka!==null&&fs(Ka,e),qa!==null&&fs(qa,e),Va!==null&&fs(Va,e),Zi.forEach(t),Ji.forEach(t);for(var l=0;l<Xa.length;l++){var i=Xa[l];i.blockedOn===e&&(i.blockedOn=null)}for(;0<Xa.length&&(l=Xa[0],l.blockedOn===null);)Hf(l),l.blockedOn===null&&Xa.shift();if(l=(e.ownerDocument||e).$$reactFormReplay,l!=null)for(i=0;i<l.length;i+=3){var n=l[i],s=l[i+1],o=n[vt]||null;if(typeof s=="function")o||Gf(l);else if(o){var c=null;if(s&&s.hasAttribute("formAction")){if(n=s,o=s[vt]||null)c=o.formAction;else if(Oo(n)!==null)continue}else c=o.action;typeof c=="function"?l[i+1]=c:(l.splice(i,3),i-=3),Gf(l)}}}function If(){function e(s){s.canIntercept&&s.info==="react-transition"&&s.intercept({handler:function(){return new Promise(function(o){return n=o})},focusReset:"manual",scroll:"manual"})}function t(){n!==null&&(n(),n=null),i||setTimeout(l,20)}function l(){if(!i&&!navigation.transition){var s=navigation.currentEntry;s&&s.url!=null&&navigation.navigate(s.url,{state:s.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var i=!1,n=null;return navigation.addEventListener("navigate",e),navigation.addEventListener("navigatesuccess",t),navigation.addEventListener("navigateerror",t),setTimeout(l,100),function(){i=!0,navigation.removeEventListener("navigate",e),navigation.removeEventListener("navigatesuccess",t),navigation.removeEventListener("navigateerror",t),n!==null&&(n(),n=null)}}}function Do(e){this._internalRoot=e}xs.prototype.render=Do.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(d(409));var l=t.current,i=Mt();Df(l,i,e,t,null,null)},xs.prototype.unmount=Do.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;Df(e.current,2,null,e,null,null),Zn(),t[bl]=null}};function xs(e){this._internalRoot=e}xs.prototype.unstable_scheduleHydration=function(e){if(e){var t=Po();e={blockedOn:null,target:e,priority:t};for(var l=0;l<Xa.length&&t!==0&&t<Xa[l].priority;l++);Xa.splice(l,0,e),l===0&&Hf(e)}};var Kf=v.version;if(Kf!=="19.2.0")throw Error(d(527,Kf,"19.2.0"));f.findDOMNode=function(e){var t=e._reactInternals;if(t===void 0)throw typeof e.render=="function"?Error(d(188)):(e=Object.keys(e).join(","),Error(d(268,e)));return e=h(t),e=e!==null?L(e):null,e=e===null?null:e.stateNode,e};var _p={bundleType:0,version:"19.2.0",rendererPackageName:"react-dom",currentDispatcherRef:T,reconcilerVersion:"19.2.0"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var ps=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!ps.isDisabled&&ps.supportsFiber)try{Ja=ps.inject(_p),ht=ps}catch{}}return Wi.createRoot=function(e,t){if(!k(e))throw Error(d(299));var l=!1,i="",n=Jd,s=Fd,o=Pd;return t!=null&&(t.unstable_strictMode===!0&&(l=!0),t.identifierPrefix!==void 0&&(i=t.identifierPrefix),t.onUncaughtError!==void 0&&(n=t.onUncaughtError),t.onCaughtError!==void 0&&(s=t.onCaughtError),t.onRecoverableError!==void 0&&(o=t.onRecoverableError)),t=Of(e,1,!1,null,null,l,i,null,n,s,o,If),e[bl]=t.current,xo(e),new Do(t)},Wi.hydrateRoot=function(e,t,l){if(!k(e))throw Error(d(299));var i=!1,n="",s=Jd,o=Fd,c=Pd,u=null;return l!=null&&(l.unstable_strictMode===!0&&(i=!0),l.identifierPrefix!==void 0&&(n=l.identifierPrefix),l.onUncaughtError!==void 0&&(s=l.onUncaughtError),l.onCaughtError!==void 0&&(o=l.onCaughtError),l.onRecoverableError!==void 0&&(c=l.onRecoverableError),l.formState!==void 0&&(u=l.formState)),t=Of(e,1,!0,t,l??null,i,n,u,s,o,c,If),t.context=Cf(null),l=t.current,i=Mt(),i=js(i),n=Oa(i),n.callback=null,Ca(l,n,i),l=i,t.current.lanes=l,Wa(t,l),ea(t),e[bl]=t.current,xo(e),new xs(t)},Wi.version="19.2.0",Wi}var $f;function Hp(){if($f)return Uo.exports;$f=1;function r(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r)}catch(v){console.error(v)}}return r(),Uo.exports=Bp(),Uo.exports}var Yp=Hp();const Gp=xx(Yp);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ip=r=>r.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),Kp=r=>r.replace(/^([A-Z])|[\s-_]+(\w)/g,(v,_,d)=>d?d.toUpperCase():_.toLowerCase()),em=r=>{const v=Kp(r);return v.charAt(0).toUpperCase()+v.slice(1)},px=(...r)=>r.filter((v,_,d)=>!!v&&v.trim()!==""&&d.indexOf(v)===_).join(" ").trim(),qp=r=>{for(const v in r)if(v.startsWith("aria-")||v==="role"||v==="title")return!0};/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var Vp={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Xp=g.forwardRef(({color:r="currentColor",size:v=24,strokeWidth:_=2,absoluteStrokeWidth:d,className:k="",children:E,iconNode:S,...U},b)=>g.createElement("svg",{ref:b,...Vp,width:v,height:v,stroke:r,strokeWidth:d?Number(_)*24/Number(v):_,className:px("lucide",k),...!E&&!qp(U)&&{"aria-hidden":"true"},...U},[...S.map(([h,L])=>g.createElement(h,L)),...Array.isArray(E)?E:[E]]));/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Pe=(r,v)=>{const _=g.forwardRef(({className:d,...k},E)=>g.createElement(Xp,{ref:E,iconNode:v,className:px(`lucide-${Ip(em(r))}`,`lucide-${r}`,d),...k}));return _.displayName=em(r),_};/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Qp=[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]],Zp=Pe("arrow-left",Qp);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Jp=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]],ii=Pe("arrow-right",Jp);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Fp=[["path",{d:"M12 8V4H8",key:"hb8ula"}],["rect",{width:"16",height:"12",x:"4",y:"8",rx:"2",key:"enze0r"}],["path",{d:"M2 14h2",key:"vft8re"}],["path",{d:"M20 14h2",key:"4cs60a"}],["path",{d:"M15 13v2",key:"1xurst"}],["path",{d:"M9 13v2",key:"rq6x2g"}]],Pp=Pe("bot",Fp);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Wp=[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]],$p=Pe("check",Wp);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const eh=[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]],Go=Pe("chevron-right",eh);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const th=[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]],Io=Pe("chevron-left",th);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ah=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]],lh=Pe("circle-alert",ah);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ih=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],ai=Pe("circle-check",ih);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const nh=[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]],sh=Pe("loader-circle",nh);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const rh=[["path",{d:"M4 5h16",key:"1tepv9"}],["path",{d:"M4 12h16",key:"1lakjw"}],["path",{d:"M4 19h16",key:"1djgab"}]],oh=Pe("menu",rh);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ch=[["path",{d:"M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",key:"18887p"}]],dh=Pe("message-square",ch);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const uh=[["rect",{x:"14",y:"3",width:"5",height:"18",rx:"1",key:"kaeet6"}],["rect",{x:"5",y:"3",width:"5",height:"18",rx:"1",key:"1wsw3u"}]],fh=Pe("pause",uh);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const mh=[["path",{d:"M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z",key:"10ikf1"}]],xh=Pe("play",mh);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ph=[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}]],Ko=Pe("rotate-ccw",ph);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const hh=[["path",{d:"m21 21-4.34-4.34",key:"14j7rj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}]],gh=Pe("search",hh);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const bh=[["path",{d:"M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",key:"1ffxy3"}],["path",{d:"m21.854 2.147-10.94 10.939",key:"12cjpa"}]],yh=Pe("send",bh);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const vh=[["path",{d:"M10 11v6",key:"nco0om"}],["path",{d:"M14 11v6",key:"outv1u"}],["path",{d:"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6",key:"miytrc"}],["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",key:"e791ji"}]],qo=Pe("trash-2",vh);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const kh=[["path",{d:"M12 3v12",key:"1x0j5s"}],["path",{d:"m17 8-5-5-5 5",key:"7q97r8"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}]],tm=Pe("upload",kh);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const jh=[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]],Nh=Pe("user",jh);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const zh=[["path",{d:"m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5",key:"ftymec"}],["rect",{x:"2",y:"6",width:"14",height:"12",rx:"2",key:"158x01"}]],am=Pe("video",zh);/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const wh=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],Qo=Pe("x",wh),Sh=window.location.hostname!=="localhost",lm=Sh?"https://egzersizlab-clean-production.up.railway.app/api":"http://localhost:5000/api";class Eh{getToken(){return localStorage.getItem("token")}async request(v,_={}){const d=this.getToken(),k={"Content-Type":"application/json",..._.headers};d&&(k.Authorization=`Bearer ${d}`);try{const E=await fetch(`${lm}${v}`,{..._,headers:k}),S=await E.json();if(E.status===401)throw localStorage.removeItem("token"),window.location.href="/#login",new Error("Oturum süresi doldu. Lütfen tekrar giriş yapın.");if(!E.ok)throw new Error(S.error||"Bir hata oluştu");return S}catch(E){throw E instanceof Error?E:new Error("Network hatası. Lütfen internet bağlantınızı kontrol edin.")}}async sendVerificationCode(v,_,d,k){return this.request("/auth/send-verification-code",{method:"POST",body:JSON.stringify({email:v,password:_,name:d,phone:k})})}async verifyAndRegister(v,_,d,k,E){const S=await this.request("/auth/verify-and-register",{method:"POST",body:JSON.stringify({email:v,code:_,password:d,name:k,phone:E})});return S.success&&S.token&&localStorage.setItem("token",S.token),S}async register(v,_,d,k){const E=await this.request("/auth/register",{method:"POST",body:JSON.stringify({email:v,password:_,name:d,phone:k})});return E.success&&E.token&&localStorage.setItem("token",E.token),E}async login(v,_){const d=this.getToken(),k={"Content-Type":"application/json"};d&&(k.Authorization=`Bearer ${d}`);try{const E=await fetch(`${lm}/auth/login`,{method:"POST",headers:k,body:JSON.stringify({email:v,password:_})}),S=await E.json();if(E.status===401)return{success:!1,error:S.error||"E-posta veya şifre hatalı"};if(!E.ok)throw new Error(S.error||"Bir hata oluştu");return S.success&&S.token&&localStorage.setItem("token",S.token),S}catch(E){throw E instanceof Error?E:new Error("Network hatası. Lütfen internet bağlantınızı kontrol edin.")}}async getCurrentUser(){return this.request("/auth/me")}logout(){localStorage.removeItem("token"),window.location.href="/"}isAuthenticated(){return!!this.getToken()}async sendPasswordResetCode(v){return this.request("/auth/forgot-password",{method:"POST",body:JSON.stringify({email:v})})}async resetPassword(v,_,d){return this.request("/auth/reset-password",{method:"POST",body:JSON.stringify({email:v,code:_,newPassword:d})})}async saveDashboardData(v){return this.request("/auth/dashboard/data",{method:"PUT",body:JSON.stringify(v)})}async getDashboardData(){return this.request("/auth/dashboard/data")}}const ta=new Eh,Th=Object.freeze(Object.defineProperty({__proto__:null,apiService:ta},Symbol.toStringTag,{value:"Module"})),_h=({email:r,onClose:v})=>{const[_,d]=g.useState(["","","",""]),[k,E]=g.useState(""),[S,U]=g.useState(""),[b,h]=g.useState(!1),[L,N]=g.useState(!1),[Y,H]=g.useState(null),[B,ae]=g.useState(!1),[Z,G]=g.useState(0),q=g.useRef([]);g.useEffect(()=>{if(Z>0){const I=setTimeout(()=>G(Z-1),1e3);return()=>clearTimeout(I)}},[Z]);const fe=(I,ne)=>{var Se;if(!/^\d*$/.test(ne))return;const se=[..._];se[I]=ne.slice(-1),d(se),H(null),ne&&I<3&&((Se=q.current[I+1])==null||Se.focus())},ee=(I,ne)=>{var se;ne.key==="Backspace"&&!_[I]&&I>0&&((se=q.current[I-1])==null||se.focus())},Re=I=>{var se;I.preventDefault();const ne=I.clipboardData.getData("text").slice(0,4);if(/^\d{4}$/.test(ne)){const Se=ne.split("");d([...Se,...Array(4-Se.length).fill("")].slice(0,4)),(se=q.current[3])==null||se.focus()}},oe=async I=>{var se,Se;I.preventDefault(),H(null);const ne=_.join("");if(ne.length!==4){H("Lütfen 4 haneli kodu giriniz");return}if(k.length<8){H("Şifre en az 8 karakter olmalıdır");return}if(!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(k)){H("Şifre en az bir küçük harf, bir büyük harf ve bir rakam içermelidir");return}if(k!==S){H("Şifreler eşleşmiyor");return}N(!0);try{const re=await ta.resetPassword(r,ne,k);re.success?(alert("Şifreniz başarıyla güncellendi! Lütfen yeni şifrenizle giriş yapın."),v(),window.dispatchEvent(new CustomEvent("openLoginModal"))):(H(re.error||"Kod doğrulanamadı veya şifre güncellenemedi. Lütfen tekrar deneyin."),d(["","","",""]),(se=q.current[0])==null||se.focus())}catch(re){H(re.message||"Bir hata oluştu. Lütfen tekrar deneyin."),d(["","","",""]),(Se=q.current[0])==null||Se.focus()}finally{N(!1)}},X=async()=>{var I;ae(!0),H(null);try{const ne=await ta.sendPasswordResetCode(r);ne.success?(G(60),d(["","","",""]),(I=q.current[0])==null||I.focus()):H(ne.error||"Kod gönderilemedi. Lütfen tekrar deneyin.")}catch(ne){H(ne.message||"Kod gönderilemedi. Lütfen tekrar deneyin.")}finally{ae(!1)}};return a.jsx("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm px-4",children:a.jsx("div",{className:"bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto",children:a.jsxs("div",{className:"p-8",children:[a.jsx("button",{onClick:v,className:"absolute right-4 top-4 text-gray-500 hover:text-gray-700 transition text-xl","aria-label":"Kapat",children:"×"}),a.jsxs("div",{className:"text-center mb-6",children:[a.jsx("div",{className:"w-16 h-16 bg-gradient-to-br from-orange-500 to-red-600 rounded-full flex items-center justify-center mx-auto mb-4",children:a.jsx("svg",{className:"w-8 h-8 text-white",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:a.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"})})}),a.jsx("h2",{className:"text-2xl font-bold text-gray-800 mb-2",children:"Yeni Şifre Belirle"}),a.jsxs("p",{className:"text-gray-600 text-sm",children:[a.jsx("strong",{children:r})," adresine gönderilen 4 haneli kodu giriniz"]})]}),Y&&a.jsx("div",{className:"mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm",children:Y}),a.jsxs("form",{onSubmit:oe,className:"space-y-6",children:[a.jsxs("div",{children:[a.jsx("label",{className:"block text-sm font-semibold text-gray-700 mb-3 text-center",children:"Şifre Sıfırlama Kodu"}),a.jsx("div",{className:"flex gap-3 justify-center",onPaste:Re,children:_.map((I,ne)=>a.jsx("input",{ref:se=>q.current[ne]=se,type:"text",inputMode:"numeric",maxLength:1,value:I,onChange:se=>fe(ne,se.target.value),onKeyDown:se=>ee(ne,se),className:"w-14 h-14 text-center text-2xl font-bold border-2 border-gray-300 rounded-xl focus:outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-200 transition"},ne))}),a.jsx("p",{className:"text-xs text-gray-500 text-center mt-2",children:"Kod 10 dakika geçerlidir"})]}),a.jsxs("div",{children:[a.jsxs("label",{className:"block text-sm font-semibold text-gray-700 mb-2",children:["Yeni Şifre ",a.jsx("span",{className:"text-red-500",children:"*"})]}),a.jsxs("div",{className:"relative",children:[a.jsx("input",{type:b?"text":"password",required:!0,value:k,onChange:I=>E(I.target.value),className:"w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-200 transition",placeholder:"En az 8 karakter"}),a.jsx("button",{type:"button",onClick:()=>h(I=>!I),className:"absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 text-sm",children:b?"Gizle":"Göster"})]}),a.jsx("p",{className:"text-xs text-gray-500 mt-1",children:"En az 8 karakter, bir büyük harf, bir küçük harf ve bir rakam içermelidir"})]}),a.jsxs("div",{children:[a.jsxs("label",{className:"block text-sm font-semibold text-gray-700 mb-2",children:["Yeni Şifre (Tekrar) ",a.jsx("span",{className:"text-red-500",children:"*"})]}),a.jsx("input",{type:b?"text":"password",required:!0,value:S,onChange:I=>U(I.target.value),className:"w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-200 transition",placeholder:"Şifrenizi tekrar giriniz"})]}),a.jsx("button",{type:"submit",disabled:L||_.join("").length!==4||!k||!S,className:"w-full py-3 text-white font-bold rounded-lg shadow-lg bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed",children:L?"Şifre Güncelleniyor...":"Şifreyi Güncelle"}),a.jsx("div",{className:"text-center",children:a.jsx("button",{type:"button",onClick:X,disabled:B||Z>0,className:"text-sm text-orange-600 hover:text-orange-700 font-semibold disabled:text-gray-400 disabled:cursor-not-allowed",children:Z>0?`Yeni kod gönder (${Z}s)`:B?"Gönderiliyor...":"Kodu tekrar gönder"})})]})]})})})},Ah=({onClose:r})=>{const[v,_]=g.useState(""),[d,k]=g.useState(!1),[E,S]=g.useState(null),[U,b]=g.useState(!1),[h,L]=g.useState(!1),[N,Y]=g.useState(""),H=async ae=>{ae.preventDefault(),S(null),k(!0);try{const Z=await ta.sendPasswordResetCode(v);Z.success?(b(!0),Y(v.split("@")[0]),Z.code&&(console.log(`
========================================`),console.log("SIFRE SIFIRLAMA KODU"),console.log("========================================"),console.log(`E-posta: ${v}`),console.log(`KOD: ${Z.code}`),console.log(`========================================
`))):S(Z.error||"Bir hata oluştu. Lütfen tekrar deneyin.")}catch(Z){S(Z.message||"Bir hata oluştu. Lütfen tekrar deneyin.")}finally{k(!1)}},B=()=>{L(!0)};return h?a.jsx(_h,{email:v,onClose:r}):a.jsx("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm px-4",children:a.jsx("div",{className:"bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden",children:a.jsxs("div",{className:"p-8",children:[a.jsx("button",{onClick:r,className:"absolute right-4 top-4 text-gray-500 hover:text-gray-700 transition text-xl","aria-label":"Kapat",children:"×"}),a.jsxs("div",{className:"text-center mb-6",children:[a.jsx("div",{className:"w-16 h-16 bg-gradient-to-br from-orange-500 to-red-600 rounded-full flex items-center justify-center mx-auto mb-4",children:a.jsx("svg",{className:"w-8 h-8 text-white",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:a.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"})})}),a.jsx("h2",{className:"text-2xl font-bold text-gray-800 mb-2",children:"Şifremi Unuttum"}),a.jsx("p",{className:"text-gray-600 text-sm",children:U?"E-posta adresinize şifre sıfırlama kodu gönderildi":"E-posta adresinizi girin, size şifre sıfırlama kodu gönderelim"})]}),E&&a.jsx("div",{className:"mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm",children:E}),U?a.jsxs("div",{className:"space-y-4",children:[a.jsx("div",{className:"p-4 bg-green-50 border border-green-200 rounded-lg",children:a.jsxs("p",{className:"text-green-800 text-sm text-center",children:[a.jsx("strong",{children:v})," adresine şifre sıfırlama kodu gönderildi.",a.jsx("br",{}),"Lütfen e-posta kutunuzu kontrol edin."]})}),a.jsx("button",{onClick:B,className:"w-full py-3 text-white font-bold rounded-lg shadow-lg bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300",children:"Kodu Girdim, Devam Et"}),a.jsx("button",{onClick:r,className:"w-full py-2 text-gray-600 hover:text-gray-800 font-semibold",children:"İptal"})]}):a.jsxs("form",{onSubmit:H,className:"space-y-4",children:[a.jsxs("div",{children:[a.jsxs("label",{className:"block text-sm font-semibold text-gray-700 mb-2",children:["E-posta Adresi ",a.jsx("span",{className:"text-red-500",children:"*"})]}),a.jsx("input",{type:"email",required:!0,value:v,onChange:ae=>_(ae.target.value),className:"w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-200 transition",placeholder:"ornek@email.com"})]}),a.jsx("button",{type:"submit",disabled:d,className:"w-full py-3 text-white font-bold rounded-lg shadow-lg bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed",children:d?"Gönderiliyor...":"Şifre Sıfırlama Kodu Gönder"}),a.jsx("button",{type:"button",onClick:r,className:"w-full py-2 text-gray-600 hover:text-gray-800 font-semibold",children:"İptal"})]})]})})})},hx=({onClose:r,onSuccess:v,onOpenRegister:_})=>{const[d,k]=g.useState(!1),[E,S]=g.useState(!1),[U,b]=g.useState(null),[h,L]=g.useState(!1),[N,Y]=g.useState({email:"",password:""}),H={backgroundImage:'linear-gradient(135deg, rgba(102,126,234,0.95), rgba(118,75,162,0.95)), url("https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=900&q=80")',backgroundSize:"cover",backgroundPosition:"center"};return a.jsxs("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm px-4",children:[a.jsx("style",{children:`
        .floating-icon { animation: float 3s ease-in-out infinite; }
        @keyframes float { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }
        .input-field:focus {
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
        }
        .checkbox-custom {
          appearance: none;
          width: 18px;
          height: 18px;
          border: 2px solid #d1d5db;
          border-radius: 4px;
          cursor: pointer;
          transition: all 0.2s;
          flex-shrink: 0;
        }
        .checkbox-custom:checked {
          background-color: #667eea;
          border-color: #667eea;
          background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='white'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='3' d='M5 13l4 4L19 7'%3E%3C/path%3E%3C/svg%3E");
          background-size: 14px;
          background-position: center;
          background-repeat: no-repeat;
        }
        .login-submit {
          position: relative;
          overflow: hidden;
        }
        .login-submit::before {
          content: '';
          position: absolute;
          top: 0;
          left: -100%;
          width: 100%;
          height: 100%;
          background: linear-gradient(90deg, transparent, rgba(255,255,255,0.25), transparent);
          transition: left 0.6s ease;
        }
        .login-submit:hover::before { left: 100%; }
      `}),a.jsxs("div",{className:"bg-white w-full max-w-5xl rounded-3xl overflow-hidden shadow-2xl grid grid-cols-1 md:grid-cols-2",children:[a.jsx("div",{className:"text-white p-8 md:p-10 flex items-center",style:H,children:a.jsxs("div",{className:"space-y-6 max-w-md text-center md:text-left",children:[a.jsx("div",{className:"floating-icon",children:a.jsx("svg",{className:"w-16 h-16 mx-auto md:mx-0",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:a.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:1.5,d:"M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"})})}),a.jsx("h1",{className:"text-3xl md:text-4xl font-bold leading-tight",children:"Tekrar Hoş Geldiniz"}),a.jsx("p",{className:"text-lg md:text-xl opacity-90 leading-relaxed",children:"İyileşme yolculuğunuza kaldığınız yerden devam edin. Bugün kendiniz için harika bir gün olsun."}),a.jsxs("div",{className:"flex items-center justify-center md:justify-start gap-3 pt-2",children:[a.jsx("div",{className:"h-1 w-12 bg-white opacity-50 rounded"}),a.jsx("div",{className:"h-1 w-12 bg-white opacity-70 rounded"}),a.jsx("div",{className:"h-1 w-12 bg-white opacity-50 rounded"})]})]})}),a.jsxs("div",{className:"p-8 md:p-10 bg-gray-50 relative",children:[a.jsx("button",{onClick:r,className:"absolute right-4 top-4 text-gray-500 hover:text-gray-700 transition text-xl","aria-label":"Kapat",children:"×"}),a.jsxs("div",{className:"bg-white rounded-2xl shadow-lg p-6 md:p-8",children:[a.jsxs("div",{className:"text-center mb-6",children:[a.jsx("h2",{className:"text-3xl font-bold text-gray-800 mb-2",children:"Hesabınıza Giriş Yapın"}),a.jsx("p",{className:"text-gray-600 text-sm",children:"Sağlık yolculuğunuza devam edin"})]}),U&&a.jsx("div",{className:"mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm",children:U}),a.jsxs("form",{className:"space-y-5",onSubmit:async B=>{B.preventDefault(),b(null),S(!0);try{const ae=await ta.login(N.email,N.password);ae.success?(localStorage.setItem("showLoginSuccess","true"),r(),v?v():(window.location.hash="#dashboard",setTimeout(()=>{window.location.reload()},100))):b(ae.error||"Giriş başarısız. Lütfen tekrar deneyin.")}catch(ae){const Z=ae.message||"Bir hata oluştu. Lütfen tekrar deneyin.";b(Z)}finally{S(!1)}},children:[a.jsxs("div",{children:[a.jsxs("label",{className:"block text-sm font-semibold text-gray-700 mb-2",children:["E-posta Adresi ",a.jsx("span",{className:"text-red-500",children:"*"})]}),a.jsx("input",{type:"email",required:!0,value:N.email,onChange:B=>Y({...N,email:B.target.value}),className:"input-field w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-purple-500",placeholder:"ornek@email.com"})]}),a.jsxs("div",{children:[a.jsxs("label",{className:"block text-sm font-semibold text-gray-700 mb-2",children:["Şifre ",a.jsx("span",{className:"text-red-500",children:"*"})]}),a.jsxs("div",{className:"relative",children:[a.jsx("input",{type:d?"text":"password",required:!0,value:N.password,onChange:B=>Y({...N,password:B.target.value}),className:"input-field w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-purple-500",placeholder:"••••••••"}),a.jsx("button",{type:"button",onClick:()=>k(B=>!B),className:"absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 text-sm","aria-label":"Şifreyi göster/gizle",children:d?"Gizle":"Göster"})]})]}),a.jsxs("div",{className:"flex items-center justify-between pt-2",children:[a.jsxs("label",{className:"flex items-center gap-2 cursor-pointer",children:[a.jsx("input",{type:"checkbox",className:"checkbox-custom"}),a.jsx("span",{className:"text-sm text-gray-700",children:"Beni Hatırla"})]}),a.jsx("button",{type:"button",onClick:()=>L(!0),className:"text-sm text-blue-600 font-semibold hover:underline",children:"Şifremi Unuttum"})]}),a.jsx("button",{type:"submit",disabled:E,className:"login-submit w-full py-4 text-white font-bold rounded-lg shadow-lg bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300 mt-6 disabled:opacity-50 disabled:cursor-not-allowed",children:E?"Giriş yapılıyor...":"Giriş Yap"}),a.jsxs("div",{className:"mt-5 text-center text-sm text-gray-600",children:["Henüz hesabınız yok mu?"," ",a.jsx("button",{type:"button",onClick:()=>{r(),_?_():window.location.hash="#register"},className:"text-purple-600 hover:text-purple-700 font-semibold",children:"Kayıt Olun"})]})]})]})]})]}),h&&a.jsx(Ah,{onClose:()=>{L(!1),r()}})]})},gx=({size:r=80})=>a.jsxs("div",{className:"animated-logo-container",style:{width:r,height:r},children:[a.jsx("style",{children:`
        .animated-logo-container {
          position: relative;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        
        .logo-svg {
          width: 100%;
          height: 100%;
        }
        
        /* Pulse ring animation */
        .pulse-ring {
          animation: pulseRing 2s ease-out infinite;
          transform-origin: center;
        }
        
        @keyframes pulseRing {
          0% { transform: scale(0.8); opacity: 0.8; }
          50% { transform: scale(1); opacity: 0.4; }
          100% { transform: scale(0.8); opacity: 0.8; }
        }
        
        /* Figure bounce animation */
        .figure-body {
          animation: figureMove 3s ease-in-out infinite;
          transform-origin: center bottom;
        }
        
        @keyframes figureMove {
          0%, 100% { transform: translateY(0) scaleY(1); }
          25% { transform: translateY(-3px) scaleY(1.02); }
          50% { transform: translateY(0) scaleY(0.98); }
          75% { transform: translateY(-2px) scaleY(1.01); }
        }
        
        /* Arms animation */
        .arm-left {
          animation: armSwingLeft 2s ease-in-out infinite;
          transform-origin: 28px 32px;
        }
        
        .arm-right {
          animation: armSwingRight 2s ease-in-out infinite;
          transform-origin: 52px 32px;
        }
        
        @keyframes armSwingLeft {
          0%, 100% { transform: rotate(-20deg); }
          50% { transform: rotate(30deg); }
        }
        
        @keyframes armSwingRight {
          0%, 100% { transform: rotate(20deg); }
          50% { transform: rotate(-30deg); }
        }
        
        /* Gradient rotation */
        .gradient-bg {
          animation: gradientShift 4s linear infinite;
        }
        
        @keyframes gradientShift {
          0% { stop-color: #667eea; }
          50% { stop-color: #764ba2; }
          100% { stop-color: #667eea; }
        }
        
        /* Sparkle effect */
        .sparkle {
          animation: sparkle 2s ease-in-out infinite;
        }
        
        .sparkle:nth-child(1) { animation-delay: 0s; }
        .sparkle:nth-child(2) { animation-delay: 0.5s; }
        .sparkle:nth-child(3) { animation-delay: 1s; }
        
        @keyframes sparkle {
          0%, 100% { opacity: 0; transform: scale(0); }
          50% { opacity: 1; transform: scale(1); }
        }
      `}),a.jsxs("svg",{viewBox:"0 0 80 80",className:"logo-svg",children:[a.jsxs("defs",{children:[a.jsxs("linearGradient",{id:"logoGradient",x1:"0%",y1:"0%",x2:"100%",y2:"100%",children:[a.jsx("stop",{offset:"0%",stopColor:"#667eea",className:"gradient-bg"}),a.jsx("stop",{offset:"100%",stopColor:"#10b981"})]}),a.jsxs("linearGradient",{id:"accentGradient",x1:"0%",y1:"0%",x2:"100%",y2:"100%",children:[a.jsx("stop",{offset:"0%",stopColor:"#f59e0b"}),a.jsx("stop",{offset:"100%",stopColor:"#ef4444"})]}),a.jsxs("filter",{id:"glow",children:[a.jsx("feGaussianBlur",{stdDeviation:"2",result:"coloredBlur"}),a.jsxs("feMerge",{children:[a.jsx("feMergeNode",{in:"coloredBlur"}),a.jsx("feMergeNode",{in:"SourceGraphic"})]})]})]}),a.jsx("circle",{cx:"40",cy:"40",r:"36",fill:"url(#logoGradient)",opacity:"0.15",className:"pulse-ring"}),a.jsx("circle",{cx:"40",cy:"40",r:"32",fill:"url(#logoGradient)",opacity:"0.1"}),a.jsx("circle",{cx:"40",cy:"40",r:"35",fill:"none",stroke:"url(#logoGradient)",strokeWidth:"3",strokeLinecap:"round",strokeDasharray:"180 220",className:"pulse-ring"}),a.jsxs("g",{className:"figure-body",children:[a.jsx("circle",{cx:"40",cy:"24",r:"8",fill:"url(#logoGradient)",filter:"url(#glow)"}),a.jsx("path",{d:"M40 32 L40 52",stroke:"url(#logoGradient)",strokeWidth:"4",strokeLinecap:"round"}),a.jsx("path",{d:"M40 52 L32 66",stroke:"url(#logoGradient)",strokeWidth:"4",strokeLinecap:"round"}),a.jsx("path",{d:"M40 52 L48 66",stroke:"url(#logoGradient)",strokeWidth:"4",strokeLinecap:"round"})]}),a.jsx("path",{d:"M40 36 L26 28",stroke:"url(#logoGradient)",strokeWidth:"4",strokeLinecap:"round",className:"arm-left"}),a.jsx("path",{d:"M40 36 L54 28",stroke:"url(#logoGradient)",strokeWidth:"4",strokeLinecap:"round",className:"arm-right"}),a.jsxs("g",{className:"arm-left",children:[a.jsx("rect",{x:"20",y:"22",width:"12",height:"4",rx:"2",fill:"url(#accentGradient)"}),a.jsx("circle",{cx:"20",cy:"24",r:"4",fill:"url(#accentGradient)"}),a.jsx("circle",{cx:"32",cy:"24",r:"4",fill:"url(#accentGradient)"})]}),a.jsx("circle",{cx:"18",cy:"18",r:"2",fill:"#f59e0b",className:"sparkle"}),a.jsx("circle",{cx:"62",cy:"45",r:"1.5",fill:"#10b981",className:"sparkle"}),a.jsx("circle",{cx:"25",cy:"58",r:"1.5",fill:"#667eea",className:"sparkle"}),a.jsx("path",{d:"M12 40 Q8 42, 12 44",stroke:"#667eea",strokeWidth:"1.5",fill:"none",opacity:"0.5",strokeLinecap:"round",className:"pulse-ring"}),a.jsx("path",{d:"M68 40 Q72 42, 68 44",stroke:"#667eea",strokeWidth:"1.5",fill:"none",opacity:"0.5",strokeLinecap:"round",className:"pulse-ring"})]})]}),Yo=[{href:"#hero",label:"Ana Sayfa"},{href:"#process",label:"Sistem Nasıl İşliyor?"},{href:"#packages",label:"Hizmet Paketleri"},{href:"#blog",label:"Blog"},{href:"#testimonials",label:"Müşteri Yorumları"},{href:"#about",label:"Hakkımızda"},{href:"#contact",label:"İletişim"}],Oh=({onOpenRegister:r,isAuthenticated:v=!1})=>{const[_,d]=g.useState(!1),[k,E]=g.useState("#hero"),[S,U]=g.useState(!1),b=()=>{r&&r()};g.useEffect(()=>{const N=()=>{const Y=window.location.hash||"#hero";E(Y)};return N(),window.addEventListener("hashchange",N),()=>window.removeEventListener("hashchange",N)},[]),g.useEffect(()=>{const N=Yo.map(H=>H.href.replace("#","")),Y=new IntersectionObserver(H=>{H.forEach(B=>{B.isIntersecting&&E(`#${B.target.id}`)})},{root:null,rootMargin:"0px 0px -60% 0px",threshold:.2});return N.forEach(H=>{const B=document.getElementById(H);B&&Y.observe(B)}),()=>Y.disconnect()},[]);const h=N=>{E(N),d(!1)},L=N=>`px-3 py-2 rounded-full transition-colors ${k===N?"bg-blue-600 text-white shadow-md":"text-gray-700 hover:bg-blue-50 hover:text-blue-700"}`;return a.jsxs(a.Fragment,{children:[a.jsxs("header",{className:"w-full bg-white shadow-sm sticky top-0 z-40",children:[a.jsx("div",{className:"hidden md:block w-full bg-gradient-to-r from-[#263562] to-[#1e2a4a] text-white py-3 shadow-sm",children:a.jsxs("div",{className:"container mx-auto px-6 flex justify-between items-center",children:[a.jsxs("div",{className:"flex items-center gap-2 text-sm font-medium",children:[a.jsx("svg",{className:"w-4 h-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:a.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"})}),a.jsx("span",{children:"iletisim@egzersizlab.com"})]}),a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx("a",{href:"#",onClick:N=>{N.preventDefault(),U(!0)},className:"relative px-6 py-2 text-sm font-semibold rounded-lg border-2 border-white bg-transparent text-white transition hover:bg-white hover:text-[#263562]",children:"Giriş Yap"}),a.jsx("div",{className:"w-px h-6 bg-white/30"}),a.jsx("a",{href:"#",onClick:N=>{N.preventDefault(),b()},className:"relative px-6 py-2 text-sm font-semibold rounded-lg bg-blue-500 hover:bg-blue-600 text-white shadow-md hover:shadow-lg transition",children:"Kayıt Ol"})]})]})}),a.jsx("div",{className:"container mx-auto px-4 py-4",children:a.jsxs("div",{className:"flex justify-between items-center",children:[a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx(gx,{size:70}),a.jsxs("div",{className:"flex flex-col",children:[a.jsx("span",{className:"text-3xl font-bold bg-gradient-to-r from-[#667eea] to-[#10b981] bg-clip-text text-transparent",children:"EgzersizLab"}),a.jsx("span",{className:"text-xs text-gray-500 font-medium tracking-wider",children:"DİJİTAL REHABİLİTASYON"})]})]}),a.jsx("nav",{className:"hidden lg:flex items-center gap-3 font-medium text-gray-600 bg-white/70 backdrop-blur-lg rounded-full px-3 py-2 shadow-sm border border-gray-100",children:Yo.map(N=>a.jsx("a",{href:N.href,onClick:()=>h(N.href),className:L(N.href),children:N.label},N.href))}),a.jsx("div",{className:"hidden lg:flex items-center gap-4",children:a.jsxs("div",{className:"relative",children:[a.jsx("input",{type:"text",placeholder:"Ara...",className:"pl-4 pr-10 py-2 border border-gray-200 rounded-full text-sm focus:outline-none focus:border-blue-500 w-48 transition-all focus:w-64"}),a.jsx(gh,{className:"absolute right-3 top-2.5 text-gray-400",size:18})]})}),a.jsx("button",{className:"lg:hidden p-2 text-gray-700",onClick:()=>d(!_),children:_?a.jsx(Qo,{size:24}):a.jsx(oh,{size:24})})]})}),_&&a.jsx("div",{className:"lg:hidden bg-white border-t border-gray-100 py-4 px-4 shadow-lg absolute w-full left-0 z-50",children:a.jsxs("div",{className:"flex flex-col space-y-4",children:[Yo.map(N=>a.jsx("a",{href:N.href,onClick:()=>h(N.href),className:L(N.href),children:N.label},N.href)),a.jsxs("div",{className:"border-t pt-4 flex flex-col gap-3",children:[a.jsxs("button",{className:"flex items-center gap-2 text-gray-700 font-medium",onClick:()=>U(!0),children:[a.jsx(Nh,{size:18})," Giriş Yap"]}),a.jsx("button",{className:"bg-[#263562] text-white py-2 rounded-lg font-medium w-full",onClick:b,children:"Kayıt Ol"})]})]})})]}),S&&a.jsx(hx,{onClose:()=>U(!1),onOpenRegister:()=>{U(!1),b()}})]})};/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *//**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */var im;(function(r){r.OUTCOME_UNSPECIFIED="OUTCOME_UNSPECIFIED",r.OUTCOME_OK="OUTCOME_OK",r.OUTCOME_FAILED="OUTCOME_FAILED",r.OUTCOME_DEADLINE_EXCEEDED="OUTCOME_DEADLINE_EXCEEDED"})(im||(im={}));var nm;(function(r){r.LANGUAGE_UNSPECIFIED="LANGUAGE_UNSPECIFIED",r.PYTHON="PYTHON"})(nm||(nm={}));var sm;(function(r){r.SCHEDULING_UNSPECIFIED="SCHEDULING_UNSPECIFIED",r.SILENT="SILENT",r.WHEN_IDLE="WHEN_IDLE",r.INTERRUPT="INTERRUPT"})(sm||(sm={}));var rm;(function(r){r.TYPE_UNSPECIFIED="TYPE_UNSPECIFIED",r.STRING="STRING",r.NUMBER="NUMBER",r.INTEGER="INTEGER",r.BOOLEAN="BOOLEAN",r.ARRAY="ARRAY",r.OBJECT="OBJECT",r.NULL="NULL"})(rm||(rm={}));var om;(function(r){r.MODE_UNSPECIFIED="MODE_UNSPECIFIED",r.MODE_DYNAMIC="MODE_DYNAMIC"})(om||(om={}));var cm;(function(r){r.API_SPEC_UNSPECIFIED="API_SPEC_UNSPECIFIED",r.SIMPLE_SEARCH="SIMPLE_SEARCH",r.ELASTIC_SEARCH="ELASTIC_SEARCH"})(cm||(cm={}));var dm;(function(r){r.AUTH_TYPE_UNSPECIFIED="AUTH_TYPE_UNSPECIFIED",r.NO_AUTH="NO_AUTH",r.API_KEY_AUTH="API_KEY_AUTH",r.HTTP_BASIC_AUTH="HTTP_BASIC_AUTH",r.GOOGLE_SERVICE_ACCOUNT_AUTH="GOOGLE_SERVICE_ACCOUNT_AUTH",r.OAUTH="OAUTH",r.OIDC_AUTH="OIDC_AUTH"})(dm||(dm={}));var um;(function(r){r.HTTP_IN_UNSPECIFIED="HTTP_IN_UNSPECIFIED",r.HTTP_IN_QUERY="HTTP_IN_QUERY",r.HTTP_IN_HEADER="HTTP_IN_HEADER",r.HTTP_IN_PATH="HTTP_IN_PATH",r.HTTP_IN_BODY="HTTP_IN_BODY",r.HTTP_IN_COOKIE="HTTP_IN_COOKIE"})(um||(um={}));var fm;(function(r){r.PHISH_BLOCK_THRESHOLD_UNSPECIFIED="PHISH_BLOCK_THRESHOLD_UNSPECIFIED",r.BLOCK_LOW_AND_ABOVE="BLOCK_LOW_AND_ABOVE",r.BLOCK_MEDIUM_AND_ABOVE="BLOCK_MEDIUM_AND_ABOVE",r.BLOCK_HIGH_AND_ABOVE="BLOCK_HIGH_AND_ABOVE",r.BLOCK_HIGHER_AND_ABOVE="BLOCK_HIGHER_AND_ABOVE",r.BLOCK_VERY_HIGH_AND_ABOVE="BLOCK_VERY_HIGH_AND_ABOVE",r.BLOCK_ONLY_EXTREMELY_HIGH="BLOCK_ONLY_EXTREMELY_HIGH"})(fm||(fm={}));var mm;(function(r){r.THINKING_LEVEL_UNSPECIFIED="THINKING_LEVEL_UNSPECIFIED",r.LOW="LOW",r.HIGH="HIGH"})(mm||(mm={}));var xm;(function(r){r.HARM_CATEGORY_UNSPECIFIED="HARM_CATEGORY_UNSPECIFIED",r.HARM_CATEGORY_HARASSMENT="HARM_CATEGORY_HARASSMENT",r.HARM_CATEGORY_HATE_SPEECH="HARM_CATEGORY_HATE_SPEECH",r.HARM_CATEGORY_SEXUALLY_EXPLICIT="HARM_CATEGORY_SEXUALLY_EXPLICIT",r.HARM_CATEGORY_DANGEROUS_CONTENT="HARM_CATEGORY_DANGEROUS_CONTENT",r.HARM_CATEGORY_CIVIC_INTEGRITY="HARM_CATEGORY_CIVIC_INTEGRITY",r.HARM_CATEGORY_IMAGE_HATE="HARM_CATEGORY_IMAGE_HATE",r.HARM_CATEGORY_IMAGE_DANGEROUS_CONTENT="HARM_CATEGORY_IMAGE_DANGEROUS_CONTENT",r.HARM_CATEGORY_IMAGE_HARASSMENT="HARM_CATEGORY_IMAGE_HARASSMENT",r.HARM_CATEGORY_IMAGE_SEXUALLY_EXPLICIT="HARM_CATEGORY_IMAGE_SEXUALLY_EXPLICIT",r.HARM_CATEGORY_JAILBREAK="HARM_CATEGORY_JAILBREAK"})(xm||(xm={}));var pm;(function(r){r.HARM_BLOCK_METHOD_UNSPECIFIED="HARM_BLOCK_METHOD_UNSPECIFIED",r.SEVERITY="SEVERITY",r.PROBABILITY="PROBABILITY"})(pm||(pm={}));var hm;(function(r){r.HARM_BLOCK_THRESHOLD_UNSPECIFIED="HARM_BLOCK_THRESHOLD_UNSPECIFIED",r.BLOCK_LOW_AND_ABOVE="BLOCK_LOW_AND_ABOVE",r.BLOCK_MEDIUM_AND_ABOVE="BLOCK_MEDIUM_AND_ABOVE",r.BLOCK_ONLY_HIGH="BLOCK_ONLY_HIGH",r.BLOCK_NONE="BLOCK_NONE",r.OFF="OFF"})(hm||(hm={}));var gm;(function(r){r.FINISH_REASON_UNSPECIFIED="FINISH_REASON_UNSPECIFIED",r.STOP="STOP",r.MAX_TOKENS="MAX_TOKENS",r.SAFETY="SAFETY",r.RECITATION="RECITATION",r.LANGUAGE="LANGUAGE",r.OTHER="OTHER",r.BLOCKLIST="BLOCKLIST",r.PROHIBITED_CONTENT="PROHIBITED_CONTENT",r.SPII="SPII",r.MALFORMED_FUNCTION_CALL="MALFORMED_FUNCTION_CALL",r.IMAGE_SAFETY="IMAGE_SAFETY",r.UNEXPECTED_TOOL_CALL="UNEXPECTED_TOOL_CALL",r.IMAGE_PROHIBITED_CONTENT="IMAGE_PROHIBITED_CONTENT",r.NO_IMAGE="NO_IMAGE"})(gm||(gm={}));var bm;(function(r){r.HARM_PROBABILITY_UNSPECIFIED="HARM_PROBABILITY_UNSPECIFIED",r.NEGLIGIBLE="NEGLIGIBLE",r.LOW="LOW",r.MEDIUM="MEDIUM",r.HIGH="HIGH"})(bm||(bm={}));var ym;(function(r){r.HARM_SEVERITY_UNSPECIFIED="HARM_SEVERITY_UNSPECIFIED",r.HARM_SEVERITY_NEGLIGIBLE="HARM_SEVERITY_NEGLIGIBLE",r.HARM_SEVERITY_LOW="HARM_SEVERITY_LOW",r.HARM_SEVERITY_MEDIUM="HARM_SEVERITY_MEDIUM",r.HARM_SEVERITY_HIGH="HARM_SEVERITY_HIGH"})(ym||(ym={}));var vm;(function(r){r.URL_RETRIEVAL_STATUS_UNSPECIFIED="URL_RETRIEVAL_STATUS_UNSPECIFIED",r.URL_RETRIEVAL_STATUS_SUCCESS="URL_RETRIEVAL_STATUS_SUCCESS",r.URL_RETRIEVAL_STATUS_ERROR="URL_RETRIEVAL_STATUS_ERROR",r.URL_RETRIEVAL_STATUS_PAYWALL="URL_RETRIEVAL_STATUS_PAYWALL",r.URL_RETRIEVAL_STATUS_UNSAFE="URL_RETRIEVAL_STATUS_UNSAFE"})(vm||(vm={}));var km;(function(r){r.BLOCKED_REASON_UNSPECIFIED="BLOCKED_REASON_UNSPECIFIED",r.SAFETY="SAFETY",r.OTHER="OTHER",r.BLOCKLIST="BLOCKLIST",r.PROHIBITED_CONTENT="PROHIBITED_CONTENT",r.IMAGE_SAFETY="IMAGE_SAFETY",r.MODEL_ARMOR="MODEL_ARMOR",r.JAILBREAK="JAILBREAK"})(km||(km={}));var jm;(function(r){r.TRAFFIC_TYPE_UNSPECIFIED="TRAFFIC_TYPE_UNSPECIFIED",r.ON_DEMAND="ON_DEMAND",r.PROVISIONED_THROUGHPUT="PROVISIONED_THROUGHPUT"})(jm||(jm={}));var Nm;(function(r){r.MODALITY_UNSPECIFIED="MODALITY_UNSPECIFIED",r.TEXT="TEXT",r.IMAGE="IMAGE",r.AUDIO="AUDIO"})(Nm||(Nm={}));var zm;(function(r){r.MEDIA_RESOLUTION_UNSPECIFIED="MEDIA_RESOLUTION_UNSPECIFIED",r.MEDIA_RESOLUTION_LOW="MEDIA_RESOLUTION_LOW",r.MEDIA_RESOLUTION_MEDIUM="MEDIA_RESOLUTION_MEDIUM",r.MEDIA_RESOLUTION_HIGH="MEDIA_RESOLUTION_HIGH"})(zm||(zm={}));var wm;(function(r){r.TUNING_MODE_UNSPECIFIED="TUNING_MODE_UNSPECIFIED",r.TUNING_MODE_FULL="TUNING_MODE_FULL",r.TUNING_MODE_PEFT_ADAPTER="TUNING_MODE_PEFT_ADAPTER"})(wm||(wm={}));var Sm;(function(r){r.ADAPTER_SIZE_UNSPECIFIED="ADAPTER_SIZE_UNSPECIFIED",r.ADAPTER_SIZE_ONE="ADAPTER_SIZE_ONE",r.ADAPTER_SIZE_TWO="ADAPTER_SIZE_TWO",r.ADAPTER_SIZE_FOUR="ADAPTER_SIZE_FOUR",r.ADAPTER_SIZE_EIGHT="ADAPTER_SIZE_EIGHT",r.ADAPTER_SIZE_SIXTEEN="ADAPTER_SIZE_SIXTEEN",r.ADAPTER_SIZE_THIRTY_TWO="ADAPTER_SIZE_THIRTY_TWO"})(Sm||(Sm={}));var Em;(function(r){r.JOB_STATE_UNSPECIFIED="JOB_STATE_UNSPECIFIED",r.JOB_STATE_QUEUED="JOB_STATE_QUEUED",r.JOB_STATE_PENDING="JOB_STATE_PENDING",r.JOB_STATE_RUNNING="JOB_STATE_RUNNING",r.JOB_STATE_SUCCEEDED="JOB_STATE_SUCCEEDED",r.JOB_STATE_FAILED="JOB_STATE_FAILED",r.JOB_STATE_CANCELLING="JOB_STATE_CANCELLING",r.JOB_STATE_CANCELLED="JOB_STATE_CANCELLED",r.JOB_STATE_PAUSED="JOB_STATE_PAUSED",r.JOB_STATE_EXPIRED="JOB_STATE_EXPIRED",r.JOB_STATE_UPDATING="JOB_STATE_UPDATING",r.JOB_STATE_PARTIALLY_SUCCEEDED="JOB_STATE_PARTIALLY_SUCCEEDED"})(Em||(Em={}));var Tm;(function(r){r.TUNING_TASK_UNSPECIFIED="TUNING_TASK_UNSPECIFIED",r.TUNING_TASK_I2V="TUNING_TASK_I2V",r.TUNING_TASK_T2V="TUNING_TASK_T2V",r.TUNING_TASK_R2V="TUNING_TASK_R2V"})(Tm||(Tm={}));var _m;(function(r){r.MEDIA_RESOLUTION_UNSPECIFIED="MEDIA_RESOLUTION_UNSPECIFIED",r.MEDIA_RESOLUTION_LOW="MEDIA_RESOLUTION_LOW",r.MEDIA_RESOLUTION_MEDIUM="MEDIA_RESOLUTION_MEDIUM",r.MEDIA_RESOLUTION_HIGH="MEDIA_RESOLUTION_HIGH"})(_m||(_m={}));var Am;(function(r){r.FEATURE_SELECTION_PREFERENCE_UNSPECIFIED="FEATURE_SELECTION_PREFERENCE_UNSPECIFIED",r.PRIORITIZE_QUALITY="PRIORITIZE_QUALITY",r.BALANCED="BALANCED",r.PRIORITIZE_COST="PRIORITIZE_COST"})(Am||(Am={}));var Om;(function(r){r.UNSPECIFIED="UNSPECIFIED",r.BLOCKING="BLOCKING",r.NON_BLOCKING="NON_BLOCKING"})(Om||(Om={}));var Cm;(function(r){r.MODE_UNSPECIFIED="MODE_UNSPECIFIED",r.MODE_DYNAMIC="MODE_DYNAMIC"})(Cm||(Cm={}));var Dm;(function(r){r.ENVIRONMENT_UNSPECIFIED="ENVIRONMENT_UNSPECIFIED",r.ENVIRONMENT_BROWSER="ENVIRONMENT_BROWSER"})(Dm||(Dm={}));var Mm;(function(r){r.MODE_UNSPECIFIED="MODE_UNSPECIFIED",r.AUTO="AUTO",r.ANY="ANY",r.NONE="NONE",r.VALIDATED="VALIDATED"})(Mm||(Mm={}));var Rm;(function(r){r.BLOCK_LOW_AND_ABOVE="BLOCK_LOW_AND_ABOVE",r.BLOCK_MEDIUM_AND_ABOVE="BLOCK_MEDIUM_AND_ABOVE",r.BLOCK_ONLY_HIGH="BLOCK_ONLY_HIGH",r.BLOCK_NONE="BLOCK_NONE"})(Rm||(Rm={}));var Um;(function(r){r.DONT_ALLOW="DONT_ALLOW",r.ALLOW_ADULT="ALLOW_ADULT",r.ALLOW_ALL="ALLOW_ALL"})(Um||(Um={}));var Lm;(function(r){r.auto="auto",r.en="en",r.ja="ja",r.ko="ko",r.hi="hi",r.zh="zh",r.pt="pt",r.es="es"})(Lm||(Lm={}));var Bm;(function(r){r.MASK_MODE_DEFAULT="MASK_MODE_DEFAULT",r.MASK_MODE_USER_PROVIDED="MASK_MODE_USER_PROVIDED",r.MASK_MODE_BACKGROUND="MASK_MODE_BACKGROUND",r.MASK_MODE_FOREGROUND="MASK_MODE_FOREGROUND",r.MASK_MODE_SEMANTIC="MASK_MODE_SEMANTIC"})(Bm||(Bm={}));var Hm;(function(r){r.CONTROL_TYPE_DEFAULT="CONTROL_TYPE_DEFAULT",r.CONTROL_TYPE_CANNY="CONTROL_TYPE_CANNY",r.CONTROL_TYPE_SCRIBBLE="CONTROL_TYPE_SCRIBBLE",r.CONTROL_TYPE_FACE_MESH="CONTROL_TYPE_FACE_MESH"})(Hm||(Hm={}));var Ym;(function(r){r.SUBJECT_TYPE_DEFAULT="SUBJECT_TYPE_DEFAULT",r.SUBJECT_TYPE_PERSON="SUBJECT_TYPE_PERSON",r.SUBJECT_TYPE_ANIMAL="SUBJECT_TYPE_ANIMAL",r.SUBJECT_TYPE_PRODUCT="SUBJECT_TYPE_PRODUCT"})(Ym||(Ym={}));var Gm;(function(r){r.EDIT_MODE_DEFAULT="EDIT_MODE_DEFAULT",r.EDIT_MODE_INPAINT_REMOVAL="EDIT_MODE_INPAINT_REMOVAL",r.EDIT_MODE_INPAINT_INSERTION="EDIT_MODE_INPAINT_INSERTION",r.EDIT_MODE_OUTPAINT="EDIT_MODE_OUTPAINT",r.EDIT_MODE_CONTROLLED_EDITING="EDIT_MODE_CONTROLLED_EDITING",r.EDIT_MODE_STYLE="EDIT_MODE_STYLE",r.EDIT_MODE_BGSWAP="EDIT_MODE_BGSWAP",r.EDIT_MODE_PRODUCT_IMAGE="EDIT_MODE_PRODUCT_IMAGE"})(Gm||(Gm={}));var Im;(function(r){r.FOREGROUND="FOREGROUND",r.BACKGROUND="BACKGROUND",r.PROMPT="PROMPT",r.SEMANTIC="SEMANTIC",r.INTERACTIVE="INTERACTIVE"})(Im||(Im={}));var Km;(function(r){r.ASSET="ASSET",r.STYLE="STYLE"})(Km||(Km={}));var qm;(function(r){r.INSERT="INSERT",r.REMOVE="REMOVE",r.REMOVE_STATIC="REMOVE_STATIC",r.OUTPAINT="OUTPAINT"})(qm||(qm={}));var Vm;(function(r){r.OPTIMIZED="OPTIMIZED",r.LOSSLESS="LOSSLESS"})(Vm||(Vm={}));var Xm;(function(r){r.SUPERVISED_FINE_TUNING="SUPERVISED_FINE_TUNING",r.PREFERENCE_TUNING="PREFERENCE_TUNING"})(Xm||(Xm={}));var Qm;(function(r){r.STATE_UNSPECIFIED="STATE_UNSPECIFIED",r.STATE_PENDING="STATE_PENDING",r.STATE_ACTIVE="STATE_ACTIVE",r.STATE_FAILED="STATE_FAILED"})(Qm||(Qm={}));var Zm;(function(r){r.STATE_UNSPECIFIED="STATE_UNSPECIFIED",r.PROCESSING="PROCESSING",r.ACTIVE="ACTIVE",r.FAILED="FAILED"})(Zm||(Zm={}));var Jm;(function(r){r.SOURCE_UNSPECIFIED="SOURCE_UNSPECIFIED",r.UPLOADED="UPLOADED",r.GENERATED="GENERATED"})(Jm||(Jm={}));var Fm;(function(r){r.TURN_COMPLETE_REASON_UNSPECIFIED="TURN_COMPLETE_REASON_UNSPECIFIED",r.MALFORMED_FUNCTION_CALL="MALFORMED_FUNCTION_CALL",r.RESPONSE_REJECTED="RESPONSE_REJECTED",r.NEED_MORE_INPUT="NEED_MORE_INPUT"})(Fm||(Fm={}));var Pm;(function(r){r.MODALITY_UNSPECIFIED="MODALITY_UNSPECIFIED",r.TEXT="TEXT",r.IMAGE="IMAGE",r.VIDEO="VIDEO",r.AUDIO="AUDIO",r.DOCUMENT="DOCUMENT"})(Pm||(Pm={}));var Wm;(function(r){r.START_SENSITIVITY_UNSPECIFIED="START_SENSITIVITY_UNSPECIFIED",r.START_SENSITIVITY_HIGH="START_SENSITIVITY_HIGH",r.START_SENSITIVITY_LOW="START_SENSITIVITY_LOW"})(Wm||(Wm={}));var $m;(function(r){r.END_SENSITIVITY_UNSPECIFIED="END_SENSITIVITY_UNSPECIFIED",r.END_SENSITIVITY_HIGH="END_SENSITIVITY_HIGH",r.END_SENSITIVITY_LOW="END_SENSITIVITY_LOW"})($m||($m={}));var ex;(function(r){r.ACTIVITY_HANDLING_UNSPECIFIED="ACTIVITY_HANDLING_UNSPECIFIED",r.START_OF_ACTIVITY_INTERRUPTS="START_OF_ACTIVITY_INTERRUPTS",r.NO_INTERRUPTION="NO_INTERRUPTION"})(ex||(ex={}));var tx;(function(r){r.TURN_COVERAGE_UNSPECIFIED="TURN_COVERAGE_UNSPECIFIED",r.TURN_INCLUDES_ONLY_ACTIVITY="TURN_INCLUDES_ONLY_ACTIVITY",r.TURN_INCLUDES_ALL_INPUT="TURN_INCLUDES_ALL_INPUT"})(tx||(tx={}));var ax;(function(r){r.SCALE_UNSPECIFIED="SCALE_UNSPECIFIED",r.C_MAJOR_A_MINOR="C_MAJOR_A_MINOR",r.D_FLAT_MAJOR_B_FLAT_MINOR="D_FLAT_MAJOR_B_FLAT_MINOR",r.D_MAJOR_B_MINOR="D_MAJOR_B_MINOR",r.E_FLAT_MAJOR_C_MINOR="E_FLAT_MAJOR_C_MINOR",r.E_MAJOR_D_FLAT_MINOR="E_MAJOR_D_FLAT_MINOR",r.F_MAJOR_D_MINOR="F_MAJOR_D_MINOR",r.G_FLAT_MAJOR_E_FLAT_MINOR="G_FLAT_MAJOR_E_FLAT_MINOR",r.G_MAJOR_E_MINOR="G_MAJOR_E_MINOR",r.A_FLAT_MAJOR_F_MINOR="A_FLAT_MAJOR_F_MINOR",r.A_MAJOR_G_FLAT_MINOR="A_MAJOR_G_FLAT_MINOR",r.B_FLAT_MAJOR_G_MINOR="B_FLAT_MAJOR_G_MINOR",r.B_MAJOR_A_FLAT_MINOR="B_MAJOR_A_FLAT_MINOR"})(ax||(ax={}));var lx;(function(r){r.MUSIC_GENERATION_MODE_UNSPECIFIED="MUSIC_GENERATION_MODE_UNSPECIFIED",r.QUALITY="QUALITY",r.DIVERSITY="DIVERSITY",r.VOCALIZATION="VOCALIZATION"})(lx||(lx={}));var ix;(function(r){r.PLAYBACK_CONTROL_UNSPECIFIED="PLAYBACK_CONTROL_UNSPECIFIED",r.PLAY="PLAY",r.PAUSE="PAUSE",r.STOP="STOP",r.RESET_CONTEXT="RESET_CONTEXT"})(ix||(ix={}));/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */var nx;(function(r){r.PAGED_ITEM_BATCH_JOBS="batchJobs",r.PAGED_ITEM_MODELS="models",r.PAGED_ITEM_TUNING_JOBS="tuningJobs",r.PAGED_ITEM_FILES="files",r.PAGED_ITEM_CACHED_CONTENTS="cachedContents",r.PAGED_ITEM_FILE_SEARCH_STORES="fileSearchStores",r.PAGED_ITEM_DOCUMENTS="documents"})(nx||(nx={}));console.warn("API_KEY not found in environment variables. Gemini features will be disabled.");const Ch=async r=>"API Anahtarı eksik. Lütfen yapılandırmayı kontrol edin.",sx="egersizlab_chat_messages",rx="egersizlab_deleted_messages",Dh=()=>{const r=[{role:"model",text:"Merhaba! Ben EgzersizLab asistanıyım. Size hangi konuda yardımcı olabilirim? Kurs önerisi ister misiniz?"}],v=()=>{try{const q=localStorage.getItem(sx);if(q){const fe=JSON.parse(q);return fe.length>0?fe:r}}catch(q){console.error("Mesajlar yüklenirken hata:",q)}return r},[_,d]=g.useState(!1),[k,E]=g.useState(v),[S,U]=g.useState(()=>{try{const q=localStorage.getItem(rx);return q?JSON.parse(q):[]}catch{return[]}}),[b,h]=g.useState(""),[L,N]=g.useState(!1),Y=g.useRef(null),H=()=>{var q;(q=Y.current)==null||q.scrollIntoView({behavior:"smooth"})};g.useEffect(()=>{try{localStorage.setItem(sx,JSON.stringify(k))}catch(q){console.error("Mesajlar kaydedilirken hata:",q)}},[k]),g.useEffect(()=>{try{localStorage.setItem(rx,JSON.stringify(S))}catch(q){console.error("Silinen mesajlar kaydedilirken hata:",q)}},[S]),g.useEffect(()=>{H()},[k,_]);const B=async()=>{if(!b.trim())return;const q={role:"user",text:b};E(ee=>[...ee,q]),h(""),N(!0);const fe=await Ch();E(ee=>[...ee,{role:"model",text:fe}]),N(!1)},ae=q=>{q.key==="Enter"&&!q.shiftKey&&(q.preventDefault(),B())},Z=()=>{window.confirm("Tüm konuşmayı silmek istediğinize emin misiniz?")&&(U(q=>[...q,...k]),E(r))},G=()=>{if(S.length===0){alert("Geri getirilecek konuşma bulunamadı.");return}window.confirm("Son silinen konuşmayı geri getirmek istediğinize emin misiniz?")&&(E(q=>[...S,...q]),U([]))};return a.jsxs(a.Fragment,{children:[a.jsx("button",{onClick:()=>d(!0),className:`fixed bottom-6 right-6 bg-gradient-to-r from-blue-600 to-teal-500 text-white p-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 z-50 hover:scale-110 ${_?"hidden":"flex"}`,children:a.jsx(dh,{size:28})}),_&&a.jsxs("div",{className:"fixed bottom-6 right-6 w-[350px] md:w-[400px] h-[500px] bg-white rounded-2xl shadow-2xl z-50 flex flex-col border border-gray-200 overflow-hidden animate-in slide-in-from-bottom-10 fade-in duration-300",children:[a.jsxs("div",{className:"bg-[#263562] text-white p-4 flex justify-between items-center",children:[a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx("div",{className:"bg-white/20 p-2 rounded-full",children:a.jsx(Pp,{size:20})}),a.jsxs("div",{children:[a.jsx("h3",{className:"font-bold text-sm",children:"EgzersizLab Asistanı"}),a.jsx("p",{className:"text-xs text-blue-200",children:"Gemini AI tarafından desteklenmektedir"})]})]}),a.jsxs("div",{className:"flex items-center gap-2",children:[S.length>0&&a.jsx("button",{onClick:G,className:"text-white/80 hover:text-white hover:bg-white/10 p-1.5 rounded transition",title:"Silinen konuşmayı geri getir",children:a.jsx(Ko,{size:18})}),k.length>1&&a.jsx("button",{onClick:Z,className:"text-white/80 hover:text-white hover:bg-white/10 p-1.5 rounded transition",title:"Konuşmayı temizle",children:a.jsx(qo,{size:18})}),a.jsx("button",{onClick:()=>d(!1),className:"text-white/80 hover:text-white hover:bg-white/10 p-1 rounded transition",children:a.jsx(Qo,{size:20})})]})]}),a.jsxs("div",{className:"flex-1 overflow-y-auto p-4 bg-gray-50 space-y-4",children:[k.map((q,fe)=>a.jsx("div",{className:`flex ${q.role==="user"?"justify-end":"justify-start"}`,children:a.jsx("div",{className:`max-w-[80%] rounded-2xl p-3 text-sm ${q.role==="user"?"bg-blue-600 text-white rounded-br-none":"bg-white text-gray-800 border border-gray-200 rounded-bl-none shadow-sm"}`,children:q.text})},fe)),L&&a.jsx("div",{className:"flex justify-start",children:a.jsxs("div",{className:"bg-white text-gray-500 border border-gray-200 rounded-2xl rounded-bl-none p-3 shadow-sm flex items-center gap-2",children:[a.jsx(sh,{size:16,className:"animate-spin"}),a.jsx("span",{className:"text-xs",children:"Yazıyor..."})]})}),a.jsx("div",{ref:Y})]}),a.jsx("div",{className:"p-4 bg-white border-t border-gray-100",children:a.jsxs("div",{className:"flex items-center gap-2 bg-gray-100 rounded-full px-4 py-2 border border-transparent focus-within:border-blue-300 focus-within:bg-white transition-all",children:[a.jsx("input",{type:"text",value:b,onChange:q=>h(q.target.value),onKeyDown:ae,placeholder:"Bir soru sorun...",className:"flex-1 bg-transparent text-sm focus:outline-none"}),a.jsx("button",{onClick:B,disabled:L||!b.trim(),className:"text-blue-600 hover:text-blue-800 disabled:opacity-50 transition",children:a.jsx(yh,{size:18})})]})})]})]})},Mh=[{tag:"Ortopedi",title:"Bel, Boyun ve Eklem Ağrıları",desc:"Kas-iskelet sistemi sorunları ve tedavi yöntemleri hakkında bilgiler",gradient:"from-blue-100 to-blue-200",pill:"bg-blue-100 text-blue-700",iconColor:"text-blue-600",icon:a.jsxs("svg",{viewBox:"0 0 24 24",className:"w-full h-full p-12",fill:"none",stroke:"currentColor",strokeWidth:"1.5",children:[a.jsx("path",{d:"M8 2v4M16 2v4M8 18v4M16 18v4M2 8h4M18 8h4M2 16h4M18 16h4"}),a.jsx("rect",{x:"6",y:"6",width:"12",height:"12",rx:"2"}),a.jsx("circle",{cx:"12",cy:"12",r:"2"})]})},{tag:"Nöroloji",title:"İnme, Sinir Sıkışması ve Rehabilitasyon",desc:"Sinir sistemi hastalıkları ve iyileşme süreçleri",gradient:"from-purple-100 to-purple-200",pill:"bg-purple-100 text-purple-700",iconColor:"text-purple-600",icon:a.jsxs("svg",{viewBox:"0 0 24 24",className:"w-full h-full p-12",fill:"none",stroke:"currentColor",strokeWidth:"1.5",children:[a.jsx("circle",{cx:"12",cy:"12",r:"10"}),a.jsx("path",{d:"M12 2C12 2 8 6 8 12s4 10 4 10"}),a.jsx("path",{d:"M12 2C12 2 16 6 16 12s-4 10-4 10"}),a.jsx("path",{d:"M2 12h20"}),a.jsx("circle",{cx:"12",cy:"8",r:"1.5",fill:"currentColor"}),a.jsx("circle",{cx:"12",cy:"16",r:"1.5",fill:"currentColor"})]})},{tag:"Pediatri",title:"Çocuk Sağlığı ve Gelişim Takibi",desc:"Çocuklarda büyüme, gelişim ve sağlık rehberi",gradient:"from-pink-100 to-pink-200",pill:"bg-pink-100 text-pink-700",iconColor:"text-pink-600",icon:a.jsxs("svg",{viewBox:"0 0 24 24",className:"w-full h-full p-12",fill:"none",stroke:"currentColor",strokeWidth:"1.5",children:[a.jsx("path",{d:"M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"}),a.jsx("circle",{cx:"12",cy:"7",r:"4"}),a.jsx("path",{d:"M8 3h8"}),a.jsx("path",{d:"M12 3v4"})]})},{tag:"Yaşam",title:"Koruyucu Sağlık ve Doğru Duruş",desc:"Egzersiz, beslenme ve sağlıklı yaşam önerileri",gradient:"from-green-100 to-green-200",pill:"bg-green-100 text-green-700",iconColor:"text-green-600",icon:a.jsxs("svg",{viewBox:"0 0 24 24",className:"w-full h-full p-12",fill:"none",stroke:"currentColor",strokeWidth:"1.5",children:[a.jsx("path",{d:"M22 12h-4l-3 9L9 3l-3 9H2"}),a.jsx("circle",{cx:"12",cy:"12",r:"1",fill:"currentColor"})]})},{tag:"Kadın Sağlığı",title:"Hamilelik ve Doğum Sonrası",desc:"Pelvik taban sağlığı, menopoz dönemi, güvenli egzersiz",gradient:"from-rose-100 to-rose-200",pill:"bg-rose-100 text-rose-700",iconColor:"text-rose-600",icon:a.jsxs("svg",{viewBox:"0 0 24 24",className:"w-full h-full p-12",fill:"none",stroke:"currentColor",strokeWidth:"1.5",children:[a.jsx("path",{d:"M12 16c3.314 0 6-2.686 6-6s-2.686-6-6-6-6 2.686-6 6 2.686 6 6 6z"}),a.jsx("path",{d:"M12 16v4"}),a.jsx("path",{d:"M8 20h8"}),a.jsx("path",{d:"M12 20v2"}),a.jsx("circle",{cx:"12",cy:"10",r:"2",fill:"currentColor"})]})},{tag:"Sporcu Sağlığı",title:"Sakatlıklar ve Performans",desc:"Spora dönüş, ön çapraz bağ, sakatlık yönetimi",gradient:"from-orange-100 to-orange-200",pill:"bg-orange-100 text-orange-700",iconColor:"text-orange-600",icon:a.jsxs("svg",{viewBox:"0 0 24 24",className:"w-full h-full p-12",fill:"none",stroke:"currentColor",strokeWidth:"1.5",children:[a.jsx("path",{d:"M6.5 6.5l11 11"}),a.jsx("path",{d:"M17.5 6.5l-11 11"}),a.jsx("circle",{cx:"12",cy:"12",r:"2",fill:"currentColor"}),a.jsx("path",{d:"M2 12h4M18 12h4M12 2v4M12 18v4"})]})},{tag:"Kronik Ağrı",title:"Fibromiyalji ve Romatizma",desc:"Kronik ağrı yönetimi, iltihaplı romatizma, sabah tutukluğu",gradient:"from-red-100 to-red-200",pill:"bg-red-100 text-red-700",iconColor:"text-red-600",icon:a.jsxs("svg",{viewBox:"0 0 24 24",className:"w-full h-full p-12",fill:"none",stroke:"currentColor",strokeWidth:"1.5",children:[a.jsx("path",{d:"M12 2L2 7l10 5 10-5-10-5z"}),a.jsx("path",{d:"M2 17l10 5 10-5"}),a.jsx("path",{d:"M2 12l10 5 10-5"}),a.jsx("circle",{cx:"12",cy:"12",r:"1.5",fill:"currentColor"})]})},{tag:"Geriatri",title:"Sağlıklı Yaşlanma",desc:"Düşme riskini azaltma, denge egzersizleri, kireçlenme yönetimi",gradient:"from-indigo-100 to-indigo-200",pill:"bg-indigo-100 text-indigo-700",iconColor:"text-indigo-600",icon:a.jsxs("svg",{viewBox:"0 0 24 24",className:"w-full h-full p-12",fill:"none",stroke:"currentColor",strokeWidth:"1.5",children:[a.jsx("circle",{cx:"12",cy:"8",r:"5"}),a.jsx("path",{d:"M3 21c0-3.5 4-6 9-6s9 2.5 9 6"}),a.jsx("path",{d:"M16 11l2 2 4-4"})]})}],Rh=()=>{const r=g.useRef(null),[v,_]=g.useState(!1),[d,k]=g.useState(!0);g.useEffect(()=>{const S=r.current;if(!S)return;const U=()=>{_(S.scrollLeft>0),k(S.scrollLeft+S.clientWidth<S.scrollWidth-8)};return requestAnimationFrame(U),S.addEventListener("scroll",U),window.addEventListener("resize",U),()=>{S.removeEventListener("scroll",U),window.removeEventListener("resize",U)}},[]);const E=S=>{const U=r.current;if(!U)return;const b=U.querySelector(".category-card"),h=b?b.offsetWidth+32:U.clientWidth*.8;U.scrollBy({left:S==="left"?-h:h,behavior:"smooth"})};return a.jsx("section",{id:"blog",className:"py-20 bg-blue-50/50",style:{scrollMarginTop:"120px"},children:a.jsxs("div",{className:"container mx-auto px-4",children:[a.jsxs("div",{className:"flex flex-col md:flex-row justify-between items-end mb-10 gap-4",children:[a.jsxs("div",{children:[a.jsx("span",{className:"text-blue-600 font-semibold tracking-wide uppercase text-sm",children:"Blog Kategorileri"}),a.jsx("h2",{className:"text-3xl font-bold text-slate-900 mt-2",children:"Sağlık Bilgilerinizi Geliştirin"})]}),a.jsxs("button",{className:"flex items-center gap-2 text-[#263562] font-semibold hover:text-blue-600 transition",children:["Tüm Yazıları İncele ",a.jsx(ii,{size:18})]})]}),a.jsxs("div",{className:"relative",children:[a.jsx("button",{onClick:()=>E("left"),disabled:!v,className:"nav-button absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 z-10 bg-blue-600 text-white w-12 h-12 rounded-full shadow-lg flex items-center justify-center disabled:opacity-30 disabled:cursor-not-allowed",children:a.jsx(ii,{className:"rotate-180"})}),a.jsx("button",{onClick:()=>E("right"),disabled:!d,className:"nav-button absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 z-10 bg-blue-600 text-white w-12 h-12 rounded-full shadow-lg flex items-center justify-center disabled:opacity-30 disabled:cursor-not-allowed",children:a.jsx(ii,{})}),a.jsxs("div",{ref:r,className:"flex gap-8 overflow-x-auto pb-2 pt-1",style:{scrollbarWidth:"none",msOverflowStyle:"none"},children:[a.jsx("style",{children:".scroll-container::-webkit-scrollbar{display:none;}"}),Mh.map(S=>a.jsxs("div",{className:"category-card bg-white rounded-2xl overflow-hidden shadow-md flex-shrink-0",style:{width:"320px"},children:[a.jsx("div",{className:`category-image h-48 bg-gradient-to-br ${S.gradient} relative`,children:a.jsx("div",{className:`${S.iconColor} opacity-70 w-full h-full`,children:S.icon})}),a.jsxs("div",{className:"p-6",children:[a.jsx("div",{className:"flex items-center gap-2 mb-3",children:a.jsx("span",{className:`px-3 py-1 ${S.pill} text-xs font-semibold rounded-full`,children:S.tag})}),a.jsx("h3",{className:"text-xl font-bold text-slate-900 mb-2",children:S.title}),a.jsx("p",{className:"text-slate-600 text-sm mb-4",children:S.desc}),a.jsx("div",{className:"flex items-center justify-end pt-4 border-t border-slate-100",children:a.jsxs("button",{className:"flex items-center gap-1 text-blue-600 font-semibold text-sm hover:gap-2 transition-all",children:["İncele ",a.jsx(ii,{size:16,className:"arrow-icon"})]})})]})]},S.title))]})]})]})})},Uh=new URL("/assets/exercise-cards.jpg-DK_D65XL.png",import.meta.url).href,li=[`Hastanelerde adeta bir broşür gibi dağıtılan bu standart egzersiz reçeteleri, hastayı gerçekten tedavi etmek için mi, yoksa "bir şeyler önermiş olmak" için mi veriliyor?

Aynı kâğıdın, 20 yaşındaki bir sporcunun ön çapraz bağ sakatlığına da, 70 yaşındaki bir teyzenin ileri derece kireçlenmesine de (osteoartrit) şifa olması beklenebilir mi?

Elinize tutuşturulan o kâğıt, sizin ağrı eşiğinizi, kas dengesizliğinizi veya hareket kısıtlılığınızı "okuyabiliyor" mu?`,`Anatomimiz parmak izimiz kadar benzersizken, tedavimiz nasıl bir fotokopi makinesinden çıkabilir?

Herkesin kemik yapısı, eklem açısı, geçmişteki yaralanmaları ve yaşam tarzı birbirinden tamamen farklıyken; hepsini aynı hareketlerle iyileştirmeye çalışmak, farklı kilitleri aynı anahtarla açmaya çalışmak değil midir?

Bir başkasına iyi gelen "bacak kaldırma" hareketi, sizin özel durumunuzda dizinize daha fazla yük bindirip sorunu büyütüyorsa, o kâğıdın sorumluluğunu kim alacak?`,`Gerçek fizik tedavi; kâğıttan hareket bakmak değil, size özel dikilmiş bir elbise gibi tasarlanan, süreç içinde değiştirilen dinamik bir programdır.

Egzersiz ilaçtır; dozajı, sıklığı ve türü kişiye göre ayarlanmadığında zehire dönüşebilir.

Planınız, semptomlarınıza ve anatomik ihtiyacınıza göre yaşayan bir reçete olmalı.`],$i=["60 saniye uzak noktaya bakmak ekran yorgunluğunu ve baş ağrısını azaltır.","Güne 5 dakikalık boyun mobilizasyonu ile başlamak migren ataklarını düşürebilir.","Bel ağrısında her 30 dakikada 2 dakikalık yürüyüş, gerginliği belirgin azaltır.","Denge egzersizleri diz cerrahisi sonrası güvenli hareket kapasitesini artırır."],Lh=()=>{const[r,v]=g.useState(0),[_,d]=g.useState(0);g.useEffect(()=>{const b=setInterval(()=>{v(h=>(h+1)%li.length)},3e4);return()=>clearInterval(b)},[]);const k=()=>v(b=>(b-1+li.length)%li.length),E=()=>v(b=>(b+1)%li.length),S=()=>d(b=>(b-1+$i.length)%$i.length),U=()=>d(b=>(b+1)%$i.length);return a.jsxs("section",{id:"hero",className:"relative bg-gradient-to-br from-[#eff6ff] to-[#f0fdfa] py-16 lg:py-24 overflow-hidden",style:{scrollMarginTop:"140px"},children:[a.jsx("div",{className:"absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-blue-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob"}),a.jsx("div",{className:"absolute top-0 left-0 -ml-20 -mt-20 w-96 h-96 bg-teal-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-2000"}),a.jsx("div",{className:"container mx-auto px-4 relative z-10",children:a.jsxs("div",{className:"flex flex-col lg:flex-row items-center gap-12",children:[a.jsxs("div",{className:"lg:w-1/2 space-y-6",children:[a.jsxs("h1",{className:"text-4xl lg:text-6xl font-extrabold text-slate-900 leading-tight",children:["Senin Vücudun, Bizim Bilimimiz: ",a.jsx("br",{}),a.jsx("span",{className:"text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-teal-500",children:"Hareketin Yeni Formülü."})]}),a.jsx("p",{className:"text-lg text-gray-600 leading-relaxed max-w-lg",children:"Egzersiz ve rehabilitasyonun birleştiği modern sağlık platformu. Sağlığın için dilediğin yerde, dilediğin zamanda harekete geç."}),a.jsxs("div",{className:"flex flex-col sm:flex-row gap-4 mt-8",children:[a.jsxs("a",{href:"#packages",className:"group relative px-8 py-4 bg-gradient-to-r from-blue-600 via-blue-500 to-teal-500 text-white font-bold text-lg rounded-xl shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300 overflow-hidden",children:[a.jsxs("span",{className:"relative z-10 flex items-center justify-center gap-2",children:[a.jsx("span",{children:"🚀 Hemen Başla"}),a.jsx("span",{className:"group-hover:translate-x-1 transition-transform",children:"→"})]}),a.jsx("div",{className:"absolute inset-0 bg-gradient-to-r from-blue-700 via-blue-600 to-teal-600 opacity-0 group-hover:opacity-100 transition-opacity"})]}),a.jsx("a",{href:"#process",className:"px-8 py-4 bg-white text-blue-600 font-semibold text-lg rounded-xl border-2 border-blue-600 hover:bg-blue-50 transform hover:scale-105 transition-all duration-300 shadow-md",children:"Nasıl Çalışır?"})]}),a.jsxs("div",{className:"mt-6 w-full max-w-lg bg-gradient-to-br from-[#0f1c3a] via-[#0f1c3a] to-[#152c58] text-white rounded-2xl shadow-xl border border-white/10 p-6",children:[a.jsxs("div",{className:"flex items-center justify-between mb-4",children:[a.jsxs("h3",{className:"text-lg font-extrabold",children:["Bunları ",a.jsx("span",{className:"text-transparent bg-clip-text bg-gradient-to-r from-emerald-300 via-cyan-300 to-blue-300",children:"biliyor muydunuz?"})]}),a.jsxs("div",{className:"flex gap-2",children:[a.jsx("button",{onClick:S,"aria-label":"Önceki bilgi",className:"h-8 w-8 rounded-full bg-white/10 hover:bg-white/20 border border-white/10 flex items-center justify-center transition",children:a.jsx(Io,{size:14})}),a.jsx("button",{onClick:U,"aria-label":"Sonraki bilgi",className:"h-8 w-8 rounded-full bg-white/10 hover:bg-white/20 border border-white/10 flex items-center justify-center transition",children:a.jsx(Go,{size:14})})]})]}),a.jsx("p",{className:"text-base text-white/90 leading-relaxed min-h-[72px] transition-all",children:$i[_]}),a.jsx("div",{className:"mt-4 flex items-center gap-2",children:$i.map((b,h)=>a.jsx("button",{onClick:()=>d(h),"aria-label":`Bilgi ${h+1}`,className:`h-2 rounded-full transition-all duration-300 ${_===h?"w-5 bg-emerald-400":"w-2 bg-white/30"}`},h))}),a.jsx("button",{className:"mt-6 w-full bg-white text-[#0f1c3a] font-semibold py-3 rounded-lg hover:bg-blue-50 transition",children:"Daha fazla kısa bilgi"})]})]}),a.jsxs("div",{className:"lg:w-1/2 relative",children:[a.jsxs("div",{className:"relative rounded-3xl overflow-hidden shadow-2xl border-4 border-white",children:[a.jsx("div",{className:"absolute top-6 left-6 right-6 flex justify-between items-start",children:a.jsxs("div",{className:"bg-gradient-to-r from-[#0f1c3a]/85 to-[#1c2f55]/85 text-white px-5 py-3 rounded-2xl shadow-2xl max-w-xl border border-white/10",children:[a.jsx("p",{className:"text-xs uppercase tracking-wide text-white/70 font-semibold",children:"Standart kâğıtlar işe yaradı mı?"}),a.jsx("h3",{className:"text-2xl lg:text-3xl font-extrabold leading-tight",children:"Gerçekten işe yaradı mı?"}),a.jsx("p",{className:"mt-2 text-sm text-white/85",children:"Kâğıdın sizin anatomik ihtiyacınızı okuyup okuyamadığını gelin birlikte sorgulayalım."})]})}),a.jsx("img",{src:Uh,alt:"Standart egzersiz kâğıtları",className:"w-full h-auto object-cover"})]}),a.jsxs("div",{className:"mt-6 rounded-2xl bg-gradient-to-br from-[#0f1c3a] via-[#0f1c3a] to-[#152c58] text-white shadow-xl p-5 lg:p-6 border border-white/10",children:[a.jsxs("div",{className:"flex items-center justify-between mb-3",children:[a.jsx("h3",{className:"text-lg lg:text-xl font-extrabold text-white",children:"Neden kişiye özel egzersiz?"}),a.jsxs("div",{className:"flex gap-2",children:[a.jsx("button",{"aria-label":"Önceki",onClick:k,className:"h-9 w-9 rounded-full bg-white/10 hover:bg-white/20 border border-white/10 flex items-center justify-center text-white transition",children:a.jsx(Io,{size:16})}),a.jsx("button",{"aria-label":"Sonraki",onClick:E,className:"h-9 w-9 rounded-full bg-white/10 hover:bg-white/20 border border-white/10 flex items-center justify-center text-white transition",children:a.jsx(Go,{size:16})})]})]}),a.jsx("div",{className:"text-sm lg:text-base text-white/90 leading-relaxed min-h-[120px] transition-all duration-300 space-y-3",children:li[r].split(`
`).filter(Boolean).map((b,h)=>a.jsx("p",{className:"bg-white/5 border border-white/10 rounded-lg px-3 py-2 shadow-sm",children:b.trim()},h))}),a.jsx("div",{className:"mt-4 flex items-center gap-2",children:li.map((b,h)=>a.jsx("button",{"aria-label":`Slayt ${h+1}`,onClick:()=>v(h),className:`h-2 rounded-full transition-all duration-300 ${r===h?"w-6 bg-emerald-400":"w-2 bg-white/50"}`},h))})]}),a.jsx("div",{className:"absolute -top-6 -right-6 w-24 h-24 bg-yellow-400 rounded-full opacity-20 blur-xl"}),a.jsx("div",{className:"absolute -bottom-6 -left-6 w-32 h-32 bg-blue-600 rounded-full opacity-20 blur-xl"})]})]})})]})},Bh=[{title:"%100 Size Özel",desc:"Anatomik ihtiyacınıza uygun plan",icon:a.jsxs("svg",{xmlns:"http://www.w3.org/2000/svg",width:"32",height:"32",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[a.jsx("path",{d:"M12 10a2 2 0 0 0-2 2c0 1.02-.1 2.51-.26 4"}),a.jsx("path",{d:"M14 13.12c0 2.38 0 6.38-1 8.88"}),a.jsx("path",{d:"M17.29 21.02c.12-.6.43-2.3.5-3.02"}),a.jsx("path",{d:"M2 12a10 10 0 0 1 18-6"}),a.jsx("path",{d:"M2 16h.01"}),a.jsx("path",{d:"M21.8 16c.2-2 .131-5.354 0-6"}),a.jsx("path",{d:"M5 19.5C5.5 18 6 15 6 12a6 6 0 0 1 .34-2"}),a.jsx("path",{d:"M8.65 22c.21-.66.45-1.32.57-2"}),a.jsx("path",{d:"M9 6.8a6 6 0 0 1 9 5.2v2"})]})},{title:"Güvenli Altyapı",desc:"Sağlık verileriniz koruma altında",icon:a.jsxs("svg",{xmlns:"http://www.w3.org/2000/svg",width:"32",height:"32",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[a.jsx("path",{d:"M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"}),a.jsx("path",{d:"m9 12 2 2 4-4"})]})},{title:"Kesintisiz Destek",desc:"Süreç boyunca yanınızdayız",icon:a.jsxs("svg",{xmlns:"http://www.w3.org/2000/svg",width:"32",height:"32",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[a.jsx("path",{d:"m3 11 18-5v12L3 14v-3z"}),a.jsx("path",{d:"M11.6 16.8a3 3 0 1 1-5.8-1.6"})]})},{title:"Dilediğin Yerden",desc:"Mobilden veya bilgisayardan takip",icon:a.jsxs("svg",{xmlns:"http://www.w3.org/2000/svg",width:"32",height:"32",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[a.jsx("rect",{width:"16",height:"20",x:"4",y:"2",rx:"2",ry:"2"}),a.jsx("path",{d:"M12 18h.01"})]})}],Hh=()=>a.jsx("section",{className:"bg-[#263562] py-12",children:a.jsx("div",{className:"container mx-auto px-4",children:a.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8",children:Bh.map((r,v)=>a.jsxs("div",{className:"flex items-center gap-4 text-white group",children:[a.jsx("div",{className:"p-3 rounded-lg transition-colors bg-white/10 group-hover:bg-white/20",children:r.icon}),a.jsxs("div",{children:[a.jsx("h4",{className:"font-bold text-lg",children:r.title}),a.jsx("p",{className:"text-sm",style:{color:"#93c5fd"},children:r.desc})]})]},v))})})}),hs=[{id:1,title:"Kayıt Ol",desc:"Hesap oluştur ve sisteme giriş yap.",detail:"İlk adımda güvenli bir hesap açarak kişisel paneline erişirsin. Hesabınla birlikte ilerlemelerin ve kayıtların seninle kalır.",icon:"📝"},{id:2,title:"Bilgileri Gir",desc:"Gerekli verileri sisteme gir.",detail:"Formları doldur, gerekli dokümanları ekle ve bize ihtiyaçlarını anlat. Sistem, eksiklerini adım adım bildirir.",icon:"⚙️"},{id:3,title:"Sonuçları Al",desc:"Sistem analiz eder ve sonuçları gösterir.",detail:"Girilen bilgilere göre sana özel çıktılar, raporlar ve öneriler oluşur. Sonuçları kaydedebilir veya paylaşabilirsin.",icon:"✅"}],Yh=()=>{const[r,v]=g.useState(1),_=hs.find(d=>d.id===r)??hs[0];return a.jsx("section",{id:"process",className:"py-16",style:{scrollMarginTop:"140px"},children:a.jsx("div",{className:"container mx-auto px-4",children:a.jsxs("div",{className:"relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#dbeafe] via-[#e9ecff] to-[#e0f5ff] border border-white shadow-xl",children:[a.jsxs("div",{className:"absolute inset-0 pointer-events-none",children:[a.jsx("div",{className:"absolute -top-20 -left-10 w-56 h-56 bg-blue-200/40 rounded-full blur-3xl"}),a.jsx("div",{className:"absolute -bottom-24 -right-6 w-64 h-64 bg-indigo-200/40 rounded-full blur-3xl"})]}),a.jsxs("div",{className:"relative p-6 md:p-10 lg:p-12",children:[a.jsxs("div",{className:"text-center max-w-3xl mx-auto",children:[a.jsx("h2",{className:"text-3xl md:text-4xl font-bold text-slate-900",children:"Sistem Nasıl İşliyor?"}),a.jsx("p",{className:"mt-3 text-base md:text-lg text-slate-600",children:"Adımları keşfetmek için tıkla; her adımda ne yapman gerektiğini ve sistemin senin için ne üreteceğini gör."})]}),a.jsx("div",{className:"mt-10 flex flex-col md:flex-row items-center justify-center gap-4 md:gap-6 lg:gap-8",children:hs.map((d,k)=>a.jsxs(Xo.Fragment,{children:[a.jsxs("button",{onClick:()=>v(d.id),className:`group text-left relative w-full max-w-[320px] bg-white/90 backdrop-blur border rounded-2xl px-6 py-8 shadow-md transition transform ${r===d.id?"border-blue-200 shadow-blue-200/60 -translate-y-1 ring-2 ring-blue-300":"hover:-translate-y-1 hover:shadow-lg border-gray-100"}`,children:[a.jsx("div",{className:"flex items-center justify-center",children:a.jsx("div",{className:`w-14 h-14 rounded-full flex items-center justify-center text-xl font-bold text-white shadow-lg ${r===d.id?"bg-gradient-to-br from-blue-600 to-teal-500":"bg-gradient-to-br from-slate-400 to-slate-500"}`,children:d.id})}),a.jsx("div",{className:"text-5xl text-center mt-4",children:d.icon}),a.jsx("h3",{className:"mt-4 text-xl font-semibold text-slate-900 text-center",children:d.title}),a.jsx("p",{className:"mt-2 text-sm text-slate-600 text-center leading-relaxed",children:d.desc})]}),k<hs.length-1&&a.jsxs("div",{className:"flex items-center justify-center text-slate-500 shrink-0",children:[a.jsx(ii,{className:"hidden md:inline-block"}),a.jsx(ii,{className:"md:hidden rotate-90"})]})]},d.id))}),a.jsxs("div",{className:"mt-10 bg-white/90 border border-gray-100 rounded-2xl p-6 shadow-md",children:[a.jsxs("p",{className:"text-sm font-semibold text-blue-700 mb-2",children:["Adım ",_.id]}),a.jsx("h4",{className:"text-2xl font-bold text-slate-900 mb-3",children:_.title}),a.jsx("p",{className:"text-base text-slate-700 leading-relaxed",children:_.detail})]})]})]})})})},Gh=[{id:"basic",badge:"Basit",price:"₺499",title:"Temel Analiz",tagline:"Temel fiziksel değerlendirme ile hızlı başlangıç.",features:["Temel fiziksel değerlendirme","Ağrı haritası analizi","Genel egzersiz önerileri","Email desteği"],recommended:!1},{id:"recommended",badge:"Orta",price:"₺999",title:"Detaylı Analiz",tagline:"Kişiselleştirilmiş program ve canlı destek.",features:["Kapsamlı fiziksel değerlendirme","Detaylı ağrı haritası analizi","Kişiselleştirilmiş egzersiz programı","Video konsültasyon (30 dk)","WhatsApp desteği"],recommended:!0},{id:"premium",badge:"Premium",price:"₺1,999",title:"Premium Analiz",tagline:"AI destekli analiz ve öncelikli randevu.",features:["AI destekli ağrı analizi","Özel egzersiz programı + video rehber","Video konsültasyon (60 dk)","4 hafta takip ve destek","7/24 WhatsApp desteği","Öncelikli randevu"],recommended:!1}],Ih=({onSelectPackage:r})=>a.jsxs("section",{id:"packages",className:"relative overflow-hidden",style:{scrollMarginTop:"140px"},children:[a.jsx("div",{className:"absolute inset-0 bg-gradient-to-br from-[#e3ecff] via-[#e8eaff] to-[#e3f4ff]"}),a.jsx("div",{className:"absolute -top-24 -left-16 w-64 h-64 bg-blue-300/30 rounded-full blur-3xl"}),a.jsx("div",{className:"absolute -bottom-24 -right-10 w-72 h-72 bg-indigo-300/25 rounded-full blur-3xl"}),a.jsxs("div",{className:"relative container mx-auto px-4 py-16",children:[a.jsxs("div",{className:"text-center max-w-3xl mx-auto",children:[a.jsx("h2",{className:"text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight",children:"Hizmet Paketleri"}),a.jsx("p",{className:"mt-3 text-base md:text-lg text-slate-600",children:"Bilimsel egzersiz reçetenizi alın, iyileşme sürecinizi profesyonel kontrolde yönetin."})]}),a.jsx("div",{className:"mt-12 grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8",children:Gh.map(v=>a.jsxs("div",{className:`relative rounded-2xl p-6 shadow-lg border-2 transition transform hover:-translate-y-1 ${v.id==="basic"?"bg-gradient-to-br from-gray-50 to-gray-200 border-gray-200":v.id==="recommended"?"bg-gradient-to-br from-sky-50 to-blue-100 border-blue-200":"bg-gradient-to-br from-amber-50 to-orange-100 border-orange-200"}`,children:[a.jsxs("div",{className:"flex items-center justify-between mb-2",children:[a.jsx("span",{className:`px-3 py-1 text-xs font-bold rounded-full uppercase ${v.id==="basic"?"bg-gray-700 text-white":v.id==="recommended"?"bg-blue-600 text-white":"bg-orange-500 text-white"}`,children:v.badge}),a.jsx("span",{className:"text-xl font-extrabold text-indigo-700",children:v.price})]}),a.jsx("h3",{className:"text-2xl font-bold text-slate-900 mb-2",children:v.title}),a.jsx("p",{className:"text-slate-600 text-sm mb-6",children:v.tagline}),a.jsx("ul",{className:"space-y-2 text-sm",children:v.features.map((_,d)=>a.jsxs("li",{className:"flex items-center gap-2 text-slate-700 leading-relaxed",children:[a.jsx("span",{className:"inline-flex items-center justify-center w-5 h-5 rounded-full bg-emerald-100 text-emerald-600",children:a.jsx($p,{size:12})}),_]},d))}),a.jsxs("div",{className:"mt-6 flex flex-col gap-2",children:[a.jsx("button",{onClick:r,className:`w-full py-3 px-6 rounded-xl font-semibold text-base transition-all duration-300 transform hover:scale-[1.02] active:scale-[0.98] shadow-md hover:shadow-lg ${v.recommended?"bg-gradient-to-r from-blue-600 to-teal-500 text-white hover:from-blue-700 hover:to-teal-600":"bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200"}`,children:v.recommended?"✨ Bu Paketi Seç":"Paketi Seç"}),v.id==="basic"&&a.jsx("button",{onClick:r,className:"w-full py-2.5 px-6 rounded-xl font-medium text-sm text-blue-600 hover:text-blue-700 border-2 border-blue-300 hover:border-blue-400 bg-blue-50 hover:bg-blue-100 transition-all duration-300",children:"🎁 Ücretsiz Dene"})]})]},v.id))}),a.jsxs("div",{className:"mt-14 grid md:grid-cols-2 gap-6",children:[a.jsx("div",{className:"bg-white border border-gray-100 rounded-2xl p-6 shadow-md",children:a.jsxs("div",{className:"flex items-start gap-3",children:[a.jsx("div",{className:"text-3xl",children:"📊"}),a.jsxs("div",{children:[a.jsx("h5",{className:"text-lg font-bold text-slate-900 mb-1",children:"Bilimsel Not"}),a.jsx("p",{className:"text-slate-700 leading-relaxed",children:"Egzersiz tedavisi ilaç gibidir; adaptasyon için zamana ihtiyaç vardır. Literatür, anlamlı iyileşme için en az 4-6 hafta düzenli uygulama önerir."})]})]})}),a.jsx("div",{className:"bg-white border border-gray-100 rounded-2xl p-6 shadow-md",children:a.jsxs("div",{className:"flex items-start gap-3",children:[a.jsx("div",{className:"text-3xl",children:"✅"}),a.jsxs("div",{children:[a.jsx("h5",{className:"text-lg font-bold text-slate-900 mb-1",children:"Memnuniyet Garantisi"}),a.jsx("p",{className:"text-slate-700 leading-relaxed",children:"Program size uymazsa ilk hafta içinde ücretsiz revizyon hakkınız var."})]})]})})]})]})]}),Kh=[{icon:"✓",label:"%100 Kişiye Özel"},{icon:"⏰",label:"7/24 Dijital Destek"},{icon:"🔬",label:"Bilimsel Metodoloji"}],qh=[{title:"Bilimin Işığında",color:"text-blue-600",text:"Uyguladığımız tüm yöntemler ve egzersiz reçeteleri, güncel fizyoterapi literatürüne ve klinik çalışmalara dayanır."},{title:"Sürdürülebilir İyileşme",color:"text-purple-600",text:"Anlık ağrı kesici çözümler değil, sorunun kök nedenine inen ve kalıcı iyileşmeyi hedefleyen alışkanlıklar kazandırırız."},{title:"Ulaşılabilirlik",color:"text-pink-600",text:"Profesyonel sağlık desteğini lüks olmaktan çıkarıp, dilediğiniz yerde ve zamanda ulaşabileceğiniz bir hizmete dönüştürüyoruz."}],Vh=()=>a.jsxs("section",{id:"about",className:"w-full bg-white",style:{scrollMarginTop:"140px"},children:[a.jsx("div",{className:"bg-gradient-to-br from-[#4f6edc] via-[#5c5db4] to-[#6a3fb0] text-white py-16 px-4 md:px-8",children:a.jsxs("div",{className:"max-w-4xl mx-auto text-center",children:[a.jsx("h1",{className:"text-4xl md:text-5xl font-extrabold mb-4 leading-tight",children:"Hareketin Bilimsel Formülü"}),a.jsx("p",{className:"text-2xl md:text-3xl font-semibold opacity-90",children:"EgzersizLab"})]})}),a.jsx("div",{className:"bg-white py-12 px-4 md:px-8",children:a.jsx("div",{className:"max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8",children:Kh.map(r=>a.jsxs("div",{className:"stat-card bg-gradient-to-br from-blue-50 via-slate-50 to-purple-50 rounded-2xl p-8 text-center shadow-sm transition transform hover:-translate-y-1 hover:shadow-xl",children:[a.jsx("div",{className:"text-5xl mb-4",children:r.icon}),a.jsx("p",{className:"text-xl font-semibold text-slate-800",children:r.label})]},r.label))})}),a.jsx("div",{className:"bg-gradient-to-b from-gray-50 to-white py-14 px-4 md:px-8",children:a.jsxs("div",{className:"max-w-4xl mx-auto space-y-14",children:[a.jsxs("section",{children:[a.jsx("h2",{className:"text-3xl font-bold text-slate-900 mb-4",children:"Biz Kimiz?"}),a.jsx("p",{className:"text-lg text-slate-700 leading-relaxed",children:"EgzersizLab, modern tıbbın kanıta dayalı rehabilitasyon yöntemlerini, dijital teknolojinin hızı ve erişilebilirliği ile birleştiren yeni nesil bir sağlık teknolojisi girişimidir. Amacımız, coğrafi sınırları ortadan kaldırarak herkesin doğru, güvenilir ve kişiye özel sağlık danışmanlığına ulaşmasını sağlamaktır."})]}),a.jsx("div",{className:"h-0.5 bg-gradient-to-r from-transparent via-blue-400/60 to-transparent"}),a.jsxs("section",{children:[a.jsx("h2",{className:"text-3xl font-bold text-slate-900 mb-4",children:"Misyonumuz"}),a.jsx("p",{className:"text-lg text-slate-700 leading-relaxed",children:'İnternetteki bilgi kirliliği ve herkese aynı reçeteyi sunan standart yaklaşımların aksine; her bireyin anatomisinin, yaşam tarzının ve ağrı geçmişinin "parmak izi" gibi benzersiz olduğuna inanıyoruz. EgzersizLab olarak, sağlığı şansa bırakmıyor; süreci bir laboratuvar titizliğiyle analiz edip, kişiye en uygun iyileşme haritasını çıkarıyoruz.'})]}),a.jsx("div",{className:"h-0.5 bg-gradient-to-r from-transparent via-blue-400/60 to-transparent"}),a.jsxs("section",{children:[a.jsx("h2",{className:"text-3xl font-bold text-slate-900 mb-6",children:"Değerlerimiz"}),a.jsx("div",{className:"space-y-5",children:qh.map(r=>a.jsxs("div",{className:"value-card bg-white rounded-xl p-6 shadow-sm border-l-4 border-transparent transition hover:border-l-blue-500 hover:bg-gradient-to-r hover:from-blue-50/60 hover:to-transparent",children:[a.jsx("h3",{className:`text-xl font-bold mb-2 ${r.color}`,children:r.title}),a.jsx("p",{className:"text-slate-700 leading-relaxed",children:r.text})]},r.title))})]}),a.jsx("div",{className:"h-0.5 bg-gradient-to-r from-transparent via-blue-400/60 to-transparent"}),a.jsxs("section",{className:"text-center",children:[a.jsx("p",{className:"text-xl text-slate-800 leading-relaxed mb-4",children:"Vücudunuz, içinde yaşadığınız en değerli evinizdir. EgzersizLab ekibi olarak, o eve en iyi şekilde bakmanız için gereken bilgiyi ve desteği sağlamak üzere yanınızdayız."}),a.jsx("p",{className:"text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent",children:"Hareket özgürlüktür. Bilimle hareket edin."})]}),a.jsx("div",{className:"text-center pt-6 border-t border-gray-200",children:a.jsx("p",{className:"text-lg font-semibold text-slate-800",children:"EgzersizLab Ekibi"})})]})})]}),hl=[{id:1,name:"Ayşe Yılmaz",rating:5,comment:"Bel ağrılarım için aldığım program sayesinde 2 ayda çok büyük ilerleme kaydettim. Fizyoterapist desteği harika!",date:"2 hafta önce",packageType:"Klinik Paket"},{id:2,name:"Mehmet Demir",rating:5,comment:"Diz cerrahisi sonrası rehabilitasyon sürecimde çok yardımcı oldu. Video anlatımlar çok net ve anlaşılır.",date:"1 ay önce",packageType:"Premium Paket"},{id:3,name:"Zeynep Kaya",rating:5,comment:"Boyun ağrılarım için kişiselleştirilmiş program aldım. Artık günlük hayatımda çok daha rahatım. Teşekkürler!",date:"3 hafta önce",packageType:"Temel Paket"},{id:4,name:"Ali Çelik",rating:5,comment:"Premium paket ile fizyoterapistimle sürekli iletişim halindeyim. Sorularıma anında cevap alıyorum. Mükemmel!",date:"1 hafta önce",packageType:"Premium Paket"},{id:5,name:"Fatma Özkan",rating:5,comment:"Omuz problemim için aldığım program gerçekten işe yaradı. Egzersizler çok etkili ve kolay takip edilebilir.",date:"2 ay önce",packageType:"Klinik Paket"},{id:6,name:"Can Arslan",rating:5,comment:"Spor yaralanması sonrası hızlı toparlanmamı sağladı. Profesyonel yaklaşım ve kişiselleştirilmiş program harika!",date:"3 hafta önce",packageType:"Premium Paket"}],Xh=()=>{const[r,v]=g.useState(0),[_,d]=g.useState(!0);g.useEffect(()=>{if(!_)return;const b=setInterval(()=>{v(h=>(h+1)%hl.length)},5e3);return()=>clearInterval(b)},[_]);const k=()=>{v(b=>(b+1)%hl.length),d(!1)},E=()=>{v(b=>(b-1+hl.length)%hl.length),d(!1)},S=b=>{v(b),d(!1)},U=b=>a.jsx("div",{className:"flex gap-1",children:[1,2,3,4,5].map(h=>a.jsx("span",{className:`text-lg ${h<=b?"text-yellow-400":"text-gray-300"}`,children:"★"},h))});return a.jsxs("section",{id:"testimonials",className:"py-20 bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50 relative overflow-hidden",style:{scrollMarginTop:"140px"},children:[a.jsx("div",{className:"absolute top-0 right-0 w-96 h-96 bg-blue-200/20 rounded-full blur-3xl"}),a.jsx("div",{className:"absolute bottom-0 left-0 w-96 h-96 bg-teal-200/20 rounded-full blur-3xl"}),a.jsxs("div",{className:"container mx-auto px-4 relative z-10",children:[a.jsxs("div",{className:"text-center mb-12",children:[a.jsx("h2",{className:"text-4xl md:text-5xl font-extrabold text-slate-900 mb-4",children:"Müşterilerimiz Ne Diyor?"}),a.jsx("p",{className:"text-lg text-slate-600 max-w-2xl mx-auto",children:"Binlerce mutlu kullanıcımızın deneyimlerini keşfedin"}),a.jsxs("div",{className:"mt-4 flex items-center justify-center gap-2",children:[a.jsx("div",{className:"flex gap-1",children:[1,2,3,4,5].map(b=>a.jsx("span",{className:"text-2xl text-yellow-400",children:"★"},b))}),a.jsx("span",{className:"text-xl font-bold text-slate-900 ml-2",children:"4.9/5"}),a.jsx("span",{className:"text-slate-600 ml-2",children:"(247 değerlendirme)"})]})]}),a.jsxs("div",{className:"relative max-w-6xl mx-auto",children:[a.jsx("div",{className:"overflow-hidden rounded-2xl",children:a.jsx("div",{className:"flex transition-transform duration-500 ease-in-out",style:{transform:`translateX(-${r*100}%)`},children:hl.map(b=>a.jsx("div",{className:"min-w-full px-4",children:a.jsx("div",{className:"bg-white rounded-2xl shadow-xl p-8 md:p-10 border border-gray-100",children:a.jsxs("div",{className:"flex flex-col md:flex-row gap-6",children:[a.jsxs("div",{className:"md:w-1/3 flex flex-col items-center md:items-start",children:[a.jsx("div",{className:"w-20 h-20 bg-gradient-to-br from-blue-500 to-teal-500 rounded-full flex items-center justify-center text-white text-2xl font-bold mb-4",children:b.name.charAt(0)}),a.jsx("h3",{className:"text-xl font-bold text-slate-900 mb-2",children:b.name}),b.packageType&&a.jsx("span",{className:"px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-semibold mb-3",children:b.packageType}),U(b.rating),a.jsx("p",{className:"text-sm text-slate-500 mt-2",children:b.date})]}),a.jsx("div",{className:"md:w-2/3 flex items-center",children:a.jsxs("div",{children:[a.jsx("div",{className:"text-4xl text-blue-200 mb-4",children:'"'}),a.jsx("p",{className:"text-lg text-slate-700 leading-relaxed italic",children:b.comment}),a.jsx("div",{className:"text-4xl text-blue-200 mt-4 text-right",children:'"'})]})})]})})},b.id))})}),a.jsx("button",{onClick:E,className:"absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 md:-translate-x-12 w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-blue-50 transition-all z-10 border border-gray-200","aria-label":"Önceki yorum",children:a.jsx(Io,{className:"w-6 h-6 text-slate-700"})}),a.jsx("button",{onClick:k,className:"absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 md:translate-x-12 w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-blue-50 transition-all z-10 border border-gray-200","aria-label":"Sonraki yorum",children:a.jsx(Go,{className:"w-6 h-6 text-slate-700"})}),a.jsx("div",{className:"flex justify-center gap-2 mt-8",children:hl.map((b,h)=>a.jsx("button",{onClick:()=>S(h),className:`w-3 h-3 rounded-full transition-all ${h===r?"bg-blue-600 w-8":"bg-gray-300 hover:bg-gray-400"}`,"aria-label":`Yorum ${h+1}`},h))})]}),a.jsx("div",{className:"hidden lg:grid lg:grid-cols-3 gap-6 mt-12",children:hl.slice(0,3).map(b=>a.jsxs("div",{className:"bg-white rounded-xl shadow-lg p-6 border border-gray-100 hover:shadow-xl transition-shadow",children:[a.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[a.jsx("div",{className:"w-12 h-12 bg-gradient-to-br from-blue-500 to-teal-500 rounded-full flex items-center justify-center text-white font-bold",children:b.name.charAt(0)}),a.jsxs("div",{children:[a.jsx("h4",{className:"font-bold text-slate-900",children:b.name}),U(b.rating)]})]}),a.jsxs("p",{className:"text-slate-700 text-sm leading-relaxed mb-3",children:['"',b.comment,'"']}),b.packageType&&a.jsx("span",{className:"text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded-full",children:b.packageType})]},b.id))})]})]})},Qh=({email:r,name:v,password:_,phone:d,onClose:k,onSuccess:E})=>{const[S,U]=g.useState(["","","",""]),[b,h]=g.useState(!1),[L,N]=g.useState(null),[Y,H]=g.useState(!1),[B,ae]=g.useState(0),Z=g.useRef([]);g.useEffect(()=>{if(B>0){const oe=setTimeout(()=>ae(B-1),1e3);return()=>clearTimeout(oe)}},[B]);const G=(oe,X)=>{var ne;if(!/^\d*$/.test(X))return;const I=[...S];I[oe]=X.slice(-1),U(I),N(null),X&&oe<3&&((ne=Z.current[oe+1])==null||ne.focus())},q=(oe,X)=>{var I;X.key==="Backspace"&&!S[oe]&&oe>0&&((I=Z.current[oe-1])==null||I.focus())},fe=oe=>{var I;oe.preventDefault();const X=oe.clipboardData.getData("text").slice(0,4);if(/^\d{4}$/.test(X)){const ne=X.split("");U([...ne,...Array(4-ne.length).fill("")].slice(0,4)),(I=Z.current[3])==null||I.focus()}},ee=async oe=>{var I,ne;oe.preventDefault(),N(null);const X=S.join("");if(X.length!==4){N("Lütfen 4 haneli kodu giriniz");return}h(!0);try{const se=await ta.verifyAndRegister(r,X,_,v,d);se.success?(localStorage.setItem("showLoginSuccess","true"),E(),k(),window.location.href="/#dashboard"):(N(se.error||"Kod doğrulanamadı. Lütfen tekrar deneyin."),U(["","","",""]),(I=Z.current[0])==null||I.focus())}catch(se){N(se.message||"Bir hata oluştu. Lütfen tekrar deneyin."),U(["","","",""]),(ne=Z.current[0])==null||ne.focus()}finally{h(!1)}},Re=async()=>{var oe;H(!0),N(null);try{const X=await ta.sendVerificationCode(r,_,v,d);X.success?(ae(60),U(["","","",""]),(oe=Z.current[0])==null||oe.focus()):N(X.error||"Kod gönderilemedi. Lütfen tekrar deneyin.")}catch(X){N(X.message||"Kod gönderilemedi. Lütfen tekrar deneyin.")}finally{H(!1)}};return a.jsx("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm px-4",children:a.jsx("div",{className:"bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden",children:a.jsxs("div",{className:"p-8",children:[a.jsx("button",{onClick:k,className:"absolute right-4 top-4 text-gray-500 hover:text-gray-700 transition text-xl","aria-label":"Kapat",children:"×"}),a.jsxs("div",{className:"text-center mb-6",children:[a.jsx("div",{className:"w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4",children:a.jsx("svg",{className:"w-8 h-8 text-white",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:a.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"})})}),a.jsx("h2",{className:"text-2xl font-bold text-gray-800 mb-2",children:"E-posta Aktivasyonu"}),a.jsxs("p",{className:"text-gray-600 text-sm",children:[a.jsx("strong",{children:r})," adresine gönderilen 4 haneli kodu giriniz"]})]}),L&&a.jsx("div",{className:"mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm",children:L}),a.jsxs("form",{onSubmit:ee,className:"space-y-6",children:[a.jsxs("div",{children:[a.jsx("label",{className:"block text-sm font-semibold text-gray-700 mb-3 text-center",children:"Aktivasyon Kodu"}),a.jsx("div",{className:"flex gap-3 justify-center",onPaste:fe,children:S.map((oe,X)=>a.jsx("input",{ref:I=>Z.current[X]=I,type:"text",inputMode:"numeric",maxLength:1,value:oe,onChange:I=>G(X,I.target.value),onKeyDown:I=>q(X,I),className:"w-14 h-14 text-center text-2xl font-bold border-2 border-gray-300 rounded-xl focus:outline-none focus:border-purple-500 focus:ring-2 focus:ring-purple-200 transition"},X))}),a.jsx("p",{className:"text-xs text-gray-500 text-center mt-2",children:"Kod 10 dakika geçerlidir"})]}),a.jsx("button",{type:"submit",disabled:b||S.join("").length!==4,className:"w-full py-3 text-white font-bold rounded-lg shadow-lg bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed",children:b?"Doğrulanıyor...":"Hesabı Aktifleştir"}),a.jsx("div",{className:"text-center",children:a.jsx("button",{type:"button",onClick:Re,disabled:Y||B>0,className:"text-sm text-purple-600 hover:text-purple-700 font-semibold disabled:text-gray-400 disabled:cursor-not-allowed",children:B>0?`Yeni kod gönder (${B}s)`:Y?"Gönderiliyor...":"Kodu tekrar gönder"})})]})]})})})},Zh=({onClose:r,onSuccess:v,onOpenLogin:_})=>{const[d,k]=g.useState(!1),[E,S]=g.useState(!1),[U,b]=g.useState(null),[h,L]=g.useState(!1),[N,Y]=g.useState(!1),[H,B]=g.useState({name:"",email:"",phone:"",password:""}),ae={backgroundImage:'linear-gradient(135deg, rgba(102,126,234,0.95), rgba(118,75,162,0.95)), url("https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=900&q=80")',backgroundSize:"cover",backgroundPosition:"center"};return a.jsxs("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm px-4",children:[a.jsx("style",{children:`
        .floating-icon { animation: float 3s ease-in-out infinite; }
        @keyframes float { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }
        .input-field:focus {
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
        }
        .checkbox-custom {
          appearance: none;
          width: 20px;
          height: 20px;
          border: 2px solid #d1d5db;
          border-radius: 4px;
          cursor: pointer;
          transition: all 0.2s;
          flex-shrink: 0;
        }
        .checkbox-custom:checked {
          background-color: #667eea;
          border-color: #667eea;
          background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='white'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='3' d='M5 13l4 4L19 7'%3E%3C/path%3E%3C/svg%3E");
          background-size: 16px;
          background-position: center;
          background-repeat: no-repeat;
        }
        .registration-submit {
          position: relative;
          overflow: hidden;
        }
        .registration-submit::before {
          content: '';
          position: absolute;
          top: 0;
          left: -100%;
          width: 100%;
          height: 100%;
          background: linear-gradient(90deg, transparent, rgba(255,255,255,0.25), transparent);
          transition: left 0.6s ease;
        }
        .registration-submit:hover::before { left: 100%; }
      `}),a.jsxs("div",{className:"bg-white w-full max-w-5xl rounded-3xl overflow-hidden shadow-2xl grid grid-cols-1 md:grid-cols-2",children:[a.jsx("div",{className:"text-white p-8 md:p-10 flex items-center",style:ae,children:a.jsxs("div",{className:"space-y-6 max-w-md",children:[a.jsx("div",{className:"floating-icon",children:a.jsx("svg",{className:"w-16 h-16",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:a.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"})})}),a.jsx("h1",{className:"text-3xl font-bold leading-tight",children:"Ağrısız bir yaşama ilk adımı atıyorsunuz"}),a.jsx("p",{className:"text-lg opacity-90",children:"Profesyonel fizyoterapistlerimiz, size özel egzersiz programlarıyla sağlıklı yaşamınızı destekliyor."}),a.jsx("div",{className:"space-y-3 pt-4",children:["Kişiye özel egzersiz programları","7/24 Dijital Erişim imkanı","Uzman fizyoterapist danışmanlığı"].map(Z=>a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx("svg",{className:"w-5 h-5 flex-shrink-0",fill:"currentColor",viewBox:"0 0 20 20",children:a.jsx("path",{fillRule:"evenodd",d:"M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z",clipRule:"evenodd"})}),a.jsx("span",{children:Z})]},Z))})]})}),a.jsxs("div",{className:"p-8 md:p-10 bg-gray-50 relative",children:[a.jsx("button",{onClick:r,className:"absolute right-4 top-4 text-gray-500 hover:text-gray-700 transition text-xl","aria-label":"Kapat",children:"×"}),a.jsxs("div",{className:"bg-white rounded-2xl shadow-lg p-6 md:p-8",children:[a.jsxs("div",{className:"text-center mb-6",children:[a.jsx("h2",{className:"text-2xl font-bold text-gray-800 mb-1",children:"Hesap Oluştur"}),a.jsx("p",{className:"text-gray-600 text-sm",children:"Sağlıklı yaşam yolculuğunuza başlayın"})]}),U&&a.jsx("div",{className:"mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm",children:U}),a.jsxs("form",{className:"space-y-4",onSubmit:async Z=>{Z.preventDefault(),b(null),S(!0);try{if(H.phone&&H.phone.trim()!==""){const q=H.phone.trim();if(!/^[0-9+\-\s()]+$/.test(q)){b("Geçerli bir telefon numarası giriniz (sadece rakam, +, -, boşluk kullanabilirsiniz)"),S(!1);return}if(q.replace(/\D/g,"").length<10){b("Telefon numarası en az 10 haneli olmalıdır (örn: 5XX XXX XX XX)"),S(!1);return}}if(H.password.length<8){b("Şifre en az 8 karakter olmalıdır"),S(!1);return}if(!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(H.password)){b("Şifre en az bir küçük harf, bir büyük harf ve bir rakam içermelidir"),S(!1);return}const G=await ta.sendVerificationCode(H.email,H.password,H.name,H.phone);G.success?L(!0):b(G.error||"Kod gönderilemedi. Lütfen tekrar deneyin.")}catch(G){b(G.message||"Bir hata oluştu. Lütfen tekrar deneyin.")}finally{S(!1)}},children:[a.jsxs("div",{children:[a.jsxs("label",{className:"block text-sm font-semibold text-gray-700 mb-2",children:["Ad Soyad ",a.jsx("span",{className:"text-red-500",children:"*"})]}),a.jsx("input",{type:"text",required:!0,value:H.name,onChange:Z=>B({...H,name:Z.target.value}),className:"input-field w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-purple-500",placeholder:"Adınız ve Soyadınız"})]}),a.jsxs("div",{children:[a.jsxs("label",{className:"block text-sm font-semibold text-gray-700 mb-2",children:["E-posta Adresi ",a.jsx("span",{className:"text-red-500",children:"*"})]}),a.jsx("input",{type:"email",required:!0,value:H.email,onChange:Z=>B({...H,email:Z.target.value}),className:"input-field w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-purple-500",placeholder:"ornek@email.com"})]}),a.jsxs("div",{children:[a.jsx("label",{className:"block text-sm font-semibold text-gray-700 mb-2",children:"Telefon"}),a.jsx("input",{type:"tel",value:H.phone,onChange:Z=>B({...H,phone:Z.target.value}),className:"input-field w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-purple-500",placeholder:"0555 555 55 55"})]}),a.jsxs("div",{children:[a.jsxs("label",{className:"block text-sm font-semibold text-gray-700 mb-2",children:["Şifre Oluştur ",a.jsx("span",{className:"text-red-500",children:"*"})]}),a.jsxs("div",{className:"relative",children:[a.jsx("input",{type:d?"text":"password",required:!0,value:H.password,onChange:Z=>B({...H,password:Z.target.value}),className:"input-field w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-purple-500",placeholder:"En az 8 karakter (büyük/küçük harf + rakam)"}),a.jsx("button",{type:"button",onClick:()=>k(Z=>!Z),className:"absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700 text-sm",children:d?"Gizle":"Göster"})]}),a.jsx("p",{className:"text-xs text-gray-500 mt-1",children:"En az 8 karakter, bir büyük harf, bir küçük harf ve bir rakam içermelidir"})]}),a.jsx("div",{className:"pt-2",children:a.jsxs("label",{className:"flex items-start gap-3 cursor-pointer",children:[a.jsx("input",{type:"checkbox",required:!0,className:"checkbox-custom mt-1"}),a.jsxs("span",{className:"text-sm text-gray-600 leading-relaxed",children:[a.jsx("button",{type:"button",onClick:()=>Y(!0),className:"text-purple-600 hover:underline font-semibold",children:"KVKK"})," ","ve"," ",a.jsx("button",{type:"button",onClick:()=>Y(!0),className:"text-purple-600 hover:underline font-semibold",children:"Aydınlatma Metni"}),"'ni okudum, kabul ediyorum."]})]})}),a.jsx("button",{type:"submit",disabled:E,className:"registration-submit w-full py-3 text-white font-bold rounded-lg shadow-lg bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300 mt-4 disabled:opacity-50 disabled:cursor-not-allowed",children:E?"Kayıt yapılıyor...":"Hesabımı Oluştur ve Değerlendirmeye Başla"})]}),a.jsxs("div",{className:"mt-5 text-center text-sm text-gray-600",children:["Zaten hesabınız var mı?"," ",a.jsx("button",{type:"button",onClick:()=>{r(),_==null||_()},className:"text-purple-600 hover:text-purple-700 font-semibold",children:"Giriş Yapın"})]})]})]})]}),h&&a.jsx(Qh,{email:H.email,name:H.name,password:H.password,phone:H.phone,onClose:()=>{L(!1),r()},onSuccess:()=>{v?v():(window.location.hash="#dashboard",setTimeout(()=>{window.location.reload()},100))}}),N&&a.jsx("div",{className:"fixed inset-0 z-[70] flex items-center justify-center bg-black/60 backdrop-blur-sm px-4",children:a.jsx("div",{className:"bg-white max-w-3xl w-full rounded-2xl shadow-2xl overflow-hidden",children:a.jsxs("div",{className:"p-6 sm:p-8 max-h-[80vh] overflow-y-auto space-y-4 text-sm text-gray-700",children:[a.jsxs("div",{className:"flex justify-between items-start",children:[a.jsx("h3",{className:"text-xl font-bold text-gray-900",children:"KVKK ve Aydınlatma Metni"}),a.jsx("button",{onClick:()=>Y(!1),className:"text-gray-500 hover:text-gray-700 text-lg","aria-label":"Kapat",children:"×"})]}),a.jsx("p",{children:'EgzersizLab olarak 6698 sayılı Kişisel Verilerin Korunması Kanunu ("KVKK") kapsamında; kimlik, iletişim, işlem güvenliği ve kullanım verilerinizi hizmet sunumu, üyelik işlemleri, destek ve güvenlik süreçleri için işliyoruz. Verileriniz, açık rızanıza dayalı olarak veya KVKK m.5/2 uyarınca sözleşmenin ifası, hukuki yükümlülüklerin yerine getirilmesi, meşru menfaat ve hakların tesisi amaçlarıyla kullanılabilir.'}),a.jsx("p",{children:"Kişisel verileriniz; yetkili kamu kurumları, iş ortakları, altyapı/hosting/e-posta sağlayıcıları ve hukuken yetkili üçüncü kişilerle, hizmetlerin sağlanması ve güvenliğinin tesis edilmesi amacıyla paylaşılabilir. Verileriniz yurt içinde veya hizmet alınan altyapılar nedeniyle yurt dışında barındırılabilir."}),a.jsx("p",{className:"font-semibold",children:"Haklarınız (KVKK m.11)"}),a.jsxs("ul",{className:"list-disc pl-5 space-y-1",children:[a.jsx("li",{children:"İşlenip işlenmediğini öğrenme,"}),a.jsx("li",{children:"İşlenme amacını ve amaca uygun kullanılıp kullanılmadığını öğrenme,"}),a.jsx("li",{children:"Yurt içi/dışı aktarılan üçüncü kişileri bilme,"}),a.jsx("li",{children:"Eksik veya yanlış işlendi ise düzeltilmesini isteme,"}),a.jsx("li",{children:"Silinmesini/yok edilmesini isteme,"}),a.jsx("li",{children:"Otomatik sistemlerle analiz sonucu aleyhinize bir sonuca itiraz etme,"}),a.jsx("li",{children:"Kanuna aykırı işlem nedeniyle zarara uğrarsanız tazminat talep etme."})]}),a.jsx("p",{children:"Başvuru: kvkk@egzersizlab.com adresine kimlik doğrulamalı e-posta ile başvurabilirsiniz. Detaylı aydınlatma ve çerez politikası için lütfen bizimle iletişime geçin."}),a.jsx("div",{className:"flex justify-end",children:a.jsx("button",{onClick:()=>Y(!1),className:"px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg shadow hover:shadow-lg transition",children:"Anladım"})})]})})})]})},Jh=[{id:1,title:"Vakalarla Omurgada Radyolojik Değerlendirme: MR-XRay-BT",instructor:"Dr. Ahmet Yılmaz",price:1100,rating:5,reviewCount:2,image:"https://picsum.photos/400/250?random=1",category:"Workshop",duration:"3 Saat",students:46},{id:2,title:"Diz Cerrahileri Sonrası Rehabilitasyon Sertifika Programı",instructor:"Prof. Dr. Ayşe Demir",price:3e3,rating:4.8,reviewCount:4,image:"https://picsum.photos/400/250?random=2",category:"Ortopedi",duration:"38 Ders",students:54},{id:3,title:"Fonksiyonel Bantlama Teknikleri",instructor:"Uzm. Fzt. Mehmet Kaya",price:3e3,rating:4.9,reviewCount:14,image:"https://picsum.photos/400/250?random=3",category:"Manuel Terapi",duration:"15 Ders",students:65},{id:4,title:"İnmede Fizyoterapi ve Rehabilitasyon",instructor:"Dr. Zeynep Çelik",price:1499,rating:5,reviewCount:7,image:"https://picsum.photos/400/250?random=4",category:"Nöroloji",duration:"2 Saat",students:26}];function Fh(){const[r,v]=g.useState(!1),[_,d]=g.useState(!1),[k,E]=g.useState(!1),[S,U]=g.useState(!1);return g.useEffect(()=>{const b=localStorage.getItem("token");U(!!b)},[]),g.useEffect(()=>{const b=()=>{const h=window.scrollY;E(h>400)};return window.addEventListener("scroll",b),()=>window.removeEventListener("scroll",b)},[]),a.jsxs("div",{className:"min-h-screen flex flex-col font-sans",children:[a.jsx("style",{children:`
        @keyframes fade-in {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-fade-in {
          animation: fade-in 0.5s ease-out;
        }
      `}),a.jsx(Oh,{onOpenRegister:()=>v(!0),isAuthenticated:S}),a.jsx(Lh,{}),a.jsx("section",{className:"py-8 px-4",children:a.jsx("div",{className:"container mx-auto",children:a.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-4 gap-4 rounded-2xl bg-white shadow-xl border border-slate-100 p-4 md:p-6",children:[a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx("div",{className:"w-12 h-12 rounded-xl bg-gradient-to-br from-blue-600 to-teal-500 text-white font-bold flex items-center justify-center",children:"⚡"}),a.jsxs("div",{children:[a.jsx("p",{className:"text-sm text-slate-500",children:"Hızlı Başlangıç"}),a.jsx("p",{className:"text-lg font-extrabold text-slate-900",children:"3 dakikada plan"})]})]}),a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx("div",{className:"w-12 h-12 rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 text-white font-bold flex items-center justify-center",children:"⭐"}),a.jsxs("div",{children:[a.jsx("p",{className:"text-sm text-slate-500",children:"Kullanıcı memnuniyeti"}),a.jsx("p",{className:"text-lg font-extrabold text-slate-900",children:"%92 mutlu"})]})]}),a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx("div",{className:"w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-400 to-cyan-500 text-white font-bold flex items-center justify-center",children:"🛡️"}),a.jsxs("div",{children:[a.jsx("p",{className:"text-sm text-slate-500",children:"Risk tersine çevirme"}),a.jsx("p",{className:"text-lg font-extrabold text-slate-900",children:"7 gün revizyon"})]})]}),a.jsxs("div",{className:"flex items-center justify-between md:justify-end gap-3",children:[a.jsxs("div",{className:"hidden md:block text-right",children:[a.jsx("p",{className:"text-sm text-slate-500",children:"Şimdi başla"}),a.jsx("p",{className:"text-lg font-extrabold text-slate-900",children:"Bugün ilk adım"})]}),a.jsx("a",{href:"#packages",onClick:b=>{b.preventDefault(),v(!0)},className:"px-5 py-3 bg-gradient-to-r from-blue-600 to-teal-500 text-white font-semibold rounded-xl shadow-lg hover:shadow-blue-500/40 transition-transform hover:-translate-y-0.5",children:"Başla"})]})]})})}),a.jsx(Yh,{}),a.jsx(Hh,{}),a.jsx(Ih,{onSelectPackage:()=>v(!0)}),a.jsx(Rh,{courses:Jh}),a.jsx("section",{id:"faq",className:"py-16 bg-gradient-to-br from-slate-50 via-white to-blue-50",style:{scrollMarginTop:"140px"},children:a.jsxs("div",{className:"container mx-auto px-4",children:[a.jsxs("div",{className:"text-center max-w-3xl mx-auto mb-10",children:[a.jsx("h2",{className:"text-3xl md:text-4xl font-extrabold text-slate-900",children:"Sık Sorulanlar"}),a.jsx("p",{className:"text-slate-600 mt-3",children:"Karar vermeden önce en merak edilenler"})]}),a.jsx("div",{className:"grid gap-4 max-w-5xl mx-auto",children:[{q:"Ne kadar sürede sonuç alırım?",a:"Düzenli uygulamada 3-6 haftada belirgin iyileşme; ilk hafta içinde ağrı ve hareket açıklığında hafifleme beklenir."},{q:"Ağrım artarsa ne olacak?",a:"İlk 7 gün içinde ücretsiz revizyon yapıyoruz; fizyoterapistiniz planı yeniden düzenler."},{q:"İptal/iade süreci nasıl?",a:"Memnun kalmazsanız ilk hafta içinde koşulsuz revizyon; yasal iade haklarınız saklı."},{q:"Paketler arasındaki fark ne?",a:"Temel hızlı başlangıç içindir; Detaylı paket kişiselleştirilmiş program ve video görüşme ekler; Premium 7/24 destek ve öncelikli randevu sunar."}].map((b,h)=>a.jsxs("div",{className:"bg-white border border-slate-100 shadow-sm rounded-2xl p-5 hover:shadow-md transition",children:[a.jsx("p",{className:"font-bold text-slate-900 text-lg",children:b.q}),a.jsx("p",{className:"text-slate-600 mt-2",children:b.a})]},h))}),a.jsx("div",{className:"text-center mt-8",children:a.jsxs("a",{href:"#packages",onClick:b=>{b.preventDefault(),v(!0)},className:"inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-teal-500 text-white font-semibold rounded-xl shadow-lg hover:shadow-blue-500/40 transition-transform hover:-translate-y-0.5",children:["Hemen Başla",a.jsx("span",{children:"→"})]})})]})}),a.jsx(Xh,{}),a.jsx(Vh,{}),a.jsx("section",{className:"py-16 bg-white",children:a.jsx("div",{className:"container mx-auto px-4",children:a.jsxs("div",{className:"grid grid-cols-2 lg:grid-cols-4 gap-8 text-center divide-x divide-gray-100",children:[a.jsxs("div",{children:[a.jsx("div",{className:"text-4xl font-bold text-teal-500 mb-2",children:"%100"}),a.jsx("div",{className:"text-gray-500 text-sm font-medium uppercase tracking-wider",children:"Kişiye Özel Analiz"})]}),a.jsxs("div",{children:[a.jsx("div",{className:"text-4xl font-bold text-pink-500 mb-2",children:"7/24"}),a.jsx("div",{className:"text-gray-500 text-sm font-medium uppercase tracking-wider",children:"Dijital Erişim ve Destek"})]}),a.jsxs("div",{children:[a.jsx("div",{className:"text-4xl font-bold text-blue-500 mb-2",children:"Kanıta Dayalı"}),a.jsx("div",{className:"text-gray-500 text-sm font-medium uppercase tracking-wider",children:"Bilimsel Egzersiz Reçetesi"})]}),a.jsxs("div",{children:[a.jsx("div",{className:"text-4xl font-bold text-orange-500 mb-2",children:"Birebir"}),a.jsx("div",{className:"text-gray-500 text-sm font-medium uppercase tracking-wider",children:"Fizyoterapist Takibi"})]})]})})}),a.jsxs("footer",{id:"contact",className:"bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-gray-300 pt-20 pb-10 w-full relative overflow-hidden",style:{scrollMarginTop:"140px"},children:[a.jsx("div",{className:"absolute top-0 left-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl"}),a.jsx("div",{className:"absolute bottom-0 right-0 w-96 h-96 bg-teal-600/10 rounded-full blur-3xl"}),a.jsxs("div",{className:"container mx-auto px-4 max-w-7xl relative z-10",children:[a.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 mb-16",children:[a.jsxs("div",{className:"lg:col-span-2",children:[a.jsxs("div",{className:"flex items-center gap-3 mb-6",children:[a.jsx("div",{className:"w-12 h-12 bg-gradient-to-br from-blue-500 to-teal-500 rounded-xl flex items-center justify-center",children:a.jsx("span",{className:"text-white text-xl font-bold",children:"E"})}),a.jsx("span",{className:"text-2xl font-bold text-white bg-gradient-to-r from-blue-400 to-teal-400 bg-clip-text text-transparent",children:"EgzersizLab"})]}),a.jsxs("p",{className:"text-sm leading-relaxed mb-6 text-gray-400",children:["EgzersizLab, bilimin ışığında kişiye özel rehabilitasyon ve egzersiz çözümleri sunan yeni nesil dijital sağlık platformudur. ",a.jsx("span",{className:"text-teal-400 font-semibold",children:"Hareket, en güçlü ilaçtır."})]}),a.jsxs("div",{className:"mb-6",children:[a.jsx("h5",{className:"text-white font-semibold mb-3 text-sm",children:"📧 Bültenimize Abone Olun"}),a.jsxs("div",{className:"flex gap-2",children:[a.jsx("input",{type:"email",placeholder:"E-posta adresiniz",className:"flex-1 px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"}),a.jsx("button",{className:"px-6 py-2 bg-gradient-to-r from-blue-600 to-teal-600 text-white rounded-lg font-semibold hover:from-blue-700 hover:to-teal-700 transition text-sm",children:"Abone Ol"})]}),a.jsx("p",{className:"text-xs text-gray-500 mt-2",children:"Sağlık ipuçları ve özel kampanyalardan haberdar olun"})]}),a.jsxs("div",{children:[a.jsx("h5",{className:"text-white font-semibold mb-3 text-sm",children:"Bizi Takip Edin"}),a.jsxs("div",{className:"flex gap-3",children:[a.jsx("a",{href:"https://instagram.com/egzersizlab",target:"_blank",rel:"noopener noreferrer",className:"social-icon w-11 h-11 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl flex items-center justify-center hover:scale-110 hover:shadow-lg transition-all duration-300 cursor-pointer group",title:"Instagram",children:a.jsx("svg",{className:"w-5 h-5 text-white",fill:"currentColor",viewBox:"0 0 24 24",children:a.jsx("path",{d:"M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"})})}),a.jsx("a",{href:"https://linkedin.com/company/egzersizlab",target:"_blank",rel:"noopener noreferrer",className:"social-icon w-11 h-11 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center hover:scale-110 hover:shadow-lg transition-all duration-300 cursor-pointer group",title:"LinkedIn",children:a.jsx("svg",{className:"w-5 h-5 text-white",fill:"currentColor",viewBox:"0 0 24 24",children:a.jsx("path",{d:"M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"})})}),a.jsx("a",{href:"https://youtube.com/@egzersizlab",target:"_blank",rel:"noopener noreferrer",className:"social-icon w-11 h-11 bg-gradient-to-br from-red-600 to-red-700 rounded-xl flex items-center justify-center hover:scale-110 hover:shadow-lg transition-all duration-300 cursor-pointer group",title:"YouTube",children:a.jsx("svg",{className:"w-5 h-5 text-white",fill:"currentColor",viewBox:"0 0 24 24",children:a.jsx("path",{d:"M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"})})}),a.jsx("a",{href:"https://wa.me/905551234567",target:"_blank",rel:"noopener noreferrer",className:"social-icon w-11 h-11 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center hover:scale-110 hover:shadow-lg transition-all duration-300 cursor-pointer group",title:"WhatsApp",children:a.jsx("svg",{className:"w-5 h-5 text-white",fill:"currentColor",viewBox:"0 0 24 24",children:a.jsx("path",{d:"M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.372a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"})})})]})]})]}),a.jsxs("div",{children:[a.jsxs("h4",{className:"text-white font-bold mb-6 text-lg flex items-center gap-2",children:[a.jsx("span",{className:"w-1 h-6 bg-gradient-to-b from-blue-500 to-teal-500 rounded-full"}),"Keşfet"]}),a.jsxs("ul",{className:"space-y-2.5",children:[a.jsx("li",{children:a.jsxs("a",{href:"#process",className:"footer-link group flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-gray-800/50 transition-all duration-300",children:[a.jsx("span",{className:"footer-link-arrow text-gray-500 group-hover:text-teal-400 group-hover:translate-x-1 transition-all duration-300 text-xs",children:"→"}),a.jsx("span",{className:"footer-link-text text-gray-400 group-hover:text-white transition-colors duration-300 text-sm",children:"Sistem Nasıl İşliyor?"})]})}),a.jsx("li",{children:a.jsxs("a",{href:"#packages",className:"footer-link group flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-gray-800/50 transition-all duration-300",children:[a.jsx("span",{className:"footer-link-arrow text-gray-500 group-hover:text-teal-400 group-hover:translate-x-1 transition-all duration-300 text-xs",children:"→"}),a.jsx("span",{className:"footer-link-text text-gray-400 group-hover:text-white transition-colors duration-300 text-sm",children:"Hizmet Paketleri"})]})}),a.jsx("li",{children:a.jsxs("a",{href:"#blog",className:"footer-link group flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-gray-800/50 transition-all duration-300",children:[a.jsx("span",{className:"footer-link-arrow text-gray-500 group-hover:text-teal-400 group-hover:translate-x-1 transition-all duration-300 text-xs",children:"→"}),a.jsx("span",{className:"footer-link-text text-gray-400 group-hover:text-white transition-colors duration-300 text-sm",children:"Blog (Sağlık Rehberi)"})]})}),a.jsx("li",{children:a.jsxs("a",{href:"#",className:"footer-link group flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-gray-800/50 transition-all duration-300",children:[a.jsx("span",{className:"footer-link-arrow text-gray-500 group-hover:text-teal-400 group-hover:translate-x-1 transition-all duration-300 text-xs",children:"→"}),a.jsx("span",{className:"footer-link-text text-gray-400 group-hover:text-white transition-colors duration-300 text-sm",children:"Sıkça Sorulan Sorular"})]})}),a.jsx("li",{children:a.jsxs("a",{href:"#",className:"footer-link group flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-gray-800/50 transition-all duration-300",children:[a.jsx("span",{className:"footer-link-arrow text-gray-500 group-hover:text-teal-400 group-hover:translate-x-1 transition-all duration-300 text-xs",children:"→"}),a.jsx("span",{className:"footer-link-text text-gray-400 group-hover:text-white transition-colors duration-300 text-sm",children:"Müşteri Yorumları"})]})})]})]}),a.jsxs("div",{children:[a.jsxs("h4",{className:"text-white font-bold mb-6 text-lg flex items-center gap-2",children:[a.jsx("span",{className:"w-1 h-6 bg-gradient-to-b from-blue-500 to-teal-500 rounded-full"}),"Kurumsal"]}),a.jsxs("ul",{className:"space-y-2.5",children:[a.jsx("li",{children:a.jsxs("a",{href:"#about",className:"footer-link group flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-gray-800/50 transition-all duration-300",children:[a.jsx("span",{className:"footer-link-arrow text-gray-500 group-hover:text-teal-400 group-hover:translate-x-1 transition-all duration-300 text-xs",children:"→"}),a.jsx("span",{className:"footer-link-text text-gray-400 group-hover:text-white transition-colors duration-300 text-sm",children:"Hakkımızda"})]})}),a.jsx("li",{children:a.jsxs("a",{href:"#",className:"footer-link group flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-gray-800/50 transition-all duration-300",children:[a.jsx("span",{className:"footer-link-arrow text-gray-500 group-hover:text-teal-400 group-hover:translate-x-1 transition-all duration-300 text-xs",children:"→"}),a.jsx("span",{className:"footer-link-text text-gray-400 group-hover:text-white transition-colors duration-300 text-sm",children:"KVKK Aydınlatma Metni"})]})}),a.jsx("li",{children:a.jsxs("a",{href:"#",className:"footer-link group flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-gray-800/50 transition-all duration-300",children:[a.jsx("span",{className:"footer-link-arrow text-gray-500 group-hover:text-teal-400 group-hover:translate-x-1 transition-all duration-300 text-xs",children:"→"}),a.jsx("span",{className:"footer-link-text text-gray-400 group-hover:text-white transition-colors duration-300 text-sm",children:"Mesafeli Satış Sözleşmesi"})]})}),a.jsx("li",{children:a.jsxs("a",{href:"#",className:"footer-link group flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-gray-800/50 transition-all duration-300",children:[a.jsx("span",{className:"footer-link-arrow text-gray-500 group-hover:text-teal-400 group-hover:translate-x-1 transition-all duration-300 text-xs",children:"→"}),a.jsx("span",{className:"footer-link-text text-gray-400 group-hover:text-white transition-colors duration-300 text-sm",children:"İptal ve İade Koşulları"})]})}),a.jsx("li",{children:a.jsxs("a",{href:"#",className:"footer-link group flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-gray-800/50 transition-all duration-300",children:[a.jsx("span",{className:"footer-link-arrow text-gray-500 group-hover:text-teal-400 group-hover:translate-x-1 transition-all duration-300 text-xs",children:"→"}),a.jsx("span",{className:"footer-link-text text-gray-400 group-hover:text-white transition-colors duration-300 text-sm",children:"Kariyer"})]})})]})]}),a.jsxs("div",{children:[a.jsx("h4",{className:"text-white font-bold mb-6 text-lg",children:"Bize Ulaşın"}),a.jsxs("div",{className:"space-y-4",children:[a.jsxs("div",{className:"contact-item flex items-start gap-3 group",children:[a.jsx("div",{className:"w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center group-hover:bg-blue-600 transition",children:a.jsx("svg",{className:"w-5 h-5 text-gray-400 group-hover:text-white transition",fill:"currentColor",viewBox:"0 0 20 20",children:a.jsx("path",{fillRule:"evenodd",d:"M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z",clipRule:"evenodd"})})}),a.jsxs("div",{children:[a.jsx("p",{className:"text-sm font-medium text-white",children:"Adres"}),a.jsx("p",{className:"text-xs text-gray-400",children:"Teknopark İzmir / Türkiye"})]})]}),a.jsxs("div",{className:"contact-item flex items-start gap-3 group",children:[a.jsx("div",{className:"w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center group-hover:bg-blue-600 transition",children:a.jsxs("svg",{className:"w-5 h-5 text-gray-400 group-hover:text-white transition",fill:"currentColor",viewBox:"0 0 20 20",children:[a.jsx("path",{d:"M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"}),a.jsx("path",{d:"M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z"})]})}),a.jsxs("div",{children:[a.jsx("p",{className:"text-sm font-medium text-white",children:"E-posta"}),a.jsx("a",{href:"mailto:iletisim@egzersizlab.com",className:"text-xs text-teal-400 hover:text-teal-300 transition",children:"iletisim@egzersizlab.com"})]})]}),a.jsxs("div",{className:"contact-item flex items-start gap-3 group",children:[a.jsx("div",{className:"w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center group-hover:bg-green-600 transition",children:a.jsx("svg",{className:"w-5 h-5 text-gray-400 group-hover:text-white transition",fill:"currentColor",viewBox:"0 0 20 20",children:a.jsx("path",{d:"M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z"})})}),a.jsxs("div",{children:[a.jsx("p",{className:"text-sm font-medium text-white",children:"WhatsApp"}),a.jsx("a",{href:"https://wa.me/905551234567",target:"_blank",rel:"noopener noreferrer",className:"text-xs text-teal-400 hover:text-teal-300 transition",children:"+90 555 123 45 67"})]})]}),a.jsxs("div",{className:"contact-item flex items-start gap-3 group",children:[a.jsx("div",{className:"w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center group-hover:bg-blue-600 transition",children:a.jsx("svg",{className:"w-5 h-5 text-gray-400 group-hover:text-white transition",fill:"currentColor",viewBox:"0 0 20 20",children:a.jsx("path",{fillRule:"evenodd",d:"M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z",clipRule:"evenodd"})})}),a.jsxs("div",{children:[a.jsx("p",{className:"text-sm font-medium text-white",children:"Çalışma Saatleri"}),a.jsx("p",{className:"text-xs text-gray-400",children:"Pzt - Cuma: 09:00 - 18:00"})]})]})]})]})]}),a.jsx("div",{className:"border-t border-gray-800 pt-8 mb-8",children:a.jsxs("div",{className:"flex flex-wrap items-center justify-center gap-6",children:[a.jsxs("div",{className:"flex items-center gap-2 px-4 py-2 bg-gray-800/50 rounded-lg border border-gray-700",children:[a.jsx("span",{className:"text-green-400",children:"🔒"}),a.jsx("span",{className:"text-xs text-gray-300",children:"KVKK Uyumlu"})]}),a.jsxs("div",{className:"flex items-center gap-2 px-4 py-2 bg-gray-800/50 rounded-lg border border-gray-700",children:[a.jsx("span",{className:"text-blue-400",children:"🛡️"}),a.jsx("span",{className:"text-xs text-gray-300",children:"SSL Güvenli"})]}),a.jsxs("div",{className:"flex items-center gap-2 px-4 py-2 bg-gray-800/50 rounded-lg border border-gray-700",children:[a.jsx("span",{className:"text-yellow-400",children:"⭐"}),a.jsx("span",{className:"text-xs text-gray-300",children:"4.9/5 Müşteri Puanı"})]})]})}),a.jsxs("div",{className:"border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center text-sm gap-4",children:[a.jsx("div",{className:"flex flex-col md:flex-row items-center gap-2",children:a.jsxs("p",{className:"text-gray-400",children:["© 2024 ",a.jsx("span",{className:"text-white font-semibold",children:"EgzersizLab"}),". Tüm hakları saklıdır."]})}),a.jsxs("div",{className:"flex gap-6 flex-wrap justify-center",children:[a.jsx("a",{href:"#",className:"text-gray-400 hover:text-teal-400 transition",children:"Gizlilik Politikası"}),a.jsx("a",{href:"#",className:"text-gray-400 hover:text-teal-400 transition",children:"Kullanım Şartları"}),a.jsx("a",{href:"#",className:"text-gray-400 hover:text-teal-400 transition",children:"Çerez Politikası"})]})]})]})]}),k&&a.jsx("div",{className:"fixed bottom-6 left-6 z-[60] animate-fade-in",children:a.jsxs("a",{href:"#packages",onClick:b=>{b.preventDefault(),v(!0)},className:"group flex items-center gap-3 px-6 py-4 bg-gradient-to-r from-blue-600 via-blue-500 to-teal-500 text-white font-bold text-lg rounded-full shadow-2xl hover:shadow-blue-500/50 transform hover:scale-110 transition-all duration-300",children:[a.jsx("span",{className:"text-2xl",children:"🚀"}),a.jsx("span",{children:"Hemen Başla"}),a.jsx("span",{className:"group-hover:translate-x-1 transition-transform text-xl",children:"→"}),a.jsx("div",{className:"absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse"})]})}),a.jsx(Dh,{}),r&&a.jsx(Zh,{onClose:()=>v(!1),onOpenLogin:()=>{v(!1),d(!0)}}),_&&a.jsx(hx,{onClose:()=>d(!1),onSuccess:()=>d(!1),onOpenRegister:()=>{d(!1),v(!0)}})]})}const Ph="modulepreload",Wh=function(r){return"/"+r},ox={},$h=function(v,_,d){let k=Promise.resolve();if(_&&_.length>0){let S=function(h){return Promise.all(h.map(L=>Promise.resolve(L).then(N=>({status:"fulfilled",value:N}),N=>({status:"rejected",reason:N}))))};document.getElementsByTagName("link");const U=document.querySelector("meta[property=csp-nonce]"),b=(U==null?void 0:U.nonce)||(U==null?void 0:U.getAttribute("nonce"));k=S(_.map(h=>{if(h=Wh(h),h in ox)return;ox[h]=!0;const L=h.endsWith(".css"),N=L?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${h}"]${N}`))return;const Y=document.createElement("link");if(Y.rel=L?"stylesheet":Ph,L||(Y.as="script"),Y.crossOrigin="",Y.href=h,b&&Y.setAttribute("nonce",b),document.head.appendChild(Y),L)return new Promise((H,B)=>{Y.addEventListener("load",H),Y.addEventListener("error",()=>B(new Error(`Unable to preload CSS for ${h}`)))})}))}function E(S){const U=new Event("vite:preloadError",{cancelable:!0});if(U.payload=S,window.dispatchEvent(U),!U.defaultPrevented)throw S}return k.then(S=>{for(const U of S||[])U.status==="rejected"&&E(U.reason);return v().catch(E)})},eg=[{value:"female",label:"Kadın",icon:"👩"},{value:"male",label:"Erkek",icon:"👨"}],tg=[{value:"desk",label:"Masa Başı / Ofis",icon:"💻"},{value:"active",label:"Ayakta / Hareketli",icon:"🚶"},{value:"physical",label:"Bedensel Güç Gerektiren",icon:"💪"}],ag=[{value:"new",label:"Yeni Başladı",helper:"1 aydan kısa süredir",icon:"🆕"},{value:"moderate",label:"Bir Süredir Var",helper:"1-3 ay arası",icon:"⏳"},{value:"chronic",label:"Kronikleşti",helper:"3 aydan uzun süredir",icon:"⚠️"}],lg=[{value:"ache",label:"Sızlama"},{value:"sharp",label:"Batma"},{value:"burning",label:"Yanma",icon:"🔥"},{value:"numbness",label:"Uyuşma",icon:"⚡"},{value:"stiffness",label:"Tutukluk",icon:"🧱"}],ig=[{key:"surgery",question:"Son 6 ay içinde ilgili bölgede ameliyat oldunuz mu?",icon:"🏥"},{key:"chronic",question:"Tanısı konmuş romatolojik veya nörolojik bir hastalığınız var mı?",icon:"🧬",helper:"Örn: MS, Ankilozan Spondilit vb."},{key:"heart",question:"Egzersize engel kalp/tansiyon probleminiz var mı?",icon:"❤️"},{key:"pregnancy",question:"Hamilelik durumunuz veya şüpheniz var mı?",icon:"🤰"}],cx={"head-front":"Baş","head-back":"Baş (Arka)","neck-front":"Boyun","neck-back":"Boyun (Arka)","shoulder-front-left":"Sol Omuz","shoulder-front-right":"Sağ Omuz","shoulder-back-left":"Sol Omuz","shoulder-back-right":"Sağ Omuz",chest:"Göğüs",abdomen:"Karın","hip-front":"Kalça","hip-back":"Kalça","upper-back":"Üst Sırt","mid-back":"Orta Sırt","lower-back":"Bel","thigh-front-left":"Sol Uyluk","thigh-front-right":"Sağ Uyluk","thigh-back-left":"Sol Uyluk","thigh-back-right":"Sağ Uyluk","knee-front-left":"Sol Diz","knee-front-right":"Sağ Diz","knee-back-left":"Sol Diz","knee-back-right":"Sağ Diz","calf-back-left":"Sol Baldır","calf-back-right":"Sağ Baldır","ankle-front-left":"Sol Ayak Bileği","ankle-front-right":"Sağ Ayak Bileği","elbow-front-left":"Sol Dirsek","elbow-front-right":"Sağ Dirsek","elbow-back-left":"Sol Dirsek","elbow-back-right":"Sağ Dirsek","wrist-front-left":"Sol El Bileği","wrist-front-right":"Sağ El Bileği","wrist-back-left":"Sol El Bileği","wrist-back-right":"Sağ El Bileği"},ng=[{id:"head-front",label:"Baş",cx:100,cy:42,r:16},{id:"neck-front",label:"Boyun",cx:100,cy:82,r:10},{id:"shoulder-front-left",label:"Sol Omuz",cx:58,cy:105,r:12},{id:"shoulder-front-right",label:"Sağ Omuz",cx:142,cy:105,r:12},{id:"chest",label:"Göğüs",cx:100,cy:130,r:18},{id:"abdomen",label:"Karın",cx:100,cy:175,r:18},{id:"hip-front",label:"Kalça",cx:100,cy:220,r:16},{id:"elbow-front-left",label:"Sol Dirsek",cx:38,cy:165,r:10},{id:"elbow-front-right",label:"Sağ Dirsek",cx:162,cy:165,r:10},{id:"wrist-front-left",label:"Sol Bilek",cx:38,cy:200,r:8},{id:"wrist-front-right",label:"Sağ Bilek",cx:162,cy:200,r:8},{id:"thigh-front-left",label:"Sol Uyluk",cx:75,cy:280,r:14},{id:"thigh-front-right",label:"Sağ Uyluk",cx:125,cy:280,r:14},{id:"knee-front-left",label:"Sol Diz",cx:73,cy:320,r:12},{id:"knee-front-right",label:"Sağ Diz",cx:127,cy:320,r:12},{id:"ankle-front-left",label:"Sol Ayak Bileği",cx:72,cy:385,r:9},{id:"ankle-front-right",label:"Sağ Ayak Bileği",cx:128,cy:385,r:9}],sg=[{id:"head-back",label:"Baş (Arka)",cx:100,cy:42,r:16},{id:"neck-back",label:"Boyun (Arka)",cx:100,cy:82,r:10},{id:"shoulder-back-left",label:"Sol Omuz",cx:58,cy:105,r:12},{id:"shoulder-back-right",label:"Sağ Omuz",cx:142,cy:105,r:12},{id:"upper-back",label:"Üst Sırt",cx:100,cy:125,r:16},{id:"mid-back",label:"Orta Sırt",cx:100,cy:155,r:16},{id:"lower-back",label:"Bel",cx:100,cy:185,r:16},{id:"hip-back",label:"Kalça",cx:100,cy:220,r:16},{id:"elbow-back-left",label:"Sol Dirsek",cx:38,cy:165,r:10},{id:"elbow-back-right",label:"Sağ Dirsek",cx:162,cy:165,r:10},{id:"wrist-back-left",label:"Sol Bilek",cx:38,cy:200,r:8},{id:"wrist-back-right",label:"Sağ Bilek",cx:162,cy:200,r:8},{id:"thigh-back-left",label:"Sol Uyluk (Arka)",cx:75,cy:280,r:14},{id:"thigh-back-right",label:"Sağ Uyluk (Arka)",cx:125,cy:280,r:14},{id:"knee-back-left",label:"Sol Diz (Arka)",cx:73,cy:320,r:12},{id:"knee-back-right",label:"Sağ Diz (Arka)",cx:127,cy:320,r:12},{id:"calf-back-left",label:"Sol Baldır",cx:72,cy:355,r:10},{id:"calf-back-right",label:"Sağ Baldır",cx:128,cy:355,r:10}],rg=({open:r,onClose:v,onComplete:_,clinicalTestType:d})=>{const[k,E]=g.useState(1),[S,U]=g.useState(null),[b,h]=g.useState(null),[L,N]=g.useState(null),[Y,H]=g.useState(null),[B,ae]=g.useState(null),[Z,G]=g.useState(""),[q,fe]=g.useState(""),[ee,Re]=g.useState([]),[oe,X]=g.useState(null),[I,ne]=g.useState(5),[se,Se]=g.useState([]),[re,Ve]=g.useState({surgery:void 0,chronic:void 0,heart:void 0,pregnancy:void 0}),[xe,_e]=g.useState({front:null,side:null,back:null}),[T,f]=g.useState("");g.useMemo(()=>k/5*100,[k]);const Q=g.useMemo(()=>I<=2?{emoji:"😀",color:"#10b981"}:I<=4?{emoji:"🙂",color:"#22c55e"}:I<=6?{emoji:"😐",color:"#f59e0b"}:I<=8?{emoji:"😣",color:"#f97316"}:{emoji:"😡",color:"#ef4444"},[I]),ce=O=>{Re(te=>te.includes(O)?te.filter(W=>W!==O):[...te,O])},me=(O,te,W)=>a.jsxs("div",{className:"body-diagram-new",children:[a.jsxs("div",{className:"body-diagram-header",children:[a.jsx("span",{className:"body-view-icon",children:W?"👤":"🔙"}),a.jsx("span",{className:"body-view-title",children:te})]}),a.jsx("div",{className:"body-svg-container",children:a.jsxs("svg",{viewBox:"0 0 200 420",className:"body-svg-new",children:[a.jsxs("defs",{children:[a.jsxs("linearGradient",{id:`bodyGrad${W?"F":"B"}`,x1:"0%",y1:"0%",x2:"0%",y2:"100%",children:[a.jsx("stop",{offset:"0%",stopColor:"#f1f5f9"}),a.jsx("stop",{offset:"100%",stopColor:"#e2e8f0"})]}),a.jsx("filter",{id:"bodyShadow",x:"-20%",y:"-20%",width:"140%",height:"140%",children:a.jsx("feDropShadow",{dx:"0",dy:"2",stdDeviation:"3",floodOpacity:"0.1"})})]}),a.jsxs("g",{filter:"url(#bodyShadow)",children:[a.jsx("ellipse",{cx:"100",cy:"42",rx:"28",ry:"32",fill:`url(#bodyGrad${W?"F":"B"})`,stroke:"#cbd5e1",strokeWidth:"1.5"}),a.jsx("rect",{x:"88",y:"72",width:"24",height:"22",rx:"8",fill:`url(#bodyGrad${W?"F":"B"})`,stroke:"#cbd5e1",strokeWidth:"1.5"}),a.jsx("path",{d:"M52 100 Q60 88 88 92 L112 92 Q140 88 148 100 L152 120 Q100 115 48 120 Z",fill:`url(#bodyGrad${W?"F":"B"})`,stroke:"#cbd5e1",strokeWidth:"1.5"}),a.jsx("path",{d:"M52 118 L56 200 Q100 215 144 200 L148 118 Q100 125 52 118",fill:`url(#bodyGrad${W?"F":"B"})`,stroke:"#cbd5e1",strokeWidth:"1.5"}),a.jsx("ellipse",{cx:"100",cy:"220",rx:"46",ry:"28",fill:`url(#bodyGrad${W?"F":"B"})`,stroke:"#cbd5e1",strokeWidth:"1.5"}),a.jsx("path",{d:"M52 100 Q42 105 38 130 L34 175 Q32 190 38 200 L42 200 Q48 188 46 175 L50 130 Q52 115 52 100",fill:`url(#bodyGrad${W?"F":"B"})`,stroke:"#cbd5e1",strokeWidth:"1.5"}),a.jsx("path",{d:"M148 100 Q158 105 162 130 L166 175 Q168 190 162 200 L158 200 Q152 188 154 175 L150 130 Q148 115 148 100",fill:`url(#bodyGrad${W?"F":"B"})`,stroke:"#cbd5e1",strokeWidth:"1.5"}),a.jsx("path",{d:"M68 240 L62 320 Q58 350 62 380 L72 395 L82 395 L86 380 Q88 350 84 320 L78 240",fill:`url(#bodyGrad${W?"F":"B"})`,stroke:"#cbd5e1",strokeWidth:"1.5"}),a.jsx("path",{d:"M132 240 L138 320 Q142 350 138 380 L128 395 L118 395 L114 380 Q112 350 116 320 L122 240",fill:`url(#bodyGrad${W?"F":"B"})`,stroke:"#cbd5e1",strokeWidth:"1.5"})]}),O.map(ke=>{const Ze=ee.includes(ke.id);return a.jsxs("g",{onClick:()=>ce(ke.id),style:{cursor:"pointer"},children:[a.jsx("circle",{cx:ke.cx,cy:ke.cy,r:ke.r+4,className:`pain-area-glow ${Ze?"active":""}`}),a.jsx("circle",{cx:ke.cx,cy:ke.cy,r:ke.r,className:`pain-area ${Ze?"selected":""}`}),Ze&&a.jsx("text",{x:ke.cx,y:ke.cy+4,textAnchor:"middle",className:"pain-check",children:"✓"}),a.jsx("title",{children:cx[ke.id]||ke.label})]},ke.id)})]})})]}),m=O=>{Se(te=>te.includes(O)?te.filter(W=>W!==O):[...te,O])},D=()=>{const O=T.trim();O&&(Re(te=>[...te,O]),f(""))},K=(O,te)=>{if(!te)return;const W=new FileReader;W.onload=ke=>{_e(Ze=>{var ft;return{...Ze,[O]:((ft=ke.target)==null?void 0:ft.result)||null}})},W.readAsDataURL(te)},J=O=>{switch(O){case 1:return S&&b&&L&&Y&&B;case 2:return ee.length>0;case 3:return oe!==null;case 4:return(S==="male"?["surgery","chronic","heart"]:["surgery","chronic","heart","pregnancy"]).every(W=>re[W]!==void 0);case 5:return!0;default:return!0}},ue=async()=>{if(J(k))if(k<5)E(O=>O+1);else{try{const{apiService:O}=await $h(async()=>{const{apiService:Ze}=await Promise.resolve().then(()=>Th);return{apiService:Ze}},void 0),te={gender:S,age:b,height:L,weight:Y,workType:B,chronicConditions:Z,medications:q,selectedAreas:ee,painDuration:oe,painIntensity:I,selectedPainTypes:se,safetyAnswers:re,manualArea:T},W={front:xe.front||null,side:xe.side||null,back:xe.back||null},ke={formData:te,photos:W,completedAt:new Date().toISOString()};await O.saveDashboardData({assessmentResults:ke,photos:W,formData:te})}catch(O){console.error("Dashboard verileri kaydedilirken hata:",O)}ee&&ee.length>0&&localStorage.setItem("userPainAreas",JSON.stringify(ee)),_&&_(),v()}},pe=()=>E(O=>Math.max(1,O-1));return r?a.jsxs("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4","aria-modal":"true",role:"dialog",children:[a.jsxs("div",{className:"assessment-modal bg-white rounded-2xl shadow-2xl w-full max-w-7xl max-h-[98vh] overflow-hidden flex flex-col",children:[a.jsxs("div",{className:"p-8 border-b border-gray-100 sticky top-0 bg-white z-10",children:[a.jsxs("div",{className:"flex items-center justify-between gap-4",children:[a.jsxs("div",{className:"flex items-center gap-4",children:[a.jsx("div",{className:"w-16 h-16 rounded-xl bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center",children:a.jsx("span",{className:"text-white text-3xl",children:"🏥"})}),a.jsxs("div",{children:[a.jsx("h2",{className:"text-4xl font-bold text-gray-900",children:"Vücut Analizi"}),a.jsx("p",{className:"text-gray-500 text-xl mt-1",children:"Kişiselleştirilmiş program için bilgi topluyoruz"})]})]}),a.jsx("button",{onClick:v,className:"w-10 h-10 rounded-full bg-gray-100 hover:bg-red-50 text-gray-400 hover:text-red-500 flex items-center justify-center transition text-2xl","aria-label":"Kapat",children:"×"})]}),a.jsxs("div",{className:"mt-4 flex items-center gap-2",children:[[1,2,3,4,5].map(O=>a.jsx("div",{className:"flex-1 flex items-center gap-1",children:a.jsx("div",{className:`h-2 flex-1 rounded-full transition-all ${O<=k?"bg-emerald-500":"bg-gray-200"}`})},O)),a.jsxs("span",{className:"text-xl font-semibold text-gray-500 ml-2",children:[k,"/5"]})]})]}),a.jsxs("div",{className:"flex-1 overflow-hidden p-8",children:[k===1&&a.jsxs("div",{className:"step1-compact",children:[a.jsxs("div",{className:"section-header-compact",children:[a.jsx("h3",{children:"Fiziksel Profiliniz"}),a.jsx("p",{children:"Kişisel bilgileriniz tedavi planınızı şekillendirir"})]}),a.jsxs("div",{className:"profile-top-row",children:[a.jsx("div",{className:"gender-compact",children:eg.map(O=>a.jsxs("button",{onClick:()=>U(O.value),className:`gender-btn ${S===O.value?"sel":""}`,children:[a.jsx("span",{children:O.icon}),a.jsx("span",{children:O.label})]},O.value))}),a.jsxs("div",{className:"measures-compact",children:[a.jsxs("div",{className:"meas-item",children:[a.jsx("span",{className:"meas-label",children:"Yaş"}),a.jsx("input",{type:"number",min:18,max:100,placeholder:"—",value:b??"",onChange:O=>h(O.target.value?Number(O.target.value):null)})]}),a.jsxs("div",{className:"meas-item",children:[a.jsx("span",{className:"meas-label",children:"Boy"}),a.jsx("input",{type:"number",min:100,max:250,placeholder:"—",value:L??"",onChange:O=>N(O.target.value?Number(O.target.value):null)}),a.jsx("span",{className:"meas-unit",children:"cm"})]}),a.jsxs("div",{className:"meas-item",children:[a.jsx("span",{className:"meas-label",children:"Kilo"}),a.jsx("input",{type:"number",min:30,max:300,placeholder:"—",value:Y??"",onChange:O=>H(O.target.value?Number(O.target.value):null)}),a.jsx("span",{className:"meas-unit",children:"kg"})]})]})]}),a.jsxs("div",{className:"work-compact",children:[a.jsx("label",{className:"field-label-sm",children:"💼 İş Hayatınız"}),a.jsx("div",{className:"work-btns",children:tg.map(O=>a.jsxs("button",{onClick:()=>ae(O.value),className:`work-btn ${B===O.value?"sel":""}`,children:[a.jsx("span",{children:O.icon}),a.jsx("span",{children:O.label})]},O.value))})]}),a.jsxs("div",{className:"optional-compact",children:[a.jsxs("div",{className:"opt-field",children:[a.jsxs("label",{children:["Kronik rahatsızlıklar ",a.jsx("span",{className:"opt-tag",children:"opsiyonel"})]}),a.jsx("textarea",{rows:1,placeholder:"Varsa belirtin...",value:Z,onChange:O=>G(O.target.value)})]}),a.jsxs("div",{className:"opt-field",children:[a.jsxs("label",{children:["Düzenli ilaçlar ",a.jsx("span",{className:"opt-tag",children:"opsiyonel"})]}),a.jsx("textarea",{rows:1,placeholder:"Varsa belirtin...",value:q,onChange:O=>fe(O.target.value)})]})]})]}),k===2&&a.jsxs("div",{className:"step2-compact",children:[a.jsxs("div",{className:"section-header-compact",children:[a.jsx("h3",{children:"Ağrı veya Sorun Nerede?"}),a.jsx("p",{children:"Şekil üzerinde tıklayarak seçin • Birden fazla bölge seçebilirsiniz"})]}),a.jsxs("div",{className:"body-diagrams-compact",children:[me(ng,"ÖN",!0),me(sg,"ARKA",!1)]}),a.jsxs("div",{className:"bottom-row-compact",children:[a.jsx("div",{className:"selected-areas-compact",children:ee.length===0?a.jsx("span",{className:"empty-hint-sm",children:"👆 Bölge seçin"}):ee.map(O=>a.jsxs("span",{className:"area-tag-sm",children:[cx[O]||O.replace(/-/g," "),a.jsx("button",{onClick:()=>ce(O),children:"×"})]},O))}),a.jsxs("div",{className:"manual-add-compact",children:[a.jsx("input",{type:"text",value:T,onChange:O=>f(O.target.value),placeholder:"Başka bölge yazın...",className:"manual-input-sm"}),a.jsx("button",{type:"button",onClick:D,className:"manual-add-btn-sm",children:"+"})]})]})]}),k===3&&a.jsxs("div",{className:"step3-compact",children:[a.jsxs("div",{className:"section-header-compact",children:[a.jsx("h3",{children:"Süre ve Şiddet"}),a.jsx("p",{children:"Ağrınızın ne zamandır devam ettiğini ve şiddetini belirtin"})]}),a.jsxs("div",{className:"step3-grid",children:[a.jsxs("div",{className:"duration-compact",children:[a.jsx("label",{className:"field-label-sm",children:"⏱️ Ne zamandır var?"}),a.jsx("div",{className:"duration-list-compact",children:ag.map(O=>a.jsxs("button",{onClick:()=>X(O.value),className:`duration-item-compact ${oe===O.value?"selected":""}`,children:[a.jsx("span",{className:"dur-icon",children:O.icon}),a.jsxs("div",{className:"dur-text",children:[a.jsx("span",{className:"dur-title",children:O.label}),a.jsx("span",{className:"dur-sub",children:O.helper})]}),oe===O.value&&a.jsx("span",{className:"dur-check",children:"✓"})]},O.value))})]}),a.jsxs("div",{className:"intensity-compact",children:[a.jsx("label",{className:"field-label-sm",children:"📊 Ağrı Şiddeti"}),a.jsxs("div",{className:"intensity-box",children:[a.jsxs("div",{className:"intensity-top",children:[a.jsx("span",{className:"int-emoji",style:{color:Q.color},children:Q.emoji}),a.jsxs("span",{className:"int-val",style:{color:Q.color},children:[I,"/10"]})]}),a.jsxs("div",{className:"int-labels",children:[a.jsx("span",{children:"Hafif"}),a.jsx("span",{children:"Orta"}),a.jsx("span",{children:"Şiddetli"})]}),a.jsx("input",{type:"range",min:1,max:10,value:I,onChange:O=>ne(Number(O.target.value)),className:"int-slider"}),a.jsx("div",{className:"int-nums",children:[1,2,3,4,5,6,7,8,9,10].map(O=>a.jsx("span",{className:I>=O?"act":"",children:O},O))})]}),a.jsxs("label",{className:"field-label-sm mt-3",children:["🎯 Ağrı Tipi ",a.jsx("span",{className:"opt-tag",children:"opsiyonel"})]}),a.jsx("div",{className:"pain-types-compact",children:lg.map(O=>a.jsxs("button",{onClick:()=>m(O.value),className:`ptype-btn ${se.includes(O.value)?"sel":""}`,children:[O.icon&&a.jsx("span",{children:O.icon}),a.jsx("span",{children:O.label})]},O.value))})]})]})]}),k===4&&a.jsxs("div",{className:"step4-compact",children:[a.jsxs("div",{className:"section-header-compact",children:[a.jsx("h3",{children:"Güvenlik Kontrolü"}),a.jsx("p",{children:"Sağlığınız için önemli sorular • Dürüstçe cevaplayın 🛡️"})]}),a.jsx("div",{className:"safety-list-compact",children:ig.map((O,te)=>{if(O.key==="pregnancy"&&S==="male")return null;const W=re[O.key];return a.jsxs("div",{className:"safety-item-compact",children:[a.jsxs("div",{className:"safety-left",children:[a.jsx("span",{className:"safety-num",children:te+1}),a.jsx("span",{className:"safety-ico",children:O.icon}),a.jsxs("div",{className:"safety-txt",children:[a.jsx("span",{className:"safety-q",children:O.question}),O.helper&&a.jsx("span",{className:"safety-h",children:O.helper})]})]}),a.jsxs("div",{className:"safety-btns",children:[a.jsx("button",{onClick:()=>Ve(ke=>({...ke,[O.key]:"no"})),className:`saf-btn no ${W==="no"?"sel":""}`,children:"Hayır"}),a.jsx("button",{onClick:()=>Ve(ke=>({...ke,[O.key]:"yes"})),className:`saf-btn yes ${W==="yes"?"sel":""}`,children:"Evet"})]})]},O.key)})}),Object.values(re).includes("yes")&&a.jsxs("div",{className:"safety-warn-compact",children:[a.jsx("span",{children:"⚠️"}),a.jsx("span",{children:"Belirttiğiniz durumlar nedeniyle, egzersiz programına başlamadan önce doktorunuza danışmanızı öneririz."})]})]}),k===5&&a.jsxs("div",{className:"step5-compact",children:[a.jsxs("div",{className:"section-header-compact",children:[a.jsx("h3",{children:"Postür Fotoğrafları"}),a.jsx("p",{children:"En doğru analiz için fotoğraf ekleyin • İsteğe bağlı"})]}),a.jsxs("div",{className:"photo-info-row",children:[a.jsx("span",{className:"info-chip",children:"🔒 KVKK korumalı"}),a.jsx("span",{className:"info-chip",children:"💡 Dar kıyafet, düz arka plan"})]}),a.jsx("div",{className:"photo-grid-compact",children:[{view:"front",title:"Önden",icon:"👤"},{view:"side",title:"Yandan",icon:"↔️"},{view:"back",title:"Arkadan",icon:"🔙"}].map(({view:O,title:te,icon:W})=>a.jsxs("div",{className:`photo-card-compact ${xe[O]?"has-photo":""}`,onClick:()=>{var ke;return(ke=document.getElementById(`file-${O}`))==null?void 0:ke.click()},children:[xe[O]?a.jsxs("div",{className:"photo-prev-compact",children:[a.jsx("img",{src:xe[O],alt:O}),a.jsx("div",{className:"photo-badge",children:"✓"})]}):a.jsxs("div",{className:"photo-empty-compact",children:[a.jsxs("svg",{viewBox:"0 0 50 100",className:"sil-svg",children:[a.jsx("ellipse",{cx:"25",cy:"12",rx:"10",ry:"11",fill:"#d1d5db"}),a.jsx("rect",{x:"20",y:"22",width:"10",height:"8",rx:"3",fill:"#d1d5db"}),a.jsx("path",{d:"M12 30 Q25 28 38 30 L40 55 Q25 60 10 55 Z",fill:"#d1d5db"}),a.jsx("ellipse",{cx:"25",cy:"65",rx:"14",ry:"10",fill:"#d1d5db"}),a.jsx("rect",{x:"17",y:"74",width:"6",height:"20",rx:"3",fill:"#d1d5db"}),a.jsx("rect",{x:"27",y:"74",width:"6",height:"20",rx:"3",fill:"#d1d5db"})]}),a.jsx("span",{className:"photo-add-icon",children:"📷"})]}),a.jsxs("div",{className:"photo-label",children:[W," ",te]}),a.jsx("input",{id:`file-${O}`,type:"file",accept:"image/*",className:"hidden",onChange:ke=>{var Ze;return K(O,((Ze=ke.target.files)==null?void 0:Ze[0])||null)}})]},O))}),a.jsx("div",{className:"photo-note-compact",children:"ℹ️ Fotoğraf eklemeden de devam edebilirsiniz"})]})]}),a.jsxs("div",{className:"p-8 bg-gray-50/80 border-t border-gray-100 flex items-center gap-4",children:[a.jsx("button",{onClick:pe,disabled:k===1,className:"back-btn",children:"← Geri"}),a.jsx("button",{onClick:ue,className:"next-btn",children:k===5?"✓ Analizi Tamamla":"Devam Et →"})]})]}),a.jsx("style",{children:`
        .assessment-modal {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
        /* Global font size increase for readability */
        .assessment-modal * {
          font-size: inherit;
        }
        .assessment-modal {
          font-size: 18px;
        }
        
        /* Section Header */
        .section-header {
          margin-bottom: 4px;
        }
        .section-header h3 {
          font-size: 24px;
          font-weight: 700;
          color: #1e293b;
          margin: 0;
        }
        .section-header p {
          font-size: 18px;
          color: #64748b;
          margin: 6px 0 0 0;
        }
        
        /* Compact Step 1 */
        .step1-compact {
          display: flex;
          flex-direction: column;
          gap: 14px;
        }
        .profile-top-row {
          display: grid;
          grid-template-columns: auto 1fr;
          gap: 16px;
          align-items: start;
        }
        .gender-compact {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .gender-btn {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 16px 24px;
          border-radius: 12px;
          border: 2px solid #e2e8f0;
          background: #fff;
          font-size: 20px;
          font-weight: 600;
          color: #475569;
          cursor: pointer;
          transition: all 0.2s;
        }
        .gender-btn:hover, .gender-btn.sel {
          border-color: #10b981;
          background: #ecfdf5;
          color: #047857;
        }
        .measures-compact {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 10px;
        }
        .meas-item {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }
        .meas-label {
          font-size: 20px;
          font-weight: 700;
          color: #64748b;
          text-transform: uppercase;
        }
        .meas-item input {
          padding: 20px;
          border: 2px solid #e2e8f0;
          border-radius: 12px;
          font-size: 26px;
          font-weight: 600;
          color: #1e293b;
          background: #f8fafc;
          width: 100%;
        }
        .meas-item input:focus {
          outline: none;
          border-color: #10b981;
          background: #fff;
        }
        .meas-unit {
          font-size: 18px;
          color: #94a3b8;
          margin-top: 4px;
        }
        .work-compact {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .work-btns {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 8px;
        }
        .work-btn {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 10px;
          padding: 20px 16px;
          border-radius: 12px;
          border: 2px solid #e2e8f0;
          background: #fff;
          font-size: 22px;
          font-weight: 600;
          color: #475569;
          cursor: pointer;
          transition: all 0.2s;
        }
        .work-btn:hover, .work-btn.sel {
          border-color: #10b981;
          background: #ecfdf5;
          color: #047857;
        }
        .optional-compact {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 10px;
          padding-top: 10px;
          border-top: 1px dashed #e2e8f0;
        }
        .opt-field {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }
        .opt-field label {
          font-size: 22px;
          font-weight: 500;
          color: #475569;
        }
        .opt-tag {
          font-size: 16px;
          font-weight: 600;
          color: #94a3b8;
          background: #f1f5f9;
          padding: 6px 10px;
          border-radius: 6px;
          margin-left: 6px;
        }
        .opt-field textarea {
          border: 2px solid #e2e8f0;
          border-radius: 12px;
          padding: 18px 20px;
          font-size: 20px;
          color: #334155;
          background: #f8fafc;
          resize: none;
        }
        .opt-field textarea:focus {
          outline: none;
          border-color: #10b981;
          background: #fff;
        }
        
        /* Gender Cards */
        .gender-card {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 14px 18px;
          border-radius: 12px;
          border: 2px solid #e2e8f0;
          background: #fff;
          cursor: pointer;
          transition: all 0.2s;
        }
        .gender-card:hover {
          border-color: #10b981;
          background: #f0fdf4;
        }
        .gender-card.selected {
          border-color: #10b981;
          background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%);
        }
        .gender-icon {
          font-size: 32px;
        }
        .gender-label {
          font-size: 20px;
          font-weight: 600;
          color: #334155;
        }
        .gender-card.selected .gender-label {
          color: #047857;
        }
        
        /* Measurements Grid */
        .measurements-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 12px;
        }
        .measure-field {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }
        .measure-field label {
          font-size: 18px;
          font-weight: 600;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 0.3px;
        }
        .measure-input-wrap {
          display: flex;
          align-items: center;
          background: #f8fafc;
          border: 2px solid #e2e8f0;
          border-radius: 12px;
          overflow: hidden;
          transition: all 0.2s;
        }
        .measure-input-wrap:focus-within {
          border-color: #10b981;
          background: #fff;
        }
        .measure-input-wrap input {
          flex: 1;
          border: none;
          background: transparent;
          padding: 16px;
          font-size: 22px;
          font-weight: 600;
          color: #1e293b;
          width: 100%;
          outline: none;
        }
        .measure-input-wrap input::placeholder {
          color: #cbd5e1;
        }
        .measure-input-wrap .unit {
          padding: 0 16px;
          font-size: 18px;
          color: #94a3b8;
          font-weight: 500;
          background: #f1f5f9;
        }
        
        /* Work Section */
        .work-section {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }
        .field-label {
          font-size: 18px;
          font-weight: 600;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 0.3px;
        }
        .work-options {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 14px;
        }
        .work-card {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 8px;
          padding: 18px 14px;
          border-radius: 14px;
          border: 2px solid #e2e8f0;
          background: #fff;
          cursor: pointer;
          transition: all 0.2s;
        }
        .work-card:hover {
          border-color: #10b981;
          background: #f0fdf4;
        }
        .work-card.selected {
          border-color: #10b981;
          background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%);
        }
        .work-icon {
          font-size: 32px;
        }
        .work-label {
          font-size: 18px;
          font-weight: 600;
          color: #475569;
          text-align: center;
          line-height: 1.4;
        }
        .work-card.selected .work-label {
          color: #047857;
        }
        
        /* Optional Fields */
        .optional-section {
          display: flex;
          flex-direction: column;
          gap: 12px;
          padding-top: 8px;
          border-top: 1px dashed #e2e8f0;
        }
        .optional-field {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }
        .optional-field label {
          font-size: 18px;
          font-weight: 500;
          color: #475569;
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .optional-tag {
          font-size: 14px;
          font-weight: 600;
          color: #94a3b8;
          background: #f1f5f9;
          padding: 4px 8px;
          border-radius: 6px;
          text-transform: uppercase;
        }
        .optional-field textarea {
          border: 2px solid #e2e8f0;
          border-radius: 12px;
          padding: 14px 16px;
          font-size: 18px;
          color: #334155;
          background: #f8fafc;
          resize: none;
          transition: all 0.2s;
        }
        .optional-field textarea:focus {
          outline: none;
          border-color: #10b981;
          background: #fff;
        }
        .optional-field textarea::placeholder {
          color: #94a3b8;
        }
        
        /* Navigation Buttons */
        .back-btn {
          padding: 18px 28px;
          border-radius: 12px;
          border: 2px solid #e2e8f0;
          background: #fff;
          font-size: 20px;
          font-weight: 600;
          color: #64748b;
          cursor: pointer;
          transition: all 0.2s;
        }
        .back-btn:hover:not(:disabled) {
          border-color: #cbd5e1;
          color: #334155;
        }
        .back-btn:disabled {
          opacity: 0.4;
          cursor: not-allowed;
        }
        .next-btn {
          flex: 1;
          padding: 18px 32px;
          border-radius: 12px;
          border: none;
          background: linear-gradient(135deg, #10b981 0%, #059669 100%);
          font-size: 20px;
          font-weight: 700;
          color: #fff;
          cursor: pointer;
          transition: all 0.2s;
          box-shadow: 0 4px 14px rgba(16, 185, 129, 0.3);
        }
        .next-btn:hover {
          transform: translateY(-1px);
          box-shadow: 0 6px 20px rgba(16, 185, 129, 0.4);
        }
        
        /* Legacy styles for other steps */
        .wizard-option-btn {
          display: inline-flex;
          align-items: center;
          gap: 12px;
          padding: 18px 20px;
          border-radius: 12px;
          border: 2px solid #e2e8f0;
          background: #fff;
          font-size: 20px;
          font-weight: 600;
          color: #374151;
          transition: all 0.2s;
          width: 100%;
          justify-content: flex-start;
        }
        .wizard-option-btn.active {
          border-color: #10b981;
          background: #ecfdf5;
          color: #047857;
        }
        .wizard-field {
          display: flex;
          flex-direction: column;
          gap: 8px;
          font-size: 18px;
          color: #4b5563;
        }
        .wizard-field input,
        .wizard-field textarea {
          border: 2px solid #e2e8f0;
          border-radius: 12px;
          padding: 16px 18px;
          font-size: 20px;
          transition: border-color 0.2s;
        }
        .wizard-field input:focus,
        .wizard-field textarea:focus {
          outline: none;
          border-color: #10b981;
        }
        /* Compact Step 2 - Body Selection */
        .step2-compact {
          display: flex;
          flex-direction: column;
          gap: 10px;
          height: 100%;
        }
        .section-header-compact {
          margin-bottom: 0;
        }
        .section-header-compact h3 {
          font-size: 28px;
          font-weight: 700;
          color: #1e293b;
          margin: 0;
        }
        .section-header-compact p {
          font-size: 20px;
          color: #64748b;
          margin: 6px 0 0 0;
        }
        .body-diagrams-compact {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 12px;
          flex: 1;
          min-height: 0;
        }
        .bottom-row-compact {
          display: flex;
          gap: 12px;
          align-items: center;
        }
        .selected-areas-compact {
          flex: 1;
          display: flex;
          flex-wrap: wrap;
          gap: 5px;
          padding: 6px 8px;
          background: #f8fafc;
          border-radius: 8px;
          min-height: 36px;
          max-height: 100px;
          overflow-y: auto;
          overflow-x: hidden;
          align-items: flex-start;
          align-content: flex-start;
        }
        .selected-areas-compact::-webkit-scrollbar {
          width: 8px;
        }
        .selected-areas-compact::-webkit-scrollbar-track {
          background: #f1f5f9;
          border-radius: 4px;
        }
        .selected-areas-compact::-webkit-scrollbar-thumb {
          background: #94a3b8;
          border-radius: 4px;
        }
        .selected-areas-compact::-webkit-scrollbar-thumb:hover {
          background: #64748b;
        }
        .empty-hint-sm {
          font-size: 16px;
          color: #94a3b8;
        }
        .area-tag-sm {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          padding: 4px 8px;
          background: #ecfdf5;
          border: 1px solid #a7f3d0;
          border-radius: 12px;
          font-size: 13px;
          font-weight: 600;
          color: #047857;
          white-space: nowrap;
          flex-shrink: 0;
        }
        .area-tag-sm button {
          background: none;
          border: none;
          color: #059669;
          font-size: 14px;
          cursor: pointer;
          padding: 0;
          line-height: 1;
          margin-left: 2px;
        }
        .manual-add-compact {
          display: flex;
          gap: 6px;
          flex-shrink: 0;
        }
        .manual-input-sm {
          width: 160px;
          padding: 8px 12px;
          border: 2px solid #e2e8f0;
          border-radius: 10px;
          font-size: 14px;
        }
        .manual-input-sm:focus {
          outline: none;
          border-color: #10b981;
        }
        .manual-add-btn-sm {
          width: 40px;
          height: 40px;
          border: none;
          border-radius: 10px;
          background: #10b981;
          color: #fff;
          font-size: 20px;
          font-weight: 700;
          cursor: pointer;
          flex-shrink: 0;
        }
        
        /* Compact Body Diagram */
        .body-diagram-new {
          background: linear-gradient(180deg, #f8fafc 0%, #f1f5f9 100%);
          border: 2px solid #e2e8f0;
          border-radius: 14px;
          overflow: hidden;
          transition: all 0.3s;
          display: flex;
          flex-direction: column;
        }
        .body-diagram-new:hover {
          border-color: #10b981;
        }
        .body-diagram-header {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          padding: 8px;
          background: linear-gradient(135deg, #10b981 0%, #059669 100%);
        }
        .body-view-icon {
          font-size: 20px;
        }
        .body-view-title {
          font-size: 18px;
          font-weight: 700;
          color: #fff;
          letter-spacing: 0.5px;
          text-transform: uppercase;
        }
        .body-svg-container {
          padding: 8px;
          display: flex;
          justify-content: center;
          flex: 1;
          min-height: 0;
        }
        .body-svg-new {
          width: 100%;
          max-width: 160px;
          height: auto;
          max-height: 100%;
        }
        
        /* Legacy grid fallback */
        .body-diagrams-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 16px;
        }
        
        /* Pain area circles */
        .pain-area {
          fill: rgba(16, 185, 129, 0.15);
          stroke: #10b981;
          stroke-width: 2;
          stroke-dasharray: 4 2;
          cursor: pointer;
          transition: all 0.25s ease;
        }
        .pain-area:hover {
          fill: rgba(16, 185, 129, 0.35);
          stroke-width: 2.5;
          stroke-dasharray: none;
        }
        .pain-area.selected {
          fill: #10b981;
          stroke: #047857;
          stroke-width: 3;
          stroke-dasharray: none;
        }
        .pain-area-glow {
          fill: transparent;
          stroke: transparent;
          transition: all 0.25s ease;
        }
        .pain-area-glow.active {
          fill: rgba(16, 185, 129, 0.2);
          stroke: rgba(16, 185, 129, 0.4);
          stroke-width: 2;
          animation: pulseGlow 2s ease-in-out infinite;
        }
        .pain-check {
          fill: #fff;
          font-size: 16px;
          font-weight: 700;
          pointer-events: none;
        }
        
        @keyframes pulseGlow {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.6; transform: scale(1.1); }
        }
        
        /* Legacy body diagram (fallback) */
        .body-diagram {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 8px;
          background: #f8fafc;
          border: 1px solid #e5e7eb;
          border-radius: 16px;
          padding: 16px;
        }
        .body-diagram-title {
          font-size: 20px;
          font-weight: 700;
          letter-spacing: 0.5px;
          color: #6b7280;
          text-transform: uppercase;
        }
        .body-svg {
          width: 100%;
          max-width: 260px;
          height: auto;
        }
        .body-part {
          fill: #e5e7eb;
          stroke: #d1d5db;
          stroke-width: 2px;
          cursor: pointer;
          transition: all 0.2s ease;
        }
        .body-part:hover {
          fill: #a7f3d0;
          stroke: #34d399;
        }
        .body-part.selected {
          fill: #34d399;
          stroke: #059669;
        }
        .pain-slider-ui {
          -webkit-appearance: none;
          width: 100%;
          height: 12px;
          border-radius: 9999px;
          background: linear-gradient(90deg, #10b981 0%, #f59e0b 50%, #ef4444 100%);
          outline: none;
        }
        .pain-slider-ui::-webkit-slider-thumb {
          -webkit-appearance: none;
          width: 24px;
          height: 24px;
          border-radius: 50%;
          background: #fff;
          border: 3px solid #10b981;
          box-shadow: 0 2px 10px rgba(16, 185, 129, 0.4);
          cursor: pointer;
          transition: transform 0.15s;
        }
        .pain-slider-ui::-webkit-slider-thumb:hover {
          transform: scale(1.1);
        }
        .pain-slider-ui::-moz-range-thumb {
          width: 24px;
          height: 24px;
          border-radius: 50%;
          background: #fff;
          border: 3px solid #10b981;
          box-shadow: 0 2px 10px rgba(16, 185, 129, 0.4);
          cursor: pointer;
          transition: transform 0.15s;
        }
        .pain-slider-ui::-moz-range-thumb:hover {
          transform: scale(1.1);
        }
        .safety-card {
          border: 1px solid #e5e7eb;
          background: #f8fafc;
          border-radius: 16px;
          padding: 14px;
        }
        .safety-btn {
          padding: 16px 24px;
          border-radius: 12px;
          border: 2px solid #e5e7eb;
          background: #fff;
          font-size: 20px;
          font-weight: 700;
          color: #374151;
          transition: all 0.2s;
          min-width: 120px;
        }
        .safety-btn.active-yes {
          border-color: #22c55e;
          background: #dcfce7;
          color: #166534;
        }
        .safety-btn.active-no {
          border-color: #10b981;
          background: #ecfdf5;
          color: #047857;
        }
        .alert {
          border-radius: 12px;
          padding: 14px 16px;
          border: 1px solid;
        }
        .alert-warning {
          border-color: #fbbf24;
          background: #fef3c7;
        }
        .alert-info {
          border-color: #93c5fd;
          background: #eff6ff;
        }
        .alert-rules {
          border-color: #e5e7eb;
          background: #f9fafb;
        }
        
        /* Step 2 - Body Selection */
        .selected-areas-wrap {
          min-height: 36px;
          padding: 10px 14px;
          background: #f8fafc;
          border-radius: 10px;
          border: 1px dashed #e2e8f0;
        }
        .empty-hint {
          font-size: 18px;
          color: #94a3b8;
        }
        .selected-areas {
          display: flex;
          flex-wrap: wrap;
          gap: 10px;
        }
        .area-tag {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 10px 14px;
          background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%);
          border: 1px solid #a7f3d0;
          border-radius: 24px;
          font-size: 18px;
          font-weight: 600;
          color: #047857;
        }
        .area-tag button {
          background: none;
          border: none;
          color: #059669;
          font-size: 20px;
          cursor: pointer;
          padding: 0;
          line-height: 1;
          opacity: 0.6;
        }
        .area-tag button:hover {
          opacity: 1;
        }
        .manual-add-row {
          display: flex;
          gap: 10px;
        }
        .manual-input {
          flex: 1;
          padding: 16px 20px;
          border: 2px solid #e2e8f0;
          border-radius: 12px;
          font-size: 20px;
          color: #334155;
          background: #f8fafc;
          transition: all 0.2s;
        }
        .manual-input:focus {
          outline: none;
          border-color: #10b981;
          background: #fff;
        }
        .manual-input::placeholder {
          color: #94a3b8;
        }
        .manual-add-btn {
          padding: 16px 24px;
          border: none;
          border-radius: 12px;
          background: #10b981;
          color: #fff;
          font-size: 20px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
        }
        .manual-add-btn:hover {
          background: #059669;
        }
        
        /* Compact Step 3 */
        .step3-compact {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }
        .step3-grid {
          display: grid;
          grid-template-columns: 1fr 1.2fr;
          gap: 16px;
        }
        .field-label-sm {
          font-size: 20px;
          font-weight: 700;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 0.3px;
          display: block;
          margin-bottom: 8px;
        }
        .mt-3 { margin-top: 12px; }
        .opt-tag {
          font-size: 9px;
          font-weight: 600;
          color: #94a3b8;
          background: #f1f5f9;
          padding: 2px 5px;
          border-radius: 4px;
          text-transform: uppercase;
          margin-left: 4px;
        }
        
        /* Duration Compact */
        .duration-compact {
          display: flex;
          flex-direction: column;
        }
        .duration-list-compact {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .duration-item-compact {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 10px 12px;
          border-radius: 10px;
          border: 2px solid #e2e8f0;
          background: #fff;
          cursor: pointer;
          transition: all 0.2s;
          text-align: left;
        }
        .duration-item-compact:hover {
          border-color: #10b981;
          background: #f0fdf4;
        }
        .duration-item-compact.selected {
          border-color: #10b981;
          background: #ecfdf5;
        }
        .dur-icon {
          font-size: 20px;
          width: 36px;
          height: 36px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: #f1f5f9;
          border-radius: 8px;
        }
        .duration-item-compact.selected .dur-icon {
          background: rgba(16, 185, 129, 0.2);
        }
        .dur-text {
          flex: 1;
          display: flex;
          flex-direction: column;
        }
        .dur-title {
          font-size: 20px;
          font-weight: 700;
          color: #1e293b;
        }
        .dur-sub {
          font-size: 16px;
          color: #64748b;
        }
        .dur-check {
          width: 20px;
          height: 20px;
          border-radius: 50%;
          background: #10b981;
          color: #fff;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 11px;
          font-weight: 700;
        }
        
        /* Intensity Compact */
        .intensity-compact {
          display: flex;
          flex-direction: column;
        }
        .intensity-box {
          background: #f8fafc;
          border: 2px solid #e2e8f0;
          border-radius: 12px;
          padding: 12px;
        }
        .intensity-top {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 10px;
          margin-bottom: 10px;
        }
        .int-emoji {
          font-size: 32px;
          line-height: 1;
        }
        .int-val {
          font-size: 24px;
          font-weight: 800;
        }
        .int-labels {
          display: flex;
          justify-content: space-between;
          font-size: 16px;
          font-weight: 600;
          color: #94a3b8;
          text-transform: uppercase;
          margin-bottom: 4px;
        }
        .int-slider {
          -webkit-appearance: none;
          width: 100%;
          height: 8px;
          border-radius: 8px;
          background: linear-gradient(90deg, #10b981 0%, #f59e0b 50%, #ef4444 100%);
          outline: none;
        }
        .int-slider::-webkit-slider-thumb {
          -webkit-appearance: none;
          width: 22px;
          height: 22px;
          border-radius: 50%;
          background: #fff;
          border: 3px solid #1e293b;
          box-shadow: 0 2px 8px rgba(0,0,0,0.15);
          cursor: pointer;
        }
        .int-nums {
          display: flex;
          justify-content: space-between;
          padding: 0 2px;
          margin-top: 4px;
        }
        .int-nums span {
          font-size: 9px;
          font-weight: 600;
          color: #cbd5e1;
          width: 16px;
          text-align: center;
        }
        .int-nums span.act {
          color: #10b981;
        }
        
        /* Pain Types Compact */
        .pain-types-compact {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 6px;
        }
        .ptype-btn {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 4px;
          padding: 8px;
          border-radius: 8px;
          border: 2px solid #e2e8f0;
          background: #fff;
          font-size: 11px;
          font-weight: 600;
          color: #475569;
          cursor: pointer;
          transition: all 0.2s;
        }
        .ptype-btn:hover {
          border-color: #10b981;
          background: #f0fdf4;
        }
        .ptype-btn.sel {
          border-color: #10b981;
          background: #ecfdf5;
          color: #047857;
        }
        
        /* Legacy Step 3 styles */
        .step3-container {
          display: flex;
          flex-direction: column;
          gap: 20px;
        }
        .duration-section {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }
        .duration-cards {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }
        .duration-card-new {
          display: flex;
          align-items: center;
          gap: 14px;
          padding: 14px 16px;
          border-radius: 14px;
          border: 2px solid #e2e8f0;
          background: #fff;
          cursor: pointer;
          transition: all 0.2s;
          text-align: left;
        }
        .duration-card-new:hover {
          border-color: #10b981;
          background: #f0fdf4;
        }
        .duration-card-new.selected {
          border-color: #10b981;
          background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%);
        }
        .duration-icon {
          font-size: 28px;
          width: 50px;
          height: 50px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: #f1f5f9;
          border-radius: 12px;
        }
        .duration-card-new.selected .duration-icon {
          background: rgba(16, 185, 129, 0.2);
        }
        .duration-content {
          flex: 1;
        }
        .duration-title {
          font-size: 15px;
          font-weight: 700;
          color: #1e293b;
        }
        .duration-helper {
          font-size: 12px;
          color: #64748b;
          margin-top: 2px;
        }
        .duration-check {
          width: 24px;
          height: 24px;
          border-radius: 50%;
          background: #10b981;
          color: #fff;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 14px;
          font-weight: 700;
        }
        
        /* Intensity Section */
        .intensity-section {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }
        .intensity-card {
          background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
          border: 2px solid #e2e8f0;
          border-radius: 16px;
          padding: 20px;
        }
        .intensity-emoji-display {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 12px;
          margin-bottom: 16px;
        }
        .intensity-emoji {
          font-size: 48px;
          line-height: 1;
        }
        .intensity-value {
          font-size: 32px;
          font-weight: 800;
        }
        .intensity-slider-wrap {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .intensity-labels {
          display: flex;
          justify-content: space-between;
          font-size: 11px;
          font-weight: 600;
          color: #94a3b8;
          text-transform: uppercase;
        }
        .intensity-slider {
          -webkit-appearance: none;
          width: 100%;
          height: 10px;
          border-radius: 10px;
          background: linear-gradient(90deg, #10b981 0%, #f59e0b 50%, #ef4444 100%);
          outline: none;
        }
        .intensity-slider::-webkit-slider-thumb {
          -webkit-appearance: none;
          width: 28px;
          height: 28px;
          border-radius: 50%;
          background: #fff;
          border: 4px solid #1e293b;
          box-shadow: 0 4px 12px rgba(0,0,0,0.15);
          cursor: pointer;
        }
        .intensity-scale {
          display: flex;
          justify-content: space-between;
          padding: 0 4px;
        }
        .intensity-scale span {
          font-size: 11px;
          font-weight: 600;
          color: #cbd5e1;
          width: 20px;
          text-align: center;
        }
        .intensity-scale span.active {
          color: #10b981;
        }
        
        /* Pain Type Section */
        .pain-type-section {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }
        .pain-type-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
          gap: 10px;
        }
        .pain-type-btn {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          padding: 16px;
          border-radius: 12px;
          border: 2px solid #e2e8f0;
          background: #fff;
          font-size: 20px;
          font-weight: 600;
          color: #475569;
          cursor: pointer;
          transition: all 0.2s;
        }
        .pain-type-btn:hover {
          border-color: #10b981;
          background: #f0fdf4;
        }
        .pain-type-btn.selected {
          border-color: #10b981;
          background: #ecfdf5;
          color: #047857;
        }
        .pain-type-icon {
          font-size: 16px;
        }
        
        /* Compact Step 4 - Safety */
        .step4-compact {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }
        .safety-list-compact {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .safety-item-compact {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          padding: 12px 14px;
          background: #f8fafc;
          border: 2px solid #e2e8f0;
          border-radius: 12px;
        }
        .safety-left {
          display: flex;
          align-items: center;
          gap: 10px;
          flex: 1;
          min-width: 0;
        }
        .safety-num {
          width: 22px;
          height: 22px;
          border-radius: 50%;
          background: #e2e8f0;
          color: #64748b;
          font-size: 11px;
          font-weight: 700;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }
        .safety-ico {
          font-size: 20px;
          flex-shrink: 0;
        }
        .safety-txt {
          flex: 1;
          min-width: 0;
        }
        .safety-q {
          font-size: 20px;
          font-weight: 600;
          color: #1e293b;
          display: block;
          line-height: 1.4;
        }
        .safety-h {
          font-size: 16px;
          color: #64748b;
          display: block;
          margin-top: 4px;
        }
        .safety-btns {
          display: flex;
          gap: 8px;
          flex-shrink: 0;
        }
        .saf-btn {
          padding: 14px 20px;
          border-radius: 10px;
          border: 2px solid #e2e8f0;
          background: #fff;
          font-size: 18px;
          font-weight: 600;
          color: #64748b;
          cursor: pointer;
          transition: all 0.2s;
        }
        .saf-btn.no:hover, .saf-btn.no.sel {
          border-color: #10b981;
          background: #ecfdf5;
          color: #047857;
        }
        .saf-btn.yes:hover {
          border-color: #f59e0b;
          background: #fffbeb;
        }
        .saf-btn.yes.sel {
          border-color: #f59e0b;
          background: #fef3c7;
          color: #b45309;
        }
        .safety-warn-compact {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 10px 14px;
          background: #fef3c7;
          border: 1px solid #fbbf24;
          border-radius: 10px;
          font-size: 12px;
          color: #92400e;
        }
        
        /* Legacy Step 4 styles */
        .step4-container {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }
        .safety-info-banner {
          display: flex;
          align-items: center;
          gap: 14px;
          padding: 14px 18px;
          background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%);
          border: 1px solid #a7f3d0;
          border-radius: 14px;
        }
        .safety-info-icon {
          font-size: 32px;
        }
        .safety-info-text {
          display: flex;
          flex-direction: column;
          gap: 2px;
        }
        .safety-info-text strong {
          font-size: 20px;
          color: #047857;
        }
        .safety-info-text span {
          font-size: 18px;
          color: #059669;
        }
        .safety-questions-list {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }
        .safety-question-card {
          display: flex;
          align-items: center;
          gap: 14px;
          padding: 16px;
          background: #f8fafc;
          border: 2px solid #e2e8f0;
          border-radius: 14px;
          transition: all 0.2s;
        }
        .safety-question-card:hover {
          border-color: #cbd5e1;
        }
        .safety-question-number {
          width: 40px;
          height: 40px;
          border-radius: 50%;
          background: #e2e8f0;
          color: #64748b;
          font-size: 20px;
          font-weight: 700;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }
        .safety-question-icon {
          font-size: 32px;
          flex-shrink: 0;
        }
        .safety-question-content {
          flex: 1;
          min-width: 0;
        }
        .safety-question-text {
          font-size: 20px;
          font-weight: 600;
          color: #1e293b;
          line-height: 1.5;
        }
        .safety-question-helper {
          font-size: 18px;
          color: #64748b;
          margin-top: 6px;
        }
        .safety-answer-buttons {
          display: flex;
          gap: 8px;
          flex-shrink: 0;
        }
        .safety-answer-btn {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
          padding: 16px 22px;
          border-radius: 12px;
          border: 2px solid #e2e8f0;
          background: #fff;
          font-size: 20px;
          font-weight: 600;
          color: #64748b;
          cursor: pointer;
          transition: all 0.2s;
          min-width: 100px;
        }
        .safety-answer-btn .btn-icon {
          font-size: 24px;
        }
        .safety-answer-btn.no:hover {
          border-color: #10b981;
          background: #f0fdf4;
        }
        .safety-answer-btn.no.selected {
          border-color: #10b981;
          background: #ecfdf5;
          color: #047857;
        }
        .safety-answer-btn.yes:hover {
          border-color: #f59e0b;
          background: #fffbeb;
        }
        .safety-answer-btn.yes.selected {
          border-color: #f59e0b;
          background: #fef3c7;
          color: #b45309;
        }
        .safety-warning-box {
          display: flex;
          align-items: flex-start;
          gap: 14px;
          padding: 16px;
          background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
          border: 1px solid #fbbf24;
          border-radius: 14px;
        }
        .safety-warning-box .warning-icon {
          font-size: 24px;
        }
        .safety-warning-box .warning-content {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }
        .safety-warning-box .warning-content strong {
          font-size: 14px;
          color: #92400e;
        }
        .safety-warning-box .warning-content p {
          font-size: 13px;
          color: #a16207;
          margin: 0;
          line-height: 1.4;
        }
        
        /* Compact Step 5 - Photo Upload */
        .step5-compact {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }
        .photo-info-row {
          display: flex;
          gap: 10px;
          flex-wrap: wrap;
        }
        .info-chip {
          padding: 6px 12px;
          background: #f1f5f9;
          border-radius: 20px;
          font-size: 11px;
          font-weight: 600;
          color: #475569;
        }
        .photo-grid-compact {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 12px;
        }
        .photo-card-compact {
          border: 2px dashed #d1d5db;
          border-radius: 12px;
          background: #f8fafc;
          cursor: pointer;
          transition: all 0.2s;
          overflow: hidden;
        }
        .photo-card-compact:hover {
          border-color: #10b981;
          border-style: solid;
          background: #f0fdf4;
        }
        .photo-card-compact.has-photo {
          border-style: solid;
          border-color: #10b981;
        }
        .photo-empty-compact {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 16px 10px;
          gap: 6px;
          height: 130px;
        }
        .sil-svg {
          width: 50px;
          height: 80px;
        }
        .photo-add-icon {
          font-size: 20px;
        }
        .photo-prev-compact {
          position: relative;
          height: 130px;
        }
        .photo-prev-compact img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
        .photo-badge {
          position: absolute;
          top: 6px;
          right: 6px;
          width: 20px;
          height: 20px;
          border-radius: 50%;
          background: #10b981;
          color: #fff;
          font-size: 10px;
          font-weight: 700;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .photo-label {
          padding: 12px;
          background: #fff;
          text-align: center;
          font-size: 18px;
          font-weight: 600;
          color: #1e293b;
        }
        .photo-note-compact {
          font-size: 20px;
          color: #64748b;
          text-align: center;
          padding: 16px;
          background: #f1f5f9;
          border-radius: 12px;
        }
        .photo-note-compact-old {
          text-align: center;
          font-size: 18px;
          color: #64748b;
          padding: 12px;
          background: #f1f5f9;
          border-radius: 10px;
        }
        
        /* Legacy Step 5 styles */
        .step5-container {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }
        .photo-info-cards {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 12px;
        }
        .photo-info-card {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 12px 14px;
          border-radius: 12px;
        }
        .photo-info-card.privacy {
          background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%);
          border: 1px solid #93c5fd;
        }
        .photo-info-card.tips {
          background: linear-gradient(135deg, #fefce8 0%, #fef08a 100%);
          border: 1px solid #fde047;
        }
        .info-card-icon {
          font-size: 24px;
        }
        .info-card-content {
          display: flex;
          flex-direction: column;
          gap: 2px;
        }
        .info-card-content strong {
          font-size: 18px;
          color: #1e293b;
        }
        .info-card-content span {
          font-size: 16px;
          color: #64748b;
        }
        .photo-upload-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 14px;
        }
        .photo-upload-card {
          border: 2px dashed #d1d5db;
          border-radius: 16px;
          background: #f8fafc;
          cursor: pointer;
          transition: all 0.2s;
          overflow: hidden;
        }
        .photo-upload-card:hover {
          border-color: #10b981;
          border-style: solid;
          background: #f0fdf4;
        }
        .photo-upload-card.has-photo {
          border-style: solid;
          border-color: #10b981;
        }
        .photo-placeholder {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 24px 16px;
          gap: 8px;
        }
        .photo-silhouette {
          width: 60px;
          height: 100px;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .silhouette-svg {
          width: 100%;
          height: 100%;
        }
        .photo-upload-icon {
          font-size: 24px;
        }
        .photo-upload-text {
          font-size: 18px;
          font-weight: 600;
          color: #64748b;
        }
        .photo-preview-wrap {
          position: relative;
          height: 140px;
        }
        .photo-preview-img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
        .photo-preview-overlay {
          position: absolute;
          inset: 0;
          background: rgba(0,0,0,0.5);
          display: flex;
          align-items: center;
          justify-content: center;
          opacity: 0;
          transition: opacity 0.2s;
        }
        .photo-upload-card:hover .photo-preview-overlay {
          opacity: 1;
        }
        .photo-change-btn {
          padding: 8px 14px;
          background: #fff;
          border-radius: 8px;
          font-size: 12px;
          font-weight: 600;
          color: #1e293b;
        }
        .photo-success-badge {
          position: absolute;
          top: 8px;
          right: 8px;
          width: 24px;
          height: 24px;
          border-radius: 50%;
          background: #10b981;
          color: #fff;
          font-size: 12px;
          font-weight: 700;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .photo-card-footer {
          padding: 12px;
          background: #fff;
          text-align: center;
        }
        .photo-card-title {
          font-size: 22px;
          font-weight: 700;
          color: #1e293b;
        }
        .photo-card-hint {
          font-size: 18px;
          color: #64748b;
          margin-top: 4px;
        }
        .photo-skip-note {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          padding: 12px;
          background: #f1f5f9;
          border-radius: 10px;
        }
        .photo-skip-note .skip-icon {
          font-size: 16px;
        }
        .photo-skip-note span {
          font-size: 12px;
          color: #64748b;
        }
        
        /* Legacy Duration Cards */
        .duration-card {
          padding: 16px;
          border-radius: 12px;
          border: 2px solid #e2e8f0;
          background: #fff;
          cursor: pointer;
          transition: all 0.2s;
          text-align: left;
        }
        .duration-card:hover {
          border-color: #10b981;
          background: #f0fdf4;
        }
        .duration-card.selected {
          border-color: #10b981;
          background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%);
        }
        
        @media (max-width: 640px) {
          .measurements-grid {
            grid-template-columns: 1fr;
          }
          .work-options {
            grid-template-columns: 1fr;
          }
          .body-diagrams-grid, .body-diagrams-compact {
            grid-template-columns: 1fr;
          }
          .body-svg-new {
            max-width: 180px;
          }
          .photo-info-cards {
            grid-template-columns: 1fr;
          }
          .photo-upload-grid {
            grid-template-columns: 1fr;
          }
          .safety-question-card {
            flex-wrap: wrap;
          }
          .safety-answer-buttons {
            width: 100%;
            margin-top: 10px;
          }
          .safety-answer-btn {
            flex: 1;
          }
          .step3-grid {
            grid-template-columns: 1fr;
          }
        }
      `})]}):null},og=[{id:"basic",badge:"Temel",name:"Temel Analiz & Egzersiz Planı",subtitle:"Vücudunuzun neye ihtiyacı olduğunu öğrenin ve hemen başlayın.",price:"599",features:["Detaylı anamnez değerlendirmesi","Fizyoterapist tarafından vaka analizi","4-6 haftalık kişiye özel egzersiz reçetesi","Egzersiz videoları ve açıklamaları"],gradient:"from-white to-slate-50",accent:"text-gray-700"},{id:"medium",badge:"⭐ Önerilen",name:"Klinik Takip & İlerleme Paketi",subtitle:"Sadece bir liste değil, dinamik bir iyileşme süreci.",price:"1.299",features:["Temel paketteki tüm hizmetler","Haftalık kontrol ve değerlendirme","Ağrı ve gelişime göre program revizyonu","Sistem üzerinden soru-cevap hakkı","1 aylık aktif takip"],gradient:"from-emerald-50 to-teal-50",accent:"text-emerald-700"},{id:"premium",badge:"👑 Premium",name:"Premium Danışmanlık & Video Analizi",subtitle:"Fizyoterapistiniz cebinizde; yanlış yapma riskini sıfıra indirin.",price:"2.499",features:["Tüm paketlerdeki hizmetler","Video analizi: egzersizlerinizi kaydedin, geri bildirim alın","Hızlı destek (chat/WhatsApp)","Öncelikli değerlendirme (aynı gün dönüş)","Sınırsız program güncellemesi"],gradient:"from-amber-50 to-orange-50",accent:"text-orange-700"}],cg=[{icon:"🛡️",title:"Detaylı Kas Kuvvet Analizi",subtitle:"Manuel kas testi simülasyonu",desc:"Hangi kaslarınız uykuda, hangileri aşırı çalışıyor? (Gluteal amnezi, core stabilizasyonu vb.)"},{icon:"📏",title:"Kas Kısalık ve Esneklik Testleri",subtitle:"Ağrısının sebebi kas kısalığı mı?",desc:"Hamstring, pektoral, iliopsoas, piriformis gerginlik testleri."},{icon:"📐",title:"Eklem Hareket Açıklığı",subtitle:"Gonyometrik analiz",desc:"Eklemler tam açıyla hareket ediyor mu, kısıtlılık derecesi nedir?"},{icon:"🧠",title:"Nörodinamik Testler",subtitle:"Sinir germe testleri",desc:"Ağrı kas kaynaklı mı yoksa sinir sıkışması mı (Fıtık/Siyatik)?"},{icon:"⚖️",title:"Fonksiyonel Denge ve Propriosepsiyon",subtitle:"Vücudun uzaydaki konum algısı ve denge stratejisi",desc:"Vücudun uzaydaki konum algısı ve denge stratejisi."},{icon:"🩺",title:"Hareket Kalitesi Analizi",subtitle:"Çömelme, eğilme ve uzanma sırasında omurga biyomekaniği kontrolü",desc:"Çömelme, eğilme ve uzanma sırasında omurga biyomekaniği kontrolü."}],dg=({open:r,onClose:v,onAddToCart:_,cartItems:d=[]})=>{const[k,E]=g.useState(0),S=L=>d.some(N=>N.id===L),U=L=>{!S(L.id)&&_&&_(L)},b=()=>{k<1&&E(k+1)},h=()=>{k>0&&E(k-1)};return r?a.jsx("div",{className:"fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4",children:a.jsxs("div",{className:"bg-white w-full max-w-[95vw] h-[95vh] rounded-2xl shadow-2xl overflow-hidden relative",children:[a.jsx("button",{onClick:v,className:"absolute top-4 right-4 h-12 w-12 rounded-full bg-white border-2 border-gray-200 shadow-lg flex items-center justify-center text-gray-500 hover:text-gray-700 hover:bg-gray-50 z-30 text-2xl font-bold","aria-label":"Kapat",children:"×"}),a.jsx("div",{className:"carousel-container",children:a.jsxs("div",{className:"carousel-wrapper",style:{transform:`translateX(calc(-${k} * 50%))`},children:[a.jsx("div",{className:"carousel-page",children:a.jsxs("div",{className:"page-content",children:[a.jsxs("div",{className:"success-badge",children:[a.jsx("span",{className:"success-check",children:"✓"}),a.jsx("span",{children:"Ön Profiliniz Sisteme İşlendi"})]}),a.jsxs("div",{className:"status-card",children:[a.jsx("div",{className:"status-icon",children:"📤"}),a.jsx("h3",{className:"status-title",children:"Verileriniz Fizyoterapiste İletildi"}),a.jsx("p",{className:"status-sub",children:"✓ Tüm fotoğraflar ve ağrı haritanız başarıyla gönderildi"}),a.jsxs("div",{className:"ai-banner",children:[a.jsx("span",{className:"ai-icon",children:"🤖"}),a.jsxs("div",{className:"ai-text",children:[a.jsx("strong",{children:"Yapay Zeka Ön Analizi Devam Ediyor"}),a.jsx("span",{children:"Duruş analizi, kas dengesizlik tespiti işleniyor..."})]})]})]}),a.jsxs("div",{className:"cta-card",children:[a.jsx("span",{className:"cta-badge",children:"🎯 SON ADIM"}),a.jsxs("p",{className:"cta-text",children:["Fizyoterapistinizin egzersiz reçetenizi hazırlayabilmesi için ",a.jsx("strong",{children:"size uygun paketi seçin"})]})]}),a.jsxs("div",{className:"progress-card",children:[a.jsxs("div",{className:"progress-header",children:[a.jsx("span",{children:"Süreç İlerlemesi"}),a.jsx("span",{className:"progress-pct",children:"75%"})]}),a.jsx("div",{className:"progress-track",children:a.jsx("div",{className:"progress-fill",style:{width:"75%"}})}),a.jsxs("div",{className:"progress-steps",children:[a.jsx("span",{className:"step done",children:"✓ Bilgiler Gönderildi"}),a.jsx("span",{className:"step current",children:"⏳ Paket Seçimi"})]})]})]})}),a.jsx("div",{className:"carousel-page",children:a.jsxs("div",{className:"page-content-two-columns",children:[a.jsxs("div",{className:"packages-column",children:[a.jsx("h2",{className:"column-title",children:"🎁 Hizmet Paketleri"}),a.jsx("div",{className:"packages-list-vertical",children:og.map(L=>{const N=S(L.id);return a.jsxs("div",{className:`package-card-vertical ${L.id==="medium"?"recommended":""} ${N?"in-cart":""}`,children:[a.jsxs("div",{className:"package-header",children:[a.jsx("span",{className:`package-badge ${L.id}`,children:L.badge}),a.jsxs("span",{className:"package-price",children:[L.price,a.jsx("small",{children:"₺"})]})]}),a.jsx("h3",{className:"package-name",children:L.name}),a.jsx("ul",{className:"package-features",children:L.features.map((Y,H)=>a.jsxs("li",{children:[a.jsx("span",{className:"feat-check",children:"✓"}),Y]},H))}),N?a.jsx("button",{className:"cart-btn added",children:"✓ Sepete Eklendi"}):a.jsx("button",{className:`cart-btn ${L.id==="medium"?"green":""}`,onClick:()=>U(L),children:"🛒 Sepete Ekle"})]},L.id)})})]}),a.jsx("div",{className:"center-arrow",children:a.jsx("button",{onClick:h,className:"arrow-button","aria-label":"Önceki sayfa",children:"→"})}),a.jsxs("div",{className:"tests-column",children:[a.jsxs("div",{className:"tests-header",children:[a.jsx("h2",{className:"column-title",children:"🔒 Paket Sonrası Klinik Testler"}),a.jsx("p",{className:"column-subtitle",children:"Bu testler olmadan reçete yazmayız; paket alımından sonra uygulayacağız."})]}),a.jsx("div",{className:"tests-list-vertical",children:cg.map((L,N)=>a.jsxs("div",{className:"test-card-vertical",children:[a.jsxs("div",{className:"test-header",children:[a.jsx("span",{className:"test-icon",children:L.icon}),a.jsx("span",{className:"lock-icon",children:"🔒"})]}),a.jsxs("div",{className:"test-content",children:[a.jsx("h4",{className:"test-title",children:L.title}),L.subtitle&&a.jsx("p",{className:"test-subtitle",children:L.subtitle}),a.jsx("p",{className:"test-desc",children:L.desc})]})]},N))}),a.jsxs("div",{className:"info-box",children:[a.jsx("span",{className:"info-icon",children:"💡"}),a.jsxs("div",{children:[a.jsx("strong",{children:"Neden bu testler?"}),a.jsx("p",{children:"Egzersiz bir ilaçtır; rastgele verilemez. Bu testlerle nokta atışı tedavi protokolü oluşturuyoruz."})]})]})]})]})})]})}),k===0&&a.jsx("button",{onClick:b,className:"nav-btn nav-btn-right","aria-label":"Sonraki",children:"→"}),a.jsx("div",{className:"page-indicators",children:[0,1].map(L=>a.jsx("button",{onClick:()=>E(L),className:`indicator ${k===L?"active":""}`,"aria-label":`Sayfa ${L+1}`},L))}),a.jsx("style",{children:`
          .carousel-container {
            width: 100%;
          height: 100%;
            overflow: hidden;
            position: relative;
          }
          .carousel-wrapper {
          display: flex;
            width: 200%;
            height: 100%;
            transition: transform 0.5s cubic-bezier(0.4, 0, 0.2, 1);
            will-change: transform;
        }
          .carousel-page {
            width: 50%;
            min-width: 50%;
            max-width: 50%;
            height: 100%;
            flex-shrink: 0;
          overflow: hidden;
            position: relative;
          }
          .page-content {
            padding: 40px;
            max-width: 1200px;
            width: 100%;
            margin: 0 auto;
            height: 100%;
          display: flex;
          flex-direction: column;
            gap: 24px;
            box-sizing: border-box;
            overflow-y: auto;
          }
          .page-content-two-columns {
            padding: 30px;
            width: 100%;
          height: 100%;
            display: grid;
            grid-template-columns: 1fr auto 1fr;
            gap: 20px;
            box-sizing: border-box;
            overflow: hidden;
        }
          
          /* Page 1 Styles */
          .success-badge {
          display: inline-flex;
          align-items: center;
            gap: 12px;
          background: linear-gradient(135deg, #10b981, #059669);
          color: #fff;
            padding: 14px 24px;
          border-radius: 50px;
            font-size: 18px;
          font-weight: 700;
          width: fit-content;
            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.4);
        }
        .success-check {
            width: 28px;
            height: 28px;
          background: #fff;
          color: #10b981;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
            font-size: 16px;
          font-weight: 800;
        }
          .status-card {
          background: #fff;
            border: 2px solid #e2e8f0;
            border-radius: 20px;
            padding: 32px;
          text-align: center;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        }
          .status-icon {
            font-size: 64px;
            margin-bottom: 16px;
        }
          .status-title {
            font-size: 28px;
          font-weight: 800;
          color: #1e293b;
            margin: 0 0 12px 0;
        }
          .status-sub {
            font-size: 18px;
          color: #10b981;
          font-weight: 600;
            margin: 0 0 20px 0;
        }
          .ai-banner {
          background: linear-gradient(135deg, #4f46e5, #7c3aed);
            padding: 20px 24px;
            border-radius: 16px;
          display: flex;
          align-items: center;
            gap: 16px;
          text-align: left;
            margin-top: 20px;
        }
          .ai-icon {
            font-size: 40px;
            flex-shrink: 0;
        }
          .ai-text {
          color: #fff;
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
          .ai-text strong {
          display: block;
            font-size: 20px;
            font-weight: 700;
        }
          .ai-text span {
            font-size: 16px;
          opacity: 0.9;
        }
          .cta-card {
          background: linear-gradient(135deg, #fbbf24, #f97316);
            padding: 24px 32px;
            border-radius: 20px;
          text-align: center;
            box-shadow: 0 4px 20px rgba(249, 115, 22, 0.3);
        }
          .cta-badge {
          display: inline-block;
          background: rgba(255,255,255,0.9);
          color: #ea580c;
            padding: 6px 16px;
          border-radius: 20px;
            font-size: 14px;
          font-weight: 800;
            letter-spacing: 0.5px;
            margin-bottom: 12px;
        }
          .cta-text {
            font-size: 20px;
          color: #fff;
          margin: 0;
            line-height: 1.5;
        }
          .cta-text strong {
            display: block;
            font-size: 24px;
            margin-top: 8px;
        }
          .progress-card {
          background: #f8fafc;
            border: 2px solid #e2e8f0;
            border-radius: 16px;
            padding: 24px;
        }
          .progress-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
            font-size: 18px;
          font-weight: 600;
          color: #64748b;
            margin-bottom: 12px;
        }
          .progress-pct {
          background: #10b981;
          color: #fff;
            padding: 6px 16px;
          border-radius: 20px;
            font-size: 16px;
          font-weight: 700;
        }
          .progress-track {
            height: 12px;
          background: #e2e8f0;
            border-radius: 12px;
          overflow: hidden;
            margin-bottom: 16px;
        }
          .progress-fill {
          height: 100%;
          background: linear-gradient(90deg, #10b981, #34d399);
            border-radius: 12px;
            transition: width 0.5s ease;
        }
          .progress-steps {
          display: flex;
          justify-content: center;
            gap: 16px;
        }
          .step {
            font-size: 16px;
          font-weight: 600;
            padding: 10px 20px;
            border-radius: 10px;
          background: #fff;
            border: 2px solid #e2e8f0;
          color: #64748b;
        }
          .step.done {
          background: #ecfdf5;
          border-color: #a7f3d0;
          color: #047857;
        }
          .step.current {
          background: #fef3c7;
          border-color: #fde047;
          color: #a16207;
        }
        
          /* Page 2 Styles - Two Column Layout */
          .packages-column, .tests-column {
          display: flex;
          flex-direction: column;
            height: 100%;
            overflow-y: auto;
            overflow-x: hidden;
          }
          .packages-column {
            padding-right: 10px;
          }
          .tests-column {
            padding-left: 10px;
            position: relative;
          }
          .tests-header {
            margin-bottom: 16px;
            filter: blur(0.5px);
            opacity: 0.9;
          }
          .tests-list-vertical {
            filter: blur(1.5px);
            opacity: 0.85;
          }
          .tests-column .info-box {
            filter: blur(0.5px);
            opacity: 0.9;
        }
          .column-title {
            font-size: 28px;
            font-weight: 800;
          color: #1e293b;
          text-align: center;
            margin: 0 0 16px 0;
        }
          .column-subtitle {
            font-size: 16px;
          color: #64748b;
          text-align: center;
            margin: 0 0 20px 0;
            line-height: 1.5;
        }
          .packages-list-vertical, .tests-list-vertical {
          display: flex;
          flex-direction: column;
            gap: 16px;
          flex: 1;
            overflow-y: auto;
        }
          .package-card-vertical {
            background: #fff;
          border: 2px solid #e2e8f0;
            border-radius: 16px;
            padding: 20px;
          display: flex;
          flex-direction: column;
            transition: all 0.3s;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
          }
          .package-card-vertical:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
          .package-card-vertical.recommended {
          border-color: #10b981;
          background: linear-gradient(135deg, #f0fdf4, #ecfdf5);
            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.15);
        }
          .package-card-vertical.in-cart {
            border-color: #10b981 !important;
            box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.2);
          }
          .package-card-vertical .package-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
            margin-bottom: 12px;
        }
          .package-card-vertical .package-badge {
            font-size: 12px;
          font-weight: 700;
            padding: 4px 10px;
          border-radius: 20px;
          background: #e2e8f0;
          color: #64748b;
        }
          .package-card-vertical .package-badge.medium {
          background: linear-gradient(135deg, #10b981, #059669);
          color: #fff;
        }
          .package-card-vertical .package-badge.premium {
          background: linear-gradient(135deg, #f59e0b, #d97706);
          color: #fff;
        }
          .package-card-vertical .package-price {
            font-size: 24px;
          font-weight: 800;
          color: #1e293b;
        }
          .package-card-vertical .package-price small {
            font-size: 16px;
          color: #64748b;
        }
          .package-card-vertical .package-name {
            font-size: 20px;
          font-weight: 700;
          color: #1e293b;
            margin: 0 0 12px 0;
            line-height: 1.3;
        }
          .package-card-vertical .package-features {
          list-style: none;
          padding: 0;
            margin: 0 0 16px 0;
          flex: 1;
        }
          .package-card-vertical .package-features li {
            font-size: 15px;
          color: #475569;
            padding: 6px 0;
          display: flex;
          align-items: flex-start;
            gap: 8px;
            line-height: 1.4;
        }
          .package-card-vertical .feat-check {
          color: #10b981;
          font-weight: 700;
          flex-shrink: 0;
            font-size: 16px;
        }
          .package-card-vertical .cart-btn {
          width: 100%;
            padding: 14px;
          border: none;
            border-radius: 10px;
          background: linear-gradient(135deg, #3b82f6, #2563eb);
          color: #fff;
            font-size: 16px;
          font-weight: 700;
          cursor: pointer;
          transition: all 0.2s;
            box-shadow: 0 2px 10px rgba(37, 99, 235, 0.3);
        }
          .package-card-vertical .cart-btn:hover {
          transform: translateY(-1px);
            box-shadow: 0 4px 15px rgba(37, 99, 235, 0.4);
        }
          .package-card-vertical .cart-btn.green {
          background: linear-gradient(135deg, #10b981, #059669);
            box-shadow: 0 2px 10px rgba(16, 185, 129, 0.3);
        }
          .package-card-vertical .cart-btn.added {
          background: linear-gradient(135deg, #6b7280, #4b5563);
        }
          .center-arrow {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0 10px;
        }
          .arrow-button {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            border: none;
            background: #10b981;
            color: #fff;
            font-size: 24px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3);
            display: flex;
            align-items: center;
            justify-content: center;
          }
          .arrow-button:hover {
            background: #059669;
            transform: scale(1.1);
            box-shadow: 0 6px 20px rgba(16, 185, 129, 0.4);
          }
          .test-card-vertical {
            background: #fff;
            border: 2px solid #e2e8f0;
            border-radius: 14px;
            padding: 16px;
          display: flex;
            flex-direction: column;
            gap: 12px;
            transition: all 0.2s;
          }
          .test-card-vertical:hover {
            border-color: #10b981;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
          }
          .test-card-vertical .test-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
          .test-card-vertical .test-icon {
            font-size: 32px;
        }
          .test-card-vertical .lock-icon {
            font-size: 20px;
            opacity: 0.5;
          }
          .test-card-vertical .test-title {
            font-size: 18px;
          font-weight: 700;
          color: #1e293b;
            margin: 0 0 6px 0;
            line-height: 1.3;
        }
          .test-card-vertical .test-subtitle {
            font-size: 15px;
          color: #6366f1;
          font-weight: 600;
            margin: 0 0 6px 0;
        }
          .test-card-vertical .test-desc {
            font-size: 14px;
          color: #64748b;
            line-height: 1.4;
            margin: 0;
          }
          .tests-column .info-box {
            margin-top: 16px;
            padding: 16px;
          flex-shrink: 0;
        }
          .tests-column .info-box strong {
            font-size: 16px;
          color: #92400e;
            margin-bottom: 6px;
        }
          .tests-column .info-box p {
            font-size: 14px;
          color: #a16207;
            margin: 0;
            line-height: 1.4;
          }
          .package-card {
            background: #fff;
            border: 2px solid #e2e8f0;
            border-radius: 20px;
            padding: 32px;
          display: flex;
            flex-direction: column;
            transition: all 0.3s;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
          }
          .package-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 30px rgba(0,0,0,0.12);
        }
          .package-card.recommended {
            border-color: #10b981;
            background: linear-gradient(135deg, #f0fdf4, #ecfdf5);
            box-shadow: 0 8px 30px rgba(16, 185, 129, 0.2);
          }
          .package-card.in-cart {
            border-color: #10b981 !important;
            box-shadow: 0 0 0 4px rgba(16, 185, 129, 0.2);
        }
          .package-header {
          display: flex;
            justify-content: space-between;
          align-items: center;
            margin-bottom: 16px;
        }
          .package-badge {
          font-size: 14px;
            font-weight: 700;
            padding: 6px 14px;
            border-radius: 20px;
            background: #e2e8f0;
            color: #64748b;
        }
          .package-badge.medium {
            background: linear-gradient(135deg, #10b981, #059669);
          color: #fff;
        }
          .package-badge.premium {
            background: linear-gradient(135deg, #f59e0b, #d97706);
          color: #fff;
        }
          .package-price {
            font-size: 32px;
          font-weight: 800;
            color: #1e293b;
          }
          .package-price small {
            font-size: 20px;
            color: #64748b;
          }
          .package-name {
            font-size: 24px;
            font-weight: 700;
          color: #1e293b;
            margin: 0 0 20px 0;
            line-height: 1.3;
        }
          .package-features {
            list-style: none;
            padding: 0;
            margin: 0 0 24px 0;
            flex: 1;
          }
          .package-features li {
            font-size: 18px;
            color: #475569;
            padding: 8px 0;
          display: flex;
            align-items: flex-start;
          gap: 10px;
            line-height: 1.5;
        }
          .package-features .more-feat {
            color: #94a3b8;
            font-style: italic;
            padding-left: 24px;
        }
          .feat-check {
            color: #10b981;
          font-weight: 700;
            flex-shrink: 0;
            font-size: 20px;
          }
          .cart-btn {
            width: 100%;
            padding: 18px;
            border: none;
            border-radius: 12px;
            background: linear-gradient(135deg, #3b82f6, #2563eb);
          color: #fff;
            font-size: 18px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
            box-shadow: 0 4px 15px rgba(37, 99, 235, 0.3);
        }
          .cart-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(37, 99, 235, 0.4);
          }
          .cart-btn.green {
            background: linear-gradient(135deg, #10b981, #059669);
            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3);
          }
          .cart-btn.green:hover {
            box-shadow: 0 6px 20px rgba(16, 185, 129, 0.4);
        }
          .cart-btn.added {
            background: linear-gradient(135deg, #6b7280, #4b5563);
        }
          .cart-btn.added:hover {
            background: linear-gradient(135deg, #ef4444, #dc2626);
        }
          
          /* Info Box (used in Page 2) */
          .info-box {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            background: linear-gradient(135deg, #fef3c7, #fde68a);
            border: 2px solid #fbbf24;
          border-radius: 12px;
            padding: 16px;
        }
          .info-icon {
            font-size: 24px;
            flex-shrink: 0;
          }
          
          /* Navigation */
          .nav-btn {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            width: 60px;
            height: 60px;
            border-radius: 50%;
            border: none;
            background: #fff;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
            font-size: 28px;
            color: #10b981;
            cursor: pointer;
            z-index: 20;
            transition: all 0.2s;
          display: flex;
          align-items: center;
            justify-content: center;
        }
          .nav-btn:hover {
          background: #10b981;
          color: #fff;
            transform: translateY(-50%) scale(1.1);
            box-shadow: 0 6px 25px rgba(16, 185, 129, 0.4);
        }
          .nav-btn-left {
            left: 20px;
        }
          .nav-btn-right {
            right: 20px;
          }
          
          /* Page Indicators */
          .page-indicators {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
          display: flex;
          gap: 12px;
            z-index: 20;
        }
          .indicator {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            border: 2px solid #10b981;
            background: transparent;
            cursor: pointer;
          transition: all 0.2s;
            padding: 0;
        }
          .indicator.active {
            background: #10b981;
            width: 32px;
            border-radius: 6px;
        }
          
          @media (max-width: 1400px) {
            .page-content-two-columns {
              grid-template-columns: 1fr auto 1fr;
              gap: 15px;
              padding: 20px;
        }
            .column-title {
              font-size: 24px;
        }
            .package-card-vertical .package-name {
              font-size: 18px;
        }
            .package-card-vertical .package-features li {
              font-size: 14px;
        }
            .test-card-vertical .test-title {
              font-size: 16px;
            }
            .test-card-vertical .test-desc {
              font-size: 13px;
        }
          }
          @media (max-width: 1024px) {
            .page-content-two-columns {
              grid-template-columns: 1fr;
              gap: 20px;
        }
            .center-arrow {
              display: none;
            }
            .page-content {
              padding: 24px;
            }
        }
      `})]})}):null},en={technical:{label:"Teknik",icon:"🔧"},payment:{label:"Ödeme",icon:"💳"},exercise:{label:"Egzersiz",icon:"🏋️"},other:{label:"Diğer",icon:"📝"}},ug=[{id:"TKT-001",subject:"Video oynatma sorunu",category:"technical",priority:"medium",message:"Egzersiz videolarını oynatamıyorum.",status:"pending",createdAt:new Date("2024-12-01")},{id:"TKT-002",subject:"Paket yenileme",category:"payment",priority:"low",message:"Paketimi nasıl yenileyebilirim?",status:"resolved",createdAt:new Date("2024-11-28")}],fg=({open:r,onClose:v})=>{const[_,d]=g.useState("new"),[k,E]=g.useState(""),[S,U]=g.useState("technical"),[b,h]=g.useState(""),[L,N]=g.useState(!1),[Y,H]=g.useState(!1),[B]=g.useState(ug);if(!r)return null;const ae=G=>{G.preventDefault(),N(!0),setTimeout(()=>{N(!1),H(!0),E(""),h(""),setTimeout(()=>{H(!1),d("history")},1500)},1e3)},Z=G=>{const fe={open:{bg:"#dbeafe",text:"#1d4ed8",label:"Açık"},pending:{bg:"#fef3c7",text:"#b45309",label:"İnceleniyor"},resolved:{bg:"#d1fae5",text:"#047857",label:"Çözüldü"}}[G];return a.jsx("span",{style:{background:fe.bg,color:fe.text,padding:"3px 10px",borderRadius:"12px",fontSize:"11px",fontWeight:600},children:fe.label})};return a.jsxs("div",{className:"support-modal-overlay",children:[a.jsx("style",{children:`
        .support-modal-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.5);
          backdrop-filter: blur(6px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
          padding: 16px;
          animation: fadeIn 0.2s ease;
        }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        
        .support-modal {
          background: #fff;
          border-radius: 20px;
          width: 100%;
          max-width: 580px;
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
          animation: slideUp 0.3s ease;
        }
        
        .modal-header {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          padding: 20px 24px;
          color: white;
          position: relative;
          border-radius: 20px 20px 0 0;
        }
        .modal-header h2 {
          font-size: 20px;
          font-weight: 700;
          margin: 0;
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .close-btn {
          position: absolute;
          top: 14px;
          right: 14px;
          width: 32px;
          height: 32px;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.2);
          border: none;
          color: white;
          font-size: 20px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
        }
        .close-btn:hover { background: rgba(255, 255, 255, 0.3); transform: rotate(90deg); }
        
        .tab-bar {
          display: flex;
          background: #f8fafc;
          border-bottom: 1px solid #e2e8f0;
        }
        .tab-btn {
          flex: 1;
          padding: 12px;
          border: none;
          background: transparent;
          font-size: 13px;
          font-weight: 600;
          color: #64748b;
          cursor: pointer;
          transition: all 0.2s;
          position: relative;
        }
        .tab-btn:hover { color: #667eea; }
        .tab-btn.active { color: #667eea; background: white; }
        .tab-btn.active::after {
          content: '';
          position: absolute;
          bottom: -1px;
          left: 0;
          right: 0;
          height: 2px;
          background: #667eea;
        }
        
        .modal-content { padding: 20px 24px; }
        
        .form-row { display: flex; gap: 16px; margin-bottom: 16px; }
        .form-group { flex: 1; }
        .form-group.full { flex: none; width: 100%; margin-bottom: 16px; }
        
        .form-label {
          display: block;
          font-size: 12px;
          font-weight: 600;
          color: #475569;
          margin-bottom: 6px;
        }
        .form-label span { color: #ef4444; }
        
        .form-input {
          width: 100%;
          padding: 10px 14px;
          border: 2px solid #e2e8f0;
          border-radius: 10px;
          font-size: 14px;
          transition: all 0.2s;
          outline: none;
        }
        .form-input:focus { border-color: #667eea; }
        .form-input::placeholder { color: #94a3b8; }
        textarea.form-input { min-height: 80px; resize: none; font-family: inherit; }
        
        .category-options { display: flex; gap: 10px; }
        .category-chip {
          flex: 1;
          padding: 12px 8px;
          border: 2px solid #e2e8f0;
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s;
          background: #fff;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
        }
        .category-chip:hover { border-color: #c7d2fe; background: #f8fafc; }
        .category-chip.selected { border-color: #667eea; background: #eef2ff; }
        .cat-icon { font-size: 20px; }
        .cat-label { font-size: 11px; font-weight: 600; color: #64748b; }
        .category-chip.selected .cat-label { color: #667eea; }
        
        .submit-btn {
          width: 100%;
          padding: 14px;
          border: none;
          border-radius: 12px;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          font-size: 15px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          margin-top: 8px;
        }
        .submit-btn:hover:not(:disabled) { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4); }
        .submit-btn:disabled { opacity: 0.6; cursor: not-allowed; }
        
        .spinner {
          width: 18px;
          height: 18px;
          border: 2px solid rgba(255, 255, 255, 0.3);
          border-top-color: white;
          border-radius: 50%;
          animation: spin 0.8s linear infinite;
        }
        @keyframes spin { to { transform: rotate(360deg); } }
        
        .success-box {
          background: linear-gradient(135deg, #10b981, #059669);
          color: white;
          padding: 24px;
          border-radius: 12px;
          text-align: center;
        }
        .success-box h3 { margin: 0; font-size: 18px; }
        
        .ticket-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 14px;
          border: 1px solid #e2e8f0;
          border-radius: 12px;
          margin-bottom: 10px;
          transition: all 0.2s;
        }
        .ticket-item:hover { border-color: #c7d2fe; background: #fafafa; }
        .ticket-info h4 { margin: 0 0 4px 0; font-size: 14px; color: #1e293b; }
        .ticket-info p { margin: 0; font-size: 12px; color: #64748b; display: flex; align-items: center; gap: 8px; }
        
        .empty-box { text-align: center; padding: 32px; color: #94a3b8; }
        .empty-box span { font-size: 40px; display: block; margin-bottom: 8px; }
      `}),a.jsxs("div",{className:"support-modal",children:[a.jsxs("div",{className:"modal-header",children:[a.jsx("button",{className:"close-btn",onClick:v,children:"×"}),a.jsx("h2",{children:"🎟️ Destek Talebi"})]}),a.jsxs("div",{className:"tab-bar",children:[a.jsx("button",{className:`tab-btn ${_==="new"?"active":""}`,onClick:()=>d("new"),children:"✨ Yeni Talep"}),a.jsxs("button",{className:`tab-btn ${_==="history"?"active":""}`,onClick:()=>d("history"),children:["📋 Taleplerim (",B.length,")"]})]}),a.jsx("div",{className:"modal-content",children:_==="new"?Y?a.jsx("div",{className:"success-box",children:a.jsx("h3",{children:"✅ Talebiniz Alındı!"})}):a.jsxs("form",{onSubmit:ae,children:[a.jsxs("div",{className:"form-group full",children:[a.jsxs("label",{className:"form-label",children:["Konu ",a.jsx("span",{children:"*"})]}),a.jsx("input",{type:"text",className:"form-input",placeholder:"Sorununuzu kısaca özetleyin...",value:k,onChange:G=>E(G.target.value),required:!0})]}),a.jsxs("div",{className:"form-group full",children:[a.jsx("label",{className:"form-label",children:"Kategori"}),a.jsx("div",{className:"category-options",children:Object.keys(en).map(G=>a.jsxs("div",{className:`category-chip ${S===G?"selected":""}`,onClick:()=>U(G),children:[a.jsx("span",{className:"cat-icon",children:en[G].icon}),a.jsx("span",{className:"cat-label",children:en[G].label})]},G))})]}),a.jsxs("div",{className:"form-group full",children:[a.jsxs("label",{className:"form-label",children:["Mesaj ",a.jsx("span",{children:"*"})]}),a.jsx("textarea",{className:"form-input",placeholder:"Detaylı açıklayın...",value:b,onChange:G=>h(G.target.value),required:!0})]}),a.jsx("button",{type:"submit",className:"submit-btn",disabled:L||!k||!b,children:L?a.jsxs(a.Fragment,{children:[a.jsx("div",{className:"spinner"})," Gönderiliyor..."]}):a.jsx(a.Fragment,{children:"📤 Gönder"})})]}):a.jsx("div",{children:B.length===0?a.jsxs("div",{className:"empty-box",children:[a.jsx("span",{children:"📭"}),a.jsx("p",{children:"Henüz talebiniz yok"})]}):B.map(G=>a.jsxs("div",{className:"ticket-item",children:[a.jsxs("div",{className:"ticket-info",children:[a.jsx("h4",{children:G.subject}),a.jsxs("p",{children:[en[G.category].icon," ",en[G.category].label,a.jsx("span",{children:"•"}),G.createdAt.toLocaleDateString("tr-TR")]})]}),Z(G.status)]},G.id))})})]})]})},dx={general:{label:"Genel",icon:"📌"},exercise:{label:"Egzersiz",icon:"🏋️"},payment:{label:"Ödeme",icon:"💳"},account:{label:"Hesap",icon:"👤"}},mg=[{id:"1",question:"EgzersizLab nasıl çalışır?",answer:"EgzersizLab, size özel egzersiz programları oluşturan dijital bir sağlık platformudur. Önce kısa bir değerlendirme yapılır, ardından uzman fizyoterapistlerimiz size özel bir program hazırlar.",category:"general"},{id:"2",question:"Egzersiz programım ne kadar sürede hazırlanır?",answer:"Değerlendirmenizi tamamladıktan sonra egzersiz programınız 24-48 saat içinde hazırlanır ve size bildirim gönderilir.",category:"exercise"},{id:"3",question:"Egzersizleri günde kaç kez yapmalıyım?",answer:"Bu, programınıza ve durumunuza göre değişir. Genellikle günde 1-2 seans önerilir. Detaylar programınızda belirtilecektir.",category:"exercise"},{id:"4",question:"Ödeme yöntemleri nelerdir?",answer:"Kredi kartı, banka kartı ve havale/EFT ile ödeme yapabilirsiniz. Tüm ödemeler 256-bit SSL ile güvence altındadır.",category:"payment"},{id:"5",question:"İptal ve iade politikası nedir?",answer:"Satın alma tarihinden itibaren 14 gün içinde, program başlamadıysa tam iade yapılır. Detaylar için destek ekibimize ulaşabilirsiniz.",category:"payment"},{id:"6",question:"Şifremi nasıl değiştirebilirim?",answer:'Profil menüsünden "Şifre Değiştir" seçeneğine tıklayarak şifrenizi güncelleyebilirsiniz.',category:"account"},{id:"7",question:"Fizyoterapistle nasıl iletişime geçebilirim?",answer:'Premium paket kullanıcıları "Fizyoterapiste Sor" özelliğini kullanabilir. Diğer kullanıcılar destek talebi oluşturabilir.',category:"general"},{id:"8",question:"Egzersiz videolarını indirebilir miyim?",answer:"Şu an için videolar yalnızca çevrimiçi izlenebilmektedir. Offline erişim özelliği yakında eklenecektir.",category:"exercise"}],xg=({open:r,onClose:v,onOpenSupport:_})=>{const[d,k]=g.useState(""),[E,S]=g.useState(null),[U,b]=g.useState(null);if(!r)return null;const h=mg.filter(N=>{const Y=N.question.toLowerCase().includes(d.toLowerCase())||N.answer.toLowerCase().includes(d.toLowerCase()),H=!E||N.category===E;return Y&&H}),L=N=>{b(U===N?null:N)};return a.jsxs("div",{className:"faq-overlay",children:[a.jsx("style",{children:`
        .faq-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.5);
          backdrop-filter: blur(6px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
          padding: 16px;
          animation: fadeIn 0.2s ease;
        }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        
        .faq-modal {
          background: #fff;
          border-radius: 20px;
          width: 100%;
          max-width: 600px;
          max-height: 85vh;
          display: flex;
          flex-direction: column;
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
          animation: slideUp 0.3s ease;
        }
        
        .faq-header {
          background: linear-gradient(135deg, #10b981 0%, #059669 100%);
          padding: 20px 24px;
          color: white;
          position: relative;
          border-radius: 20px 20px 0 0;
        }
        .faq-header h2 {
          font-size: 20px;
          font-weight: 700;
          margin: 0 0 4px 0;
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .faq-header p {
          margin: 0;
          font-size: 13px;
          opacity: 0.9;
        }
        .close-btn {
          position: absolute;
          top: 14px;
          right: 14px;
          width: 32px;
          height: 32px;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.2);
          border: none;
          color: white;
          font-size: 20px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
        }
        .close-btn:hover { background: rgba(255, 255, 255, 0.3); transform: rotate(90deg); }
        
        .search-box {
          padding: 16px 20px;
          background: #f8fafc;
          border-bottom: 1px solid #e2e8f0;
        }
        .search-input {
          width: 100%;
          padding: 12px 16px 12px 40px;
          border: 2px solid #e2e8f0;
          border-radius: 10px;
          font-size: 14px;
          outline: none;
          transition: all 0.2s;
          background: white url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%2394a3b8'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z'%3E%3C/path%3E%3C/svg%3E") 12px center no-repeat;
          background-size: 18px;
        }
        .search-input:focus { border-color: #10b981; }
        .search-input::placeholder { color: #94a3b8; }
        
        .category-tabs {
          display: flex;
          gap: 6px;
          padding: 12px 20px;
          background: #fff;
          border-bottom: 1px solid #e2e8f0;
          overflow-x: auto;
        }
        .cat-tab {
          padding: 8px 14px;
          border: none;
          border-radius: 20px;
          background: #f1f5f9;
          font-size: 13px;
          font-weight: 500;
          color: #64748b;
          cursor: pointer;
          transition: all 0.2s;
          white-space: nowrap;
          display: flex;
          align-items: center;
          gap: 6px;
        }
        .cat-tab:hover { background: #e2e8f0; }
        .cat-tab.active { background: #10b981; color: white; }
        
        .faq-content {
          flex: 1;
          overflow-y: auto;
          padding: 16px 20px;
        }
        
        .faq-item {
          border: 1px solid #e2e8f0;
          border-radius: 12px;
          margin-bottom: 10px;
          overflow: hidden;
          transition: all 0.2s;
        }
        .faq-item:hover { border-color: #c7d2fe; }
        .faq-item.expanded { border-color: #10b981; }
        
        .faq-question {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 14px 16px;
          background: #fff;
          cursor: pointer;
          gap: 12px;
        }
        .faq-question:hover { background: #f8fafc; }
        .faq-item.expanded .faq-question { background: #f0fdf4; }
        
        .q-text {
          font-size: 14px;
          font-weight: 600;
          color: #1e293b;
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .q-icon {
          width: 24px;
          height: 24px;
          border-radius: 6px;
          background: #f1f5f9;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 12px;
          flex-shrink: 0;
        }
        .faq-item.expanded .q-icon { background: #10b981; color: white; }
        
        .expand-icon {
          width: 24px;
          height: 24px;
          border-radius: 50%;
          background: #f1f5f9;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.3s;
          flex-shrink: 0;
          font-size: 14px;
          color: #64748b;
        }
        .faq-item.expanded .expand-icon { transform: rotate(180deg); background: #10b981; color: white; }
        
        .faq-answer {
          max-height: 0;
          overflow: hidden;
          transition: max-height 0.3s ease;
        }
        .faq-item.expanded .faq-answer { max-height: 200px; }
        
        .answer-content {
          padding: 0 16px 16px 50px;
          font-size: 13px;
          line-height: 1.6;
          color: #475569;
        }
        
        .no-results {
          text-align: center;
          padding: 40px 20px;
          color: #94a3b8;
        }
        .no-results span { font-size: 40px; display: block; margin-bottom: 12px; }
        .no-results p { margin: 0; font-size: 14px; }
        
        .help-footer {
          padding: 16px 20px;
          background: #f8fafc;
          border-top: 1px solid #e2e8f0;
          border-radius: 0 0 20px 20px;
          text-align: center;
        }
        .help-footer p {
          margin: 0 0 10px 0;
          font-size: 13px;
          color: #64748b;
        }
        .contact-btn {
          padding: 10px 20px;
          border: none;
          border-radius: 8px;
          background: linear-gradient(135deg, #667eea, #764ba2);
          color: white;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
        }
        .contact-btn:hover { transform: translateY(-1px); box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3); }
      `}),a.jsxs("div",{className:"faq-modal",children:[a.jsxs("div",{className:"faq-header",children:[a.jsx("button",{className:"close-btn",onClick:v,children:"×"}),a.jsx("h2",{children:"❓ Yardım / SSS"}),a.jsx("p",{children:"Sık sorulan sorular ve cevapları"})]}),a.jsx("div",{className:"search-box",children:a.jsx("input",{type:"text",className:"search-input",placeholder:"Soru ara...",value:d,onChange:N=>k(N.target.value)})}),a.jsxs("div",{className:"category-tabs",children:[a.jsx("button",{className:`cat-tab ${E?"":"active"}`,onClick:()=>S(null),children:"📋 Tümü"}),Object.entries(dx).map(([N,{label:Y,icon:H}])=>a.jsxs("button",{className:`cat-tab ${E===N?"active":""}`,onClick:()=>S(N),children:[H," ",Y]},N))]}),a.jsx("div",{className:"faq-content",children:h.length===0?a.jsxs("div",{className:"no-results",children:[a.jsx("span",{children:"🔍"}),a.jsx("p",{children:"Sonuç bulunamadı"})]}):h.map(N=>a.jsxs("div",{className:`faq-item ${U===N.id?"expanded":""}`,children:[a.jsxs("div",{className:"faq-question",onClick:()=>L(N.id),children:[a.jsxs("span",{className:"q-text",children:[a.jsx("span",{className:"q-icon",children:dx[N.category].icon}),N.question]}),a.jsx("span",{className:"expand-icon",children:"▼"})]}),a.jsx("div",{className:"faq-answer",children:a.jsx("div",{className:"answer-content",children:N.answer})})]},N.id))}),a.jsxs("div",{className:"help-footer",children:[a.jsx("p",{children:"Aradığınızı bulamadınız mı?"}),a.jsx("button",{className:"contact-btn",onClick:()=>{v(),_()},children:"🎟️ Destek Talebi Oluştur"})]})]})]})},ux=[{id:"basic",name:"Temel Analiz & Egzersiz Planı",price:599,duration:"Tek Seferlik",description:"Vücudunuzun neye ihtiyacı olduğunu öğrenin ve hemen başlayın.",features:["Detaylı anamnez değerlendirmesi","Fizyoterapist tarafından vaka analizi","4-6 haftalık kişiye özel egzersiz reçetesi","Egzersiz videoları ve açıklamaları"],notIncluded:["Takip ve revizyon hizmeti içermez"]},{id:"pro",name:"Klinik Takip & İlerleme Paketi",price:1299,duration:"1 Aylık",description:"Sadece bir liste değil, dinamik bir iyileşme süreci.",features:["Temel paketteki tüm hizmetler","Haftalık kontrol ve değerlendirme","Ağrı ve gelişime göre program revizyonu","Sistem üzerinden soru-cevap hakkı","1 aylık aktif takip"],popular:!0},{id:"premium",name:"Premium Danışmanlık & Video Analizi",price:2499,duration:"Aylık",description:"Fizyoterapistiniz cebinizde - yanlış yapma riskini sıfıra indirin.",features:["Tüm paketlerdeki hizmetler","Video analizi: Egzersizlerinizi kaydedin, geri bildirim alın","Hızlı destek (chat/WhatsApp)","Öncelikli değerlendirme (aynı gün dönüş)","Sınırsız program güncellemesi"]}],fx=[{id:"1",date:new Date("2024-12-01"),amount:699,description:"Profesyonel Paket - 3 Ay",status:"success"},{id:"2",date:new Date("2024-09-01"),amount:299,description:"Başlangıç Paket - 1 Ay",status:"success"}],pg=({open:r,onClose:v,onPurchase:_,onCancelPackage:d,hasPackage:k,onAddToCart:E,cartItems:S=[]})=>{const[U,b]=g.useState(k?"current":"packages"),[h,L]=g.useState(!1),[N,Y]=g.useState(!1),H=G=>S.some(q=>q.id===G),B=G=>{!H(G.id)&&E&&E({id:G.id,name:G.name,price:G.price.toLocaleString()})};if(!r)return null;const ae=ux[1],Z=45;return a.jsxs("div",{className:"pkg-overlay",children:[a.jsx("style",{children:`
        .pkg-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.5);
          backdrop-filter: blur(6px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
          padding: 16px;
          animation: fadeIn 0.2s ease;
        }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        
        .pkg-modal {
          background: #fff;
          border-radius: 20px;
          width: 100%;
          max-width: 900px;
          max-height: 85vh;
          display: flex;
          flex-direction: column;
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
          animation: slideUp 0.3s ease;
        }
        
        .pkg-header {
          background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
          padding: 20px 24px;
          color: white;
          position: relative;
          border-radius: 20px 20px 0 0;
        }
        .pkg-header h2 {
          font-size: 20px;
          font-weight: 700;
          margin: 0;
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .close-btn {
          position: absolute;
          top: 14px;
          right: 14px;
          width: 32px;
          height: 32px;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.2);
          border: none;
          color: white;
          font-size: 20px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
        }
        .close-btn:hover { background: rgba(255, 255, 255, 0.3); transform: rotate(90deg); }
        
        .tab-bar {
          display: flex;
          background: #f8fafc;
          border-bottom: 1px solid #e2e8f0;
        }
        .tab-btn {
          flex: 1;
          padding: 12px;
          border: none;
          background: transparent;
          font-size: 13px;
          font-weight: 600;
          color: #64748b;
          cursor: pointer;
          transition: all 0.2s;
          position: relative;
        }
        .tab-btn:hover { color: #f59e0b; }
        .tab-btn.active { color: #f59e0b; background: white; }
        .tab-btn.active::after {
          content: '';
          position: absolute;
          bottom: -1px;
          left: 0;
          right: 0;
          height: 2px;
          background: #f59e0b;
        }
        
        .pkg-content {
          flex: 1;
          overflow-y: auto;
          padding: 20px;
        }
        
        /* Current Package */
        .current-pkg {
          background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
          border-radius: 16px;
          padding: 20px;
          border: 2px solid #f59e0b;
        }
        .current-badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          background: #f59e0b;
          color: white;
          padding: 4px 12px;
          border-radius: 20px;
          font-size: 11px;
          font-weight: 700;
          margin-bottom: 12px;
        }
        .current-name {
          font-size: 24px;
          font-weight: 700;
          color: #92400e;
          margin: 0 0 8px 0;
        }
        .current-info {
          display: flex;
          gap: 20px;
          margin-bottom: 16px;
        }
        .info-item {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 13px;
          color: #92400e;
        }
        .days-bar {
          background: rgba(255,255,255,0.6);
          border-radius: 8px;
          height: 8px;
          overflow: hidden;
        }
        .days-fill {
          height: 100%;
          background: #f59e0b;
          border-radius: 8px;
          transition: width 0.3s;
        }
        .days-text {
          font-size: 12px;
          color: #92400e;
          margin-top: 6px;
        }
        
        /* Package Cards */
        .packages-grid {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }
        .pkg-card {
          border: 2px solid #e2e8f0;
          border-radius: 14px;
          padding: 16px;
          display: flex;
          align-items: center;
          gap: 16px;
          transition: all 0.2s;
          cursor: pointer;
          position: relative;
        }
        .pkg-card:hover { border-color: #f59e0b; background: #fffbeb; }
        .pkg-card.popular { border-color: #f59e0b; }
        .popular-tag {
          position: absolute;
          top: -10px;
          right: 16px;
          background: #f59e0b;
          color: white;
          padding: 3px 10px;
          border-radius: 10px;
          font-size: 10px;
          font-weight: 700;
        }
        .pkg-icon {
          width: 48px;
          height: 48px;
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 24px;
          flex-shrink: 0;
        }
        .pkg-card:nth-child(1) .pkg-icon { background: #dbeafe; }
        .pkg-card:nth-child(2) .pkg-icon { background: #fef3c7; }
        .pkg-card:nth-child(3) .pkg-icon { background: #f3e8ff; }
        .pkg-info { flex: 1; }
        .pkg-name {
          font-size: 16px;
          font-weight: 700;
          color: #1e293b;
          margin: 0 0 4px 0;
        }
        .pkg-features {
          font-size: 12px;
          color: #64748b;
          margin: 0;
        }
        .pkg-price {
          text-align: right;
        }
        .price-amount {
          font-size: 22px;
          font-weight: 700;
          color: #f59e0b;
        }
        .price-duration {
          font-size: 11px;
          color: #94a3b8;
        }
        
        /* Payment History */
        .payment-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 14px;
          border: 1px solid #e2e8f0;
          border-radius: 12px;
          margin-bottom: 10px;
        }
        .payment-item:hover { background: #f8fafc; }
        .payment-left {
          display: flex;
          align-items: center;
          gap: 12px;
        }
        .payment-icon {
          width: 40px;
          height: 40px;
          border-radius: 10px;
          background: #d1fae5;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 18px;
        }
        .payment-info h4 {
          margin: 0 0 2px 0;
          font-size: 14px;
          color: #1e293b;
        }
        .payment-info p {
          margin: 0;
          font-size: 12px;
          color: #64748b;
        }
        .payment-right {
          text-align: right;
        }
        .payment-amount {
          font-size: 15px;
          font-weight: 700;
          color: #1e293b;
        }
        .payment-status {
          font-size: 11px;
          padding: 2px 8px;
          border-radius: 10px;
          font-weight: 600;
        }
        .payment-status.success { background: #d1fae5; color: #047857; }
        .payment-status.pending { background: #fef3c7; color: #b45309; }
        .payment-status.failed { background: #fee2e2; color: #dc2626; }
        
        .empty-history {
          text-align: center;
          padding: 32px;
          color: #94a3b8;
        }
        .empty-history span { font-size: 40px; display: block; margin-bottom: 8px; }
        
        .buy-btn {
          margin-top: 12px;
          padding: 10px 16px;
          border: none;
          border-radius: 8px;
          background: linear-gradient(135deg, #f59e0b, #d97706);
          color: white;
          font-size: 13px;
          font-weight: 700;
          cursor: pointer;
          transition: all 0.2s;
          width: 100%;
        }
        .buy-btn:hover:not(:disabled) {
          transform: translateY(-1px);
          box-shadow: 0 4px 12px rgba(245, 158, 11, 0.4);
        }
        .buy-btn:disabled {
          opacity: 0.7;
          cursor: wait;
        }
        .pkg-card {
          flex-direction: column;
          align-items: stretch;
        }
        
        .cancel-btn {
          margin-top: 20px;
          padding: 12px 16px;
          border: 2px solid #fca5a5;
          border-radius: 10px;
          background: #fef2f2;
          color: #dc2626;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
          width: 100%;
        }
        .cancel-btn:hover {
          background: #fee2e2;
          border-color: #f87171;
        }
        
        /* New Package Cards */
        .packages-new-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 16px;
        }
        
        .package-card {
          background: #f8fafc;
          border: 1px solid #e2e8f0;
          border-radius: 16px;
          padding: 20px;
          display: flex;
          flex-direction: column;
          transition: all 0.2s;
          position: relative;
        }
        .package-card:hover {
          border-color: #10b981;
          box-shadow: 0 4px 12px rgba(16, 185, 129, 0.1);
        }
        .package-card.recommended {
          border-color: #10b981;
          border-width: 2px;
        }
        
        .recommended-badge {
          position: absolute;
          top: -12px;
          left: 50%;
          transform: translateX(-50%);
          background: #10b981;
          color: white;
          padding: 4px 12px;
          border-radius: 12px;
          font-size: 11px;
          font-weight: 600;
          white-space: nowrap;
        }
        
        .package-title {
          font-size: 16px;
          font-weight: 700;
          color: #1e293b;
          margin: 0 0 8px 0;
        }
        
        .package-desc {
          font-size: 12px;
          color: #64748b;
          margin: 0 0 16px 0;
          line-height: 1.4;
        }
        
        .package-features {
          flex: 1;
        }
        
        .features-label {
          font-size: 10px;
          font-weight: 700;
          color: #10b981;
          letter-spacing: 0.5px;
          margin-bottom: 10px;
        }
        
        .feature-item {
          display: flex;
          align-items: flex-start;
          gap: 8px;
          font-size: 12px;
          margin-bottom: 8px;
          line-height: 1.4;
        }
        .feature-item.included {
          color: #334155;
        }
        .feature-item.not-included {
          color: #ef4444;
        }
        
        .feature-icon {
          flex-shrink: 0;
          width: 16px;
          height: 16px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 10px;
          font-weight: 700;
        }
        .feature-item.included .feature-icon {
          background: #d1fae5;
          color: #10b981;
        }
        .feature-item.not-included .feature-icon {
          background: #fee2e2;
          color: #ef4444;
        }
        
        .package-footer {
          margin-top: 16px;
          padding-top: 16px;
          border-top: 1px solid #e2e8f0;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        
        .package-price {
          display: flex;
          flex-direction: column;
        }
        .price-value {
          font-size: 20px;
          font-weight: 700;
          color: #1e293b;
        }
        .price-period {
          font-size: 11px;
          color: #94a3b8;
        }
        
        .select-btn {
          padding: 10px 20px;
          border: none;
          border-radius: 8px;
          background: #10b981;
          color: white;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
        }
        .select-btn:hover:not(:disabled):not(.added) {
          background: #059669;
        }
        .select-btn:disabled {
          opacity: 0.6;
          cursor: wait;
        }
        .select-btn.added {
          background: #6b7280;
          cursor: default;
        }
        
        @media (max-width: 768px) {
          .packages-new-grid {
            grid-template-columns: 1fr;
          }
        }
      `}),a.jsxs("div",{className:"pkg-modal",children:[a.jsxs("div",{className:"pkg-header",children:[a.jsx("button",{className:"close-btn",onClick:v,children:"×"}),a.jsx("h2",{children:"📦 Paketlerim & Ödemeler"})]}),a.jsxs("div",{className:"tab-bar",children:[a.jsx("button",{className:`tab-btn ${U==="current"?"active":""}`,onClick:()=>b("current"),children:"✨ Aktif Paket"}),a.jsx("button",{className:`tab-btn ${U==="packages"?"active":""}`,onClick:()=>b("packages"),children:"🎁 Paketler"}),a.jsx("button",{className:`tab-btn ${U==="history"?"active":""}`,onClick:()=>b("history"),children:"📋 Geçmiş"})]}),a.jsxs("div",{className:"pkg-content",children:[U==="current"&&(k?a.jsxs("div",{className:"current-pkg",children:[a.jsx("div",{className:"current-badge",children:"⭐ AKTİF PAKET"}),a.jsxs("h3",{className:"current-name",children:[ae.name," Paket"]}),a.jsxs("div",{className:"current-info",children:[a.jsxs("div",{className:"info-item",children:["💰 ",ae.price,"₺"]}),a.jsxs("div",{className:"info-item",children:["📅 ",ae.duration]}),a.jsxs("div",{className:"info-item",children:["🔥 ",Z," gün kaldı"]})]}),a.jsx("div",{className:"days-bar",children:a.jsx("div",{className:"days-fill",style:{width:`${Z/90*100}%`}})}),a.jsx("div",{className:"days-text",children:"Bitiş: 15 Şubat 2025"}),a.jsxs("div",{style:{marginTop:20,paddingTop:16,borderTop:"1px dashed #d97706"},children:[a.jsx("div",{style:{fontSize:13,fontWeight:600,color:"#92400e",marginBottom:10},children:"Paket Özellikleri:"}),ae.features.map((G,q)=>a.jsxs("div",{style:{display:"flex",alignItems:"center",gap:8,fontSize:13,color:"#92400e",marginBottom:6},children:[a.jsx("span",{children:"✓"})," ",G]},q))]}),a.jsx("button",{className:"cancel-btn",onClick:()=>{d&&(d(),v())},children:"🗑️ Paketi İptal Et (Demo)"})]}):a.jsxs("div",{style:{textAlign:"center",padding:40},children:[a.jsx("div",{style:{fontSize:64,marginBottom:16},children:"📦"}),a.jsx("h3",{style:{margin:"0 0 8px 0",color:"#64748b"},children:"Aktif paketiniz yok"}),a.jsx("p",{style:{color:"#94a3b8",marginBottom:20},children:"Paketler sekmesinden bir paket satın alabilirsiniz."}),a.jsx("button",{style:{padding:"12px 24px",background:"#f59e0b",color:"white",border:"none",borderRadius:10,fontWeight:600,cursor:"pointer"},onClick:()=>b("packages"),children:"🎁 Paketlere Git"})]})),U==="packages"&&a.jsx("div",{className:"packages-new-grid",children:N?a.jsxs("div",{style:{textAlign:"center",padding:40,gridColumn:"1 / -1"},children:[a.jsx("div",{style:{fontSize:64,marginBottom:16},children:"🎉"}),a.jsx("h3",{style:{margin:"0 0 8px 0",color:"#10b981"},children:"Satın Alma Başarılı!"}),a.jsx("p",{style:{color:"#64748b",marginBottom:20},children:"Egzersiz programınız hazırlanıyor..."})]}):ux.map(G=>{var q;return a.jsxs("div",{className:`package-card ${G.popular?"recommended":""}`,children:[G.popular&&a.jsx("div",{className:"recommended-badge",children:"Fizyoterapist önerisi"}),a.jsx("h3",{className:"package-title",children:G.name}),a.jsx("p",{className:"package-desc",children:G.description}),a.jsxs("div",{className:"package-features",children:[a.jsx("div",{className:"features-label",children:"PAKET İÇERİĞİ"}),G.features.map((fe,ee)=>a.jsxs("div",{className:"feature-item included",children:[a.jsx("span",{className:"feature-icon",children:"✓"}),a.jsx("span",{children:fe})]},ee)),(q=G.notIncluded)==null?void 0:q.map((fe,ee)=>a.jsxs("div",{className:"feature-item not-included",children:[a.jsx("span",{className:"feature-icon",children:"✕"}),a.jsx("span",{children:fe})]},ee))]}),a.jsxs("div",{className:"package-footer",children:[a.jsxs("div",{className:"package-price",children:[a.jsxs("span",{className:"price-value",children:[G.price,"₺"]}),a.jsx("span",{className:"price-period",children:G.duration})]}),H(G.id)?a.jsx("button",{className:"select-btn added",children:"✓ Sepette"}):a.jsx("button",{className:"select-btn",onClick:()=>B(G),children:"🛒 Sepete Ekle"})]})]},G.id)})}),U==="history"&&a.jsx("div",{children:fx.length===0?a.jsxs("div",{className:"empty-history",children:[a.jsx("span",{children:"📭"}),a.jsx("p",{children:"Henüz ödeme geçmişiniz yok"})]}):fx.map(G=>a.jsxs("div",{className:"payment-item",children:[a.jsxs("div",{className:"payment-left",children:[a.jsx("div",{className:"payment-icon",children:"✓"}),a.jsxs("div",{className:"payment-info",children:[a.jsx("h4",{children:G.description}),a.jsx("p",{children:G.date.toLocaleDateString("tr-TR",{day:"numeric",month:"long",year:"numeric"})})]})]}),a.jsxs("div",{className:"payment-right",children:[a.jsxs("div",{className:"payment-amount",children:[G.amount,"₺"]}),a.jsx("span",{className:`payment-status ${G.status}`,children:G.status==="success"?"Başarılı":G.status==="pending"?"Bekliyor":"Başarısız"})]})]},G.id))})]})]})]})},hg=({open:r,onClose:v})=>{const[_,d]=g.useState("profile"),[k,E]=g.useState("Ahmet Yılmaz"),[S,U]=g.useState("ahmet@email.com"),[b,h]=g.useState("0555 123 45 67"),[L,N]=g.useState(!0),[Y,H]=g.useState(!1),[B,ae]=g.useState(!0),[Z,G]=g.useState(!0),[q,fe]=g.useState(!0),[ee,Re]=g.useState(!1),[oe,X]=g.useState("light"),[I,ne]=g.useState("medium"),[se,Se]=g.useState(!1);if(!r)return null;const re=()=>{Se(!0),setTimeout(()=>Se(!1),2e3)},Ve=[{id:"profile",label:"Profil",icon:"👤"},{id:"notifications",label:"Bildirimler",icon:"🔔"},{id:"privacy",label:"Gizlilik",icon:"🔒"},{id:"appearance",label:"Görünüm",icon:"🎨"}];return a.jsxs("div",{className:"settings-overlay",children:[a.jsx("style",{children:`
        .settings-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.5);
          backdrop-filter: blur(6px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
          padding: 16px;
          animation: fadeIn 0.2s ease;
        }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        
        .settings-modal {
          background: #fff;
          border-radius: 20px;
          width: 100%;
          max-width: 600px;
          max-height: 85vh;
          display: flex;
          flex-direction: column;
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
          animation: slideUp 0.3s ease;
        }
        
        .settings-header {
          background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%);
          padding: 20px 24px;
          color: white;
          position: relative;
          border-radius: 20px 20px 0 0;
        }
        .settings-header h2 {
          font-size: 20px;
          font-weight: 700;
          margin: 0;
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .close-btn {
          position: absolute;
          top: 14px;
          right: 14px;
          width: 32px;
          height: 32px;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.2);
          border: none;
          color: white;
          font-size: 20px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
        }
        .close-btn:hover { background: rgba(255, 255, 255, 0.3); transform: rotate(90deg); }
        
        .settings-body {
          display: flex;
          flex: 1;
          overflow: hidden;
        }
        
        .settings-nav {
          width: 140px;
          background: #f8fafc;
          border-right: 1px solid #e2e8f0;
          padding: 12px 8px;
          flex-shrink: 0;
        }
        .nav-item {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
          padding: 12px 8px;
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s;
          margin-bottom: 4px;
        }
        .nav-item:hover { background: #e2e8f0; }
        .nav-item.active { background: #6366f1; color: white; }
        .nav-icon { font-size: 20px; }
        .nav-label { font-size: 11px; font-weight: 600; }
        
        .settings-content {
          flex: 1;
          padding: 20px;
          overflow-y: auto;
        }
        
        .section-title {
          font-size: 16px;
          font-weight: 700;
          color: #1e293b;
          margin: 0 0 16px 0;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        
        .form-group {
          margin-bottom: 16px;
        }
        .form-label {
          display: block;
          font-size: 12px;
          font-weight: 600;
          color: #64748b;
          margin-bottom: 6px;
        }
        .form-input {
          width: 100%;
          padding: 10px 14px;
          border: 2px solid #e2e8f0;
          border-radius: 10px;
          font-size: 14px;
          transition: all 0.2s;
          outline: none;
        }
        .form-input:focus { border-color: #6366f1; }
        
        .toggle-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 12px 0;
          border-bottom: 1px solid #f1f5f9;
        }
        .toggle-row:last-child { border-bottom: none; }
        .toggle-info h4 {
          margin: 0 0 2px 0;
          font-size: 14px;
          color: #1e293b;
        }
        .toggle-info p {
          margin: 0;
          font-size: 12px;
          color: #94a3b8;
        }
        
        .toggle-switch {
          width: 44px;
          height: 24px;
          background: #e2e8f0;
          border-radius: 12px;
          position: relative;
          cursor: pointer;
          transition: all 0.2s;
        }
        .toggle-switch.active { background: #6366f1; }
        .toggle-switch::after {
          content: '';
          position: absolute;
          width: 20px;
          height: 20px;
          background: white;
          border-radius: 50%;
          top: 2px;
          left: 2px;
          transition: all 0.2s;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .toggle-switch.active::after { left: 22px; }
        
        .option-cards {
          display: flex;
          gap: 10px;
        }
        .option-card {
          flex: 1;
          padding: 14px;
          border: 2px solid #e2e8f0;
          border-radius: 12px;
          text-align: center;
          cursor: pointer;
          transition: all 0.2s;
        }
        .option-card:hover { border-color: #c7d2fe; }
        .option-card.active { border-color: #6366f1; background: #eef2ff; }
        .option-icon { font-size: 24px; margin-bottom: 6px; }
        .option-label { font-size: 12px; font-weight: 600; color: #475569; }
        .option-card.active .option-label { color: #6366f1; }
        
        .save-bar {
          padding: 16px 20px;
          background: #f8fafc;
          border-top: 1px solid #e2e8f0;
          border-radius: 0 0 20px 20px;
          display: flex;
          justify-content: flex-end;
          gap: 10px;
        }
        .btn {
          padding: 10px 20px;
          border: none;
          border-radius: 10px;
          font-size: 14px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
        }
        .btn-secondary {
          background: #e2e8f0;
          color: #475569;
        }
        .btn-secondary:hover { background: #cbd5e1; }
        .btn-primary {
          background: linear-gradient(135deg, #6366f1, #4f46e5);
          color: white;
        }
        .btn-primary:hover { transform: translateY(-1px); box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3); }
        
        .saved-toast {
          position: fixed;
          top: 20px;
          right: 20px;
          background: #10b981;
          color: white;
          padding: 12px 20px;
          border-radius: 10px;
          font-size: 14px;
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 8px;
          box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
          animation: slideIn 0.3s ease;
          z-index: 1001;
        }
        @keyframes slideIn { from { opacity: 0; transform: translateX(20px); } to { opacity: 1; transform: translateX(0); } }
      `}),a.jsxs("div",{className:"settings-modal",children:[a.jsxs("div",{className:"settings-header",children:[a.jsx("button",{className:"close-btn",onClick:v,children:"×"}),a.jsx("h2",{children:"⚙️ Ayarlar"})]}),a.jsxs("div",{className:"settings-body",children:[a.jsx("div",{className:"settings-nav",children:Ve.map(xe=>a.jsxs("div",{className:`nav-item ${_===xe.id?"active":""}`,onClick:()=>d(xe.id),children:[a.jsx("span",{className:"nav-icon",children:xe.icon}),a.jsx("span",{className:"nav-label",children:xe.label})]},xe.id))}),a.jsxs("div",{className:"settings-content",children:[_==="profile"&&a.jsxs(a.Fragment,{children:[a.jsx("h3",{className:"section-title",children:"👤 Profil Bilgileri"}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Ad Soyad"}),a.jsx("input",{type:"text",className:"form-input",value:k,onChange:xe=>E(xe.target.value)})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"E-posta"}),a.jsx("input",{type:"email",className:"form-input",value:S,onChange:xe=>U(xe.target.value)})]}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Telefon"}),a.jsx("input",{type:"tel",className:"form-input",value:b,onChange:xe=>h(xe.target.value)})]})]}),_==="notifications"&&a.jsxs(a.Fragment,{children:[a.jsx("h3",{className:"section-title",children:"🔔 Bildirim Tercihleri"}),a.jsxs("div",{className:"toggle-row",children:[a.jsxs("div",{className:"toggle-info",children:[a.jsx("h4",{children:"E-posta Bildirimleri"}),a.jsx("p",{children:"Önemli güncellemeler için e-posta al"})]}),a.jsx("div",{className:`toggle-switch ${L?"active":""}`,onClick:()=>N(!L)})]}),a.jsxs("div",{className:"toggle-row",children:[a.jsxs("div",{className:"toggle-info",children:[a.jsx("h4",{children:"SMS Bildirimleri"}),a.jsx("p",{children:"Randevu hatırlatmaları için SMS al"})]}),a.jsx("div",{className:`toggle-switch ${Y?"active":""}`,onClick:()=>H(!Y)})]}),a.jsxs("div",{className:"toggle-row",children:[a.jsxs("div",{className:"toggle-info",children:[a.jsx("h4",{children:"Push Bildirimleri"}),a.jsx("p",{children:"Anlık bildirimler al"})]}),a.jsx("div",{className:`toggle-switch ${B?"active":""}`,onClick:()=>ae(!B)})]}),a.jsxs("div",{className:"toggle-row",children:[a.jsxs("div",{className:"toggle-info",children:[a.jsx("h4",{children:"Egzersiz Hatırlatıcı"}),a.jsx("p",{children:"Günlük egzersiz hatırlatması"})]}),a.jsx("div",{className:`toggle-switch ${Z?"active":""}`,onClick:()=>G(!Z)})]})]}),_==="privacy"&&a.jsxs(a.Fragment,{children:[a.jsx("h3",{className:"section-title",children:"🔒 Gizlilik Ayarları"}),a.jsxs("div",{className:"toggle-row",children:[a.jsxs("div",{className:"toggle-info",children:[a.jsx("h4",{children:"Profil Görünürlüğü"}),a.jsx("p",{children:"Profilim diğer kullanıcılara görünsün"})]}),a.jsx("div",{className:`toggle-switch ${q?"active":""}`,onClick:()=>fe(!q)})]}),a.jsxs("div",{className:"toggle-row",children:[a.jsxs("div",{className:"toggle-info",children:[a.jsx("h4",{children:"İlerleme Paylaşımı"}),a.jsx("p",{children:"Egzersiz ilerlememizi fizyoterapistle paylaş"})]}),a.jsx("div",{className:`toggle-switch ${ee?"active":""}`,onClick:()=>Re(!ee)})]})]}),_==="appearance"&&a.jsxs(a.Fragment,{children:[a.jsx("h3",{className:"section-title",children:"🎨 Görünüm"}),a.jsxs("div",{className:"form-group",children:[a.jsx("label",{className:"form-label",children:"Tema"}),a.jsxs("div",{className:"option-cards",children:[a.jsxs("div",{className:`option-card ${oe==="light"?"active":""}`,onClick:()=>X("light"),children:[a.jsx("div",{className:"option-icon",children:"☀️"}),a.jsx("div",{className:"option-label",children:"Açık"})]}),a.jsxs("div",{className:`option-card ${oe==="dark"?"active":""}`,onClick:()=>X("dark"),children:[a.jsx("div",{className:"option-icon",children:"🌙"}),a.jsx("div",{className:"option-label",children:"Koyu"})]}),a.jsxs("div",{className:`option-card ${oe==="auto"?"active":""}`,onClick:()=>X("auto"),children:[a.jsx("div",{className:"option-icon",children:"🔄"}),a.jsx("div",{className:"option-label",children:"Otomatik"})]})]})]}),a.jsxs("div",{className:"form-group",style:{marginTop:20},children:[a.jsx("label",{className:"form-label",children:"Yazı Boyutu"}),a.jsxs("div",{className:"option-cards",children:[a.jsxs("div",{className:`option-card ${I==="small"?"active":""}`,onClick:()=>ne("small"),children:[a.jsx("div",{className:"option-icon",style:{fontSize:16},children:"A"}),a.jsx("div",{className:"option-label",children:"Küçük"})]}),a.jsxs("div",{className:`option-card ${I==="medium"?"active":""}`,onClick:()=>ne("medium"),children:[a.jsx("div",{className:"option-icon",style:{fontSize:22},children:"A"}),a.jsx("div",{className:"option-label",children:"Orta"})]}),a.jsxs("div",{className:`option-card ${I==="large"?"active":""}`,onClick:()=>ne("large"),children:[a.jsx("div",{className:"option-icon",style:{fontSize:28},children:"A"}),a.jsx("div",{className:"option-label",children:"Büyük"})]})]})]})]})]})]}),a.jsxs("div",{className:"save-bar",children:[a.jsx("button",{className:"btn btn-secondary",onClick:v,children:"İptal"}),a.jsx("button",{className:"btn btn-primary",onClick:re,children:"💾 Kaydet"})]})]}),se&&a.jsx("div",{className:"saved-toast",children:"✓ Ayarlar kaydedildi!"})]})},gg=({open:r,onClose:v})=>{const[_,d]=g.useState(!1);if(!r)return null;const k="gC_L9qAHVJ8",E=[{icon:"📝",title:"Değerlendirme",desc:"3 dakikalık form"},{icon:"🔍",title:"Analiz",desc:"Uzman incelemesi"},{icon:"📋",title:"Program",desc:"Kişiye özel plan"},{icon:"🏋️",title:"Egzersiz",desc:"Video rehberlik"}];return a.jsxs("div",{className:"video-overlay",onClick:v,children:[a.jsx("style",{children:`
        .video-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.85);
          backdrop-filter: blur(8px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
          padding: 20px;
          animation: fadeIn 0.3s ease;
        }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.1); } }
        
        .video-modal {
          background: #fff;
          border-radius: 24px;
          width: 100%;
          max-width: 800px;
          overflow: hidden;
          box-shadow: 0 25px 60px rgba(0, 0, 0, 0.4);
          animation: slideUp 0.4s ease;
        }
        
        .video-header {
          background: linear-gradient(135deg, #ec4899 0%, #8b5cf6 100%);
          padding: 20px 24px;
          color: white;
          position: relative;
        }
        .video-header h2 {
          font-size: 20px;
          font-weight: 700;
          margin: 0 0 4px 0;
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .video-header p {
          margin: 0;
          font-size: 13px;
          opacity: 0.9;
        }
        .close-btn {
          position: absolute;
          top: 14px;
          right: 14px;
          width: 36px;
          height: 36px;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.2);
          border: none;
          color: white;
          font-size: 22px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
        }
        .close-btn:hover { background: rgba(255, 255, 255, 0.3); transform: rotate(90deg); }
        
        .video-container {
          position: relative;
          background: #000;
          aspect-ratio: 16/9;
        }
        
        .video-placeholder {
          position: absolute;
          inset: 0;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          background: linear-gradient(135deg, #1e1b4b 0%, #312e81 100%);
          cursor: pointer;
        }
        
        .play-button {
          width: 80px;
          height: 80px;
          border-radius: 50%;
          background: linear-gradient(135deg, #ec4899, #8b5cf6);
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: all 0.3s;
          box-shadow: 0 8px 30px rgba(236, 72, 153, 0.5);
          animation: pulse 2s infinite;
        }
        .play-button:hover {
          transform: scale(1.1);
          box-shadow: 0 12px 40px rgba(236, 72, 153, 0.6);
        }
        .play-icon {
          width: 0;
          height: 0;
          border-left: 28px solid white;
          border-top: 18px solid transparent;
          border-bottom: 18px solid transparent;
          margin-left: 6px;
        }
        
        .video-title-overlay {
          color: white;
          margin-top: 20px;
          text-align: center;
        }
        .video-title-overlay h3 {
          margin: 0 0 6px 0;
          font-size: 18px;
        }
        .video-title-overlay p {
          margin: 0;
          font-size: 13px;
          opacity: 0.7;
        }
        
        .video-iframe {
          width: 100%;
          height: 100%;
          border: none;
        }
        
        .video-footer {
          padding: 20px 24px;
          background: #f8fafc;
        }
        .footer-title {
          font-size: 14px;
          font-weight: 700;
          color: #1e293b;
          margin: 0 0 16px 0;
          text-align: center;
        }
        
        .steps-row {
          display: flex;
          justify-content: space-between;
          gap: 12px;
        }
        .step-item {
          flex: 1;
          text-align: center;
          padding: 12px 8px;
          background: white;
          border-radius: 12px;
          border: 1px solid #e2e8f0;
          position: relative;
        }
        .step-item:not(:last-child)::after {
          content: '→';
          position: absolute;
          right: -14px;
          top: 50%;
          transform: translateY(-50%);
          color: #cbd5e1;
          font-size: 16px;
        }
        .step-icon {
          font-size: 24px;
          margin-bottom: 6px;
        }
        .step-title {
          font-size: 12px;
          font-weight: 700;
          color: #1e293b;
          margin-bottom: 2px;
        }
        .step-desc {
          font-size: 10px;
          color: #94a3b8;
        }
        
        .cta-section {
          margin-top: 16px;
          text-align: center;
        }
        .cta-btn {
          padding: 12px 28px;
          border: none;
          border-radius: 12px;
          background: linear-gradient(135deg, #ec4899, #8b5cf6);
          color: white;
          font-size: 14px;
          font-weight: 700;
          cursor: pointer;
          transition: all 0.2s;
        }
        .cta-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 20px rgba(236, 72, 153, 0.4);
        }
      `}),a.jsxs("div",{className:"video-modal",onClick:S=>S.stopPropagation(),children:[a.jsxs("div",{className:"video-header",children:[a.jsx("button",{className:"close-btn",onClick:v,children:"×"}),a.jsx("h2",{children:"🎬 Sistem Nasıl İşliyor?"}),a.jsx("p",{children:"1 dakikalık tanıtım videosu"})]}),a.jsx("div",{className:"video-container",children:_?a.jsx("iframe",{className:"video-iframe",src:`https://www.youtube.com/embed/${k}?autoplay=1&rel=0`,allow:"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",allowFullScreen:!0,title:"EgzersizLab Tanıtım Videosu"}):a.jsxs("div",{className:"video-placeholder",onClick:()=>d(!0),children:[a.jsx("div",{className:"play-button",children:a.jsx("div",{className:"play-icon"})}),a.jsxs("div",{className:"video-title-overlay",children:[a.jsx("h3",{children:"Videoyu İzle"}),a.jsx("p",{children:"Tıklayarak başlat • 1:24"})]})]})}),a.jsxs("div",{className:"video-footer",children:[a.jsx("h4",{className:"footer-title",children:"4 Adımda Sağlıklı Yaşam"}),a.jsx("div",{className:"steps-row",children:E.map((S,U)=>a.jsxs("div",{className:"step-item",children:[a.jsx("div",{className:"step-icon",children:S.icon}),a.jsx("div",{className:"step-title",children:S.title}),a.jsx("div",{className:"step-desc",children:S.desc})]},U))}),a.jsx("div",{className:"cta-section",children:a.jsx("button",{className:"cta-btn",onClick:v,children:"▶ Hemen Başla"})})]})]})]})},gs=[{id:1,name:"Boyun Germe",duration:"5 dk",icon:"🦴",status:"todo"},{id:2,name:"Omuz Rotasyonu",duration:"3 dk",icon:"💪",status:"todo"},{id:3,name:"Sırt Esneme",duration:"5 dk",icon:"🔙",status:"done"},{id:4,name:"Bel Güçlendirme",duration:"8 dk",icon:"⬇️",status:"todo"},{id:5,name:"Kalça Açma",duration:"4 dk",icon:"🦵",status:"done"},{id:6,name:"Nefes Egzersizi",duration:"3 dk",icon:"🧘",status:"todo"}],bg=({open:r,onClose:v})=>{if(!r)return null;const _=gs.filter(k=>k.status==="done").length,d=_/gs.length*100;return a.jsxs("div",{className:"modal-overlay",children:[a.jsx("style",{children:`
        .modal-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.5);
          backdrop-filter: blur(6px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
          padding: 16px;
          animation: fadeIn 0.2s ease;
        }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        
        .modal-box {
          background: #fff;
          border-radius: 20px;
          width: 100%;
          max-width: 500px;
          max-height: 85vh;
          overflow: hidden;
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
          animation: slideUp 0.3s ease;
        }
        
        .modal-header {
          background: linear-gradient(135deg, #10b981 0%, #059669 100%);
          padding: 20px 24px;
          color: white;
          position: relative;
        }
        .modal-header h2 {
          font-size: 20px;
          font-weight: 700;
          margin: 0 0 8px 0;
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .close-btn {
          position: absolute;
          top: 14px;
          right: 14px;
          width: 32px;
          height: 32px;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.2);
          border: none;
          color: white;
          font-size: 20px;
          cursor: pointer;
          transition: all 0.2s;
        }
        .close-btn:hover { background: rgba(255, 255, 255, 0.3); }
        
        .progress-bar {
          height: 6px;
          background: rgba(255,255,255,0.3);
          border-radius: 3px;
          overflow: hidden;
        }
        .progress-fill {
          height: 100%;
          background: white;
          border-radius: 3px;
          transition: width 0.3s;
        }
        .progress-text {
          font-size: 13px;
          margin-top: 6px;
          opacity: 0.9;
        }
        
        .modal-content {
          padding: 20px;
          max-height: 60vh;
          overflow-y: auto;
        }
        
        .exercise-item {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 14px;
          border: 2px solid #e2e8f0;
          border-radius: 12px;
          margin-bottom: 10px;
          cursor: pointer;
          transition: all 0.2s;
        }
        .exercise-item:hover { border-color: #10b981; background: #f0fdf4; }
        .exercise-item.done { border-color: #10b981; background: #ecfdf5; }
        
        .exercise-icon {
          width: 44px;
          height: 44px;
          border-radius: 12px;
          background: #f1f5f9;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 22px;
        }
        .exercise-item.done .exercise-icon { background: #d1fae5; }
        
        .exercise-info { flex: 1; }
        .exercise-name { font-size: 15px; font-weight: 600; color: #1e293b; }
        .exercise-duration { font-size: 12px; color: #64748b; }
        
        .exercise-status {
          width: 28px;
          height: 28px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 14px;
        }
        .exercise-item.done .exercise-status { background: #10b981; color: white; }
        .exercise-item:not(.done) .exercise-status { background: #e2e8f0; color: #94a3b8; }
      `}),a.jsxs("div",{className:"modal-box",children:[a.jsxs("div",{className:"modal-header",children:[a.jsx("button",{className:"close-btn",onClick:v,children:"×"}),a.jsx("h2",{children:"🧘 Egzersiz Programım"}),a.jsx("div",{className:"progress-bar",children:a.jsx("div",{className:"progress-fill",style:{width:`${d}%`}})}),a.jsxs("div",{className:"progress-text",children:[_,"/",gs.length," tamamlandı"]})]}),a.jsx("div",{className:"modal-content",children:gs.map(k=>a.jsxs("div",{className:`exercise-item ${k.status==="done"?"done":""}`,children:[a.jsx("div",{className:"exercise-icon",children:k.icon}),a.jsxs("div",{className:"exercise-info",children:[a.jsx("div",{className:"exercise-name",children:k.name}),a.jsxs("div",{className:"exercise-duration",children:["⏱️ ",k.duration]})]}),a.jsx("div",{className:"exercise-status",children:k.status==="done"?"✓":"▶"})]},k.id))})]})]})},yg=[{day:"Pzt",done:!0},{day:"Sal",done:!0},{day:"Çar",done:!1},{day:"Per",done:!0},{day:"Cum",done:!1},{day:"Cmt",done:!1,today:!0},{day:"Paz",done:!1}],vg=[{label:"Toplam Gün",value:"12",icon:"📅"},{label:"Seri",value:"3",icon:"🔥"},{label:"Egzersiz",value:"45",icon:"🏋️"},{label:"Dakika",value:"180",icon:"⏱️"}],kg=({open:r,onClose:v})=>r?a.jsxs("div",{className:"modal-overlay",children:[a.jsx("style",{children:`
        .modal-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.5);
          backdrop-filter: blur(6px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
          padding: 16px;
          animation: fadeIn 0.2s ease;
        }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        
        .modal-box {
          background: #fff;
          border-radius: 20px;
          width: 100%;
          max-width: 480px;
          overflow: hidden;
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
          animation: slideUp 0.3s ease;
        }
        
        .modal-header {
          background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%);
          padding: 20px 24px;
          color: white;
          position: relative;
        }
        .modal-header h2 {
          font-size: 20px;
          font-weight: 700;
          margin: 0;
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .close-btn {
          position: absolute;
          top: 14px;
          right: 14px;
          width: 32px;
          height: 32px;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.2);
          border: none;
          color: white;
          font-size: 20px;
          cursor: pointer;
          transition: all 0.2s;
        }
        .close-btn:hover { background: rgba(255, 255, 255, 0.3); }
        
        .modal-content {
          padding: 20px;
        }
        
        .stats-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 10px;
          margin-bottom: 20px;
        }
        .stat-card {
          text-align: center;
          padding: 12px 8px;
          background: #f8fafc;
          border-radius: 12px;
        }
        .stat-icon { font-size: 20px; margin-bottom: 4px; }
        .stat-value { font-size: 20px; font-weight: 700; color: #1e293b; }
        .stat-label { font-size: 10px; color: #64748b; }
        
        .week-section h3 {
          font-size: 14px;
          color: #64748b;
          margin: 0 0 12px 0;
        }
        .week-grid {
          display: flex;
          gap: 8px;
        }
        .day-item {
          flex: 1;
          text-align: center;
          padding: 12px 8px;
          border-radius: 12px;
          background: #f1f5f9;
          transition: all 0.2s;
        }
        .day-item.done { background: #d1fae5; }
        .day-item.today { border: 2px solid #6366f1; background: #eef2ff; }
        .day-name { font-size: 11px; color: #64748b; margin-bottom: 6px; }
        .day-status { font-size: 18px; }
        
        .motivation {
          margin-top: 20px;
          padding: 16px;
          background: linear-gradient(135deg, #fef3c7, #fde68a);
          border-radius: 12px;
          text-align: center;
        }
        .motivation-text {
          font-size: 14px;
          color: #92400e;
          font-weight: 600;
        }
      `}),a.jsxs("div",{className:"modal-box",children:[a.jsxs("div",{className:"modal-header",children:[a.jsx("button",{className:"close-btn",onClick:v,children:"×"}),a.jsx("h2",{children:"📅 Takvim / İlerleme"})]}),a.jsxs("div",{className:"modal-content",children:[a.jsx("div",{className:"stats-grid",children:vg.map((_,d)=>a.jsxs("div",{className:"stat-card",children:[a.jsx("div",{className:"stat-icon",children:_.icon}),a.jsx("div",{className:"stat-value",children:_.value}),a.jsx("div",{className:"stat-label",children:_.label})]},d))}),a.jsxs("div",{className:"week-section",children:[a.jsx("h3",{children:"Bu Hafta"}),a.jsx("div",{className:"week-grid",children:yg.map((_,d)=>a.jsxs("div",{className:`day-item ${_.done?"done":""} ${_.today?"today":""}`,children:[a.jsx("div",{className:"day-name",children:_.day}),a.jsx("div",{className:"day-status",children:_.done?"✅":_.today?"📍":"⚪"})]},d))})]}),a.jsx("div",{className:"motivation",children:a.jsx("div",{className:"motivation-text",children:"🔥 3 günlük serin var! Devam et!"})})]})]})]}):null,jg={"muscle-strength":{title:"Kas Kuvveti Değerlendirmesi",icon:"💪",instructions:["Kamerayı yan profilden konumlandırın (vücudunuzun yarısı görünsün)","Rahat kıyafetler giyin, hareketi engellemesin","Testi yaparken ağrı olursa durun","Her hareketi 3 kez tekrarlayın"],tests:[{id:"squat",name:"Çömelme Testi (Squat)",description:"Ayaklar omuz genişliğinde, eller önde, yavaşça çömelin ve kalkın",duration:"30 saniye",videoTips:"Yan profilden çekin, diz ve kalça hareketini görebilmeli",relevantBodyAreas:["knee-front-left","knee-front-right","knee-back-left","knee-back-right","hip-front","hip-back","lower-back","thigh-front-left","thigh-front-right","thigh-back-left","thigh-back-right","ankle-front-left","ankle-front-right","ankle-back-left","ankle-back-right","calf-back-left","calf-back-right"],instructions:["Kamerayı yan profilden konumlandırın","Rahat kıyafetler giyin, hareketi engellemesin","Testi yaparken ağrı olursa durun","Hareketi 30 saniye boyunca yapabildiğiniz kadar yapın"],detailedInstructions:{startPosition:{title:"1. Başlangıç Pozisyonu",items:[{label:"Ayaklar",text:"Ayaklarınızı omuz genişliğinde açın. Ayak parmak uçlarınız hafifçe dışa baksın."},{label:"Duruş",text:"Dik durun, göğsünüzü yukarıda tutun ve karşıya bakın."},{label:"Kollar",text:"Dengeyi sağlamak için kollarınızı öne doğru uzatabilir veya ellerinizi belinize koyabilirsiniz."}]},movementDown:{title:"2. Hareketin Yapılışı (İniş)",items:[{label:"Sandalyeye Oturma Hissi",text:"Hareketi dizlerinizi bükerek değil, kalçanızı geriye doğru iterek başlatın. Tıpkı arkanızda görünmez bir sandalye varmış ve ona oturacakmışsınız gibi düşünün."},{label:"Dizler",text:"Çömelirken dizlerinizin içeriye doğru çökmesine izin vermeyin; dizlerinizi hafifçe dışa doğru iterek ayak parmaklarınızla aynı hizada tutun."},{label:"Derinlik",text:"Uyluklarınız yere paralel olana kadar (veya ağrı hissetmediğiniz, doktorunuzun izin verdiği seviyeye kadar) inin."},{label:"Topuklar",text:"Topuklarınızın yerden kalkmasına asla izin vermeyin, ağırlığınızı topuklarınıza verin."}]},movementUp:{title:"3. Hareketin Yapılışı (Kalkış)",items:[{label:"İtme",text:"Topuklarınızdan kuvvet alarak vücudunuzu yukarı doğru itin."},{label:"Bitiş",text:"Tamamen dik konuma geldiğinizde kalçanızı hafifçe sıkın."}]}},evaluationPoints:["Dizler içe dönüyor mu?","Kalça yeterince geri gidiyor mu?","Topuklar yerden kalkıyor mu?","Gövde öne eğiliyor mu?"]},{id:"calf-raise",name:"Topuk Yükseltme (Calf Raise)",description:"Tek ayak üzerinde durun, bir yerden destek alarak 30 saniye boyunca parmak ucuna yükselip inin",duration:"30 saniye",videoTips:"Yandan çekin, topuk yükselme hareketini görebilmeli",relevantBodyAreas:["ankle-front-left","ankle-front-right","ankle-back-left","ankle-back-right","calf-back-left","calf-back-right","lower-back","mid-back","upper-back","hip-front","hip-back","knee-front-left","knee-front-right","knee-back-left","knee-back-right"],instructions:["Kamerayı yandan konumlandırın","Rahat kıyafetler giyin, hareketi engellemesin","Testi yaparken ağrı olursa durun","Tek ayak üzerinde durun, bir yerden destek alarak 30 saniye boyunca parmak ucuna yükselip inin"],evaluationPoints:["Topuk tam kalkıyor mu?","Yorulunca titreme başlıyor mu?"]},{id:"heel-walk",name:"Topuk Üzerinde Yürüyüş (Heel Walk)",description:"Ayakkabılarını çıkar. Olduğun yerde veya odada ileri geri giderek, parmak uçlarını havaya kaldır ve sadece topukların üzerinde yürü",duration:"20 saniye",videoTips:"Önden veya yandan çekin, ayak pozisyonunu ve parmak yüksekliğini görebilmeli",relevantBodyAreas:["ankle-front-left","ankle-front-right","ankle-back-left","ankle-back-right","calf-back-left","calf-back-right","lower-back","hip-front","hip-back","knee-front-left","knee-front-right","knee-back-left","knee-back-right"],instructions:["Kamerayı önden veya yandan konumlandırın","Ayakkabılarını çıkar","Rahat kıyafetler giyin, hareketi engellemesin","Testi yaparken ağrı olursa durun","Olduğun yerde veya odada ileri geri giderek, parmak uçlarını havaya kaldır ve sadece topukların üzerinde yürü (20 saniye)"],evaluationPoints:['Parmak yüksekliği: Ayak ucunu yerden ne kadar kesebiliyor? (Düşükse "Düşük Ayak" riski veya ön kas zayıflığı)',"Ağrı ifadesi: Bunu yaparken kaval kemiği önünde ağrı oluyor mu? (Shin Splints şüphesi)"]}]},flexibility:{title:"Esneklik Testleri",icon:"📏",instructions:["Her testi dikkatli bir şekilde uygulayın","Hareketi yavaş yapın, zorlamayın","Ağrı olursa durun"],tests:[{id:"knee-wall-distance",name:"Diz-Duvar Mesafesi Testi",description:"Baldır ve ayak bileği esnekliği için altın standart test. Sadece cetvel yeterli!",duration:"2 dakika",testMode:"measurement",measurementUnit:"cm",measurementLabel:"Ayak Bileği",relevantBodyAreas:["ankle-front-left","ankle-front-right","ankle-back-left","ankle-back-right","calf-back-left","calf-back-right"],instructions:["Görsel talimatlara bakarak testi uygulayın."],evaluationCriteria:{good:{min:10,label:"Normal",color:"#10b981",icon:"✅",description:"Esneklik normal."},moderate:{min:5,max:9,label:"Hafif Kısıtlı",color:"#f59e0b",icon:"⚠️",description:"Germe önerilir."},poor:{max:4,label:"Kısıtlı",color:"#ef4444",icon:"❌",description:"Yoğun esneklik çalışması gerekli."}},evaluationPoints:[]},{id:"hamstring",name:"Hamstring Esneklik",description:"Bacak düz, öne eğilin, ne kadar uzanabiliyorsunuz?",duration:"15 saniye",videoTips:"Yandan çekin, eğilme açısını görebilmeli",relevantBodyAreas:["lower-back","hip-front","hip-back","thigh-back-left","thigh-back-right"],evaluationPoints:["Ne kadar eğilebildi?","Diz bükülüyor mu?","Ağrı var mı?"]}]},rom:{title:"Eklem Hareket Açıklığı (EHA)",icon:"📐",instructions:["Kamerayı eklemi net görecek şekilde konumlandırın","Hareketi yavaş ve kontrollü yapın"],tests:[{id:"ankle-dorsiflexion-rom",name:"Ayak Bileği Dorsifleksiyon EHA",description:"Ayak bileğinizi yukarı çekme hareketinizi kaydedin. Görsel açı rehberi ile karşılaştırın.",duration:"15 saniye",videoTips:"Yandan çekin, ayak ve baldır net görünsün",relevantBodyAreas:["ankle-front-left","ankle-front-right","ankle-back-left","ankle-back-right","calf-back-left","calf-back-right"],instructions:["Yere oturun, bacağınızı düz uzatın","Kamerayı yandan konumlandırın (ayak profili görünsün)","Ayak ucunuzu kendinize doğru çekin (dorsifleksiyon)","Maksimum noktada 3 saniye tutun","Hareketi yavaş ve kontrollü yapın"],evaluationPoints:["Ayak ucu baldıra yaklaşabiliyor mu? (Normal: 20°+)","Hareket sırasında ağrı var mı?","Sol-sağ fark var mı?","Topuk yerden kalkıyor mu?"],angleGuide:{title:"Dorsifleksiyon Açı Rehberi",ranges:[{angle:"20°+",status:"Normal",color:"#10b981",description:"Ayak ucu rahatça yukarı çıkıyor"},{angle:"10-20°",status:"Hafif Kısıtlı",color:"#f59e0b",description:"Ayak ucu biraz yukarı çıkıyor"},{angle:"<10°",status:"Kısıtlı",color:"#ef4444",description:"Ayak ucu çok az hareket ediyor"}]}},{id:"ankle-plantarflexion-rom",name:"Ayak Bileği Plantarfleksiyon EHA",description:"Ayak bileğinizi aşağı indirme (parmak ucuna basma) hareketinizi kaydedin.",duration:"15 saniye",videoTips:"Yandan çekin, ayak ve baldır net görünsün",relevantBodyAreas:["ankle-front-left","ankle-front-right","ankle-back-left","ankle-back-right","calf-back-left","calf-back-right"],instructions:["Yere oturun, bacağınızı düz uzatın","Kamerayı yandan konumlandırın","Ayak ucunuzu ileri doğru uzatın (bale hareketi gibi)","Maksimum noktada 3 saniye tutun"],evaluationPoints:["Ayak ucu tam uzanabiliyor mu? (Normal: 40-50°)","Hareket sırasında ağrı var mı?","Sol-sağ fark var mı?"],angleGuide:{title:"Plantarfleksiyon Açı Rehberi",ranges:[{angle:"40°+",status:"Normal",color:"#10b981",description:"Ayak ucu tam uzanıyor"},{angle:"30-40°",status:"Hafif Kısıtlı",color:"#f59e0b",description:"Ayak ucu biraz uzanıyor"},{angle:"<30°",status:"Kısıtlı",color:"#ef4444",description:"Ayak ucu az uzanıyor"}]}},{id:"shoulder",name:"Omuz EHA",description:"Kolu yukarı kaldırın, ne kadar açılabiliyor?",duration:"20 saniye",videoTips:"Önden çekin, omuz açısını görebilmeli",relevantBodyAreas:["shoulder-front-left","shoulder-front-right","shoulder-back-left","shoulder-back-right"],evaluationPoints:["Tam açılabiliyor mu?","Ağrı var mı?","Kısıtlılık var mı?"]}]},neurodynamic:{title:"Nörodinamik Testler (Sinir Germe)",icon:"🧠",instructions:["Testi yavaş ve kontrollü yapın","Ağrı veya uyuşma olursa hareketi durdurun","Her testte hissettiğinizi seçin"],tests:[{id:"tibial-nerve-test",name:"Tibial Sinir Testi",description:"Baldır arkası, topuk ve ayak tabanı ağrıları için. Tarsal Tünel Sendromu veya topuk dikeni sanılan sinir ağrılarını tespit eder.",duration:"30 saniye",testMode:"response",relevantBodyAreas:["ankle-front-left","ankle-front-right","ankle-back-left","ankle-back-right","calf-back-left","calf-back-right"],targetArea:"Baldırın tam arkası, topuk ve ayak tabanı",detailedSteps:[{step:1,title:"Başlangıç Pozisyonu",instruction:"Sırtüstü yat, kolların yanlarda rahat olsun."},{step:2,title:"Bacak Kaldırma",instruction:"Test edeceğin bacağı dizini BÜKMEDEN dümdüz yukarı kaldır. Diğer bacak yerde düz kalsın."},{step:3,title:"Ayağı Çekme",instruction:"Ayak ucunu kendine doğru çek (sanki ayak tabanıyla tavana bakmaya çalışıyorsun)."},{step:4,title:"Ayağı Döndürme",instruction:"Ayak tabanını DIŞA doğru çevirmeye çalış (ayak tabanı dışarı baksın)."},{step:5,title:"Bekle ve Hisset",instruction:"5 saniye bu pozisyonda kal. Ne hissediyorsun?"}],responseOptions:[{id:"normal",label:"Sadece gerilme hissettim",icon:"✅",result:"Negatif",description:"Normal kas esnekliği. Sinir sorunu yok.",color:"#10b981"},{id:"nerve",label:"Elektrik çarpması / Karıncalanma oldu",icon:"⚡",result:"Pozitif",description:"Tibial sinir hassasiyeti tespit edildi. Fizyoterapist değerlendirmesi önerilir.",color:"#f59e0b"},{id:"back",label:"Belimde ağrı oldu",icon:"🔴",result:"Dikkat",description:"Bel fıtığı riski olabilir. Doktor kontrolü önerilir.",color:"#ef4444"}]},{id:"peroneal-nerve-test",name:"Peroneal (Fibular) Sinir Testi",description:"Kaval kemiği önü, ayak bileği ön-dış kısmı ve ayak sırtı ağrıları için. Düşük ayak başlangıcı veya Shin Splints ile karışan sinir sorunlarını tespit eder.",duration:"30 saniye",testMode:"response",relevantBodyAreas:["ankle-front-left","ankle-front-right","ankle-back-left","ankle-back-right","calf-back-left","calf-back-right"],targetArea:"Kaval kemiği önü, ayak bileği ön-dış kısmı, ayak sırtı",detailedSteps:[{step:1,title:"Başlangıç Pozisyonu",instruction:"Sırtüstü yat, rahatla."},{step:2,title:"Bacak Kaldırma",instruction:"Test edeceğin bacağı dizini BÜKMEDEN düz kaldır."},{step:3,title:"Ayağı Uzatma",instruction:"Gaz pedalına basar gibi ayağını ileri uzat (bale hareketi gibi)."},{step:4,title:"Ayağı Döndürme",instruction:"Ayak tabanını İÇERİ doğru döndür (ayak tabanı diğer ayağa baksın)."},{step:5,title:"Bekle ve Hisset",instruction:"5 saniye bu pozisyonda kal. Ne hissediyorsun?"}],responseOptions:[{id:"normal",label:"Sadece gerilme hissettim",icon:"✅",result:"Negatif",description:"Normal kas esnekliği. Sinir sorunu yok.",color:"#10b981"},{id:"nerve",label:"Elektrik çarpması / Uyuşma oldu",icon:"⚡",result:"Pozitif",description:"Peroneal sinir hassasiyeti tespit edildi. Fizyoterapist değerlendirmesi önerilir.",color:"#f59e0b"},{id:"back",label:"Belimde ağrı oldu",icon:"🔴",result:"Dikkat",description:"Bel fıtığı riski olabilir. Doktor kontrolü önerilir.",color:"#ef4444"}]},{id:"sural-nerve-test",name:"Sural Sinir Testi",description:"Ayak bileği dış topuk kısmı ve baldır dış yan ağrıları için. Kronik burkulma sonrası geçmeyen ağrıların sinir kaynaklı olup olmadığını tespit eder.",duration:"30 saniye",testMode:"response",relevantBodyAreas:["ankle-front-left","ankle-front-right","ankle-back-left","ankle-back-right","calf-back-left","calf-back-right"],targetArea:"Ayak bileği dış topuk (lateral malleol) çevresi, baldır dış yanı",detailedSteps:[{step:1,title:"Başlangıç Pozisyonu",instruction:"Sırtüstü yat, rahatla."},{step:2,title:"Bacak Kaldırma",instruction:"Test edeceğin bacağı dizini BÜKMEDEN düz kaldır."},{step:3,title:"Ayağı Çekme",instruction:"Ayak ucunu kendine doğru çek (dorsifleksiyon)."},{step:4,title:"Ayağı Döndürme",instruction:"Ayak tabanını İÇERİ doğru döndür (ayak tabanı diğer ayağa baksın)."},{step:5,title:"Bekle ve Hisset",instruction:"5 saniye bu pozisyonda kal. Ne hissediyorsun?"}],responseOptions:[{id:"normal",label:"Sadece gerilme hissettim",icon:"✅",result:"Negatif",description:"Normal kas esnekliği. Sinir sorunu yok.",color:"#10b981"},{id:"nerve",label:"Elektrik çarpması / Yanma oldu",icon:"⚡",result:"Pozitif",description:"Sural sinir hassasiyeti tespit edildi. Kronik burkulma sonrası sinir hasarı olabilir.",color:"#f59e0b"},{id:"back",label:"Belimde ağrı oldu",icon:"🔴",result:"Dikkat",description:"Bel fıtığı riski olabilir. Doktor kontrolü önerilir.",color:"#ef4444"}]}]},balance:{title:"Denge Testleri",icon:"⚖️",instructions:["Güvenli bir alanda yapın","Yanınızda destek olsun"],tests:[{id:"tandem",name:"Tandem Yürüyüş",description:"Ayaklar bir önde bir arkada, düz çizgide yürüyün",duration:"30 saniye",videoTips:"Ardından çekin, yürüyüşü görebilmeli",evaluationPoints:["Dengede kalabiliyor mu?","Sallanıyor mu?","Kaç adım yürüyebildi?"]}]},movement:{title:"Hareket Analizi",icon:"🩺",instructions:["Günlük hareketleri yapın","Doğal hareket edin"],tests:[{id:"squat-daily",name:"Günlük Çömelme",description:"Yerden bir şey alır gibi çömelin",duration:"20 saniye",videoTips:"Yandan çekin, tüm hareket görünmeli",evaluationPoints:["Bel eğiliyor mu?","Dizler içe mi?","Asimetri var mı?"]}]}},mx=(r,v)=>r>=v.good.min?{value:r,status:"good",...v.good}:r>=v.moderate.min&&r<=v.moderate.max?{value:r,status:"moderate",...v.moderate}:{value:r,status:"poor",...v.poor},Ng=({isOpen:r,onClose:v,testType:_,userPainAreas:d=[]})=>{var ke,Ze,ft,Za,bt,va,ka,ni,yt,ja,Xt,st;const[k,E]=g.useState("instructions"),[S,U]=g.useState(0),[b,h]=g.useState({}),[L,N]=g.useState({}),[Y,H]=g.useState(!1),[B,ae]=g.useState(0),[Z,G]=g.useState(new Set),[q,fe]=g.useState({}),[ee,Re]=g.useState({}),[oe,X]=g.useState(!1),[I,ne]=g.useState({}),se=g.useRef(null),Se=g.useRef(null),re=g.useRef([]),Ve=g.useRef(null);g.useRef(null),g.useRef(null);const xe=jg[_],_e=Xo.useMemo(()=>{if(!d||d.length===0)return xe.tests;const F=De=>De.includes("hip")?"hip":De.includes("thigh")?"thigh":De.includes("knee")?"knee":De.includes("ankle")?"ankle":De.includes("calf")?"calf":De,le=d.map(F),he=xe.tests.filter(De=>!De.relevantBodyAreas||De.relevantBodyAreas.length===0?!0:De.relevantBodyAreas.some(Ft=>{const Et=F(Ft);return le.some(Na=>Et===Na?!0:Na.includes(Et)||Et.includes(Na))}));return he.length===0?(console.log("Filtrelenmiş test bulunamadı, tüm testler gösteriliyor"),xe.tests):he},[xe.tests,d]),T={...xe,tests:_e};if(T.tests.length===0)return a.jsx("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm px-4",children:a.jsx("div",{className:"bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden p-6",children:a.jsxs("div",{className:"text-center",children:[a.jsx("div",{className:"text-4xl mb-4",children:"⚠️"}),a.jsx("h3",{className:"text-xl font-bold text-gray-900 mb-2",children:"Test Bulunamadı"}),a.jsx("p",{className:"text-gray-600 mb-4",children:"Seçtiğiniz şikayet için uygun test bulunamadı. Lütfen farklı bir test kategorisi deneyin."}),a.jsx("button",{onClick:v,className:"w-full bg-blue-600 text-white py-3 rounded-xl font-semibold hover:bg-blue-700 transition",children:"Kapat"})]})})});const f=T.tests[S],Q=Object.keys(ee).filter(F=>{var le,he;return((le=ee[F])==null?void 0:le.left)||((he=ee[F])==null?void 0:he.right)}).length,ce=Object.keys(b).length+Q;if(S>=T.tests.length-1,!r)return null;const me=async()=>{try{const F=await navigator.mediaDevices.getUserMedia({video:{width:{ideal:1280},height:{ideal:720},facingMode:"user"},audio:!1});H(!0),ae(0),se.current&&(se.current.srcObject=F,await new Promise(he=>{se.current&&(se.current.onloadedmetadata=()=>{var De;(De=se.current)==null||De.play().then(()=>{console.log("Video oynatılıyor"),he(!0)}).catch(We=>{console.error("Video play hatası:",We),he(!1)})})}));const le=new MediaRecorder(F,{mimeType:"video/webm;codecs=vp9"});re.current=[],le.ondataavailable=he=>{he.data.size>0&&re.current.push(he.data)},le.onstop=()=>{const he=new Blob(re.current,{type:"video/webm"}),De=URL.createObjectURL(he);h(We=>({...We,[f.id]:De})),N(We=>({...We,[f.id]:he})),H(!1),ae(0),Ve.current&&clearInterval(Ve.current),F.getTracks().forEach(We=>We.stop())},Se.current=le,le.start(),Ve.current=setInterval(()=>{ae(he=>he+1)},1e3)}catch(F){console.error("Kamera erişim hatası:",F),alert("Kameraya erişilemedi. Lütfen izin verin.")}},m=()=>{Se.current&&Y&&(Se.current.stop(),se.current&&se.current.srcObject&&(se.current.srcObject.getTracks().forEach(le=>le.stop()),se.current.srcObject=null))},D=async()=>{const F=L[f.id];F&&(console.log("Video gönderiliyor:",f.id,F),O())},K=()=>{h(F=>{const le={...F};return delete le[f.id],le}),N(F=>{const le={...F};return delete le[f.id],le}),H(!1),ae(0),me()},J=()=>{h(F=>{const le={...F};return delete le[f.id],le}),N(F=>{const le={...F};return delete le[f.id],le}),E("instructions")},ue=F=>{var he;const le=(he=F.target.files)==null?void 0:he[0];if(le&&le.type.startsWith("video/")){N(We=>({...We,[f.id]:le}));const De=URL.createObjectURL(le);h(We=>({...We,[f.id]:De})),E("review")}},pe=()=>{G(F=>new Set([...F,f.id])),S<T.tests.length-1?(U(S+1),E("instructions")):E("completed")},O=()=>{S<T.tests.length-1?(U(S+1),E("instructions")):E("completed")},te=()=>{E("completed")},W=()=>{if(ce<1){alert("En az 1 test tamamlamanız gerekiyor. Lütfen bir test yapın."),U(0),E("instructions");return}console.log("Videolar gönderiliyor:",L),console.log("Tamamlanan testler:",ce),console.log("Atlanan testler:",Z.size),v()};return a.jsx("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm px-4",children:a.jsxs("div",{className:"bg-white w-full max-w-7xl rounded-3xl shadow-2xl overflow-hidden max-h-[95vh] flex flex-col",children:[a.jsxs("div",{className:"bg-gradient-to-r from-blue-600 to-purple-600 text-white p-6 flex justify-between items-center",children:[a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx("span",{className:"text-3xl",children:T.icon}),a.jsxs("div",{children:[a.jsx("h2",{className:"text-2xl font-bold",children:T.title}),a.jsxs("p",{className:"text-blue-100 text-sm",children:["Test ",S+1," / ",T.tests.length]})]})]}),a.jsx("button",{onClick:v,className:"text-white/80 hover:text-white transition",children:a.jsx(Qo,{size:24})})]}),a.jsxs("div",{className:"flex-1 overflow-y-auto p-6",children:[k==="instructions"&&a.jsxs("div",{className:`grid gap-6 ${f.testMode==="measurement"?"grid-cols-1":f.testMode==="response"||["squat","calf-raise","heel-walk","ankle-dorsiflexion-rom","ankle-plantarflexion-rom"].includes(f.id)?"grid-cols-1 lg:grid-cols-2":"grid-cols-1"}`,children:[f.testMode==="response"&&a.jsxs("div",{className:"space-y-4",children:[a.jsxs("div",{className:"bg-gradient-to-br from-purple-50 to-indigo-50 rounded-xl p-5 border border-purple-200",children:[a.jsxs("div",{className:"flex items-center gap-3 mb-3",children:[a.jsx("div",{className:"w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center text-white font-bold text-lg",children:S+1}),a.jsxs("div",{children:[a.jsx("h3",{className:"text-xl font-bold text-gray-900",children:f.name}),a.jsxs("p",{className:"text-gray-600 text-sm",children:["Süre: ",f.duration]})]})]}),a.jsx("p",{className:"text-gray-700 text-sm",children:f.description})]}),a.jsxs("div",{className:"bg-amber-50 border border-amber-200 rounded-xl p-4",children:[a.jsxs("div",{className:"flex items-center gap-2 mb-1",children:[a.jsx("span",{className:"text-lg",children:"🎯"}),a.jsx("span",{className:"font-bold text-amber-800",children:"Hedef Bölge"})]}),a.jsx("p",{className:"text-sm text-gray-700",children:f.targetArea})]}),a.jsxs("div",{className:"bg-white border-2 border-purple-200 rounded-xl p-4",children:[a.jsxs("h4",{className:"font-bold text-purple-700 mb-4 flex items-center gap-2",children:[a.jsx("span",{className:"text-lg",children:"📋"})," Adım Adım Uygulama"]}),a.jsx("div",{className:"space-y-3",children:(ke=f.detailedSteps)==null?void 0:ke.map(F=>a.jsxs("div",{className:"flex items-start gap-3",children:[a.jsx("div",{className:"w-7 h-7 bg-purple-600 text-white rounded-full flex items-center justify-center font-bold text-sm flex-shrink-0",children:F.step}),a.jsxs("div",{children:[a.jsx("p",{className:"font-semibold text-gray-800 text-sm",children:F.title}),a.jsx("p",{className:"text-sm text-gray-600",children:F.instruction})]})]},F.step))})]})]}),f.testMode!=="measurement"&&f.testMode!=="response"&&a.jsxs("div",{className:"space-y-4",children:[a.jsxs("div",{className:"bg-gradient-to-br from-purple-50 to-blue-50 rounded-xl p-5 border border-purple-200",children:[a.jsxs("div",{className:"flex items-center gap-3 mb-3",children:[a.jsx("div",{className:"w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center text-white font-bold text-lg",children:S+1}),a.jsxs("div",{children:[a.jsx("h3",{className:"text-xl font-bold text-gray-900",children:f.name}),a.jsxs("p",{className:"text-gray-600 text-sm",children:["Süre: ",f.duration]})]})]}),a.jsx("p",{className:"text-gray-700 text-base mb-3",children:f.description}),f.videoTips&&a.jsxs("div",{className:"bg-white rounded-lg p-3 border border-purple-100",children:[a.jsx("p",{className:"text-sm font-semibold text-purple-700 mb-1",children:"📹 Video İpuçları:"}),a.jsx("p",{className:"text-sm text-gray-600",children:f.videoTips})]})]}),a.jsxs("div",{className:"bg-blue-50 border-l-4 border-blue-600 p-4 rounded-lg",children:[a.jsx("h3",{className:"font-bold text-base mb-3",children:"📋 Genel Talimatlar"}),a.jsx("ul",{className:"space-y-2 text-sm mb-3",children:(f.instructions||T.instructions).map((F,le)=>a.jsxs("li",{className:"flex items-start gap-2",children:[a.jsx("span",{className:"text-blue-600 mt-1",children:"•"}),a.jsx("span",{children:F})]},le))}),a.jsx("div",{className:"bg-yellow-50 border border-yellow-200 rounded p-3 mt-3",children:a.jsxs("p",{className:"text-sm text-yellow-800",children:[a.jsx("strong",{children:"💡 Önemli:"})," En az ",a.jsx("strong",{children:"1 test"})," yeterlidir. Ağrı olursa durun."]})})]})]}),f.id==="squat"&&a.jsx("div",{className:"flex flex-col",children:a.jsxs("div",{className:"bg-white border-2 border-purple-200 rounded-xl p-4 shadow-lg flex-1 flex flex-col",children:[a.jsx("h4",{className:"text-lg font-bold text-gray-900 mb-4 text-center",children:"🎥 Squat Nasıl Yapılır?"}),a.jsxs("div",{className:"relative bg-black rounded-lg overflow-hidden aspect-video flex items-center justify-center",children:[a.jsxs("video",{autoPlay:!0,loop:!0,muted:!0,playsInline:!0,className:"w-full h-full object-contain",onError:()=>{},children:[a.jsx("source",{src:"/animations/squat-animation.mp4",type:"video/mp4"}),a.jsx("source",{src:"/animations/squat-animation.webm",type:"video/webm"})]}),a.jsx("div",{className:"absolute inset-0 flex items-center justify-center bg-gradient-to-br from-purple-900 to-blue-900 text-white",children:a.jsxs("div",{className:"text-center p-6",children:[a.jsx("p",{className:"text-4xl mb-3",children:"🏋️"}),a.jsx("p",{className:"text-sm opacity-90",children:"Squat animasyonu yüklenecek"}),a.jsx("p",{className:"text-xs opacity-70 mt-2",children:"public/animations/squat-animation.mp4"})]})})]}),a.jsx("p",{className:"text-xs text-gray-500 text-center mt-3",children:"Video otomatik olarak tekrar eder"})]})}),f.id==="calf-raise"&&a.jsx("div",{className:"flex flex-col",children:a.jsxs("div",{className:"bg-white border-2 border-purple-200 rounded-xl p-4 shadow-lg flex-1 flex flex-col",children:[a.jsx("h4",{className:"text-lg font-bold text-gray-900 mb-4 text-center",children:"🎥 Topuk Yükseltme Nasıl Yapılır?"}),a.jsxs("div",{className:"relative bg-black rounded-lg overflow-hidden aspect-video flex items-center justify-center",children:[a.jsxs("video",{autoPlay:!0,loop:!0,muted:!0,playsInline:!0,className:"w-full h-full object-contain",onError:()=>{},children:[a.jsx("source",{src:"/animations/calf-raise-animation.mp4",type:"video/mp4"}),a.jsx("source",{src:"/animations/calf-raise-animation.webm",type:"video/webm"})]}),a.jsx("div",{className:"absolute inset-0 flex items-center justify-center bg-gradient-to-br from-purple-900 to-blue-900 text-white",children:a.jsxs("div",{className:"text-center p-6",children:[a.jsx("p",{className:"text-4xl mb-3",children:"🦵"}),a.jsx("p",{className:"text-sm opacity-90",children:"Topuk Yükseltme animasyonu yüklenecek"}),a.jsx("p",{className:"text-xs opacity-70 mt-2",children:"public/animations/calf-raise-animation.mp4"})]})})]}),a.jsx("p",{className:"text-xs text-gray-500 text-center mt-3",children:"Video otomatik olarak tekrar eder"})]})}),f.id==="heel-walk"&&a.jsx("div",{className:"flex flex-col",children:a.jsxs("div",{className:"bg-white border-2 border-purple-200 rounded-xl p-4 shadow-lg flex-1 flex flex-col",children:[a.jsx("h4",{className:"text-lg font-bold text-gray-900 mb-4 text-center",children:"🎥 Topuk Üzerinde Yürüyüş Nasıl Yapılır?"}),a.jsxs("div",{className:"relative bg-black rounded-lg overflow-hidden aspect-video flex items-center justify-center",children:[a.jsxs("video",{autoPlay:!0,loop:!0,muted:!0,playsInline:!0,className:"w-full h-full object-contain",onError:()=>{},children:[a.jsx("source",{src:"/animations/heel-walk-animation.mp4",type:"video/mp4"}),a.jsx("source",{src:"/animations/heel-walk-animation.webm",type:"video/webm"})]}),a.jsx("div",{className:"absolute inset-0 flex items-center justify-center bg-gradient-to-br from-purple-900 to-blue-900 text-white",children:a.jsxs("div",{className:"text-center p-6",children:[a.jsx("p",{className:"text-4xl mb-3",children:"🚶"}),a.jsx("p",{className:"text-sm opacity-90",children:"Topuk Üzerinde Yürüyüş animasyonu yüklenecek"}),a.jsx("p",{className:"text-xs opacity-70 mt-2",children:"public/animations/heel-walk-animation.mp4"})]})})]}),a.jsx("p",{className:"text-xs text-gray-500 text-center mt-3",children:"Video otomatik olarak tekrar eder"})]})}),f.id==="ankle-dorsiflexion-rom"&&a.jsxs("div",{className:"flex flex-col gap-4",children:[a.jsxs("div",{className:"bg-white border-2 border-cyan-200 rounded-xl p-4 shadow-lg",children:[a.jsx("h4",{className:"text-lg font-bold text-gray-900 mb-4 text-center",children:"🦶 Dorsifleksiyon Nasıl Yapılır?"}),a.jsxs("div",{className:"relative bg-gradient-to-br from-cyan-900 to-blue-900 rounded-lg overflow-hidden aspect-video flex items-center justify-center",children:[a.jsx("video",{autoPlay:!0,loop:!0,muted:!0,playsInline:!0,className:"w-full h-full object-contain",children:a.jsx("source",{src:"/animations/dorsiflexion.mp4",type:"video/mp4"})}),a.jsx("div",{className:"absolute inset-0 flex items-center justify-center text-white",children:a.jsxs("div",{className:"text-center p-6",children:[a.jsx("p",{className:"text-5xl mb-3",children:"🦶⬆️"}),a.jsx("p",{className:"text-lg font-semibold",children:"Ayak Ucunu Yukarı Çek"}),a.jsx("p",{className:"text-sm opacity-70 mt-2",children:"Video buraya eklenecek"})]})})]}),a.jsx("p",{className:"text-xs text-gray-500 text-center mt-3",children:"Video otomatik olarak tekrar eder"})]}),a.jsxs("div",{className:"bg-gradient-to-br from-cyan-50 to-blue-50 border-2 border-cyan-200 rounded-xl p-4",children:[a.jsxs("h4",{className:"font-bold text-cyan-700 mb-3 flex items-center gap-2",children:[a.jsx("span",{className:"text-xl",children:"📐"})," Açı Rehberi"]}),a.jsxs("div",{className:"space-y-2",children:[a.jsxs("div",{className:"flex items-center gap-3 p-3 bg-white rounded-lg",children:[a.jsx("div",{className:"w-14 h-10 bg-green-500 rounded flex items-center justify-center text-white font-bold text-sm",children:"20°+"}),a.jsxs("div",{className:"flex-1",children:[a.jsx("span",{className:"font-semibold text-green-600",children:"Normal"}),a.jsx("span",{className:"text-sm text-gray-600 ml-2",children:"Ayak ucu rahatça yukarı çıkıyor"})]}),a.jsx("span",{className:"text-xl",children:"✅"})]}),a.jsxs("div",{className:"flex items-center gap-3 p-3 bg-white rounded-lg",children:[a.jsx("div",{className:"w-14 h-10 bg-yellow-500 rounded flex items-center justify-center text-white font-bold text-sm",children:"10-20°"}),a.jsxs("div",{className:"flex-1",children:[a.jsx("span",{className:"font-semibold text-yellow-600",children:"Hafif Kısıtlı"}),a.jsx("span",{className:"text-sm text-gray-600 ml-2",children:"Biraz yukarı çıkıyor"})]}),a.jsx("span",{className:"text-xl",children:"⚠️"})]}),a.jsxs("div",{className:"flex items-center gap-3 p-3 bg-white rounded-lg",children:[a.jsx("div",{className:"w-14 h-10 bg-red-500 rounded flex items-center justify-center text-white font-bold text-sm",children:"<10°"}),a.jsxs("div",{className:"flex-1",children:[a.jsx("span",{className:"font-semibold text-red-600",children:"Kısıtlı"}),a.jsx("span",{className:"text-sm text-gray-600 ml-2",children:"Çok az hareket"})]}),a.jsx("span",{className:"text-xl",children:"❌"})]})]})]})]}),f.id==="ankle-plantarflexion-rom"&&a.jsxs("div",{className:"flex flex-col gap-4",children:[a.jsxs("div",{className:"bg-white border-2 border-cyan-200 rounded-xl p-4 shadow-lg",children:[a.jsx("h4",{className:"text-lg font-bold text-gray-900 mb-4 text-center",children:"🦶 Plantarfleksiyon Nasıl Yapılır?"}),a.jsxs("div",{className:"relative bg-gradient-to-br from-cyan-900 to-blue-900 rounded-lg overflow-hidden aspect-video flex items-center justify-center",children:[a.jsx("video",{autoPlay:!0,loop:!0,muted:!0,playsInline:!0,className:"w-full h-full object-contain",children:a.jsx("source",{src:"/animations/plantarflexion.mp4",type:"video/mp4"})}),a.jsx("div",{className:"absolute inset-0 flex items-center justify-center text-white",children:a.jsxs("div",{className:"text-center p-6",children:[a.jsx("p",{className:"text-5xl mb-3",children:"🦶⬇️"}),a.jsx("p",{className:"text-lg font-semibold",children:"Ayak Ucunu Aşağı Uzat"}),a.jsx("p",{className:"text-sm opacity-70 mt-2",children:"Video buraya eklenecek"})]})})]}),a.jsx("p",{className:"text-xs text-gray-500 text-center mt-3",children:"Video otomatik olarak tekrar eder"})]}),a.jsxs("div",{className:"bg-gradient-to-br from-cyan-50 to-blue-50 border-2 border-cyan-200 rounded-xl p-4",children:[a.jsxs("h4",{className:"font-bold text-cyan-700 mb-3 flex items-center gap-2",children:[a.jsx("span",{className:"text-xl",children:"📐"})," Açı Rehberi"]}),a.jsxs("div",{className:"space-y-2",children:[a.jsxs("div",{className:"flex items-center gap-3 p-3 bg-white rounded-lg",children:[a.jsx("div",{className:"w-14 h-10 bg-green-500 rounded flex items-center justify-center text-white font-bold text-sm",children:"40°+"}),a.jsxs("div",{className:"flex-1",children:[a.jsx("span",{className:"font-semibold text-green-600",children:"Normal"}),a.jsx("span",{className:"text-sm text-gray-600 ml-2",children:"Ayak ucu tam uzanıyor"})]}),a.jsx("span",{className:"text-xl",children:"✅"})]}),a.jsxs("div",{className:"flex items-center gap-3 p-3 bg-white rounded-lg",children:[a.jsx("div",{className:"w-14 h-10 bg-yellow-500 rounded flex items-center justify-center text-white font-bold text-sm",children:"30-40°"}),a.jsxs("div",{className:"flex-1",children:[a.jsx("span",{className:"font-semibold text-yellow-600",children:"Hafif Kısıtlı"}),a.jsx("span",{className:"text-sm text-gray-600 ml-2",children:"Biraz uzanıyor"})]}),a.jsx("span",{className:"text-xl",children:"⚠️"})]}),a.jsxs("div",{className:"flex items-center gap-3 p-3 bg-white rounded-lg",children:[a.jsx("div",{className:"w-14 h-10 bg-red-500 rounded flex items-center justify-center text-white font-bold text-sm",children:"<30°"}),a.jsxs("div",{className:"flex-1",children:[a.jsx("span",{className:"font-semibold text-red-600",children:"Kısıtlı"}),a.jsx("span",{className:"text-sm text-gray-600 ml-2",children:"Az uzanıyor"})]}),a.jsx("span",{className:"text-xl",children:"❌"})]})]})]})]}),f.testMode==="response"&&a.jsxs("div",{className:"flex flex-col gap-4",children:[a.jsxs("div",{className:"bg-white border-2 border-purple-200 rounded-xl p-4 shadow-lg",children:[a.jsx("h4",{className:"text-lg font-bold text-gray-900 mb-3 text-center",children:"🎥 Nasıl Yapılır?"}),a.jsxs("div",{className:"relative bg-gradient-to-br from-purple-900 to-indigo-900 rounded-lg overflow-hidden aspect-video flex items-center justify-center",children:[a.jsx("video",{autoPlay:!0,loop:!0,muted:!0,playsInline:!0,className:"w-full h-full object-contain",children:a.jsx("source",{src:`/animations/${f.id}.mp4`,type:"video/mp4"})}),a.jsx("div",{className:"absolute inset-0 flex items-center justify-center text-white",children:a.jsxs("div",{className:"text-center p-6",children:[a.jsx("p",{className:"text-5xl mb-3",children:"🦵⬆️"}),a.jsx("p",{className:"text-lg font-semibold",children:"Bacak Kaldırma + Ayak Hareketi"}),a.jsx("p",{className:"text-sm opacity-70 mt-2",children:"Video buraya eklenecek"})]})})]})]}),a.jsxs("div",{className:"bg-gradient-to-br from-purple-50 to-indigo-50 border-2 border-purple-300 rounded-xl p-4",children:[a.jsx("h4",{className:"font-bold text-purple-700 mb-3 text-center",children:"🤔 Testi yaptıktan sonra ne hissettiniz?"}),a.jsx("div",{className:"space-y-2",children:(Ze=f.responseOptions)==null?void 0:Ze.map(F=>{var le,he;return a.jsx("button",{onClick:()=>{ne(De=>({...De,[f.id]:{responseId:F.id,result:F.result,description:F.description,color:F.color}}))},className:`w-full p-3 rounded-lg border-2 text-left transition-all ${((le=I[f.id])==null?void 0:le.responseId)===F.id?"border-purple-500 bg-white shadow-md":"border-gray-200 bg-white hover:border-purple-300"}`,children:a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx("span",{className:"text-2xl",children:F.icon}),a.jsx("span",{className:"font-medium text-gray-800",children:F.label}),((he=I[f.id])==null?void 0:he.responseId)===F.id&&a.jsx(ai,{size:20,className:"text-purple-600 ml-auto"})]})},F.id)})}),I[f.id]&&a.jsx("div",{className:"mt-3 p-3 rounded-lg text-sm",style:{backgroundColor:I[f.id].color+"20",borderLeft:`4px solid ${I[f.id].color}`},children:a.jsx("p",{className:"text-gray-700",children:I[f.id].description})}),a.jsxs("div",{className:"flex gap-2 mt-4",children:[a.jsxs("button",{onClick:()=>{I[f.id]&&(S<_e.length-1?U(S+1):te())},disabled:!I[f.id],className:"flex-1 bg-gradient-to-r from-green-600 to-emerald-600 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2",children:[a.jsx(ai,{size:18}),S<_e.length-1?"Kaydet ve İlerle":"Tamamla"]}),a.jsx("button",{onClick:pe,className:"px-5 bg-white border-2 border-gray-200 text-gray-600 py-3 rounded-xl font-semibold hover:bg-gray-50 transition",children:"Atla"})]})]})]}),f.testMode==="measurement"?a.jsx("div",{className:"lg:col-span-2",children:a.jsxs("div",{className:"grid lg:grid-cols-2 gap-6",children:[a.jsxs("div",{className:"space-y-4",children:[a.jsxs("div",{className:"bg-white border-2 border-purple-200 rounded-xl p-4 shadow-lg",children:[a.jsx("h4",{className:"text-lg font-bold text-gray-900 mb-4 text-center",children:"🎥 Diz-Duvar Mesafesi Testi"}),a.jsxs("div",{className:"relative bg-gradient-to-br from-purple-900 to-blue-900 rounded-lg overflow-hidden aspect-video flex items-center justify-center",children:[a.jsx("video",{autoPlay:!0,loop:!0,muted:!0,playsInline:!0,className:"w-full h-full object-contain absolute inset-0",style:{display:"none"},children:a.jsx("source",{src:"/animations/knee-wall-test.mp4",type:"video/mp4"})}),a.jsxs("div",{className:"text-center text-white p-6",children:[a.jsx("p",{className:"text-5xl mb-3",children:"📏"}),a.jsx("p",{className:"text-lg font-semibold",children:"Diz-Duvar Mesafesi Testi"}),a.jsx("p",{className:"text-sm opacity-70 mt-2",children:"Video veya görsel buraya eklenecek"})]})]})]}),a.jsxs("div",{className:"bg-blue-50 border-l-4 border-blue-600 p-5 rounded-lg",children:[a.jsx("h3",{className:"font-bold text-base mb-4 text-blue-800",children:"📋 Adım Adım Uygulama"}),a.jsxs("div",{className:"space-y-4",children:[a.jsxs("div",{className:"flex items-start gap-3",children:[a.jsx("span",{className:"w-7 h-7 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0",children:"1"}),a.jsxs("div",{children:[a.jsx("p",{className:"font-semibold text-gray-800",children:"Hazırlık"}),a.jsx("p",{className:"text-sm text-gray-600",children:"Yüzünü duvara dön. Ayakkabı ve çoraplarını çıkar. Yanına cetvel veya mezura al."})]})]}),a.jsxs("div",{className:"flex items-start gap-3",children:[a.jsx("span",{className:"w-7 h-7 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0",children:"2"}),a.jsxs("div",{children:[a.jsx("p",{className:"font-semibold text-gray-800",children:"Pozisyon Al"}),a.jsxs("p",{className:"text-sm text-gray-600",children:["Test edeceğin ayağının ",a.jsx("strong",{children:"başparmağını duvara değdir"}),". Diğer ayağını denge için geriye al."]})]})]}),a.jsxs("div",{className:"flex items-start gap-3",children:[a.jsx("span",{className:"w-7 h-7 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0",children:"3"}),a.jsxs("div",{children:[a.jsx("p",{className:"font-semibold text-gray-800",children:"Hareketi Yap"}),a.jsxs("p",{className:"text-sm text-gray-600",children:[a.jsx("strong",{children:"Topuğunu yerden kaldırmadan"})," dizini bükerek duvara değdirmeye çalış. Kolay gelirse ayağı geriye kaydır."]})]})]}),a.jsxs("div",{className:"flex items-start gap-3",children:[a.jsx("span",{className:"w-7 h-7 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0",children:"4"}),a.jsxs("div",{children:[a.jsx("p",{className:"font-semibold text-gray-800",children:"Ölç ve Kaydet"}),a.jsxs("p",{className:"text-sm text-gray-600",children:["Topuğun kalkmadan dizin değebildiği son noktada dur. ",a.jsx("strong",{children:"Parmak ucu - duvar mesafesini"})," cetvel ile ölç."]})]})]})]}),a.jsx("div",{className:"mt-4 bg-yellow-50 border border-yellow-300 rounded-lg p-3",children:a.jsxs("p",{className:"text-sm text-yellow-800",children:[a.jsx("strong",{children:"⚠️ Dikkat:"})," Topuğun yerden kalkarsa, ayağını biraz duvara yaklaştır ve tekrar dene."]})})]})]}),a.jsxs("div",{className:"bg-white rounded-2xl p-6 border-2 border-green-200 shadow-lg h-fit",children:[a.jsx("h4",{className:"text-lg font-bold text-gray-800 mb-5",children:"📏 Ölçüm Sonuçlarını Gir"}),a.jsxs("div",{className:"space-y-4",children:[a.jsxs("div",{className:"bg-gray-50 rounded-xl p-4",children:[a.jsxs("label",{className:"block text-sm font-semibold text-gray-600 mb-2",children:["🦶 Sol ",f.measurementLabel||"Ayak Bileği"]}),a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx("input",{type:"number",min:"0",max:f.measurementUnit==="°"?60:25,step:f.measurementUnit==="°"?1:.5,placeholder:"0",value:((ft=q[f.id])==null?void 0:ft.left)||"",onChange:F=>fe(le=>({...le,[f.id]:{...le[f.id],left:F.target.value}})),className:"w-24 px-4 py-3 border-2 border-gray-300 rounded-xl text-2xl font-bold text-center focus:outline-none focus:border-purple-500"}),a.jsx("span",{className:"text-xl text-gray-500 font-semibold",children:f.measurementUnit||"cm"}),((Za=ee[f.id])==null?void 0:Za.left)&&a.jsx("span",{className:"text-2xl",children:ee[f.id].left.icon})]})]}),a.jsxs("div",{className:"bg-gray-50 rounded-xl p-4",children:[a.jsxs("label",{className:"block text-sm font-semibold text-gray-600 mb-2",children:["🦶 Sağ ",f.measurementLabel||"Ayak Bileği"]}),a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx("input",{type:"number",min:"0",max:f.measurementUnit==="°"?60:25,step:f.measurementUnit==="°"?1:.5,placeholder:"0",value:((bt=q[f.id])==null?void 0:bt.right)||"",onChange:F=>fe(le=>({...le,[f.id]:{...le[f.id],right:F.target.value}})),className:"w-24 px-4 py-3 border-2 border-gray-300 rounded-xl text-2xl font-bold text-center focus:outline-none focus:border-purple-500"}),a.jsx("span",{className:"text-xl text-gray-500 font-semibold",children:f.measurementUnit||"cm"}),((va=ee[f.id])==null?void 0:va.right)&&a.jsx("span",{className:"text-2xl",children:ee[f.id].right.icon})]})]})]}),(((ka=ee[f.id])==null?void 0:ka.left)||((ni=ee[f.id])==null?void 0:ni.right))&&a.jsxs("div",{className:"mt-4 space-y-2",children:[((yt=ee[f.id])==null?void 0:yt.left)&&a.jsx("div",{className:"p-3 rounded-lg",style:{backgroundColor:ee[f.id].left.color+"15"},children:a.jsxs("span",{className:"font-semibold",style:{color:ee[f.id].left.color},children:["Sol: ",ee[f.id].left.label," - ",ee[f.id].left.description]})}),((ja=ee[f.id])==null?void 0:ja.right)&&a.jsx("div",{className:"p-3 rounded-lg",style:{backgroundColor:ee[f.id].right.color+"15"},children:a.jsxs("span",{className:"font-semibold",style:{color:ee[f.id].right.color},children:["Sağ: ",ee[f.id].right.label," - ",ee[f.id].right.description]})})]}),a.jsxs("div",{className:"mt-5 bg-gray-100 rounded-lg p-3",children:[a.jsx("p",{className:"text-xs font-semibold text-gray-600 mb-2",children:"📊 Değerlendirme:"}),a.jsxs("div",{className:"flex items-center justify-between text-xs",children:[a.jsxs("span",{className:"flex items-center gap-1",children:[a.jsx("span",{className:"w-3 h-3 bg-red-500 rounded-full"})," <5cm Kısıtlı"]}),a.jsxs("span",{className:"flex items-center gap-1",children:[a.jsx("span",{className:"w-3 h-3 bg-yellow-500 rounded-full"})," 5-9cm Hafif"]}),a.jsxs("span",{className:"flex items-center gap-1",children:[a.jsx("span",{className:"w-3 h-3 bg-green-500 rounded-full"})," 10+cm Normal"]})]})]}),a.jsxs("div",{className:"mt-5 flex gap-3",children:[a.jsx("button",{onClick:()=>{var De,We;const F=parseFloat(((De=q[f.id])==null?void 0:De.left)||"0"),le=parseFloat(((We=q[f.id])==null?void 0:We.right)||"0"),he=f.evaluationCriteria;if(he&&(F>0||le>0)){const Ft={};F>0&&(Ft.left=mx(F,he)),le>0&&(Ft.right=mx(le,he)),Re(Et=>({...Et,[f.id]:Ft}))}},disabled:!((Xt=q[f.id])!=null&&Xt.left)&&!((st=q[f.id])!=null&&st.right),className:"flex-1 bg-gradient-to-r from-green-500 to-teal-500 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition disabled:opacity-50",children:"✓ Değerlendir"}),a.jsx("button",{onClick:S<_e.length-1?()=>{U(S+1),E("instructions")}:te,className:"px-5 bg-purple-100 text-purple-600 py-3 rounded-xl font-semibold hover:bg-purple-200 transition",children:S<_e.length-1?"İleri →":"Bitir"})]})]})]})}):f.testMode!=="response"?a.jsxs("div",{className:"flex flex-col gap-3",children:[a.jsxs("div",{className:"flex gap-3",children:[a.jsxs("button",{onClick:()=>E("recording"),className:"flex-1 bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition flex items-center justify-center gap-2",children:[a.jsx(am,{size:20}),"Kamera ile Kaydet"]}),a.jsxs("button",{onClick:()=>E("upload"),className:"flex-1 bg-white border-2 border-blue-600 text-blue-600 py-3 rounded-xl font-semibold hover:bg-blue-50 transition flex items-center justify-center gap-2",children:[a.jsx(tm,{size:20}),"Video Yükle"]})]}),a.jsx("div",{className:"flex gap-3",children:S<_e.length-1?a.jsx("button",{onClick:pe,className:"flex-1 bg-gray-100 text-gray-600 py-3 rounded-xl font-semibold hover:bg-gray-200 transition",children:"Bu Testi Atla"}):a.jsx("button",{onClick:te,className:"flex-1 bg-gray-100 text-gray-600 py-3 rounded-xl font-semibold hover:bg-gray-200 transition",children:ce>0?"Testleri Tamamla":"Bu Testi Atla"})})]}):null]}),k==="recording"&&a.jsxs("div",{className:"space-y-4",children:[a.jsxs("div",{className:"bg-gray-900 rounded-2xl overflow-hidden relative",style:{minHeight:"500px"},children:[a.jsx("video",{ref:se,autoPlay:!0,muted:!0,playsInline:!0,style:{width:"100%",height:"auto",minHeight:"500px",maxHeight:"600px",backgroundColor:"#000",display:"block",objectFit:"cover"},onLoadedMetadata:F=>{const le=F.currentTarget;console.log("Video metadata yüklendi:",le.videoWidth,le.videoHeight),le.play().catch(he=>console.error("Play hatası:",he))},onError:F=>{console.error("Video hatası:",F)},onCanPlay:()=>{console.log("Video oynatılabilir")}}),Y&&a.jsxs("div",{className:"absolute top-4 left-4 bg-red-600 text-white px-4 py-2 rounded-full flex items-center gap-2 z-20",children:[a.jsx("div",{className:"w-3 h-3 bg-white rounded-full animate-pulse"}),a.jsxs("span",{className:"font-semibold",children:["Kayıt: ",Math.floor(B/60),":",(B%60).toString().padStart(2,"0")]})]})]}),Y&&a.jsxs("div",{className:"flex gap-3",children:[a.jsxs("button",{onClick:m,className:"flex-1 bg-gray-600 text-white py-3 rounded-xl font-semibold hover:bg-gray-700 transition flex items-center justify-center gap-2",children:[a.jsx(fh,{size:20}),"Kaydı Durdur"]}),a.jsx("button",{onClick:()=>{m(),E("instructions")},className:"px-6 bg-gray-200 text-gray-700 py-3 rounded-xl font-semibold hover:bg-gray-300 transition",children:"İptal"})]}),!Y&&!b[f.id]&&a.jsxs("div",{className:"flex gap-3",children:[a.jsxs("button",{onClick:me,className:"flex-1 bg-red-600 text-white py-3 rounded-xl font-semibold hover:bg-red-700 transition flex items-center justify-center gap-2",children:[a.jsx(am,{size:20}),"Kaydı Başlat"]}),a.jsx("button",{onClick:()=>E("instructions"),className:"px-6 bg-gray-200 text-gray-700 py-3 rounded-xl font-semibold hover:bg-gray-300 transition",children:"İptal"})]}),!Y&&b[f.id]&&a.jsxs("div",{className:"bg-green-50 border border-green-200 rounded-xl p-5",children:[a.jsxs("div",{className:"flex items-center gap-2 text-green-700 mb-4",children:[a.jsx(ai,{size:24}),a.jsx("span",{className:"font-semibold text-lg",children:"Video kaydedildi!"})]}),a.jsxs("div",{className:"flex gap-3",children:[a.jsxs("button",{onClick:()=>E("review"),className:"flex-1 bg-blue-600 text-white py-3 rounded-xl font-semibold hover:bg-blue-700 transition flex items-center justify-center gap-2",children:[a.jsx(xh,{size:20}),"İncele"]}),a.jsxs("button",{onClick:K,className:"flex-1 bg-gray-200 text-gray-700 py-3 rounded-xl font-semibold hover:bg-gray-300 transition flex items-center justify-center gap-2",children:[a.jsx(Ko,{size:20}),"Tekrar Kaydet"]}),a.jsxs("button",{onClick:D,className:"flex-1 bg-gradient-to-r from-green-600 to-emerald-600 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition flex items-center justify-center gap-2",children:[a.jsx(ai,{size:20}),"Gönder"]})]}),a.jsxs("button",{onClick:J,className:"w-full bg-red-600 text-white py-3 rounded-xl font-semibold hover:bg-red-700 transition flex items-center justify-center gap-2 mt-3",children:[a.jsx(qo,{size:20}),"Kaydedilen Videoyu Sil"]})]})]}),k==="upload"&&a.jsxs("div",{className:"space-y-4",children:[a.jsxs("div",{className:"border-2 border-dashed border-blue-300 rounded-2xl p-12 text-center bg-blue-50",children:[a.jsx(tm,{size:48,className:"mx-auto text-blue-600 mb-4"}),a.jsx("h3",{className:"text-xl font-bold text-gray-900 mb-2",children:"Video Dosyası Yükle"}),a.jsx("p",{className:"text-gray-600 mb-6",children:"MP4, MOV veya WebM formatında video yükleyin"}),a.jsxs("label",{className:"inline-block bg-blue-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-blue-700 transition cursor-pointer",children:["Dosya Seç",a.jsx("input",{type:"file",accept:"video/*",onChange:ue,className:"hidden"})]})]}),a.jsx("button",{onClick:()=>E("instructions"),className:"w-full bg-gray-200 text-gray-700 py-2 rounded-xl font-semibold hover:bg-gray-300 transition",children:"Geri"})]}),k==="review"&&b[f.id]&&a.jsxs("div",{className:"space-y-4",children:[a.jsxs("button",{onClick:()=>E("instructions"),className:"flex items-center gap-2 text-gray-600 hover:text-gray-900 transition mb-2",children:[a.jsx(Zp,{size:20}),a.jsx("span",{className:"font-semibold",children:"Geri"})]}),a.jsx("div",{className:"bg-gray-900 rounded-2xl overflow-hidden",children:a.jsx("video",{src:b[f.id],controls:!0,className:"w-full h-auto max-h-[400px]"})}),a.jsxs("div",{className:"bg-yellow-50 border border-yellow-200 rounded-xl p-4",children:[a.jsxs("div",{className:"flex items-center gap-2 text-yellow-700 mb-3",children:[a.jsx(lh,{size:20}),a.jsx("span",{className:"font-semibold",children:"Değerlendirme Kriterleri"})]}),a.jsx("ul",{className:"space-y-2 text-sm",children:f.evaluationPoints.map((F,le)=>a.jsxs("li",{className:"flex items-start gap-2",children:[a.jsx("span",{className:"text-yellow-600 mt-1",children:"•"}),a.jsx("span",{className:"text-gray-700",children:F})]},le))})]}),f.angleGuide&&a.jsxs("div",{className:"bg-gradient-to-br from-blue-50 to-cyan-50 border border-blue-200 rounded-xl p-4",children:[a.jsxs("div",{className:"flex items-center gap-2 text-blue-700 mb-3",children:[a.jsx("span",{className:"text-xl",children:"📐"}),a.jsx("span",{className:"font-semibold",children:f.angleGuide.title})]}),a.jsx("div",{className:"space-y-2",children:f.angleGuide.ranges.map((F,le)=>a.jsxs("div",{className:"flex items-center gap-3 p-3 rounded-lg",style:{backgroundColor:F.color+"15"},children:[a.jsx("div",{className:"w-12 h-12 rounded-lg flex items-center justify-center font-bold text-white text-sm",style:{backgroundColor:F.color},children:F.angle}),a.jsxs("div",{className:"flex-1",children:[a.jsx("div",{className:"font-semibold",style:{color:F.color},children:F.status}),a.jsx("div",{className:"text-sm text-gray-600",children:F.description})]})]},le))})]}),a.jsxs("div",{className:"flex flex-col gap-3",children:[a.jsxs("div",{className:"flex gap-3",children:[a.jsxs("button",{onClick:D,className:"flex-1 bg-gradient-to-r from-green-600 to-emerald-600 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition flex items-center justify-center gap-2",children:[a.jsx(ai,{size:20}),"Gönder"]}),a.jsxs("button",{onClick:K,className:"flex-1 bg-gray-200 text-gray-700 py-3 rounded-xl font-semibold hover:bg-gray-300 transition flex items-center justify-center gap-2",children:[a.jsx(Ko,{size:20}),"Tekrar Kaydet"]})]}),a.jsxs("button",{onClick:J,className:"w-full bg-red-600 text-white py-3 rounded-xl font-semibold hover:bg-red-700 transition flex items-center justify-center gap-2",children:[a.jsx(qo,{size:20}),"Kaydedilen Videoyu Sil"]})]})]}),k==="completed"&&a.jsxs("div",{className:"text-center py-12",children:[a.jsx("div",{className:"w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6",children:a.jsx(ai,{size:48,className:"text-green-600"})}),a.jsx("h3",{className:"text-2xl font-bold text-gray-900 mb-2",children:ce>0?"Testler Tamamlandı!":"Test Atlandı"}),a.jsxs("div",{className:"bg-blue-50 rounded-xl p-4 mb-4",children:[a.jsxs("p",{className:"text-sm text-gray-700 mb-2",children:[a.jsx("strong",{children:"Tamamlanan Testler:"})," ",ce," / ",T.tests.length]}),Z.size>0&&a.jsxs("p",{className:"text-sm text-gray-600",children:[a.jsx("strong",{children:"Atlanan Testler:"})," ",Z.size]})]}),ce>0?a.jsxs(a.Fragment,{children:[a.jsx("p",{className:"text-gray-600 mb-6",children:"Videolarınız fizyoterapistiniz tarafından değerlendirilecek."}),a.jsx("div",{className:"bg-blue-50 rounded-xl p-4 mb-6",children:a.jsxs("p",{className:"text-sm text-gray-700",children:[a.jsx("strong",{children:"Sonraki Adım:"})," Fizyoterapistiniz videoları inceleyip 24-48 saat içinde size özel egzersiz programınızı hazırlayacak."]})}),a.jsx("button",{onClick:W,className:"bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-3 rounded-xl font-semibold hover:shadow-lg transition",children:"Testleri Gönder"})]}):a.jsxs(a.Fragment,{children:[a.jsx("p",{className:"text-gray-600 mb-6",children:"Henüz hiçbir test tamamlanmadı. En az 1 test yapmanız önerilir."}),a.jsxs("div",{className:"flex gap-3 justify-center",children:[a.jsx("button",{onClick:()=>{U(0),E("instructions")},className:"bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-xl font-semibold hover:shadow-lg transition",children:"Test Yapmaya Başla"}),a.jsx("button",{onClick:v,className:"bg-gray-200 text-gray-700 px-6 py-3 rounded-xl font-semibold hover:bg-gray-300 transition",children:"İptal Et"})]})]})]})]})]})})},pt={user_name:"Ahmet",welcome_subtitle:"Bugün, ağrısız bir yaşam için harika bir başlangıç.",cta_title:"Henüz Vücut Analizinizi Yapmadık",cta_description:"Size en uygun tedavi paketini belirleyebilmemiz ve ağrı haritanızı çıkarabilmemiz için 3 dakikalık ücretsiz ön değerlendirmeyi tamamlayın.",cta_button_text:"Analizi Başlat",cta_duration:"Yaklaşık 3 dakika sürer",video_title:"Süreci İzleyin",tip_title:"Biliyor muydunuz?",tip_text:"Kronik ağrıların %80'i doğru duruş ve egzersizle ameliyatsız iyileşebilir.",background_color:"#667eea",card_background:"#ffffff",text_color:"#1f2937",button_color:"#f59e0b",accent_color:"#764ba2"},zg=()=>{var Fa,Pa;const[r,v]=g.useState(pt),[_,d]=g.useState(!1),[k,E]=g.useState(null),[S,U]=g.useState(!1),[b,h]=g.useState(!1),[L,N]=g.useState(null),[Y,H]=g.useState(!1),[B,ae]=g.useState(!1),[Z,G]=g.useState(!1),[q,fe]=g.useState(!1),[ee,Re]=g.useState(!1),[oe,X]=g.useState(!1),[I,ne]=g.useState(!1),[se,Se]=g.useState(0),[re,Ve]=g.useState(()=>localStorage.getItem("packageType")||"none"),xe=re!=="none",_e=p=>{Ve(p),localStorage.setItem("packageType",p)},[T,f]=g.useState(!1),[Q,ce]=g.useState(!1),[me,m]=g.useState([]),[D,K]=g.useState(!1),[J,ue]=g.useState(!1),[pe,O]=g.useState(!1),[te,W]=g.useState(()=>{try{const p=localStorage.getItem("userPainAreas");return p?JSON.parse(p):[]}catch{return[]}});g.useEffect(()=>{const p=localStorage.getItem("userPainAreas");if(p)try{W(JSON.parse(p))}catch{W([])}},[Y]);const[ke,Ze]=g.useState([{id:"n1",title:"Fizyoterapistiniz programınızı güncelledi.",message:"Yeni hareket planınız hazır, detayları görmek için tıklayın.",type:"clinical",read:!1,date:"2 saat önce"},{id:"n2",title:"Ödemeniz başarıyla alındı.",message:"Klinik Takip Paketi hesabınıza tanımlandı, faturanızı görüntüleyebilirsiniz.",type:"admin",read:!1,date:"1 gün önce"},{id:"n3",title:"Egzersiz Vakti! 🏃‍♂️",message:"Bugünkü programını henüz yapmadın. 15 dakikanı ayırmayı unutma.",type:"motivation",read:!0,date:"3 gün önce"}]),[ft,Za]=g.useState({todayExercises:3,todayCompleted:1,weeklyCompleted:12,weeklyTotal:18,progressPercentage:68,streak:5,totalExercises:47}),[bt,va]=g.useState([{id:"t1",name:"Boyun Germe Egzersizi",duration:"10 dk",completed:!0,time:"09:00"},{id:"t2",name:"Omuz Rotasyonu",duration:"5 dk",completed:!1,time:"14:00"},{id:"t3",name:"Bel Güçlendirme",duration:"15 dk",completed:!1,time:"18:00"}]),ka=p=>{va(V=>{const ge=V.map(Te=>Te.id===p?{...Te,completed:!Te.completed}:Te),Ae=ge.filter(Te=>Te.completed).length;return Za(Te=>({...Te,todayCompleted:Ae})),ge})},yt=(()=>{const p=new Date,V=new Date(p);V.setMonth(V.getMonth()+1);const ge=Te=>Te.toLocaleDateString("tr-TR",{day:"numeric",month:"long",year:"numeric"}),Ae=Math.ceil((V.getTime()-p.getTime())/(1e3*60*60*24));switch(re){case"basic":return{name:"Temel Analiz & Egzersiz Planı",startDate:ge(p),endDate:"Tek Seferlik",daysRemaining:null,features:["Detaylı anamnez değerlendirmesi","Fizyoterapist tarafından vaka analizi","4-6 haftalık kişiye özel egzersiz reçetesi","Egzersiz videoları ve açıklamaları"],price:"599₺"};case"pro":return{name:"Klinik Takip & İlerleme Paketi",startDate:ge(p),endDate:ge(V),daysRemaining:Ae,features:["Temel paketteki tüm hizmetler","Haftalık kontrol ve değerlendirme","Ağrı ve gelişime göre program revizyonu","Sistem üzerinden soru-cevap hakkı","1 aylık aktif takip"],price:"1.299₺"};case"premium":return{name:"Premium Danışmanlık & Video Analizi",startDate:ge(p),endDate:ge(V),daysRemaining:Ae,features:["Tüm paketlerdeki hizmetler","Video analizi: Egzersizlerinizi kaydedin, geri bildirim alın","Hızlı destek (chat/WhatsApp)","Öncelikli değerlendirme (aynı gün dönüş)","Sınırsız program güncellemesi"],price:"2.499₺"};default:return{name:"",startDate:"",endDate:"",daysRemaining:null,features:[],price:""}}})(),ja=[{id:"a1",type:"exercise",text:"Boyun Germe Egzersizi tamamlandı",time:"2 saat önce",icon:"✅"},{id:"a2",type:"message",text:"Fizyoterapistinizden yeni mesaj",time:"1 gün önce",icon:"💬"},{id:"a3",type:"program",text:"Egzersiz programınız güncellendi",time:"2 gün önce",icon:"📝"},{id:"a4",type:"achievement",text:"5 günlük streak kazandınız!",time:"3 gün önce",icon:"🏆"}],Xt=[{day:"Pzt",value:80},{day:"Sal",value:65},{day:"Çar",value:90},{day:"Per",value:70},{day:"Cum",value:85},{day:"Cmt",value:60},{day:"Paz",value:45}],st=[{id:"b1",name:"İlk Adım",icon:"🎯",earned:!0,description:"İlk egzersizini tamamladın!"},{id:"b2",name:"5 Gün Streak",icon:"🔥",earned:!0,description:"5 gün üst üste egzersiz yaptın!"},{id:"b3",name:"Haftalık Şampiyon",icon:"👑",earned:!1,description:"Bir hafta boyunca tüm egzersizleri tamamla"},{id:"b4",name:"100 Egzersiz",icon:"💯",earned:!1,description:"Toplam 100 egzersiz tamamla"},{id:"b5",name:"Sabah Kahramanı",icon:"🌅",earned:!1,description:"7 sabah egzersiz yap"},{id:"b6",name:"Hafta Sonu Savaşçısı",icon:"⚔️",earned:!1,description:"Hafta sonu egzersizlerini tamamla"},{id:"b7",name:"Mükemmel Hafta",icon:"⭐",earned:!1,description:"Bir hafta hiç egzersiz kaçırma"},{id:"b8",name:"30 Günlük Efsane",icon:"🏆",earned:!1,description:"30 gün üst üste devam et"},{id:"b9",name:"Hızlı Başlangıç",icon:"⚡",earned:!1,description:"İlk 3 günü tamamla"},{id:"b10",name:"Gece Kuşu",icon:"🦉",earned:!1,description:"10 akşam egzersiz yap"},{id:"b11",name:"İlerleme Ustası",icon:"📈",earned:!1,description:"İlerleme skorunu %80'e çıkar"},{id:"b12",name:"Sosyal Kelebek",icon:"🦋",earned:!1,description:"10 arkadaşını davet et"}],F=p=>{me.find(V=>V.id===p.id)||(m([...me,{id:p.id,name:p.name,price:p.price||"0"}]),H(!1),Re(!1),setTimeout(()=>K(!0),300))},le=p=>{m(me.filter(V=>V.id!==p))},he=()=>me.reduce((p,V)=>p+parseInt(V.price.replace(/\./g,"")),0),De=[{icon:"💡",title:"Biliyor muydunuz?",text:"Kronik ağrıların %80'i doğru duruş ve egzersizle ameliyatsız iyileşebilir."},{icon:"🧘",title:"Günlük İpucu",text:"Her gün 10 dakika germe egzersizi, kas gerginliğini %40 azaltır."},{icon:"🚶",title:"Hareket Şart!",text:"Her 45 dakikada bir 5 dakika yürümek, bel ağrısı riskini %50 düşürür."},{icon:"💧",title:"Su İçin",text:"Günde 2 litre su içmek, eklem sağlığını korur ve kas kramplarını önler."},{icon:"😴",title:"Uyku Önemli",text:"Kaliteli 7-8 saat uyku, kas onarımı ve ağrı yönetimi için kritiktir."},{icon:"🏋️",title:"Düzenli Egzersiz",text:"Haftada 3 gün egzersiz, kronik ağrıyı %60 oranında azaltabilir."},{icon:"🪑",title:"Doğru Oturuş",text:"Ergonomik oturma pozisyonu, boyun ve sırt ağrılarını önler."},{icon:"🌿",title:"Stres Yönetimi",text:"Stres kas gerginliğini artırır. Nefes egzersizleri rahatlamanıza yardımcı olur."}],[We,Ft]=g.useState(0),Et=g.useRef(null),Na=g.useRef(null),si=g.useRef(null),an=g.useRef(null);g.useEffect(()=>{const p=window.elementSdk;p&&p.init({defaultConfig:pt,onConfigChange:V=>{v(ge=>({...ge,...V}))},mapToCapabilities:V=>({recolorables:[{get:()=>V.background_color||pt.background_color,set:ge=>v(Ae=>({...Ae,background_color:ge}))},{get:()=>V.card_background||pt.card_background,set:ge=>v(Ae=>({...Ae,card_background:ge}))},{get:()=>V.text_color||pt.text_color,set:ge=>v(Ae=>({...Ae,text_color:ge}))},{get:()=>V.button_color||pt.button_color,set:ge=>v(Ae=>({...Ae,button_color:ge}))},{get:()=>V.accent_color||pt.accent_color,set:ge=>v(Ae=>({...Ae,accent_color:ge}))}],borderables:[],fontEditable:void 0,fontSizeable:void 0}),mapToEditPanelValues:V=>new Map([["user_name",V.user_name||pt.user_name],["welcome_subtitle",V.welcome_subtitle||pt.welcome_subtitle],["cta_title",V.cta_title||pt.cta_title],["cta_description",V.cta_description||pt.cta_description],["cta_button_text",V.cta_button_text||pt.cta_button_text],["cta_duration",V.cta_duration||pt.cta_duration],["video_title",V.video_title||pt.video_title],["tip_title",V.tip_title||pt.tip_title],["tip_text",V.tip_text||pt.tip_text]])})},[]),g.useEffect(()=>{if(!k)return;const p=setTimeout(()=>E(null),3500);return()=>clearTimeout(p)},[k]),g.useEffect(()=>{if(localStorage.getItem("showLoginSuccess")==="true"){U(!0),localStorage.removeItem("showLoginSuccess");const V=setTimeout(()=>{U(!1)},3e3);return()=>clearTimeout(V)}},[]),g.useEffect(()=>{(async()=>{var V;try{const ge=await ta.getCurrentUser();if(ge.success&&ge.user){const Te=ge.user,ri=(((V=Te.name)==null?void 0:V.split(" ")[0])||"Kullanıcı").toUpperCase();v(Wa=>({...Wa,user_name:ri})),Te.packageType&&(Ve(Te.packageType),localStorage.setItem("packageType",Te.packageType))}const Ae=await ta.getDashboardData();if(Ae.success&&Ae.data){const Te=Ae.data;Te.assessmentResults&&console.log("Assessment sonuçları yüklendi:",Te.assessmentResults),Te.photos&&console.log("Fotoğraflar yüklendi:",Te.photos),Te.formData&&console.log("Form verileri yüklendi:",Te.formData),Te.notifications&&Array.isArray(Te.notifications)&&Ze(Te.notifications)}}catch(ge){console.error("Kullanıcı verileri yüklenirken hata:",ge)}})()},[]);const bs=g.useMemo(()=>`linear-gradient(135deg, ${r.background_color} 0%, ${r.accent_color} 100%)`,[r.background_color,r.accent_color]),Ja=g.useMemo(()=>`linear-gradient(135deg, ${r.button_color} 0%, #f97316 100%)`,[r.button_color]),ht=()=>{d(!0),setTimeout(()=>{d(!1),h(!0)},600)},Rt=p=>{E(p?"Premium özellik: Fizyoterapistinizle mesajlaşmak için premium paket gerekir.":"Bu özelliği kullanmak için önce paket satın almalısınız.")},mt=()=>{window.location.href="/"},ys=()=>{ae(p=>!p)};g.useEffect(()=>{const p=V=>{var Ae,Te;const ge=V.target;(Ae=Na.current)!=null&&Ae.contains(ge)||(Te=Et.current)!=null&&Te.contains(ge)||ae(!1)};return document.addEventListener("click",p),()=>document.removeEventListener("click",p)},[]),g.useEffect(()=>{const p=V=>{var Ae,Te;const ge=V.target;(Ae=si.current)!=null&&Ae.contains(ge)||(Te=an.current)!=null&&Te.contains(ge)||ue(!1)};return document.addEventListener("click",p),()=>document.removeEventListener("click",p)},[]);const vs=p=>{Ze(V=>V.map(ge=>ge.id===p?{...ge,read:!0}:ge))},gl=ke.filter(p=>!p.read).length;return g.useEffect(()=>{const p=()=>{const V=document.documentElement,ge=V.scrollHeight-V.clientHeight,Ae=ge>0?V.scrollTop/ge*100:0;Ft(Ae)};return window.addEventListener("scroll",p),p(),()=>window.removeEventListener("scroll",p)},[]),g.useEffect(()=>{const p=setInterval(()=>{Se(V=>(V+1)%De.length)},8e3);return()=>clearInterval(p)},[De.length]),a.jsxs("div",{className:"dashboard-wrapper",style:{minHeight:"100vh",background:bs},children:[S&&a.jsxs("div",{style:{position:"fixed",top:20,left:"50%",transform:"translateX(-50%)",zIndex:1e4,background:"#10b981",color:"white",padding:"12px 24px",borderRadius:"8px",boxShadow:"0 4px 12px rgba(0,0,0,0.15)",display:"flex",alignItems:"center",gap:"12px",animation:"fadeIn 0.3s ease-in"},children:[a.jsx("svg",{style:{width:20,height:20},fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:a.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M5 13l4 4L19 7"})}),a.jsx("span",{style:{fontWeight:600,fontSize:14},children:"Giriş yapıldı"}),a.jsx("button",{onClick:()=>U(!1),style:{marginLeft:8,background:"transparent",border:"none",color:"white",cursor:"pointer",fontSize:18,lineHeight:1,padding:0,width:20,height:20},children:"×"})]}),a.jsx("style",{children:`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateX(-50%) translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateX(-50%) translateY(0);
          }
        }
        body { margin: 0; padding: 0; box-sizing: border-box; }
        * { box-sizing: inherit; }
        .dashboard-wrapper { display: flex; height: 100%; width: 100%; position: relative; }
        .sidebar { width: 260px; background: #fff; box-shadow: 2px 0 20px rgba(0,0,0,0.08); display: flex; flex-direction: column; height: 100%; border-radius: 0 24px 24px 0; overflow: hidden; }
        .sidebar-header { padding: 24px; border-bottom: 1px solid #e5e7eb; background: #fff; }
        .logo { display: flex; align-items: center; gap: 12px; }
        .logo-progress { width: 100%; height: 3px; background: #e5e7eb; border-radius: 999px; margin-top: 10px; overflow: hidden; }
        .logo-progress-inner { height: 100%; background: linear-gradient(90deg, #667eea, #22c55e); transition: width 0.15s ease-out; }
        .menu-items { flex: 1; padding: 16px 0; overflow-y: auto; }
        .menu-section-title { padding: 20px 24px 8px 36px; font-size: 11px; font-weight: 700; letter-spacing: 1px; color: #9ca3af; text-transform: uppercase; }
        .menu-divider { height: 1px; background: linear-gradient(90deg, transparent, #e5e7eb, transparent); margin: 12px 24px; border: none; }
        .menu-item { display: flex; align-items: center; padding: 14px 24px; color: #4b5563; cursor: pointer; transition: all 0.2s; font-size: 15px; gap: 12px; margin: 0 12px; border-radius: 12px; }
        .menu-item:hover { background: #f3f4f6; color: #667eea; }
        .menu-item.active { background: linear-gradient(135deg, #eef2ff, #f0f9ff); color: #667eea; border-left: 4px solid #667eea; box-shadow: 0 2px 8px rgba(102, 126, 234, 0.15); }
        .menu-item.locked { opacity: 0.55; cursor: not-allowed; }
        .menu-item.premium-feature { position: relative; }
        .menu-item.premium-feature::after { content: 'PREMIUM'; position: absolute; right: 50px; font-size: 9px; font-weight: 700; color: #f59e0b; background: #fef3c7; padding: 2px 6px; border-radius: 4px; letter-spacing: 0.5px; }
        .main-content { flex: 1; overflow-y: auto; height: 100%; background: transparent; }
        .top-bar { background: #fff; padding: 20px 32px 20px 48px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 12px rgba(0,0,0,0.06); position: relative; border-radius: 24px; margin: 24px 24px 24px 32px; }
        .welcome-section { display: flex; align-items: center; gap: 24px; flex: 1; }
        .welcome-text { padding-left: 16px; }
        .welcome-text h1 { font-size: 28px; font-weight: 600; color: ${r.text_color}; margin: 0 0 4px 0; }
        .welcome-text p { font-size: 15px; color: #6b7280; margin: 0; }
        .welcome-badges { display: flex; flex-direction: column; gap: 8px; padding: 12px 16px; background: linear-gradient(135deg, #fef3c7, #fde68a); border-radius: 12px; border: 2px solid #fbbf24; }
        .welcome-badges-title { font-size: 11px; font-weight: 700; color: #92400e; text-transform: uppercase; letter-spacing: 0.5px; }
        .welcome-badges-list { display: flex; align-items: center; gap: 8px; }
        .welcome-badge-item { width: 40px; height: 40px; border-radius: 50%; background: linear-gradient(135deg, #fef3c7, #fde68a); border: 2px solid #f59e0b; display: flex; align-items: center; justify-content: center; font-size: 20px; cursor: pointer; transition: all 0.2s; box-shadow: 0 2px 8px rgba(245, 158, 11, 0.2); }
        .welcome-badge-item:hover { transform: scale(1.1); box-shadow: 0 4px 12px rgba(245, 158, 11, 0.3); }
        .welcome-badge-icon { display: flex; align-items: center; justify-content: center; }
        .welcome-badge-more { width: 40px; height: 40px; border-radius: 50%; background: #e5e7eb; border: 2px solid #9ca3af; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700; color: #6b7280; cursor: pointer; transition: all 0.2s; }
        .welcome-badge-more:hover { background: #d1d5db; }
        .top-bar-right { display: flex; align-items: center; gap: 20px; position: relative; }
        .notification-bell { width: 40px; height: 40px; border-radius: 50%; background: #f3f4f6; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: all 0.2s; font-size: 18px; position: relative; }
        .notification-bell:hover { background: #e5e7eb; }
        .notification-badge { position: absolute; top: -2px; right: -2px; min-width: 18px; height: 18px; background: #ef4444; color: #fff; border-radius: 999px; font-size: 10px; font-weight: 700; display: flex; align-items: center; justify-content: center; padding: 0 5px; border: 2px solid #fff; }
        .notification-wrapper { position: relative; }
        .notification-dropdown { position: absolute; top: 50px; right: 0; width: 360px; background: #fff; border-radius: 20px; box-shadow: 0 10px 40px rgba(0,0,0,0.15); border: 1px solid #e5e7eb; overflow: hidden; z-index: 1000; animation: slideDown 0.2s ease; max-height: 500px; display: flex; flex-direction: column; }
        .notification-header { background: linear-gradient(135deg, #667eea, #764ba2); color: #fff; padding: 14px 16px; font-size: 15px; font-weight: 700; display: flex; justify-content: space-between; align-items: center; }
        .notification-items { max-height: 400px; overflow-y: auto; }
        .notification-item { padding: 12px 16px; border-bottom: 1px solid #f3f4f6; cursor: pointer; transition: all 0.2s; margin: 0 8px; border-radius: 12px; }
        .notification-item:hover { background: #f9fafb; margin: 4px 8px; }
        .notification-item.read { background: #fff; opacity: 0.7; }
        .notification-item.unread { background: #f0f9ff; }
        .notification-item-title { font-size: 13px; font-weight: 700; color: #1f2937; margin-bottom: 4px; }
        .notification-item-message { font-size: 12px; color: #6b7280; line-height: 1.4; margin-bottom: 4px; }
        .notification-item-meta { display: flex; justify-content: space-between; align-items: center; margin-top: 6px; }
        .notification-item-type { font-size: 10px; font-weight: 700; padding: 3px 8px; border-radius: 12px; }
        .notification-item-type.clinical { background: #dbeafe; color: #1d4ed8; }
        .notification-item-type.admin { background: #fee2e2; color: #b91c1c; }
        .notification-item-type.motivation { background: #dcfce7; color: #15803d; }
        .notification-item-date { font-size: 11px; color: #9ca3af; }
        .notification-empty { padding: 40px 20px; text-align: center; color: #9ca3af; font-size: 14px; }
        .notification-footer { padding: 12px 16px; background: #f9fafb; border-top: 1px solid #e5e7eb; text-align: center; }
        .notification-footer-btn { background: none; border: none; color: #667eea; font-size: 13px; font-weight: 600; cursor: pointer; padding: 4px 8px; }
        .notification-footer-btn:hover { text-decoration: underline; }
        
        /* Cart Styles */
        .cart-wrapper { position: relative; }
        .cart-bell { width: 40px; height: 40px; border-radius: 50%; background: #f3f4f6; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: all 0.2s; font-size: 18px; position: relative; flex-shrink: 0; }
        .cart-bell:hover { background: #d1fae5; }
        .cart-badge { position: absolute; top: -4px; right: -4px; width: 20px; height: 20px; background: #ef4444; color: #fff; font-size: 11px; font-weight: 700; border-radius: 50%; display: flex; align-items: center; justify-content: center; animation: bounce 0.5s ease; }
        @keyframes bounce { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.2); } }
        .cart-overlay { position: fixed; inset: 0; z-index: 999; }
        .cart-dropdown { position: absolute; top: 50px; right: 0; width: 320px; background: #fff; border-radius: 20px; box-shadow: 0 10px 40px rgba(0,0,0,0.15); border: 1px solid #e5e7eb; overflow: hidden; z-index: 1000; animation: slideDown 0.2s ease; }
        @keyframes slideDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
        .cart-header { background: linear-gradient(135deg, #10b981, #059669); color: #fff; padding: 14px 16px; font-size: 15px; font-weight: 700; }
        .cart-empty { padding: 30px; text-align: center; color: #9ca3af; font-size: 14px; }
        .cart-items { max-height: 240px; overflow-y: auto; }
        .cart-item { display: flex; align-items: center; justify-content: space-between; padding: 12px 16px; border-bottom: 1px solid #f3f4f6; margin: 0 8px; border-radius: 12px; }
        .cart-item-info { display: flex; flex-direction: column; gap: 2px; }
        .cart-item-name { font-size: 13px; font-weight: 600; color: #1f2937; }
        .cart-item-price { font-size: 14px; font-weight: 700; color: #10b981; }
        .cart-item-remove { background: none; border: none; color: #ef4444; font-size: 16px; cursor: pointer; padding: 4px; border-radius: 4px; }
        .cart-item-remove:hover { background: #fef2f2; }
        .cart-footer { padding: 14px 16px; background: #f9fafb; border-top: 1px solid #e5e7eb; }
        .cart-total { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
        .cart-total span:first-child { font-size: 14px; color: #6b7280; font-weight: 500; }
        .cart-total-price { font-size: 20px; font-weight: 800; color: #10b981; }
        .cart-checkout-btn { width: 100%; padding: 12px; background: linear-gradient(135deg, #10b981, #059669); border: none; border-radius: 10px; color: #fff; font-size: 14px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
        .cart-checkout-btn:hover { transform: translateY(-1px); box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3); }
        .profile-pic { width: 44px; height: 44px; border-radius: 50%; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center; color: #fff; font-weight: 600; font-size: 16px; cursor: pointer; position: relative; flex-shrink: 0; }
        .content-area { padding: 32px; max-width: 1200px; margin: 0 auto; }
        .main-cta-card { background: ${r.card_background}; border-radius: 16px; padding: 40px; box-shadow: 0 4px 20px rgba(0,0,0,0.08); margin-bottom: 32px; display: flex; gap: 32px; align-items: center; }
        .cta-illustration { width: 180px; height: 180px; flex-shrink: 0; }
        .cta-content h2 { font-size: 26px; font-weight: 600; color: ${r.text_color}; margin: 0 0 12px 0; }
        .cta-content p { font-size: 16px; color: #6b7280; line-height: 1.6; margin: 0 0 24px 0; }
        .cta-button { background: ${Ja}; color: #fff; border: none; padding: 16px 32px; font-size: 17px; font-weight: 600; border-radius: 12px; cursor: pointer; transition: all 0.3s; box-shadow: 0 4px 12px rgba(245, 158, 11, 0.3); display: inline-flex; align-items: center; gap: 8px; }
        .cta-button:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(245, 158, 11, 0.4); }
        .duration-hint { display: inline-block; margin-left: 12px; font-size: 14px; color: #9ca3af; font-weight: normal; }
        .info-cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 24px; }
        .info-card { background: ${r.card_background}; border-radius: 12px; padding: 24px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); transition: all 0.3s; cursor: pointer; }
        .info-card:hover { transform: translateY(-4px); box-shadow: 0 6px 16px rgba(0,0,0,0.1); }
        .info-card-icon { width: 56px; height: 56px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 28px; margin-bottom: 16px; }
        .video-card .info-card-icon { background: linear-gradient(135deg, #ec4899 0%, #8b5cf6 100%); }
        .tip-card .info-card-icon { background: linear-gradient(135deg, #10b981 0%, #059669 100%); }
        .info-card h3 { font-size: 18px; font-weight: 600; color: #1f2937; margin: 0 0 8px 0; }
        .info-card p { font-size: 14px; color: #6b7280; line-height: 1.6; margin: 0; }
        .tip-carousel { position: relative; overflow: hidden; }
        .tip-carousel .info-card-icon { transition: transform 0.5s ease; }
        .tip-title-animated, .tip-text-animated { 
          animation: tipFadeIn 0.5s ease; 
        }
        @keyframes tipFadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .tip-dots {
          display: flex;
          justify-content: center;
          gap: 6px;
          margin-top: 12px;
        }
        .tip-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #d1d5db;
          cursor: pointer;
          transition: all 0.3s;
        }
        .tip-dot:hover { background: #9ca3af; }
        .tip-dot.active { 
          background: #10b981; 
          width: 24px; 
          border-radius: 4px; 
        }
        .profile-dropdown { position: absolute; top: 70px; right: 32px; width: 320px; background: #fff; border-radius: 20px; box-shadow: 0 8px 32px rgba(0, 0, 0, 0.12); opacity: 0; visibility: hidden; transform: translateY(-10px); transition: all 0.25s ease; z-index: 1000; border: 1px solid #e5e7eb; overflow: hidden; }
        .profile-dropdown.active { opacity: 1; visibility: visible; transform: translateY(0); }
        .profile-card-header { padding: 20px; border-bottom: 1px solid rgba(255,255,255,0.2); text-align: center; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; }
        .profile-avatar-large { width: 70px; height: 70px; border-radius: 50%; background: #fff; color: #667eea; display: flex; align-items: center; justify-content: center; font-size: 30px; font-weight: 700; margin: 0 auto 10px auto; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15); }
        .profile-name { font-size: 18px; font-weight: 700; margin: 0 0 4px 0; }
        .premium-badge-inline { display: inline-flex; align-items: center; gap: 6px; background: rgba(251, 191, 36, 0.18); color: #b45309; padding: 4px 10px; border-radius: 16px; font-size: 11px; font-weight: 700; border: 1px solid rgba(251, 191, 36, 0.35); }
        .profile-menu-section { padding: 14px 0; }
        .profile-menu-section:not(:last-child) { border-bottom: 1px solid #f3f4f6; }
        .profile-section-title { padding: 8px 16px; font-size: 11px; font-weight: 700; color: #9ca3af; letter-spacing: 1px; text-transform: uppercase; }
        .profile-menu-item { display: flex; align-items: center; gap: 12px; padding: 12px 16px; color: #374151; cursor: pointer; transition: all 0.2s; font-size: 14px; margin: 0 12px; border-radius: 12px; }
        .profile-menu-item:hover { background: #f9fafb; color: #4f46e5; }
        .profile-menu-item.danger:hover { background: #fef2f2; color: #dc2626; }
        .profile-menu-icon { font-size: 18px; width: 22px; text-align: center; }
        .profile-menu-text { flex: 1; }
        .profile-menu-text .subtitle { font-size: 11px; color: #9ca3af; margin-top: 2px; }
        
        /* İstatistik Kartları */
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }
        .stat-card { background: ${r.card_background}; border-radius: 16px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); display: flex; align-items: center; gap: 16px; transition: all 0.3s; }
        .stat-card:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        .stat-icon { width: 56px; height: 56px; border-radius: 14px; display: flex; align-items: center; justify-content: center; font-size: 28px; flex-shrink: 0; }
        .stat-content { flex: 1; }
        .stat-value { font-size: 28px; font-weight: 800; color: #1f2937; margin-bottom: 4px; }
        .stat-label { font-size: 13px; color: #6b7280; font-weight: 500; }
        
        /* Hızlı Erişim Butonları */
        .quick-actions { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px; margin-bottom: 24px; }
        .quick-action-btn { background: ${r.card_background}; border: 2px solid #e5e7eb; border-radius: 14px; padding: 16px; display: flex; align-items: center; gap: 12px; cursor: pointer; transition: all 0.2s; text-align: left; }
        .quick-action-btn:hover { border-color: #667eea; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(102, 126, 234, 0.15); }
        .quick-action-btn.primary { background: linear-gradient(135deg, #667eea, #764ba2); border-color: transparent; color: #fff; }
        .quick-action-btn.primary:hover { box-shadow: 0 6px 20px rgba(102, 126, 234, 0.3); }
        .quick-action-icon { font-size: 32px; flex-shrink: 0; }
        .quick-action-text { flex: 1; }
        .quick-action-title { font-size: 15px; font-weight: 700; color: #1f2937; margin-bottom: 2px; }
        .quick-action-btn.primary .quick-action-title { color: #fff; }
        .quick-action-subtitle { font-size: 12px; color: #6b7280; }
        .quick-action-btn.primary .quick-action-subtitle { color: rgba(255,255,255,0.9); }
        
        /* Dashboard Grid */
        .dashboard-grid { display: grid; grid-template-columns: 1fr 400px; gap: 24px; margin-bottom: 24px; }
        .dashboard-left, .dashboard-right { display: flex; flex-direction: column; gap: 24px; }
        
        /* Görev Kartı */
        .task-card, .progress-chart-card, .package-status-card, .activities-card, .badges-card { background: ${r.card_background}; border-radius: 16px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
        .card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
        .card-title { font-size: 18px; font-weight: 700; color: #1f2937; margin: 0; }
        .card-badge { background: #eef2ff; color: #667eea; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 700; }
        .task-list { display: flex; flex-direction: column; gap: 12px; margin-bottom: 16px; }
        .task-item { display: flex; align-items: center; gap: 12px; padding: 12px; border-radius: 12px; background: #f9fafb; transition: all 0.2s; }
        .task-item:hover { background: #f3f4f6; }
        .task-item.completed { opacity: 0.6; }
        .task-checkbox { font-size: 20px; cursor: pointer; flex-shrink: 0; }
        .task-info { flex: 1; }
        .task-name { font-size: 14px; font-weight: 600; color: #1f2937; margin-bottom: 4px; }
        .task-item.completed .task-name { text-decoration: line-through; color: #9ca3af; }
        .task-meta { display: flex; gap: 12px; font-size: 12px; color: #6b7280; }
        .task-duration, .task-time { display: flex; align-items: center; gap: 4px; }
        .task-view-all { width: 100%; padding: 10px; background: #f3f4f6; border: none; border-radius: 10px; color: #667eea; font-weight: 600; cursor: pointer; transition: all 0.2s; }
        .task-view-all:hover { background: #eef2ff; }
        
        /* İlerleme Grafiği */
        .chart-container { margin-bottom: 16px; }
        .chart-bars { display: flex; align-items: flex-end; justify-content: space-between; gap: 8px; height: 200px; padding: 0 8px; }
        .chart-bar-wrapper { flex: 1; display: flex; flex-direction: column; align-items: center; height: 100%; }
        .chart-bar { width: 100%; max-width: 50px; background: linear-gradient(180deg, #667eea, #764ba2); border-radius: 8px 8px 0 0; position: relative; transition: all 0.3s; min-height: 20px; }
        .chart-bar:hover { opacity: 0.8; }
        .chart-value { position: absolute; top: -24px; left: 50%; transform: translateX(-50%); font-size: 11px; font-weight: 700; color: #667eea; white-space: nowrap; }
        .chart-label { margin-top: 8px; font-size: 11px; color: #6b7280; font-weight: 600; }
        .chart-footer { display: flex; justify-content: space-between; padding-top: 16px; border-top: 1px solid #e5e7eb; }
        .chart-stat { display: flex; flex-direction: column; gap: 4px; }
        .chart-stat-label { font-size: 12px; color: #6b7280; }
        .chart-stat-value { font-size: 16px; font-weight: 700; color: #1f2937; }
        
        /* Paket Durumu */
        .package-badge { padding: 4px 12px; border-radius: 12px; font-size: 11px; font-weight: 700; }
        .package-badge.active { background: #dcfce7; color: #15803d; }
        .package-info { margin-bottom: 16px; }
        .package-name { font-size: 16px; font-weight: 700; color: #1f2937; margin-bottom: 8px; }
        .package-dates { font-size: 13px; color: #6b7280; margin-bottom: 12px; }
        .package-countdown { display: flex; align-items: center; gap: 8px; padding: 10px; background: #fef3c7; border-radius: 10px; margin-bottom: 12px; }
        .countdown-icon { font-size: 18px; }
        .countdown-text { font-size: 13px; font-weight: 700; color: #92400e; }
        .package-features { display: flex; flex-direction: column; gap: 6px; }
        .package-feature { display: flex; align-items: center; gap: 8px; font-size: 13px; color: #4b5563; }
        .package-feature span { color: #10b981; font-weight: 700; }
        .package-manage-btn { width: 100%; padding: 10px; background: #f3f4f6; border: none; border-radius: 10px; color: #667eea; font-weight: 600; cursor: pointer; transition: all 0.2s; }
        .package-manage-btn:hover { background: #eef2ff; }
        
        /* Son Aktiviteler */
        .activities-list { display: flex; flex-direction: column; gap: 12px; margin-bottom: 16px; }
        .activity-item { display: flex; align-items: flex-start; gap: 12px; padding: 12px; border-radius: 12px; background: #f9fafb; transition: all 0.2s; }
        .activity-item:hover { background: #f3f4f6; }
        .activity-icon { font-size: 20px; flex-shrink: 0; }
        .activity-content { flex: 1; }
        .activity-text { font-size: 13px; font-weight: 600; color: #1f2937; margin-bottom: 4px; }
        .activity-time { font-size: 11px; color: #9ca3af; }
        .activities-view-all { width: 100%; padding: 10px; background: #f3f4f6; border: none; border-radius: 10px; color: #667eea; font-weight: 600; cursor: pointer; transition: all 0.2s; }
        .activities-view-all:hover { background: #eef2ff; }
        
        /* Rozetler */
        .badges-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
        .badge-item { position: relative; background: #f9fafb; border: 2px solid #e5e7eb; border-radius: 12px; padding: 16px; text-align: center; transition: all 0.2s; }
        .badge-item.earned { background: linear-gradient(135deg, #fef3c7, #fde68a); border-color: #fbbf24; }
        .badge-item.locked { opacity: 0.5; }
        .badge-icon { font-size: 32px; margin-bottom: 8px; }
        .badge-name { font-size: 12px; font-weight: 700; color: #1f2937; }
        .badge-lock { position: absolute; top: 8px; right: 8px; font-size: 16px; opacity: 0.6; }
        
        /* Klinik Testler Bölümü */
        .clinical-tests-section {
          background: #fff;
          border-radius: 16px;
          padding: 24px;
          margin-bottom: 24px;
          box-shadow: 0 2px 8px rgba(0,0,0,0.06);
          width: 100%;
          max-width: 100%;
          overflow: visible;
        }
        .clinical-tests-title {
          font-size: 18px;
          font-weight: 700;
          color: #1f2937;
          margin-bottom: 16px;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .clinical-tests-buttons {
          display: flex;
          gap: 12px;
          flex-wrap: nowrap;
          align-items: stretch;
          justify-content: flex-start;
        }
        .clinical-test-btn {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 12px 14px;
          background: linear-gradient(135deg, #667eea, #764ba2);
          border: 2px solid transparent;
          border-radius: 12px;
          color: #fff;
          cursor: pointer;
          transition: all 0.3s;
          flex: 1 1 0;
          min-width: 120px;
          box-shadow: 0 2px 8px rgba(102, 126, 234, 0.2);
        }
        .clinical-test-btn:hover:not(:disabled) {
          background: linear-gradient(135deg, #764ba2, #667eea);
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }
        .clinical-test-btn:disabled {
          opacity: 0.7;
          cursor: not-allowed;
        }
        .test-btn-icon {
          font-size: 24px;
          flex-shrink: 0;
        }
        .test-btn-content {
          display: flex;
          flex-direction: column;
          gap: 2px;
          flex: 1;
          min-width: 0;
          overflow: visible;
        }
        .test-btn-text {
          font-size: 13px;
          font-weight: 700;
          line-height: 1.2;
          white-space: normal;
          overflow: visible;
          word-wrap: break-word;
          hyphens: auto;
        }
        .test-btn-desc {
          font-size: 10px;
          font-weight: 500;
          opacity: 0.9;
          line-height: 1.2;
          white-space: normal;
          overflow: visible;
          word-wrap: break-word;
        }
        
        @media (max-width: 1200px) {
          .clinical-test-btn {
            padding: 10px 10px;
            min-width: 100px;
          }
          .test-btn-icon {
            font-size: 20px;
          }
          .test-btn-text {
            font-size: 11px;
          }
          .test-btn-desc {
            font-size: 9px;
          }
        }
        
        @media (max-width: 768px) {
          .clinical-tests-buttons {
            flex-wrap: wrap;
            gap: 8px;
          }
          .clinical-test-btn {
            flex: 1 1 calc(50% - 4px);
            min-width: 0;
            padding: 10px 12px;
          }
          .test-btn-icon {
            font-size: 20px;
          }
          .test-btn-text {
            font-size: 12px;
          }
          .test-btn-desc {
            font-size: 10px;
          }
          .sidebar { position: fixed; left: -260px; z-index: 100; transition: left 0.3s; }
          .sidebar.open { left: 0; }
          .main-cta-card { flex-direction: column; text-align: center; }
          .cta-illustration { width: 140px; height: 140px; }
          .profile-dropdown { right: 16px; width: calc(100% - 32px); }
          .stats-grid { grid-template-columns: repeat(2, 1fr); gap: 12px; }
          .quick-actions { grid-template-columns: 1fr; }
          .dashboard-grid { grid-template-columns: 1fr; }
          .chart-bars { height: 150px; }
          .badges-grid { grid-template-columns: repeat(2, 1fr); }
          .welcome-section { flex-direction: column; align-items: flex-start; gap: 16px; }
          .welcome-badges { width: 100%; }
        }
      `}),a.jsxs("div",{className:"sidebar",children:[a.jsxs("div",{className:"sidebar-header",children:[a.jsxs("div",{className:"logo",children:[a.jsx(gx,{size:56}),a.jsx("span",{style:{fontSize:20,fontWeight:"bold",background:"linear-gradient(135deg, #667eea, #10b981)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"},children:"EgzersizLab"})]}),a.jsx("div",{className:"logo-progress",children:a.jsx("div",{className:"logo-progress-inner",style:{width:`${We}%`}})})]}),a.jsxs("div",{className:"menu-items",children:[a.jsx("div",{className:"menu-section-title",children:"PANEL"}),a.jsxs("div",{className:"menu-item active",children:[a.jsx("span",{role:"img","aria-label":"home",children:"🏠"}),a.jsx("span",{children:"Ana Sayfa"})]}),xe?a.jsxs("div",{className:"menu-item",onClick:()=>f(!0),children:[a.jsx("span",{role:"img","aria-label":"exercise",children:"🧘"}),a.jsx("span",{children:"Egzersiz Programım"}),a.jsx("span",{children:"✅"})]}):a.jsxs("div",{className:"menu-item locked",onClick:()=>Rt(!1),children:[a.jsx("span",{role:"img","aria-label":"exercise",children:"🧘"}),a.jsx("span",{children:"Egzersiz Programım"}),a.jsx("span",{children:"🔒"})]}),xe?a.jsxs("div",{className:"menu-item",onClick:()=>ce(!0),children:[a.jsx("span",{role:"img","aria-label":"calendar",children:"📅"}),a.jsx("span",{children:"Takvim / İlerleme"}),a.jsx("span",{children:"✅"})]}):a.jsxs("div",{className:"menu-item locked",onClick:()=>Rt(!1),children:[a.jsx("span",{role:"img","aria-label":"calendar",children:"📅"}),a.jsx("span",{children:"Takvim / İlerleme"}),a.jsx("span",{children:"🔒"})]}),a.jsx("div",{className:"menu-divider"}),a.jsx("div",{className:"menu-section-title",children:"DESTEK & İLETİŞİM"}),re==="premium"?a.jsxs("div",{className:"menu-item",onClick:()=>{const p="905551234567",V=encodeURIComponent("Merhaba, EgzersizLab fizyoterapist desteği için yazıyorum.");window.open(`https://wa.me/${p}?text=${V}`,"_blank")},children:[a.jsx("span",{role:"img","aria-label":"chat",children:"💬"}),a.jsx("span",{children:"Fizyoterapiste Sor"}),a.jsx("span",{children:"✅"})]}):a.jsxs("div",{className:"menu-item locked premium-feature",onClick:()=>Rt(!0),children:[a.jsx("span",{role:"img","aria-label":"chat",children:"💬"}),a.jsx("span",{children:"Fizyoterapiste Sor"}),a.jsx("span",{children:"🔒"})]}),a.jsxs("div",{className:"menu-item",onClick:()=>G(!0),children:[a.jsx("span",{role:"img","aria-label":"ticket",children:"🎟️"}),a.jsx("span",{children:"Destek Talebi"})]}),a.jsxs("div",{className:"menu-item",onClick:()=>fe(!0),children:[a.jsx("span",{role:"img","aria-label":"help",children:"❓"}),a.jsx("span",{children:"Yardım / SSS"})]}),a.jsx("div",{className:"menu-divider"}),a.jsx("div",{className:"menu-section-title",children:"HESAP & AYARLAR"}),a.jsxs("div",{className:"menu-item",onClick:()=>Re(!0),children:[a.jsx("span",{role:"img","aria-label":"package",children:"📦"}),a.jsx("span",{children:"Paketlerim & Ödemeler"})]}),a.jsxs("div",{className:"menu-item",onClick:()=>X(!0),children:[a.jsx("span",{role:"img","aria-label":"settings",children:"⚙️"}),a.jsx("span",{children:"Ayarlar"})]}),a.jsxs("div",{className:"menu-item",onClick:mt,children:[a.jsx("span",{role:"img","aria-label":"logout",children:"🚪"}),a.jsx("span",{children:"Çıkış Yap"})]})]})]}),a.jsxs("div",{className:"main-content",children:[a.jsxs("div",{className:"top-bar",children:[a.jsxs("div",{className:"welcome-section",children:[a.jsxs("div",{className:"welcome-text",children:[a.jsxs("h1",{id:"welcome-title",children:["Merhaba, ",r.user_name," 👋"]}),a.jsx("p",{id:"welcome-subtitle",children:r.welcome_subtitle})]}),xe&&a.jsxs("div",{className:"welcome-badges",onClick:()=>O(!0),style:{cursor:"pointer"},children:[a.jsx("div",{className:"welcome-badges-title",children:"🏆 Başarılarım"}),a.jsxs("div",{className:"welcome-badges-list",children:[st.filter(p=>p.earned).slice(0,3).map(p=>a.jsx("div",{className:"welcome-badge-item",title:p.name,children:a.jsx("span",{className:"welcome-badge-icon",children:p.icon})},p.id)),st.filter(p=>p.earned).length>3&&a.jsxs("div",{className:"welcome-badge-more",title:`+${st.filter(p=>p.earned).length-3} daha fazla`,children:["+",st.filter(p=>p.earned).length-3]}),st.filter(p=>p.earned).length===0&&a.jsx("div",{style:{fontSize:"12px",color:"#92400e",fontStyle:"italic"},children:"İlk başarınızı kazanın!"})]})]})]}),a.jsxs("div",{style:{position:"fixed",top:"80px",right:"20px",zIndex:1e3,display:"flex",flexDirection:"column",gap:"8px"},children:[a.jsx("div",{style:{background:re==="none"?"#ef4444":"#e5e7eb",color:re==="none"?"#fff":"#6b7280",padding:"6px 12px",borderRadius:"8px",fontSize:"11px",fontWeight:700,cursor:"pointer",boxShadow:"0 2px 8px rgba(0,0,0,0.2)",transition:"all 0.2s",textAlign:"center",minWidth:"120px"},onClick:()=>_e("none"),title:"Paket yok görünümü",children:"❌ Paket Yok"}),a.jsx("div",{style:{background:re==="basic"?"#3b82f6":"#e5e7eb",color:re==="basic"?"#fff":"#6b7280",padding:"6px 12px",borderRadius:"8px",fontSize:"11px",fontWeight:700,cursor:"pointer",boxShadow:"0 2px 8px rgba(0,0,0,0.2)",transition:"all 0.2s",textAlign:"center",minWidth:"120px"},onClick:()=>_e("basic"),title:"Temel paket görünümü",children:"📦 Temel Paket"}),a.jsx("div",{style:{background:re==="pro"?"#10b981":"#e5e7eb",color:re==="pro"?"#fff":"#6b7280",padding:"6px 12px",borderRadius:"8px",fontSize:"11px",fontWeight:700,cursor:"pointer",boxShadow:"0 2px 8px rgba(0,0,0,0.2)",transition:"all 0.2s",textAlign:"center",minWidth:"120px"},onClick:()=>_e("pro"),title:"Klinik takip paketi görünümü",children:"⭐ Klinik Paket"}),a.jsx("div",{style:{background:re==="premium"?"#f59e0b":"#e5e7eb",color:re==="premium"?"#fff":"#6b7280",padding:"6px 12px",borderRadius:"8px",fontSize:"11px",fontWeight:700,cursor:"pointer",boxShadow:"0 2px 8px rgba(0,0,0,0.2)",transition:"all 0.2s",textAlign:"center",minWidth:"120px"},onClick:()=>_e("premium"),title:"Premium paket görünümü",children:"👑 Premium Paket"}),a.jsxs("div",{style:{marginTop:"16px",borderTop:"1px solid rgba(255,255,255,0.3)",paddingTop:"12px"},children:[a.jsx("div",{style:{background:"linear-gradient(135deg, #8b5cf6, #6366f1)",color:"#fff",padding:"6px 12px",borderRadius:"8px",fontSize:"10px",fontWeight:700,cursor:"pointer",boxShadow:"0 2px 8px rgba(0,0,0,0.2)",textAlign:"center",marginBottom:"8px"},onClick:()=>{const p=document.getElementById("dev-pain-areas");p&&(p.style.display=p.style.display==="none"?"block":"none")},title:"Geliştirici: Ağrı bölgesi seçici",children:"🔧 Bölge Seç"}),a.jsxs("div",{id:"dev-pain-areas",style:{display:"none",background:"#fff",borderRadius:"8px",padding:"8px",boxShadow:"0 4px 12px rgba(0,0,0,0.3)",maxHeight:"300px",overflowY:"auto",fontSize:"10px"},children:[a.jsx("div",{style:{fontWeight:700,marginBottom:"8px",color:"#6366f1"},children:"📍 Hızlı Bölge Seç:"}),a.jsxs("div",{style:{display:"flex",flexDirection:"column",gap:"4px"},children:[a.jsx("button",{style:{padding:"6px 8px",background:te.some(p=>p.includes("calf")||p.includes("ankle"))?"#8b5cf6":"#f3f4f6",color:te.some(p=>p.includes("calf")||p.includes("ankle"))?"#fff":"#374151",border:"none",borderRadius:"6px",cursor:"pointer",fontSize:"10px",fontWeight:600,textAlign:"left"},onClick:()=>{const p=["calf-back-left","calf-back-right","ankle-front-left","ankle-front-right"];W(p),localStorage.setItem("userPainAreas",JSON.stringify(p))},children:"🦵 Baldır + Ayak Bileği"}),a.jsx("button",{style:{padding:"6px 8px",background:te.some(p=>p.includes("knee"))?"#8b5cf6":"#f3f4f6",color:te.some(p=>p.includes("knee"))?"#fff":"#374151",border:"none",borderRadius:"6px",cursor:"pointer",fontSize:"10px",fontWeight:600,textAlign:"left"},onClick:()=>{const p=["knee-front-left","knee-front-right","knee-back-left","knee-back-right"];W(p),localStorage.setItem("userPainAreas",JSON.stringify(p))},children:"🦿 Diz (Sol + Sağ)"}),a.jsx("button",{style:{padding:"6px 8px",background:te.some(p=>p.includes("lower-back"))?"#8b5cf6":"#f3f4f6",color:te.some(p=>p.includes("lower-back"))?"#fff":"#374151",border:"none",borderRadius:"6px",cursor:"pointer",fontSize:"10px",fontWeight:600,textAlign:"left"},onClick:()=>{const p=["lower-back"];W(p),localStorage.setItem("userPainAreas",JSON.stringify(p))},children:"🔙 Bel"}),a.jsx("button",{style:{padding:"6px 8px",background:te.some(p=>p.includes("neck"))?"#8b5cf6":"#f3f4f6",color:te.some(p=>p.includes("neck"))?"#fff":"#374151",border:"none",borderRadius:"6px",cursor:"pointer",fontSize:"10px",fontWeight:600,textAlign:"left"},onClick:()=>{const p=["neck-front","neck-back"];W(p),localStorage.setItem("userPainAreas",JSON.stringify(p))},children:"🦒 Boyun"}),a.jsx("button",{style:{padding:"6px 8px",background:te.some(p=>p.includes("shoulder"))?"#8b5cf6":"#f3f4f6",color:te.some(p=>p.includes("shoulder"))?"#fff":"#374151",border:"none",borderRadius:"6px",cursor:"pointer",fontSize:"10px",fontWeight:600,textAlign:"left"},onClick:()=>{const p=["shoulder-front-left","shoulder-front-right","shoulder-back-left","shoulder-back-right"];W(p),localStorage.setItem("userPainAreas",JSON.stringify(p))},children:"💪 Omuz (Sol + Sağ)"}),a.jsx("button",{style:{padding:"6px 8px",background:te.some(p=>p.includes("hip"))?"#8b5cf6":"#f3f4f6",color:te.some(p=>p.includes("hip"))?"#fff":"#374151",border:"none",borderRadius:"6px",cursor:"pointer",fontSize:"10px",fontWeight:600,textAlign:"left"},onClick:()=>{const p=["hip-front","hip-back"];W(p),localStorage.setItem("userPainAreas",JSON.stringify(p))},children:"🍑 Kalça"}),a.jsx("div",{style:{borderTop:"1px solid #e5e7eb",marginTop:"4px",paddingTop:"4px"},children:a.jsx("button",{style:{padding:"6px 8px",background:"#ef4444",color:"#fff",border:"none",borderRadius:"6px",cursor:"pointer",fontSize:"10px",fontWeight:600,width:"100%"},onClick:()=>{W([]),localStorage.removeItem("userPainAreas")},children:"🗑️ Temizle"})})]}),te.length>0&&a.jsxs("div",{style:{marginTop:"8px",padding:"6px",background:"#f0fdf4",borderRadius:"6px",fontSize:"9px",color:"#166534"},children:[a.jsx("strong",{children:"Aktif:"})," ",te.join(", ")]})]})]})]}),a.jsxs("div",{className:"top-bar-right",children:[a.jsxs("div",{className:"notification-wrapper",children:[a.jsxs("div",{className:"notification-bell",title:"Bildirimler",ref:an,onClick:p=>{p.stopPropagation(),ue(!J)},children:["🔔",gl>0&&a.jsx("span",{className:"notification-badge",children:gl})]}),J&&a.jsxs(a.Fragment,{children:[a.jsx("div",{className:"cart-overlay",onClick:()=>ue(!1)}),a.jsxs("div",{className:"notification-dropdown",ref:si,children:[a.jsxs("div",{className:"notification-header",children:[a.jsx("span",{children:"🔔 Bildirimler"}),gl>0&&a.jsxs("span",{style:{fontSize:"12px",opacity:.9},children:[gl," okunmamış"]})]}),a.jsx("div",{className:"notification-items",children:ke.length===0?a.jsxs("div",{className:"notification-empty",children:[a.jsx("div",{style:{fontSize:"32px",marginBottom:"8px"},children:"🔕"}),a.jsx("div",{children:"Yeni bildiriminiz yok"})]}):ke.map(p=>a.jsxs("div",{className:`notification-item ${p.read?"read":"unread"}`,onClick:()=>vs(p.id),children:[a.jsx("div",{className:"notification-item-title",children:p.title}),a.jsx("div",{className:"notification-item-message",children:p.message}),a.jsxs("div",{className:"notification-item-meta",children:[a.jsx("span",{className:`notification-item-type ${p.type}`,children:p.type==="clinical"?"Klinik":p.type==="admin"?"İdari":"Motivasyon"}),a.jsx("span",{className:"notification-item-date",children:p.date})]})]},p.id))}),ke.length>0&&a.jsx("div",{className:"notification-footer",children:a.jsx("button",{className:"notification-footer-btn",children:"Tümünü Gör"})})]})]})]}),a.jsxs("div",{className:"cart-wrapper",children:[a.jsxs("div",{className:"cart-bell",title:"Sepetim",onClick:()=>K(!D),children:["🛒",me.length>0&&a.jsx("span",{className:"cart-badge",children:me.length})]}),D&&a.jsxs(a.Fragment,{children:[a.jsx("div",{className:"cart-overlay",onClick:()=>K(!1)}),a.jsxs("div",{className:"cart-dropdown",children:[a.jsxs("div",{className:"cart-header",children:["🛒 Sepetim (",me.length,")"]}),me.length===0?a.jsx("div",{className:"cart-empty",children:"Sepetiniz boş"}):a.jsxs(a.Fragment,{children:[a.jsx("div",{className:"cart-items",children:me.map(p=>a.jsxs("div",{className:"cart-item",children:[a.jsxs("div",{className:"cart-item-info",children:[a.jsx("span",{className:"cart-item-name",children:p.name}),a.jsxs("span",{className:"cart-item-price",children:[p.price,"₺"]})]}),a.jsx("button",{className:"cart-item-remove",onClick:()=>le(p.id),children:"✕"})]},p.id))}),a.jsxs("div",{className:"cart-footer",children:[a.jsxs("div",{className:"cart-total",children:[a.jsx("span",{children:"Toplam:"}),a.jsxs("span",{className:"cart-total-price",children:[he().toLocaleString(),"₺"]})]}),a.jsx("button",{className:"cart-checkout-btn",children:"💳 Ödemeye Geç"})]})]})]})]})]}),a.jsx("div",{className:"profile-pic",title:"Profil",onClick:p=>{p.stopPropagation(),ys()},ref:Et,"aria-label":"Profil menüsü",children:(Fa=r.user_name)==null?void 0:Fa.charAt(0).toUpperCase()}),a.jsxs("div",{className:`profile-dropdown ${B?"active":""}`,ref:Na,children:[a.jsxs("div",{className:"profile-card-header",children:[a.jsx("div",{className:"profile-avatar-large",children:(Pa=r.user_name)==null?void 0:Pa.charAt(0).toUpperCase()}),a.jsx("div",{className:"profile-name",children:r.user_name}),a.jsx("span",{className:"premium-badge-inline",children:"⭐ Premium Üye"})]}),a.jsxs("div",{className:"profile-menu-section",children:[a.jsx("div",{className:"profile-section-title",children:"Kişisel Sağlık Verileri"}),a.jsxs("div",{className:"profile-menu-item",children:[a.jsx("span",{className:"profile-menu-icon",children:"📸"}),a.jsxs("div",{className:"profile-menu-text",children:[a.jsx("div",{children:"Vücut Fotoğraflarım"}),a.jsx("div",{className:"subtitle",children:"Postür fotoğraflarını görüntüle"})]})]}),a.jsxs("div",{className:"profile-menu-item",children:[a.jsx("span",{className:"profile-menu-icon",children:"📋"}),a.jsxs("div",{className:"profile-menu-text",children:[a.jsx("div",{children:"Anamnez Bilgilerim"}),a.jsx("div",{className:"subtitle",children:"Ağrı haritası ve sağlık geçmişi"})]})]}),a.jsxs("div",{className:"profile-menu-item",children:[a.jsx("span",{className:"profile-menu-icon",children:"📏"}),a.jsxs("div",{className:"profile-menu-text",children:[a.jsx("div",{children:"Fiziksel Ölçümlerim"}),a.jsx("div",{className:"subtitle",children:"Boy, kilo, BMI ve ölçüler"})]})]})]}),a.jsxs("div",{className:"profile-menu-section",children:[a.jsx("div",{className:"profile-section-title",children:"Hesap Yönetimi"}),a.jsxs("div",{className:"profile-menu-item",children:[a.jsx("span",{className:"profile-menu-icon",children:"🔒"}),a.jsx("div",{className:"profile-menu-text",children:a.jsx("div",{children:"Şifre Değiştir"})})]}),a.jsxs("div",{className:"profile-menu-item danger",onClick:mt,children:[a.jsx("span",{className:"profile-menu-icon",children:"🚪"}),a.jsx("div",{className:"profile-menu-text",children:a.jsx("div",{children:"Güvenli Çıkış"})})]})]})]})]})]}),a.jsxs("div",{className:"content-area",children:[!xe&&a.jsxs("div",{className:"main-cta-card",children:[a.jsx("div",{className:"cta-illustration",children:a.jsxs("svg",{viewBox:"0 0 200 200",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[a.jsx("circle",{cx:"100",cy:"60",r:"30",fill:"#667eea",opacity:"0.2"}),a.jsx("circle",{cx:"100",cy:"60",r:"20",fill:"#667eea"}),a.jsx("rect",{x:"75",y:"90",width:"50",height:"70",rx:"5",fill:"#667eea"}),a.jsx("rect",{x:"70",y:"100",width:"15",height:"40",rx:"7",fill:"#f59e0b"}),a.jsx("rect",{x:"115",y:"100",width:"15",height:"40",rx:"7",fill:"#f59e0b"}),a.jsx("rect",{x:"85",y:"155",width:"12",height:"35",rx:"6",fill:"#667eea"}),a.jsx("rect",{x:"103",y:"155",width:"12",height:"35",rx:"6",fill:"#667eea"}),a.jsx("rect",{x:"130",y:"80",width:"50",height:"70",rx:"4",fill:"white",stroke:"#667eea",strokeWidth:"2"}),a.jsx("line",{x1:"140",y1:"100",x2:"170",y2:"100",stroke:"#667eea",strokeWidth:"2"}),a.jsx("line",{x1:"140",y1:"115",x2:"170",y2:"115",stroke:"#667eea",strokeWidth:"2"}),a.jsx("line",{x1:"140",y1:"130",x2:"165",y2:"130",stroke:"#667eea",strokeWidth:"2"})]})}),a.jsxs("div",{className:"cta-content",children:[a.jsx("h2",{id:"cta-title",children:r.cta_title}),a.jsx("p",{id:"cta-description",children:r.cta_description}),a.jsxs("button",{className:"cta-button",onClick:ht,disabled:_,children:[a.jsx("span",{children:"▶"}),a.jsx("span",{id:"cta-button-text",children:_?"Yönlendiriliyorsunuz...":r.cta_button_text})]}),a.jsx("span",{className:"duration-hint",id:"cta-duration",children:r.cta_duration})]})]}),xe?a.jsxs(a.Fragment,{children:[a.jsxs("div",{className:"clinical-tests-section",children:[a.jsx("div",{className:"clinical-tests-title",children:"🔬 Klinik Testler"}),a.jsxs("div",{className:"clinical-tests-buttons",children:[a.jsxs("button",{className:"clinical-test-btn",onClick:()=>N("muscle-strength"),title:"Manuel kas testi simülasyonu - Hangi kaslarınız uykuda, hangileri aşırı çalışıyor? (Gluteal amnezi, core stabilizasyonu vb.)",children:[a.jsx("span",{className:"test-btn-icon",children:"💪"}),a.jsxs("div",{className:"test-btn-content",children:[a.jsx("span",{className:"test-btn-text",children:"Kas Kuvveti"}),a.jsx("span",{className:"test-btn-desc",children:"Manuel test"})]})]}),a.jsxs("button",{className:"clinical-test-btn",onClick:()=>N("flexibility"),title:"Ağrısının sebebi kas kısalığı mı? Hamstring, pektoral, iliopsoas, piriformis gerginlik testleri.",children:[a.jsx("span",{className:"test-btn-icon",children:"📏"}),a.jsxs("div",{className:"test-btn-content",children:[a.jsx("span",{className:"test-btn-text",children:"Esneklik"}),a.jsx("span",{className:"test-btn-desc",children:"Kas kısalığı"})]})]}),a.jsxs("button",{className:"clinical-test-btn",onClick:()=>N("rom"),title:"Gonyometrik analiz - Eklemler tam açıyla hareket ediyor mu, kısıtlılık derecesi nedir?",children:[a.jsx("span",{className:"test-btn-icon",children:"📐"}),a.jsxs("div",{className:"test-btn-content",children:[a.jsx("span",{className:"test-btn-text",children:"EHA"}),a.jsx("span",{className:"test-btn-desc",children:"Gonyometri"})]})]}),a.jsxs("button",{className:"clinical-test-btn",onClick:()=>N("neurodynamic"),title:"Sinir germe testleri - Ağrı kas kaynaklı mı yoksa sinir sıkışması mı (Fıtık/Siyatik)?",children:[a.jsx("span",{className:"test-btn-icon",children:"🧠"}),a.jsxs("div",{className:"test-btn-content",children:[a.jsx("span",{className:"test-btn-text",children:"Nörodinamik"}),a.jsx("span",{className:"test-btn-desc",children:"Sinir testi"})]})]}),a.jsxs("button",{className:"clinical-test-btn",onClick:()=>N("balance"),title:"Vücudun uzaydaki konum algısı ve denge stratejisi",children:[a.jsx("span",{className:"test-btn-icon",children:"⚖️"}),a.jsxs("div",{className:"test-btn-content",children:[a.jsx("span",{className:"test-btn-text",children:"Denge"}),a.jsx("span",{className:"test-btn-desc",children:"Fonksiyonel"})]})]}),a.jsxs("button",{className:"clinical-test-btn",onClick:()=>N("movement"),title:"Çömelme, eğilme ve uzanma sırasında omurga biyomekaniği kontrolü",children:[a.jsx("span",{className:"test-btn-icon",children:"🩺"}),a.jsxs("div",{className:"test-btn-content",children:[a.jsx("span",{className:"test-btn-text",children:"Hareket Analizi"}),a.jsx("span",{className:"test-btn-desc",children:"Biyomekanik"})]})]})]})]}),a.jsxs("div",{className:"stats-grid",children:[a.jsxs("div",{className:"stat-card",children:[a.jsx("div",{className:"stat-icon",style:{background:"linear-gradient(135deg, #667eea, #764ba2)"},children:"📊"}),a.jsxs("div",{className:"stat-content",children:[a.jsxs("div",{className:"stat-value",children:[ft.todayCompleted,"/",ft.todayExercises]}),a.jsx("div",{className:"stat-label",children:"Bugünkü Egzersizler"})]})]}),a.jsxs("div",{className:"stat-card",children:[a.jsx("div",{className:"stat-icon",style:{background:"linear-gradient(135deg, #10b981, #059669)"},children:"📈"}),a.jsxs("div",{className:"stat-content",children:[a.jsxs("div",{className:"stat-value",children:[ft.weeklyCompleted,"/",ft.weeklyTotal]}),a.jsx("div",{className:"stat-label",children:"Bu Hafta Tamamlanan"})]})]}),a.jsxs("div",{className:"stat-card",children:[a.jsx("div",{className:"stat-icon",style:{background:"linear-gradient(135deg, #f59e0b, #d97706)"},children:"🎯"}),a.jsxs("div",{className:"stat-content",children:[a.jsxs("div",{className:"stat-value",children:[ft.progressPercentage,"%"]}),a.jsx("div",{className:"stat-label",children:"Genel İlerleme"})]})]}),a.jsxs("div",{className:"stat-card",children:[a.jsx("div",{className:"stat-icon",style:{background:"linear-gradient(135deg, #ef4444, #dc2626)"},children:"🔥"}),a.jsxs("div",{className:"stat-content",children:[a.jsxs("div",{className:"stat-value",children:[ft.streak," gün"]}),a.jsx("div",{className:"stat-label",children:"Streak"})]})]})]}),a.jsxs("div",{className:"quick-actions",children:[a.jsxs("button",{className:"quick-action-btn primary",onClick:()=>f(!0),children:[a.jsx("span",{className:"quick-action-icon",children:"🏃‍♂️"}),a.jsxs("div",{className:"quick-action-text",children:[a.jsx("div",{className:"quick-action-title",children:"Egzersiz Yap"}),a.jsx("div",{className:"quick-action-subtitle",children:"Bugünkü programını başlat"})]})]}),a.jsxs("button",{className:"quick-action-btn",onClick:()=>ce(!0),children:[a.jsx("span",{className:"quick-action-icon",children:"📊"}),a.jsxs("div",{className:"quick-action-text",children:[a.jsx("div",{className:"quick-action-title",children:"İlerlememi Gör"}),a.jsx("div",{className:"quick-action-subtitle",children:"Detaylı analiz"})]})]})]}),a.jsxs("div",{className:"dashboard-grid",children:[a.jsxs("div",{className:"dashboard-left",children:[a.jsxs("div",{className:"task-card",children:[a.jsxs("div",{className:"card-header",children:[a.jsx("h3",{className:"card-title",children:"📅 Bugünkü Görevler"}),a.jsxs("span",{className:"card-badge",children:[bt.filter(p=>p.completed).length,"/",bt.length]})]}),a.jsx("div",{className:"task-list",children:bt.map(p=>a.jsxs("div",{className:`task-item ${p.completed?"completed":""}`,children:[a.jsx("div",{className:"task-checkbox",onClick:()=>ka(p.id),children:p.completed?"✅":"⭕"}),a.jsxs("div",{className:"task-info",children:[a.jsx("div",{className:"task-name",children:p.name}),a.jsxs("div",{className:"task-meta",children:[a.jsxs("span",{className:"task-duration",children:["⏱️ ",p.duration]}),a.jsxs("span",{className:"task-time",children:["🕐 ",p.time]})]})]})]},p.id))}),a.jsx("button",{className:"task-view-all",onClick:()=>f(!0),children:"Tüm Programı Gör →"})]}),a.jsxs("div",{className:"progress-chart-card",children:[a.jsx("div",{className:"card-header",children:a.jsx("h3",{className:"card-title",children:"📈 Haftalık İlerleme"})}),a.jsx("div",{className:"chart-container",children:a.jsx("div",{className:"chart-bars",children:Xt.map((p,V)=>a.jsxs("div",{className:"chart-bar-wrapper",children:[a.jsx("div",{className:"chart-bar",style:{height:`${p.value}%`},children:a.jsxs("span",{className:"chart-value",children:[p.value,"%"]})}),a.jsx("div",{className:"chart-label",children:p.day})]},V))})}),a.jsxs("div",{className:"chart-footer",children:[a.jsxs("div",{className:"chart-stat",children:[a.jsx("span",{className:"chart-stat-label",children:"Ortalama:"}),a.jsxs("span",{className:"chart-stat-value",children:[Math.round(Xt.reduce((p,V)=>p+V.value,0)/Xt.length),"%"]})]}),a.jsxs("div",{className:"chart-stat",children:[a.jsx("span",{className:"chart-stat-label",children:"En Yüksek:"}),a.jsxs("span",{className:"chart-stat-value",children:[Math.max(...Xt.map(p=>p.value)),"%"]})]})]})]})]}),a.jsxs("div",{className:"dashboard-right",children:[a.jsxs("div",{className:"package-status-card",children:[a.jsxs("div",{className:"card-header",children:[a.jsx("h3",{className:"card-title",children:"📦 Aktif Paket"}),a.jsx("span",{className:"package-badge active",style:{background:re==="premium"?"#fef3c7":re==="pro"?"#dcfce7":"#dbeafe",color:re==="premium"?"#92400e":re==="pro"?"#15803d":"#1e40af"},children:re==="premium"?"👑 Premium":re==="pro"?"⭐ Klinik":re==="basic"?"📦 Temel":"Aktif"})]}),a.jsxs("div",{className:"package-info",children:[a.jsx("div",{className:"package-name",children:yt.name}),a.jsx("div",{className:"package-dates",children:a.jsxs("span",{children:["📅 ",yt.startDate," ",yt.endDate!=="Tek Seferlik"?`- ${yt.endDate}`:""]})}),yt.daysRemaining!==null&&a.jsxs("div",{className:"package-countdown",children:[a.jsx("span",{className:"countdown-icon",children:"⏳"}),a.jsxs("span",{className:"countdown-text",children:[yt.daysRemaining," gün kaldı"]})]}),a.jsxs("div",{style:{marginBottom:"12px",fontSize:"14px",fontWeight:700,color:"#10b981"},children:["💰 ",yt.price]}),a.jsx("div",{className:"package-features",children:yt.features.map((p,V)=>a.jsxs("div",{className:"package-feature",children:[a.jsx("span",{children:"✓"})," ",p]},V))})]}),a.jsx("button",{className:"package-manage-btn",onClick:()=>Re(!0),children:"Paketi Yönet →"})]}),a.jsxs("div",{className:"activities-card",children:[a.jsx("div",{className:"card-header",children:a.jsx("h3",{className:"card-title",children:"🕐 Son Aktiviteler"})}),a.jsx("div",{className:"activities-list",children:ja.map(p=>a.jsxs("div",{className:"activity-item",children:[a.jsx("div",{className:"activity-icon",children:p.icon}),a.jsxs("div",{className:"activity-content",children:[a.jsx("div",{className:"activity-text",children:p.text}),a.jsx("div",{className:"activity-time",children:p.time})]})]},p.id))}),a.jsx("button",{className:"activities-view-all",children:"Tüm Aktiviteleri Gör →"})]})]})]})]}):null,a.jsxs("div",{className:"info-cards",children:[a.jsxs("div",{className:"info-card video-card",onClick:()=>ne(!0),children:[a.jsx("div",{className:"info-card-icon",children:"🎬"}),a.jsx("h3",{id:"video-title",children:r.video_title}),a.jsx("p",{children:'1 dakikalık "Sistem Nasıl İşliyor?" videosunu izleyerek süreci daha iyi anlayabilirsiniz.'})]}),a.jsxs("div",{className:"info-card tip-card tip-carousel",children:[a.jsx("div",{className:"info-card-icon",children:De[se].icon}),a.jsx("h3",{className:"tip-title-animated",children:De[se].title}),a.jsx("p",{className:"tip-text-animated",children:De[se].text}),a.jsx("div",{className:"tip-dots",children:De.map((p,V)=>a.jsx("span",{className:`tip-dot ${V===se?"active":""}`,onClick:()=>Se(V)},V))})]})]})]})]}),k&&a.jsx("div",{style:{position:"fixed",top:20,right:20,background:"#fef3c7",color:"#92400e",padding:"16px 20px",borderRadius:8,boxShadow:"0 4px 12px rgba(0,0,0,0.15)",zIndex:1e3,fontSize:14,maxWidth:320,lineHeight:1.5},children:k}),a.jsx(rg,{open:b,clinicalTestType:L,onClose:()=>{h(!1),N(null)},onComplete:()=>{H(!0)}}),a.jsx(dg,{open:Y,onClose:()=>H(!1),onAddToCart:F,cartItems:me}),a.jsx(fg,{open:Z,onClose:()=>G(!1)}),a.jsx(xg,{open:q,onClose:()=>fe(!1),onOpenSupport:()=>G(!0)}),a.jsx(pg,{open:ee,onClose:()=>Re(!1),onPurchase:p=>{p==="basic"?_e("basic"):p==="pro"?_e("pro"):p==="premium"&&_e("premium"),Re(!1)},onCancelPackage:()=>_e("none"),hasPackage:xe,onAddToCart:F,cartItems:me}),a.jsx(hg,{open:oe,onClose:()=>X(!1)}),a.jsx(gg,{open:I,onClose:()=>ne(!1)}),a.jsx(bg,{open:T,onClose:()=>f(!1)}),a.jsx(kg,{open:Q,onClose:()=>ce(!1)}),L&&a.jsx(Ng,{isOpen:!!L,onClose:()=>N(null),testType:L,userPainAreas:te}),pe&&a.jsxs(a.Fragment,{children:[a.jsx("div",{style:{position:"fixed",inset:0,background:"rgba(0, 0, 0, 0.5)",zIndex:2e3},onClick:()=>O(!1)}),a.jsxs("div",{style:{position:"fixed",top:"50%",left:"50%",transform:"translate(-50%, -50%)",background:"#fff",borderRadius:"20px",padding:"32px",maxWidth:"900px",width:"90%",maxHeight:"85vh",overflowY:"auto",zIndex:2001,boxShadow:"0 20px 60px rgba(0,0,0,0.3)"},children:[a.jsxs("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"24px"},children:[a.jsx("h2",{style:{fontSize:"24px",fontWeight:700,color:"#1f2937",margin:0},children:"🏆 Başarılarım"}),a.jsx("button",{onClick:()=>O(!1),style:{background:"none",border:"none",fontSize:"24px",cursor:"pointer",color:"#6b7280",padding:"4px 8px"},children:"✕"})]}),a.jsx("div",{style:{display:"grid",gridTemplateColumns:"repeat(auto-fit, minmax(160px, 1fr))",gap:"16px"},children:st.map(p=>a.jsxs("div",{style:{background:p.earned?"linear-gradient(135deg, #fef3c7, #fde68a)":"#f9fafb",border:`2px solid ${p.earned?"#f59e0b":"#e5e7eb"}`,borderRadius:"16px",padding:"20px",textAlign:"center",position:"relative",opacity:p.earned?1:.7,transition:"all 0.2s",cursor:p.earned?"default":"pointer"},onMouseEnter:V=>{p.earned||(V.currentTarget.style.transform="scale(1.05)",V.currentTarget.style.boxShadow="0 4px 12px rgba(0,0,0,0.1)")},onMouseLeave:V=>{p.earned||(V.currentTarget.style.transform="scale(1)",V.currentTarget.style.boxShadow="none")},children:[a.jsx("div",{style:{fontSize:"48px",marginBottom:"12px"},children:p.icon}),a.jsx("div",{style:{fontSize:"15px",fontWeight:700,color:p.earned?"#92400e":"#6b7280",marginBottom:"6px"},children:p.name}),p.description&&a.jsx("div",{style:{fontSize:"11px",color:p.earned?"#b45309":"#9ca3af",marginBottom:"8px",lineHeight:"1.4",minHeight:"30px"},children:p.description}),!p.earned&&a.jsx("div",{style:{position:"absolute",top:"8px",right:"8px",fontSize:"20px",opacity:.5},children:"🔒"}),p.earned&&a.jsx("div",{style:{fontSize:"12px",color:"#92400e",fontWeight:700,marginTop:"8px",background:"rgba(251, 191, 36, 0.2)",padding:"4px 8px",borderRadius:"8px",display:"inline-block"},children:"✓ Kazanıldı"})]},p.id))}),a.jsxs("div",{style:{marginTop:"24px",padding:"20px",background:"linear-gradient(135deg, #fef3c7, #fde68a)",borderRadius:"16px",textAlign:"center",border:"2px solid #fbbf24"},children:[a.jsxs("div",{style:{fontSize:"18px",color:"#92400e",fontWeight:700,marginBottom:"6px"},children:[st.filter(p=>p.earned).length," / ",st.length," başarı kazandınız! 🎉"]}),a.jsx("div",{style:{fontSize:"13px",color:"#b45309",marginTop:"4px"},children:"Devam edin, daha fazla başarı sizi bekliyor! Her rozet seni hedefine bir adım daha yaklaştırıyor! 💪"}),a.jsx("div",{style:{marginTop:"12px",width:"100%",height:"8px",background:"#e5e7eb",borderRadius:"999px",overflow:"hidden"},children:a.jsx("div",{style:{width:`${st.filter(p=>p.earned).length/st.length*100}%`,height:"100%",background:"linear-gradient(90deg, #f59e0b, #d97706)",borderRadius:"999px",transition:"width 0.3s ease"}})})]})]})]})]})},wg=typeof window<"u"&&window.location.hostname!=="localhost",tn=wg?"https://egzersizlab-clean-production.up.railway.app/api":"http://localhost:5000/api",Sg=()=>{var re,Ve,xe,_e,T;const[r,v]=g.useState(!1),[_,d]=g.useState(""),[k,E]=g.useState(""),[S,U]=g.useState(""),[b,h]=g.useState(!1),[L,N]=g.useState([]),[Y,H]=g.useState(null),[B,ae]=g.useState(null),[Z,G]=g.useState("list"),[q,fe]=g.useState("");g.useEffect(()=>{const f=localStorage.getItem("adminToken");f&&(E(f),v(!0))},[]),g.useEffect(()=>{r&&k&&(oe(),X())},[r,k]);const ee=async f=>{f.preventDefault(),h(!0),U("");try{const ce=await(await fetch(`${tn}/admin/login`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({password:_})})).json();ce.success?(E(ce.token),localStorage.setItem("adminToken",ce.token),v(!0)):U(ce.error||"Giriş başarısız")}catch{U("Bağlantı hatası")}finally{h(!1)}},Re=()=>{localStorage.removeItem("adminToken"),E(""),v(!1),N([]),H(null)},oe=async()=>{try{const Q=await(await fetch(`${tn}/admin/stats`,{headers:{"X-Admin-Token":k}})).json();Q.success&&H(Q.data)}catch(f){console.error("Stats yüklenemedi:",f)}},X=async()=>{h(!0);try{const Q=await(await fetch(`${tn}/admin/users`,{headers:{"X-Admin-Token":k}})).json();Q.success&&N(Q.data)}catch(f){console.error("Kullanıcılar yüklenemedi:",f)}finally{h(!1)}},I=async f=>{h(!0);try{const ce=await(await fetch(`${tn}/admin/users/${f}`,{headers:{"X-Admin-Token":k}})).json();ce.success&&(ae(ce.data),G("detail"))}catch(Q){console.error("Kullanıcı detayı yüklenemedi:",Q)}finally{h(!1)}},ne=async f=>{if(confirm("Bu kullanıcıyı silmek istediğinize emin misiniz?"))try{(await(await fetch(`${tn}/admin/users/${f}`,{method:"DELETE",headers:{"X-Admin-Token":k}})).json()).success&&(X(),(B==null?void 0:B._id)===f&&(ae(null),G("list")))}catch(Q){console.error("Kullanıcı silinemedi:",Q)}},se=L.filter(f=>f.name.toLowerCase().includes(q.toLowerCase())||f.email.toLowerCase().includes(q.toLowerCase())),Se=f=>new Date(f).toLocaleString("tr-TR");return r?a.jsxs("div",{className:"min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900",children:[a.jsx("header",{className:"bg-gray-800/50 backdrop-blur-xl border-b border-purple-500/30",children:a.jsxs("div",{className:"max-w-7xl mx-auto px-4 py-4 flex items-center justify-between",children:[a.jsxs("div",{className:"flex items-center gap-4",children:[a.jsx("div",{className:"w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center",children:a.jsx("svg",{className:"w-6 h-6 text-white",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:a.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"})})}),a.jsxs("div",{children:[a.jsx("h1",{className:"text-xl font-bold text-white",children:"EgzersizLab Admin"}),a.jsx("p",{className:"text-sm text-gray-400",children:"Yönetim Paneli"})]})]}),a.jsxs("div",{className:"flex items-center gap-4",children:[a.jsx("button",{onClick:()=>{oe(),X()},className:"text-gray-400 hover:text-white transition-colors",title:"Yenile",children:a.jsx("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:a.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"})})}),a.jsx("button",{onClick:Re,className:"bg-red-500/20 hover:bg-red-500/30 text-red-400 px-4 py-2 rounded-lg transition-colors",children:"Çıkış Yap"})]})]})}),a.jsxs("div",{className:"max-w-7xl mx-auto px-4 py-6",children:[Y&&a.jsxs("div",{className:"grid grid-cols-2 md:grid-cols-5 gap-4 mb-6",children:[a.jsxs("div",{className:"bg-gray-800/50 backdrop-blur-xl rounded-xl p-4 border border-purple-500/30",children:[a.jsx("div",{className:"text-3xl font-bold text-white",children:Y.totalUsers}),a.jsx("div",{className:"text-sm text-gray-400",children:"Toplam Kullanıcı"})]}),a.jsxs("div",{className:"bg-gray-800/50 backdrop-blur-xl rounded-xl p-4 border border-green-500/30",children:[a.jsx("div",{className:"text-3xl font-bold text-green-400",children:Y.activeUsers}),a.jsx("div",{className:"text-sm text-gray-400",children:"Aktif Kullanıcı"})]}),a.jsxs("div",{className:"bg-gray-800/50 backdrop-blur-xl rounded-xl p-4 border border-blue-500/30",children:[a.jsx("div",{className:"text-3xl font-bold text-blue-400",children:Y.usersWithData}),a.jsx("div",{className:"text-sm text-gray-400",children:"Veri Girişi Yapan"})]}),a.jsxs("div",{className:"bg-gray-800/50 backdrop-blur-xl rounded-xl p-4 border border-yellow-500/30",children:[a.jsx("div",{className:"text-3xl font-bold text-yellow-400",children:Y.newUsersLastWeek}),a.jsx("div",{className:"text-sm text-gray-400",children:"Son 7 Gün"})]}),a.jsxs("div",{className:"bg-gray-800/50 backdrop-blur-xl rounded-xl p-4 border border-pink-500/30",children:[a.jsx("div",{className:"text-3xl font-bold text-pink-400",children:Y.newUsersLastMonth}),a.jsx("div",{className:"text-sm text-gray-400",children:"Son 30 Gün"})]})]}),a.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-3 gap-6",children:[a.jsx("div",{className:`${Z==="detail"?"hidden lg:block":""} lg:col-span-1`,children:a.jsxs("div",{className:"bg-gray-800/50 backdrop-blur-xl rounded-xl border border-purple-500/30 overflow-hidden",children:[a.jsxs("div",{className:"p-4 border-b border-gray-700",children:[a.jsxs("h2",{className:"text-lg font-semibold text-white mb-3",children:["Kullanıcılar (",L.length,")"]}),a.jsx("input",{type:"text",placeholder:"Ara...",value:q,onChange:f=>fe(f.target.value),className:"w-full bg-gray-700/50 border border-gray-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-purple-500"})]}),a.jsx("div",{className:"max-h-[600px] overflow-y-auto",children:b?a.jsx("div",{className:"p-4 text-center text-gray-400",children:"Yükleniyor..."}):se.length===0?a.jsx("div",{className:"p-4 text-center text-gray-400",children:"Kullanıcı bulunamadı"}):se.map(f=>{var Q;return a.jsxs("div",{onClick:()=>I(f._id),className:`p-4 border-b border-gray-700/50 cursor-pointer hover:bg-gray-700/30 transition-colors ${(B==null?void 0:B._id)===f._id?"bg-purple-500/20":""}`,children:[a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx("div",{className:"w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white font-semibold",children:f.name.charAt(0).toUpperCase()}),a.jsxs("div",{className:"flex-1 min-w-0",children:[a.jsx("div",{className:"text-white font-medium truncate",children:f.name}),a.jsx("div",{className:"text-gray-400 text-sm truncate",children:f.email})]}),((Q=f.dashboardData)==null?void 0:Q.photos)&&a.jsx("div",{className:"w-2 h-2 bg-green-500 rounded-full",title:"Fotoğraf var"})]}),a.jsxs("div",{className:"mt-2 text-xs text-gray-500",children:["Kayıt: ",Se(f.createdAt)]})]},f._id)})})]})}),a.jsx("div",{className:`${Z==="list"&&!B?"hidden lg:block":""} lg:col-span-2`,children:B?a.jsxs("div",{className:"bg-gray-800/50 backdrop-blur-xl rounded-xl border border-purple-500/30 overflow-hidden",children:[a.jsxs("div",{className:"p-4 border-b border-gray-700 flex items-center justify-between",children:[a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx("button",{onClick:()=>{G("list"),ae(null)},className:"lg:hidden text-gray-400 hover:text-white",children:a.jsx("svg",{className:"w-6 h-6",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:a.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M15 19l-7-7 7-7"})})}),a.jsx("div",{className:"w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white text-xl font-semibold",children:B.name.charAt(0).toUpperCase()}),a.jsxs("div",{children:[a.jsx("h2",{className:"text-xl font-semibold text-white",children:B.name}),a.jsx("p",{className:"text-gray-400",children:B.email})]})]}),a.jsx("button",{onClick:()=>ne(B._id),className:"bg-red-500/20 hover:bg-red-500/30 text-red-400 px-3 py-2 rounded-lg transition-colors text-sm",children:"Sil"})]}),a.jsxs("div",{className:"p-4 max-h-[600px] overflow-y-auto",children:[a.jsxs("div",{className:"grid grid-cols-2 gap-4 mb-6",children:[a.jsxs("div",{className:"bg-gray-700/30 rounded-lg p-3",children:[a.jsx("div",{className:"text-gray-400 text-sm",children:"Telefon"}),a.jsx("div",{className:"text-white",children:B.phone||"Belirtilmemiş"})]}),a.jsxs("div",{className:"bg-gray-700/30 rounded-lg p-3",children:[a.jsx("div",{className:"text-gray-400 text-sm",children:"Durum"}),a.jsx("div",{className:B.isActive?"text-green-400":"text-red-400",children:B.isActive?"Aktif":"Pasif"})]}),a.jsxs("div",{className:"bg-gray-700/30 rounded-lg p-3",children:[a.jsx("div",{className:"text-gray-400 text-sm",children:"Kayıt Tarihi"}),a.jsx("div",{className:"text-white",children:Se(B.createdAt)})]}),a.jsxs("div",{className:"bg-gray-700/30 rounded-lg p-3",children:[a.jsx("div",{className:"text-gray-400 text-sm",children:"Son Güncelleme"}),a.jsx("div",{className:"text-white",children:Se(B.updatedAt)})]})]}),((re=B.dashboardData)==null?void 0:re.photos)&&a.jsxs("div",{className:"mb-6",children:[a.jsx("h3",{className:"text-lg font-semibold text-white mb-3",children:"📸 Fotoğraflar"}),a.jsxs("div",{className:"grid grid-cols-3 gap-4",children:[B.dashboardData.photos.front&&a.jsxs("div",{children:[a.jsx("div",{className:"text-sm text-gray-400 mb-2",children:"Önden"}),a.jsx("img",{src:B.dashboardData.photos.front,alt:"Önden",className:"w-full h-40 object-cover rounded-lg border border-gray-600"})]}),B.dashboardData.photos.side&&a.jsxs("div",{children:[a.jsx("div",{className:"text-sm text-gray-400 mb-2",children:"Yandan"}),a.jsx("img",{src:B.dashboardData.photos.side,alt:"Yandan",className:"w-full h-40 object-cover rounded-lg border border-gray-600"})]}),B.dashboardData.photos.back&&a.jsxs("div",{children:[a.jsx("div",{className:"text-sm text-gray-400 mb-2",children:"Arkadan"}),a.jsx("img",{src:B.dashboardData.photos.back,alt:"Arkadan",className:"w-full h-40 object-cover rounded-lg border border-gray-600"})]})]})]}),((Ve=B.dashboardData)==null?void 0:Ve.assessmentResults)&&a.jsxs("div",{className:"mb-6",children:[a.jsx("h3",{className:"text-lg font-semibold text-white mb-3",children:"📊 Değerlendirme Sonuçları"}),a.jsx("div",{className:"bg-gray-700/30 rounded-lg p-4",children:a.jsx("pre",{className:"text-sm text-gray-300 overflow-x-auto whitespace-pre-wrap",children:JSON.stringify(B.dashboardData.assessmentResults,null,2)})})]}),((xe=B.dashboardData)==null?void 0:xe.formData)&&a.jsxs("div",{className:"mb-6",children:[a.jsx("h3",{className:"text-lg font-semibold text-white mb-3",children:"📝 Form Verileri"}),a.jsx("div",{className:"bg-gray-700/30 rounded-lg p-4",children:a.jsx("pre",{className:"text-sm text-gray-300 overflow-x-auto whitespace-pre-wrap",children:JSON.stringify(B.dashboardData.formData,null,2)})})]}),((_e=B.dashboardData)==null?void 0:_e.exercisePrograms)&&B.dashboardData.exercisePrograms.length>0&&a.jsxs("div",{className:"mb-6",children:[a.jsx("h3",{className:"text-lg font-semibold text-white mb-3",children:"🏋️ Egzersiz Programları"}),a.jsx("div",{className:"bg-gray-700/30 rounded-lg p-4",children:a.jsx("pre",{className:"text-sm text-gray-300 overflow-x-auto whitespace-pre-wrap",children:JSON.stringify(B.dashboardData.exercisePrograms,null,2)})})]}),((T=B.dashboardData)==null?void 0:T.progressData)&&a.jsxs("div",{className:"mb-6",children:[a.jsx("h3",{className:"text-lg font-semibold text-white mb-3",children:"📈 İlerleme Verileri"}),a.jsx("div",{className:"bg-gray-700/30 rounded-lg p-4",children:a.jsx("pre",{className:"text-sm text-gray-300 overflow-x-auto whitespace-pre-wrap",children:JSON.stringify(B.dashboardData.progressData,null,2)})})]}),a.jsxs("div",{children:[a.jsx("h3",{className:"text-lg font-semibold text-white mb-3",children:"🗂️ Tüm Dashboard Verileri (Ham)"}),a.jsx("div",{className:"bg-gray-700/30 rounded-lg p-4",children:a.jsx("pre",{className:"text-sm text-gray-300 overflow-x-auto whitespace-pre-wrap max-h-96",children:JSON.stringify(B.dashboardData,null,2)||"Veri yok"})})]})]})]}):a.jsxs("div",{className:"bg-gray-800/50 backdrop-blur-xl rounded-xl border border-purple-500/30 p-8 flex flex-col items-center justify-center h-full min-h-[400px]",children:[a.jsx("svg",{className:"w-16 h-16 text-gray-600 mb-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:a.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"})}),a.jsx("p",{className:"text-gray-400",children:"Detayları görmek için bir kullanıcı seçin"})]})})]})]})]}):a.jsx("div",{className:"min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 flex items-center justify-center p-4",children:a.jsxs("div",{className:"bg-gray-800/50 backdrop-blur-xl rounded-2xl p-8 w-full max-w-md border border-purple-500/30",children:[a.jsxs("div",{className:"text-center mb-8",children:[a.jsx("div",{className:"w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl mx-auto mb-4 flex items-center justify-center",children:a.jsx("svg",{className:"w-8 h-8 text-white",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:a.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"})})}),a.jsx("h1",{className:"text-2xl font-bold text-white",children:"Admin Paneli"}),a.jsx("p",{className:"text-gray-400 mt-2",children:"EgzersizLab Yönetim"})]}),a.jsxs("form",{onSubmit:ee,className:"space-y-4",children:[a.jsxs("div",{children:[a.jsx("label",{className:"block text-sm text-gray-400 mb-2",children:"Admin Şifresi"}),a.jsx("input",{type:"password",value:_,onChange:f=>d(f.target.value),className:"w-full bg-gray-700/50 border border-gray-600 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-purple-500",placeholder:"••••••••",required:!0})]}),S&&a.jsx("div",{className:"bg-red-500/20 border border-red-500/50 rounded-lg p-3 text-red-300 text-sm",children:S}),a.jsx("button",{type:"submit",disabled:b,className:"w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold py-3 rounded-lg transition-all disabled:opacity-50",children:b?"Giriş yapılıyor...":"Giriş Yap"})]}),a.jsx("div",{className:"mt-6 text-center",children:a.jsx("a",{href:"/",className:"text-gray-400 hover:text-white text-sm",children:"← Ana Sayfaya Dön"})})]})})},bx=document.getElementById("root");if(!bx)throw new Error("Could not find root element to mount to");const Eg=()=>{const[r,v]=g.useState(()=>{const d=window.location.hash,k=window.location.pathname;return d==="#admin"||k.includes("admin")?"admin":d==="#dashboard"||k.includes("dashboard")?"dashboard":"home"});g.useEffect(()=>{const d=()=>{const k=window.location.hash,E=window.location.pathname;k==="#admin"||E.includes("admin")?v("admin"):k==="#dashboard"||E.includes("dashboard")?v("dashboard"):v("home")};return window.addEventListener("hashchange",d),d(),()=>window.removeEventListener("hashchange",d)},[]);const _=()=>{switch(r){case"admin":return a.jsx(Sg,{});case"dashboard":return a.jsx(zg,{});default:return a.jsx(Fh,{})}};return a.jsx(Xo.StrictMode,{children:_()})},Tg=Gp.createRoot(bx);Tg.render(a.jsx(Eg,{}));
